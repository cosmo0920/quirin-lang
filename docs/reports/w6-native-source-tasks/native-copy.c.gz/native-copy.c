#define QCORE_TASK_ARGUMENT_CAPACITY 1
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <threads.h>
#if defined(__STDC_NO_THREADS__)
#error "The scoped-copy task profile requires C11 threads"
#endif
#ifndef QCORE_TASK_CALLOC
#define QCORE_TASK_CALLOC calloc
#endif
#ifndef QCORE_TASK_FREE
#define QCORE_TASK_FREE free
#endif
#ifndef QCORE_TASK_CREATE
#define QCORE_TASK_CREATE thrd_create
#endif
#ifndef QCORE_TASK_JOIN
#define QCORE_TASK_JOIN thrd_join
#endif
struct qcore_task_result { int kind; int32_t value; int error; };
struct qcore_task_context { uint64_t next_task; };
typedef struct qcore_task_result (*qcore_task_worker)(const int32_t *, struct qcore_task_context *);
struct qcore_task_start_record {
    thrd_t thread;
    uint64_t identity;
    qcore_task_worker worker;
    int32_t arguments[QCORE_TASK_ARGUMENT_CAPACITY];
    struct qcore_task_result result;
};
struct qcore_task_slot {
    int32_t scalar;
    struct qcore_task_result result;
    struct qcore_task_start_record *handle;
    int error;
};
static const char *qcore_task_error_name(int);
static void qcore_task_print_result(uint64_t identity, struct qcore_task_result result) {
    if (result.error != 0)
        printf("QCORE_TASK_RESULT %" PRIu64 " ERROR %s\n", identity, qcore_task_error_name(result.error));
    else if (result.kind == 0)
        printf("QCORE_TASK_RESULT %" PRIu64 " UNIT\n", identity);
    else
        printf("QCORE_TASK_RESULT %" PRIu64 " I32 %" PRId32 "\n", identity, result.value);
}
static int qcore_task_trampoline(void *pointer) {
    struct qcore_task_start_record *record = pointer;
    record->result = record->worker(record->arguments, NULL);
    return 0;
}
static struct qcore_task_start_record *qcore_task_start(qcore_task_worker worker,
        const int32_t *arguments, size_t count, struct qcore_task_context *context, size_t worker_id) {
    struct qcore_task_start_record *record = QCORE_TASK_CALLOC(1, sizeof(*record));
    if (record == NULL) {
        printf("QCORE_TASK_CREATE_FAILED %zu\n", worker_id);
        return NULL;
    }
    record->worker = worker;
    record->identity = context->next_task;
    for (size_t i = 0; i < count; ++i) record->arguments[i] = arguments[i];
    if (QCORE_TASK_CREATE(&record->thread, qcore_task_trampoline, record) != thrd_success) {
        QCORE_TASK_FREE(record);
        printf("QCORE_TASK_CREATE_FAILED %zu\n", worker_id);
        return NULL;
    }
    ++context->next_task;
    printf("QCORE_TASK_SPAWN %" PRIu64 " %zu\n", record->identity, worker_id);
    return record;
}
static struct qcore_task_result qcore_task_collect(struct qcore_task_start_record *record) {
    int status;
    if (QCORE_TASK_JOIN(record->thread, &status) != thrd_success) abort();
    if (status != 0) abort();
    struct qcore_task_result result = record->result;
    qcore_task_print_result(record->identity, result);
    printf("QCORE_TASK_JOIN %" PRIu64 "\n", record->identity);
    QCORE_TASK_FREE(record);
    return result;
}
static const char *qcore_task_error_name(int tag) {
    switch (tag) {
    case 1: return "\123\160\141\167\156\105\162\162\157\162";
    default: abort();
    }
}
static struct qcore_task_result qcore_task_fn_0(const int32_t *, struct qcore_task_context *);
static struct qcore_task_result qcore_task_fn_1(const int32_t *, struct qcore_task_context *);
static struct qcore_task_result qcore_task_fn_0(const int32_t *args, struct qcore_task_context *context) {
    (void)args; (void)context;
    struct qcore_task_slot s_2 = {0}; (void)&s_2;
    s_2.scalar = args[0];
    goto qcore_block_0;
qcore_block_0: ;
    return (struct qcore_task_result){1, s_2.scalar, 0};
}
static struct qcore_task_result qcore_task_fn_1(const int32_t *args, struct qcore_task_context *context) {
    (void)args; (void)context;
    struct qcore_task_slot s_3 = {0}; (void)&s_3;
    struct qcore_task_slot s_5 = {0}; (void)&s_5;
    struct qcore_task_slot s_6 = {0}; (void)&s_6;
    struct qcore_task_slot s_7 = {0}; (void)&s_7;
    struct qcore_task_slot s_8 = {0}; (void)&s_8;
    goto qcore_block_0;
qcore_block_0: ;
    s_3.scalar = INT32_C(42);
    /* checked scope 4 begins */
    {
        int32_t captures[QCORE_TASK_ARGUMENT_CAPACITY] = {0};
        captures[0] = s_3.scalar;
        s_5.handle = qcore_task_start(qcore_task_fn_0, captures, 1, context, 0);
        if (s_5.handle == NULL) goto qcore_block_2;
        goto qcore_block_1;
    }
qcore_block_1: ;
    s_6.result = qcore_task_collect(s_5.handle);
    s_5.handle = NULL;
    if (s_6.result.error != 0) {
        s_8.error = s_6.result.error;
        goto qcore_block_4;
    }
    s_7.scalar = s_6.result.value;
    goto qcore_block_3;
qcore_block_2: ;
    /* checked scope 4 exits without tasks */
    return (struct qcore_task_result){0, 0, 1};
qcore_block_3: ;
    /* checked scope 4 exits without tasks */
    return (struct qcore_task_result){1, s_7.scalar, 0};
qcore_block_4: ;
    /* checked scope 4 exits without tasks */
    return (struct qcore_task_result){0, 0, s_8.error};
}
int main(void) {
    (void)&qcore_task_start; (void)&qcore_task_collect;
    (void)&qcore_task_fn_0;
    (void)&qcore_task_fn_1;
    struct qcore_task_context context = {1};
    struct qcore_task_result result = qcore_task_fn_1(NULL, &context);
    qcore_task_print_result(0, result);
    return 0;
}
