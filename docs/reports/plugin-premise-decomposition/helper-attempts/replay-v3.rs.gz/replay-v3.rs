//! Report-owned explicit reconstruction, not a consumer of premise truth.
//! INPUT holds old/new root environments, actual diagnostics, and build commits.
//! Only independently held root source/inclusion metadata may be reversed here.
//! Every reconstructed effective environment must hit the actual BASE hash.
use qcore_c_gateway::reading_site_evidence::{Receipt, bind, publication_environments, validate_environment};
use qcore_schemas::{contract::ResourceContracts, hypothesis::Context};
use serde_json::{Value, json};
use std::{collections::BTreeMap, fs};
fn read(path: &Value) -> Vec<u8> { fs::read(path.as_str().expect("explicit file path")).unwrap() }
fn value(path: &Value) -> Value { serde_json::from_slice(&read(path)).unwrap() }
fn typed(value: &Value) -> ResourceContracts { serde_json::from_value(value.clone()).unwrap() }
fn digest(v: &ResourceContracts) -> String { qcore_schemas::sha256_hex(&serde_json::to_vec(v).unwrap()) }
fn source_digest(v: &BTreeMap<String,String>) -> String { qcore_schemas::sha256_hex(&serde_json::to_vec(v).unwrap()) }
// Only the two existing diagnostic provenance records have snapshot paths.
// Every changed scalar must match both independently held roots and the same
// literal suffix under their explicitly supplied immutable snapshot prefixes.
fn reverse_snapshot_paths(environment: &mut ResourceContracts, old: &ResourceContracts,
    new: &ResourceContracts, old_root: &str, new_root: &str) {
    let before=serde_json::to_value(old).unwrap();
    let after=serde_json::to_value(new).unwrap();
    let mut value=serde_json::to_value(&*environment).unwrap();
    for kind in ["pending_review","pin_mismatch"] {
        let Some(records)=value.get_mut(kind).and_then(Value::as_object_mut) else {continue;};
        for (name,record) in records {
            for field in ["module","lock"] {
                let Some(expected_new)=after.get(kind).and_then(|v|v.get(name)).and_then(|v|v.get(field)) else {continue;};
                let expected_old=&before[kind][name][field];
                if expected_new==expected_old {continue;}
                let new_path=expected_new.as_str().expect("provenance path scalar");
                let suffix=new_path.strip_prefix(new_root).expect("new provenance has actual TIP snapshot prefix");
                assert!(suffix.starts_with('/'));
                assert_eq!(expected_old.as_str(),Some(format!("{old_root}{suffix}").as_str()),"provenance path suffix differs");
                assert!(record.get(field)==Some(expected_new),"captured provenance differs from held TIP field");
                record[field]=expected_old.clone();
            }
        }
    }
    *environment=serde_json::from_value(value).unwrap();
}
fn replay_build(base:&Value,tip:&Value,bc:&Context,tc:&Context,old:&ResourceContracts,new:&ResourceContracts) {
    use qcore_audit::compile_db::{CompileEntry,compiler_options,compile_task_identity,EffectiveInput};
    use qcore_c_gateway::{ClangIdentity,legacy_c::{C11TranslationUnit,LegacyFunctionScope,prepare_translation_unit}};
    let entry=CompileEntry{directory:base["directory"].as_str().unwrap().into(),file:base["file"].as_str().unwrap().into(),command:base["command"].as_str().unwrap().into()};
    for field in ["directory","file","command","compiler","raw_source_sha256","source_revision"] {assert_eq!(base[field],tip[field],"compile source field changed");}
    let raw=fs::read_to_string(&entry.file).unwrap();
    let options=compiler_options(&entry).unwrap();
    let unit=C11TranslationUnit{source:&raw,include_paths:options.include_paths,definitions:options.definitions,preprocessor_options:options.preprocessor_options,dialect:options.dialect,function_scope:LegacyFunctionScope::MainSourceDefinitions,input:options.input};
    let prepared=prepare_translation_unit(&unit);
    let pp=prepared.preprocessed_source().unwrap();
    let compiler=ClangIdentity::capture().unwrap();
    assert_eq!(serde_json::to_value(&compiler).unwrap(),base["compiler"]);
    let mut tasks=Vec::new();
    for (cfg,context,root) in [(base,bc,old),(tip,tc,new)] {
        let dependencies:BTreeMap<String,String>=serde_json::from_value(cfg["dependencies"].clone()).unwrap();
        assert_eq!(dependencies["resource_contract_sources"],source_digest(root.source_assumptions()));
        let task=compile_task_identity(&entry,&unit,EffectiveInput::Accepted(pp),&compiler,dependencies).unwrap();
        assert_eq!(serde_json::to_value(&task).unwrap(),cfg["compile_task_identity"],"production compile-task reconstruction");
        assert_eq!(task.digest().unwrap(),context.build_identity,"actual complete typed task digest");
        let mut inventory=cfg.clone(); let published=inventory.as_object_mut().unwrap().remove("inventory_sha256").unwrap();
        assert_eq!(qcore_schemas::sha256_hex(&serde_json::to_vec(&inventory).unwrap()),published.as_str().unwrap(),"complete compile inventory preimage");
        tasks.push(serde_json::to_value(&task).unwrap());
    }
    tasks[1]["dependencies"]["resource_contract_sources"]=tasks[0]["dependencies"]["resource_contract_sources"].clone();
    assert_eq!(tasks[0],tasks[1],"compile task has unexplained delta beyond held root-source identity");
}
fn main() {
    let args=std::env::args().collect::<Vec<_>>();
    assert_eq!(args.len(),3,"INPUT OUTPUT");
    let spec:Value=serde_json::from_slice(&fs::read(&args[1]).unwrap()).unwrap();
    let old=typed(&value(&spec["base_environment"]));
    let new=typed(&value(&spec["tip_environment"]));
    // No semantic, import, settlement, contract, or source authority substitution.
    let mut erased_new=new.clone();
    erased_new.set_source_assumptions(old.source_assumptions().clone());
    erased_new.set_inclusion_evidence(old.inclusion_evidence().clone());
    let old_root=spec["base_inputs_root"].as_str().unwrap();
    let new_root=spec["tip_inputs_root"].as_str().unwrap();
    reverse_snapshot_paths(&mut erased_new,&old,&new,old_root,new_root);
    assert!(serde_json::to_value(&erased_new).unwrap()==serde_json::to_value(&old).unwrap(),"root delta exceeds held source/inclusion and exact snapshot-path metadata; needs independent attribution");
    let old_graphs=qcore_contract::hypothesis::replay(old.source_assumptions()).unwrap();
    let new_graphs=qcore_contract::hypothesis::replay(new.source_assumptions()).unwrap();
    let before=value(&spec["base_diagnostics"]);
    let after=value(&spec["tip_diagnostics"]);
    let old_contracts=value(&spec["base_contracts"]);
    let new_contracts=value(&spec["tip_contracts"]);
    for (sidecar,environment) in [(&old_contracts,&old),(&new_contracts,&new)] {
        let source_field=sidecar.get("sources").or_else(||sidecar.get("contracts")).unwrap();
        assert_eq!(source_field,&json!(environment.source_assumptions()));
        assert!(sidecar["refuted_contracts"]["entries"].as_array().unwrap().iter().all(|entry| entry["applied"]!=true),"nonempty home refutation stage requires separately reconstructed held environment");
    }
    // current_route and pinned_route export homes under the held pre-import root.
    // Check every actual selected home before deriving the sole permitted delta.
    let old_home_root=digest(&old);
    let new_home_root=digest(&new);
    let home_records=|sidecar:&Value| -> BTreeMap<String,Value> {
        let mut out=BTreeMap::new();
        for entry in sidecar["cross_unit_link_resolution"]["imported"].as_array().into_iter().flatten() {
            assert!(out.insert(entry["function"].as_str().unwrap().to_owned(),entry.clone()).is_none());
        }
        out
    };
    let old_homes=home_records(&old_contracts);
    let new_homes=home_records(&new_contracts);
    assert_eq!(old_homes.keys().collect::<Vec<_>>(),new_homes.keys().collect::<Vec<_>>());
    for (function,new_home) in &new_homes {
        assert_eq!(new_home["home_environment_sha256"],new_home_root);
        assert_eq!(old_homes[function]["home_environment_sha256"],old_home_root);
        let mut reconstructed=new_home.clone();
        reconstructed["home_environment_sha256"]=json!(old_home_root);
        assert_eq!(reconstructed,old_homes[function],"home identity or selected link premise changed beyond exact root environment");
    }
    let mut old_cross=old_contracts["cross_unit_link_resolution"].clone();
    let new_cross=&new_contracts["cross_unit_link_resolution"];
    if let Some(imported)=old_cross.get_mut("imported").and_then(Value::as_array_mut) {
        for entry in imported {entry["home_environment_sha256"]=json!(new_home_root);}
    }
    assert_eq!(&old_cross,new_cross,"complete link-resolution premise/selection must agree");
    let bu=before["units"].as_array().unwrap();
    let tu=after["units"].as_array().unwrap();
    assert_eq!(bu.len(),tu.len());
    let mut records=Vec::new();
    let mut environments=BTreeMap::<String,String>::new();
    for (base,tip) in bu.iter().zip(tu) {
        for key in ["library","file"] {assert_eq!(base[key],tip[key],"unit alignment");}
        let bf=base["functions"].as_array().unwrap();
        let tf=tip["functions"].as_array().unwrap();
        assert_eq!(bf.len(),tf.len());
        let captured:BTreeMap<String,String>=tip.get("reading_site_environments")
            .map(|v|serde_json::from_value(v["environments"].clone()).unwrap()).unwrap_or_default();
        let mut bound=Vec::new();
        for (b,t) in bf.iter().zip(tf) {
            assert_eq!(b["function"],t["function"],"function alignment");
            let mut base_receipts:Vec<Receipt>=b.get("reading_site_evidence").map(|v|serde_json::from_value(v.clone()).unwrap()).unwrap_or_default();
            let tip_receipts:Vec<Receipt>=t.get("reading_site_evidence").map(|v|serde_json::from_value(v.clone()).unwrap()).unwrap_or_default();
            assert_eq!(base_receipts.len(),tip_receipts.len());
            if tip_receipts.is_empty() {continue;}
            let bc:Context=serde_json::from_value(b["hypothesis_context"].clone()).unwrap();
            let tc:Context=serde_json::from_value(t["hypothesis_context"].clone()).unwrap();
            assert_eq!(bc.assumptions,source_digest(old.source_assumptions()));
            assert_eq!(tc.assumptions,source_digest(new.source_assumptions()));
            assert_eq!(bc.evidence_version,format!("contract-hypothesis-graph.v1:{}",spec["base_build_commit"].as_str().unwrap()));
            assert_eq!(tc.evidence_version,format!("contract-hypothesis-graph.v1:{}",spec["tip_build_commit"].as_str().unwrap()));
            replay_build(&base["compile_configuration"],&tip["compile_configuration"],&bc,&tc,&old,&new);
            let mut reversed_context=tc.clone();
            reversed_context.build_identity=bc.build_identity.clone();
            reversed_context.assumptions=bc.assumptions.clone();
            reversed_context.evidence_version=bc.evidence_version.clone();
            assert_eq!(reversed_context,bc,"unexplained Context coordinate; no field erasure");
            for receipt in tip_receipts {
                let declaration=&receipt.observation.declaration;
                assert_eq!(bind(&receipt.observation,&tc,&new_graphs[declaration]).unwrap(),receipt,"actual TIP binding");
                let bytes=&captured[&receipt.observation.environment_sha256];
                let mut reconstructed=validate_environment(bytes,&receipt.observation.environment_sha256).unwrap();
                assert_eq!(reconstructed.source_assumptions(),new.source_assumptions(),"effective source metadata differs from held TIP root");
                assert_eq!(reconstructed.inclusion_evidence(),new.inclusion_evidence(),"effective inclusion metadata differs from held TIP root");
                reconstructed.set_source_assumptions(old.source_assumptions().clone());
                reconstructed.set_inclusion_evidence(old.inclusion_evidence().clone());
                reverse_snapshot_paths(&mut reconstructed,&old,&new,old_root,new_root);
                let mut imports=reconstructed.cross_unit_import_identities().clone();
                for (function,identity) in &mut imports {
                    let home=&new_homes[function];
                    assert_eq!(identity.environment_sha256,new_home_root);
                    assert_eq!(identity.raw_source_sha256,home["home_raw_source_sha256"]);
                    assert_eq!(identity.preprocessed_source_sha256,home["home_preprocessed_source_sha256"]);
                    identity.environment_sha256=old_home_root.clone();
                }
                reconstructed.set_cross_unit_import_identities(imports);
                let canonical=serde_json::to_string(&reconstructed).unwrap();
                let old_sha=qcore_schemas::sha256_hex(canonical.as_bytes());
                let mut observation=receipt.observation.clone();
                observation.environment_sha256=old_sha.clone();
                let rebuilt=bind(&observation,&bc,&old_graphs[declaration]).unwrap();
                let position=base_receipts.iter().position(|r|r==&rebuilt).expect("no exact BASE receipt: unexplained effective environment or observation field");
                let actual=base_receipts.remove(position);
                // Both preimages are independently checked, not merely a root-hash map.
                validate_environment(&canonical,&actual.observation.environment_sha256).unwrap();
                environments.insert(old_sha.clone(),canonical);
                records.push(json!({"artifact":tc.artifact,"function":b["function"],"base_receipt":actual.id,"tip_receipt":receipt.id,"base_environment":old_sha,"tip_environment":receipt.observation.environment_sha256,"non_environment_observation_payload":"exact","receipt_replay":"actual unchanged bind both sides","disposition":"open"}));
                bound.push(receipt);
            }
            assert!(base_receipts.is_empty());
        }
        assert_eq!(publication_environments(&bound,&captured).unwrap(),captured,"published captures must be exactly the bound receipt domain");
    }
    let hashes=["base_environment","tip_environment","base_diagnostics","tip_diagnostics","base_contracts","tip_contracts"].into_iter().map(|key|(key,qcore_schemas::sha256_hex(&read(&spec[key])))).collect::<BTreeMap<_,_>>();
    fs::write(&args[2],serde_json::to_vec_pretty(&json!({"status":"exact canonical reconstruction and complete old/new receipt replay","input_sha256":hashes,"receipts":records,"reconstructed_base_environments":environments,"source_binding":"open","truth_transport":false})).unwrap()).unwrap();
}
