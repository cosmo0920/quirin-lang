import json,subprocess,shutil
from pathlib import Path
p=Path('private/event-collector-landing-20261030').resolve()
for n in ['provenance-preimages.json','provenance-run.json','provenance.stderr']:
 shutil.move(p/n,p/(n+'.wrong-clang-attempt'))
old=json.loads((p/'provenance-run.json.wrong-clang-attempt').read_text());argv=old['argv'];slot=next(i for i,a in enumerate(argv) if a.startswith('QCORE_CLANG='));argv[slot]='QCORE_CLANG=/usr/bin/clang'
# The pinned wrapper's own run.json records this spelling; the outer route
# environment is overridden by scripts/run_pinned_audit.py.
with (p/'provenance-preimages.json').open('w') as out,(p/'provenance.stderr').open('w') as err:r=subprocess.run(argv,stdout=out,stderr=err)
(p/'provenance-run.json').write_text(json.dumps({'argv':argv,'exit':r.returncode,'correction':'Use pinned inner wrapper compiler spelling /usr/bin/clang, independently recorded in both baseline corpus/corpus/run.json files, rather than outer route /usr/lib/llvm-21/bin/clang.'},indent=2)+'\n');assert r.returncode==0
cmd=json.loads((p/'native-command.json').read_text());argv=['python3',str(p/'validate-native.py'),'--native',str(p/'native-baselines'),'--base',cmd['base'],'--tip',cmd['tip'],'--provenance',str(p/'provenance-preimages.json'),'--task-preimages',str(p/'provenance-task-preimages.json'),'--output',str(p/'native-attribution/candidate.json')]
with (p/'native-attribution/candidate-2.log').open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
(p/'native-attribution/candidate-2.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
print('Corrected independent attribution candidate complete.',flush=True)
