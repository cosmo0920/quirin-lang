import json,subprocess,shlex,hashlib,time
from pathlib import Path
root=Path('/home/cosmo/Documents/GitHub/qcore-c').resolve();out=Path(__file__).resolve().parent
receipts=[]
for profile,db in [('corpus','build/cycle19/c-gateway-wave-pin/fluent-bit-clang-source/build/compile_commands.json'),('slice','private/w47-tail/attempt-1/prep/fluent-bit-clang-production/compile_commands.json')]:
    path=root/db
    rows=[r for r in json.loads(path.read_text()) if r['file'].endswith('/flb_input.c')]
    assert rows
    for i,row in enumerate(rows):
        args=shlex.split(row['command']);argv=[];skip=False
        for arg in args:
            if skip:skip=False;continue
            if arg=='-o':skip=True;continue
            if arg=='-c':continue
            argv.append(arg)
        argv+=['-E','-P'];stem=f'production-{profile}-{i}';started=time.time()
        with (out/(stem+'.i')).open('wb') as f,(out/(stem+'.stderr')).open('wb') as e:
            r=subprocess.run(argv,cwd=row['directory'],stdout=f,stderr=e)
        receipt={'profile':profile,'configuration':i,'compile_database':str(path),'compile_database_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'row':row,'argv':argv,'cwd':row['directory'],'exit':r.returncode,'seconds':time.time()-started,'source_sha256':hashlib.sha256(Path(row['file']).read_bytes()).hexdigest(),'preprocessed_sha256':hashlib.sha256((out/(stem+'.i')).read_bytes()).hexdigest()}
        receipts.append(receipt);(out/'production-other-preprocess.json').write_text(json.dumps(receipts,indent=2)+'\n');assert r.returncode==0
        with (out/(stem+'.json')).open('wb') as f,(out/(stem+'.log')).open('wb') as e:
            r=subprocess.run(['target/debug/examples/collector_identity_audit',str(out/(stem+'.i')),str(out/'production-query.json')],stdout=f,stderr=e)
        (out/(stem+'.exit')).write_text(str(r.returncode)+'\n');assert r.returncode==0
        result=json.load((out/(stem+'.json')).open());assert 'Ok' in result['selector'] and 'Ok' in result['conditional_loop'],result
