import json,subprocess,shlex,hashlib,time
from pathlib import Path
root=Path('/home/cosmo/Documents/GitHub/qcore-c').resolve()
out=Path(__file__).resolve().parent
base=root/'private/measure/landing-80c8aea989029c10b3dfbd0179715b7ea050262c-20261028T083848603607Z/mirror/system-compile_commands.json'
rows=[r for r in json.loads(base.read_text()) if r['file'].endswith('/flb_input.c')]
assert len(rows)==2
receipts=[]
for i,row in enumerate(rows):
    args=shlex.split(row['command']); argv=[]; skip=False
    for arg in args:
        if skip:skip=False;continue
        if arg=='-o':skip=True;continue
        if arg=='-c':continue
        argv.append(arg)
    argv+=['-E','-P']
    started=time.time()
    with (out/f'production-{i}.i').open('wb') as f,(out/f'production-{i}.stderr').open('wb') as e:
        result=subprocess.run(argv,cwd=row['directory'],stdout=f,stderr=e)
    receipts.append({'configuration':i,'compile_database':str(base),'compile_database_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'row':row,'argv':argv,'cwd':row['directory'],'exit':result.returncode,'seconds':time.time()-started,'source_sha256':hashlib.sha256(Path(row['file']).read_bytes()).hexdigest(),'preprocessed_sha256':hashlib.sha256((out/f'production-{i}.i').read_bytes()).hexdigest()})
    (out/'production-preprocess.json').write_text(json.dumps(receipts,indent=2)+'\n')
    assert result.returncode==0
query={'selector':{'function':'get_collector','record':'flb_input_collector','owner_record':'flb_input_instance','list_record':'mk_list','list_member':'collectors','link_member':'_head','key_member':'id'},'conditional_loop':{'function':'collector_create','predicate':'flb_input_is_threaded','record':'flb_input_collector','owner_record':'flb_input_instance','worker_record':'flb_input_thread_instance','config_record':'flb_config','loop_record':'mk_event_loop','instance_member':'instance','threaded_member':'is_threaded','worker_member':'thi','loop_member':'evl'}}
(out/'production-query.json').write_text(json.dumps(query,indent=2)+'\n')
