import json,subprocess,time,hashlib
from pathlib import Path
root=Path.cwd();out=root/'private/collector-selection/production-final';out.mkdir(exist_ok=False)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
source=root/'private/collector-selection';receipts=[]
for stem in ['production-0','production-1','production-corpus-0','production-corpus-1','production-slice-0','production-slice-1']:
 argv=['target/debug/examples/collector_identity_audit',str(source/(stem+'.i')),str(source/'production-query.json')]
 started=time.time()
 with (out/(stem+'.json')).open('w') as f,(out/(stem+'.log')).open('w') as e:r=subprocess.run(argv,stdout=f,stderr=e)
 (out/(stem+'.exit')).write_text(str(r.returncode)+'\n')
 receipt={'stem':stem,'head':head,'argv':argv,'cwd':str(root),'exit':r.returncode,'seconds':time.time()-started,'binary_sha256':hashlib.sha256((root/argv[0]).read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((source/(stem+'.i')).read_bytes()).hexdigest()}
 receipts.append(receipt);(out/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
 assert r.returncode==0
 result=json.load((out/(stem+'.json')).open());assert 'Ok' in result['selector'] and 'Ok' in result['conditional_loop'],result
(out/'COMPLETED.json').write_text(json.dumps({'head':head,'imports':12,'independent_replays':12,'configurations':6,'all_exit_zero':True,'lifetime_verdict':'not established'},indent=2)+'\n')
