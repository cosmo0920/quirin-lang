import json,subprocess,time,os
from pathlib import Path
root=Path.cwd();shared=Path('/home/cosmo/Documents/GitHub/qcore-c').resolve();p=root/'private/event-collector-landing-20261030'
while not (p/'native.exit').exists():time.sleep(5)
assert (p/'native.exit').read_text().strip()=='0'
cmd=json.loads((p/'native-command.json').read_text());native=p/'native-baselines'
before_run=json.loads((shared/'private/baselines'/cmd['base']/'eight-home/run.json').read_text())
after_run=json.loads((shared/'private/baselines'/cmd['tip']/'eight-home/run.json').read_text())
before=before_run['routes']['corpus']['working_directory'];after=after_run['routes']['corpus']['working_directory']
assert before!=after
input_file=p/'provenance-input.json'
input_file.write_text(json.dumps({'before_cwd':before,'after_cwd':after,'databases':['/tmp/quirin-measure/mirror/'+d['path'] for d in after_run['routes']['corpus']['route_definition']['compile_databases']]},indent=2)+'\n')
def run(argv,log):
 with (p/log).open('w') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 (p/(log+'.exit')).write_text(str(r.returncode)+'\n');assert r.returncode==0,(argv,r.returncode)
run(['cargo','build','--offline','--manifest-path',str(p/'provenance-crate/Cargo.toml'),'--target-dir',str(p/'provenance-target')],'provenance-cargo.log')
binary=p/'provenance-target/debug/collector-selection-provenance'
script='set -e\nmount --bind "$1" "$2"\nmount --bind "$3" "$4"\ncd "$5"\nshift 5\nexec "$@"\n'
argv=['unshare','-rm','sh','-c',script,'quirin-provenance-ns',after_run['source'],'/tmp/quirin-measure/src',str(Path(after_run['mirror']['manifest']).parent),'/tmp/quirin-measure/mirror',after,'env','QCORE_CLANG='+after_run['routes']['corpus']['environment']['QCORE_CLANG'],str(binary),str(input_file)]
with (p/'provenance-preimages.json').open('w') as out,(p/'provenance.stderr').open('w') as err:r=subprocess.run(argv,stdout=out,stderr=err)
(p/'provenance-run.json').write_text(json.dumps({'argv':argv,'exit':r.returncode},indent=2)+'\n');assert r.returncode==0
q=p/'provenance-tasks-input.json';q.write_text(json.dumps({'tasks':[str(shared/'private/baselines'/cmd['base']/'eight-home/corpus/corpus/resource-diagnostics.source-effects.json'),str(shared/'private/baselines'/cmd['tip']/'eight-home/corpus/corpus/resource-diagnostics.source-effects.json')]})+'\n')
with (p/'provenance-task-preimages.json').open('w') as out,(p/'provenance-tasks.stderr').open('w') as err:r=subprocess.run([str(binary),str(q)],stdout=out,stderr=err)
(p/'provenance-tasks.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
out=p/'native-attribution';out.mkdir(exist_ok=False)
argv=['python3',str(p/'validate-native.py'),'--native',str(native),'--base',cmd['base'],'--tip',cmd['tip'],'--provenance',str(p/'provenance-preimages.json'),'--task-preimages',str(p/'provenance-task-preimages.json'),'--output',str(out/'candidate.json')]
run(argv,'native-attribution/candidate.log')
print('Independent provenance preimages and full-payload comparison candidate are ready for review.',flush=True)
