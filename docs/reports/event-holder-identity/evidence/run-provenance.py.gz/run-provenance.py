import json,subprocess,time
from pathlib import Path
p=Path('private/holder-identity');trigger=p/'native.exit'
while not trigger.exists():time.sleep(5)
assert trigger.read_text().strip()=='0'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==json.loads((p/'native-command.json').read_text())['tip']
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
cmd=['cargo','build','--offline','--manifest-path',str(p/'provenance-crate/Cargo.toml'),'--target-dir','target']
with (p/'provenance-cargo.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(p/'provenance-cargo.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
binary=Path('target/debug/holder-identity-provenance').resolve()
argv=json.loads((p/'provenance-run.json').read_text())['argv'];argv[-2]=str(binary)
with (p/'provenance-preimages.json').open('w') as out,(p/'provenance-run-3.stderr').open('w') as err:r=subprocess.run(argv,stdout=out,stderr=err)
(p/'provenance-run-3.json').write_text(json.dumps({'argv':argv,'exit':r.returncode},indent=2)+'\n');assert r.returncode==0
shared=Path('/media/Data/GitHub/quirin-lang')
base=shared/'private/baselines/80c8aea989029c10b3dfbd0179715b7ea050262c/eight-home/corpus/corpus/resource-diagnostics.source-effects.json'
after=shared/'private/event-holder-native-20261028/sides/tip/corpus/corpus/resource-diagnostics.source-effects.json'
q=p/'provenance-tasks-input.json';q.write_text(json.dumps({'tasks':[str(base),str(after)]})+'\n')
cmd=[str(binary),str(q)]
with (p/'provenance-task-preimages.json').open('w') as out,(p/'provenance-tasks.stderr').open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
(p/'provenance-tasks.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
print('All provenance preimages and source task identities independently recomputed',flush=True)
