import datetime,json,subprocess,sys,time,shutil
from pathlib import Path
root=Path.cwd(); private=root/'private/holder-identity'
trigger=private/'native.exit'
sys.path.insert(0,str(root/'scripts'));import gate_scope as gate
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
expected=json.loads((private/'validation-tip.json').read_text())['tip'];assert head==expected
native_tip=json.loads((private/'native-command.json').read_text())['tip']
allowed=['crates/qcore-c-gateway/tests/loop_lifetime_s3.rs']
changed=subprocess.check_output(['git','diff','--name-only',native_tip,head],text=True).splitlines();assert changed==allowed
source_check=['git','diff','--exit-code',native_tip,head,'--','.',':(exclude)'+allowed[0]]
assert subprocess.run(source_check,check=False).returncode==0
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
out=private/'final-gate';out.mkdir(exist_ok=False)
doc=json.loads((private/'../holder-final-plan-v5/gate.json').read_text());doc['head']=head;doc['validation_tip']=head
doc['started']=datetime.datetime.now(datetime.timezone.utc).isoformat();doc['scope_plan_origin']='../holder-final-plan-v5 generated on '+head+', full root Rust/all Lean/provider selection'
doc['native_checkpoint']=native_tip;doc['native_difference']={'paths':changed,'all_other_tracked_inputs_equal':True,'argv':source_check,'exit':0}
with (out/'clang-version.txt').open('w') as f:code=subprocess.run(['clang','--version'],stdout=f,stderr=subprocess.STDOUT).returncode
(out/'clang-version.exit').write_text(str(code)+'\n');assert code==0
steps=gate.steps_for(doc['scope'],out)
for step in steps:
 if step.name=='rust-suite':step.argv += ['--jobs','16']
ordered=[s for s in steps if s.name!='python']; python=[s for s in steps if s.name=='python']
pre=[s for s in ordered if s.name not in {'rust-suite','provider-test'}]
heavy=[s for s in ordered if s.name in {'rust-suite','provider-test'}]
records=gate.run_steps(pre,out,use_slots=True,echo=lambda x:print(x,flush=True))
doc.update(steps=records,ran=True,ok=False)
(out/'before-native.json').write_text(json.dumps(doc,indent=2)+'\n')
assert all(r['exit']==0 for r in records), 'Failed prerequisite commands retained'
print('Prerequisites passed; waiting for native comparison before exclusive Rust suites',flush=True)
while not trigger.exists():time.sleep(5)
assert trigger.read_text().strip()=='0', 'Native comparison must pass before final exclusive suites'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
records += gate.run_steps(heavy,out,use_slots=True,echo=lambda x:print(x,flush=True))
doc.update(steps=records,ran=True,ok=False)
(out/'before-python.json').write_text(json.dumps(doc,indent=2)+'\n')
assert all(r['exit']==0 for r in records), 'Failed source steps retained before Python records'
by={r['name']:r for r in records};assert by['rust-suite']['counts']['passed']==8847;assert by['lean']['counts']['audits']==391
report=root/'docs/reports/event-holder-identity'
for name in ['clang-version.txt','clang-version.exit']:shutil.copyfile(out/name,report/name)
flat={'note':'Final source/provider commands on '+head+' passed. Python records admission follows this candidate; no completed standing gate is claimed until the independent Python result is retained.', 'workspace_tests':by['rust-suite']['counts']['passed'],'provider_tests':by['provider-test']['counts']['passed'],'python_evidence_validator_tests':554,'reevaluation_probe_exit':0,'reevaluation_followup_exit':0,'cargo_fmt':'clean','cargo_clippy':'clean','standing_gate':'source/provider steps passed; Python admission pending','lean_audits':391,'clang':'present: '+(out/'clang-version.txt').read_text().splitlines()[0]}
def writeflat(): (report/'gate.json').write_text(json.dumps(flat,indent=2)+'\n')
def regen():
 for cmd in [['python3','docs/reports/remaining-d02/build_matrix.py','.', '--gate','docs/reports/event-holder-identity/gate.json'],['python3','scripts/build_docs_index.py'],['python3','scripts/contribution_ledgers.py','render'],['python3','scripts/land.py','check']]:
  print('$ '+' '.join(cmd),flush=True);subprocess.run(cmd,check=True)
writeflat();regen()
subprocess.run(['git','add','docs/reports/event-holder-identity/gate.json','docs/reports/event-holder-identity/clang-version.txt','docs/reports/event-holder-identity/clang-version.exit','docs/reviews/r0_3/acceptance_matrix.json','docs/reports/INDEX.md','docs/development/contributions.md'],check=True)
records += gate.run_steps(python,out,use_slots=True,echo=lambda x:print(x,flush=True))
doc.update(steps=records,ok=all(r['exit']==0 for r in records),finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'gate.json').write_text(json.dumps(doc,indent=2)+'\n')
assert doc['ok'], 'Failed Python admission retained'
assert records[-1]['counts']['tests']==554 and records[-1]['counts']['skipped']==0
flat.update(note='EVENT-HOLDER-IDENTITY full source/provider gate on '+head+': Rust 8847/0/15 (574 units/593 summaries); provider 133/0/1; Lean391; Python554/no skips; all commands exit0. Exact commands and private logs are in evidence/gate-steps.json. Initial focused/partial attempts are separate checkpoints. Records-only Python rerun follows the completion commit.',standing_gate='full source/provider gate on '+head+'; records-only Python rerun after completion commit')
writeflat();regen()
print('Final source/provider gate passed '+head,flush=True)
