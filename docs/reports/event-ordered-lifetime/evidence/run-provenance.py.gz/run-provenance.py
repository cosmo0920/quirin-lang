import json,subprocess,time
from pathlib import Path
p=Path('private/ordered-lifetime');gate=p/'final-gate/gate.json'
while not gate.exists():time.sleep(5)
assert json.loads(gate.read_text())['ok']
cmd=['cargo','build','--offline','--manifest-path',str(p/'provenance-crate/Cargo.toml'),'--target-dir','target']
with (p/'provenance-cargo.log').open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(p/'provenance-cargo.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
binary=Path('target/debug/ordered-lifetime-provenance').resolve()
record=json.loads((p/'provenance-run.json').read_text());argv=record['argv'];argv[-2]=str(binary)
with (p/'provenance-preimages.json').open('w') as out,(p/'provenance-run-3.stderr').open('w') as err:r=subprocess.run(argv,stdout=out,stderr=err)
(p/'provenance-run-3.json').write_text(json.dumps({'argv':argv,'exit':r.returncode},indent=2)+'\n');assert r.returncode==0
base=Path('/media/Data/GitHub/quirin-lang/private/baselines/facdb5f4ec1806c38f09f953f4c5b2ae463386e5/eight-home/corpus/corpus/resource-diagnostics.source-effects.json')
after=Path('/media/Data/GitHub/quirin-lang/private/event-ordered-native-20261028/sides/tip/corpus/corpus/resource-diagnostics.source-effects.json')
q=p/'provenance-tasks-input.json';q.write_text(json.dumps({'tasks':[str(base),str(after)]})+'\n')
cmd=[str(binary),str(q)]
with (p/'provenance-task-preimages.json').open('w') as out,(p/'provenance-tasks.stderr').open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
(p/'provenance-tasks.exit').write_text(str(r.returncode)+'\n');assert r.returncode==0
print('All provenance preimages and source task identities independently recomputed',flush=True)
