#define QCORE_TASK_ARGUMENT_CAPACITY 1
#define QCORE_BUFFER_EVENT_CAPACITY 32
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <threads.h>
#if defined(__STDC_NO_THREADS__)
#error "The scoped task profile requires C11 threads"
#endif
#ifndef QCORE_TASK_CALLOC
#define QCORE_TASK_CALLOC calloc
#endif
#ifndef QCORE_TASK_FREE
#define QCORE_TASK_FREE free
#endif
#ifndef QCORE_TASK_CREATE
#define QCORE_TASK_CREATE thrd_create
#endif
#ifndef QCORE_TASK_JOIN
#define QCORE_TASK_JOIN thrd_join
#endif
#ifndef QCORE_BUFFER_MALLOC
#define QCORE_BUFFER_MALLOC malloc
#endif
#ifndef QCORE_BUFFER_MALLOC_FOR_TASK
#define QCORE_BUFFER_MALLOC_FOR_TASK(size, task, attempt) QCORE_BUFFER_MALLOC(size)
#endif
#ifndef QCORE_BUFFER_FREE
#define QCORE_BUFFER_FREE free
#endif
/* Only checked move operations expose this private allocation to workers.
 * Payload and generation never change after successful allocation. */
struct qcore_buffer { uint64_t generation; int32_t payload; };
struct qcore_task_value { int32_t scalar; struct qcore_buffer *buffer; };
struct qcore_task_result { int kind; struct qcore_task_value value; int error; };
struct qcore_buffer_event { int kind; uint64_t generation; int32_t payload; };
struct qcore_task_context {
    uint64_t identity;
    uint64_t next_task;
    uint64_t next_buffer;
    uint64_t allocation_attempt;
    size_t event_count;
    struct qcore_buffer_event events[QCORE_BUFFER_EVENT_CAPACITY];
};
typedef struct qcore_task_result (*qcore_task_worker)(const struct qcore_task_value *, struct qcore_task_context *);
struct qcore_task_start_record {
    thrd_t thread;
    uint64_t identity;
    qcore_task_worker worker;
    struct qcore_task_value arguments[QCORE_TASK_ARGUMENT_CAPACITY];
    struct qcore_task_result result;
    struct qcore_task_context context;
};
struct qcore_task_slot {
    struct qcore_task_value value;
    struct qcore_task_result result;
    struct qcore_task_start_record *handle;
    int error;
};
static const char *qcore_task_error_name(int);
static void qcore_buffer_print_event(uint64_t task, struct qcore_buffer_event event) {
    switch (event.kind) {
    case 0: printf("QCORE_BUFFER_ALLOC %" PRIu64 " %" PRIu64 " %" PRId32 "\n", task, event.generation, event.payload); break;
    case 1: printf("QCORE_BUFFER_ALLOC_FAILED %" PRIu64 "\n", task); break;
    case 2: printf("QCORE_BUFFER_READ %" PRIu64 " %" PRIu64 " %" PRId32 "\n", task, event.generation, event.payload); break;
    case 3: printf("QCORE_BUFFER_DROP %" PRIu64 " %" PRIu64 "\n", task, event.generation); break;
    default: abort();
    }
}
static void qcore_buffer_event(struct qcore_task_context *context, int kind, uint64_t generation, int32_t payload) {
    struct qcore_buffer_event event = {kind, generation, payload};
    if (context->identity == 0) qcore_buffer_print_event(0, event);
    else {
        /* Each leaf worker owns its event storage. Only its parent reads this
         * array, after successful native join. No shared trace counter exists. */
        if (context->event_count >= QCORE_BUFFER_EVENT_CAPACITY) abort();
        context->events[context->event_count++] = event;
    }
}
static struct qcore_buffer *qcore_buffer_new(int32_t payload, struct qcore_task_context *context) {
    /* Finite leaf tasks have disjoint identity ranges and private counters.
     * Failed allocations consume an attempt, not a resource generation. */
    if (context->identity > UINT32_MAX || context->next_buffer == 0 ||
        context->next_buffer > UINT32_MAX || context->allocation_attempt == UINT64_MAX) abort();
    ++context->allocation_attempt;
    struct qcore_buffer *buffer = QCORE_BUFFER_MALLOC_FOR_TASK(
        sizeof(*buffer), context->identity, context->allocation_attempt);
    if (buffer == NULL) {
        qcore_buffer_event(context, 1, 0, 0);
        return NULL;
    }
    buffer->generation = context->identity * UINT64_C(4294967296) + context->next_buffer++;
    buffer->payload = payload;
    qcore_buffer_event(context, 0, buffer->generation, payload);
    return buffer;
}
static int32_t qcore_buffer_read(const struct qcore_buffer *buffer, struct qcore_task_context *context) {
    if (buffer == NULL) abort();
    int32_t payload = buffer->payload;
    qcore_buffer_event(context, 2, buffer->generation, payload);
    return payload;
}
static void qcore_buffer_drop(struct qcore_buffer *buffer, struct qcore_task_context *context) {
    if (buffer == NULL) abort();
    qcore_buffer_event(context, 3, buffer->generation, 0);
    QCORE_BUFFER_FREE(buffer);
}
static void qcore_task_print_result(uint64_t identity, struct qcore_task_result result) {
    if (result.error != 0)
        printf("QCORE_TASK_RESULT %" PRIu64 " ERROR %s\n", identity, qcore_task_error_name(result.error));
    else if (result.kind == 0)
        printf("QCORE_TASK_RESULT %" PRIu64 " UNIT\n", identity);
    else if (result.kind == 1)
        printf("QCORE_TASK_RESULT %" PRIu64 " I32 %" PRId32 "\n", identity, result.value.scalar);
    else if (result.kind == 2) {
        if (result.value.buffer == NULL) abort();
        printf("QCORE_TASK_RESULT %" PRIu64 " BUFFER %" PRIu64 "\n", identity, result.value.buffer->generation);
    } else abort();
}
static int qcore_task_trampoline(void *pointer) {
    struct qcore_task_start_record *record = pointer;
    record->result = record->worker(record->arguments, &record->context);
    return 0;
}
static struct qcore_task_start_record *qcore_task_start(qcore_task_worker worker,
        const struct qcore_task_value *arguments, size_t count, struct qcore_task_context *context, size_t worker_id) {
    if (context->next_task == 0 || context->next_task > UINT32_MAX) abort();
    struct qcore_task_start_record *record = QCORE_TASK_CALLOC(1, sizeof(*record));
    if (record == NULL) {
        printf("QCORE_TASK_CREATE_FAILED %zu\n", worker_id);
        return NULL;
    }
    record->worker = worker;
    record->identity = context->next_task;
    record->context.identity = record->identity;
    record->context.next_buffer = 1;
    for (size_t i = 0; i < count; ++i) record->arguments[i] = arguments[i];
    if (QCORE_TASK_CREATE(&record->thread, qcore_task_trampoline, record) != thrd_success) {
        /* Creation failure never transfers the buffer; discard only the
         * environment's non-owning copies. The parent still owns each slot. */
        QCORE_TASK_FREE(record);
        printf("QCORE_TASK_CREATE_FAILED %zu\n", worker_id);
        return NULL;
    }
    ++context->next_task;
    printf("QCORE_TASK_SPAWN %" PRIu64 " %zu\n", record->identity, worker_id);
    return record;
}
static struct qcore_task_result qcore_task_collect(struct qcore_task_start_record *record) {
    int status;
    /* An unsuccessful join gives no permission to read completion data or
     * reclaim either the environment or an owned completion payload. */
    if (QCORE_TASK_JOIN(record->thread, &status) != thrd_success) abort();
    if (status != 0) abort();
    struct qcore_task_result result = record->result;
    for (size_t i = 0; i < record->context.event_count; ++i)
        qcore_buffer_print_event(record->identity, record->context.events[i]);
    qcore_task_print_result(record->identity, result);
    printf("QCORE_TASK_JOIN %" PRIu64 "\n", record->identity);
    QCORE_TASK_FREE(record);
    return result;
}
static const char *qcore_task_error_name(int tag) {
    switch (tag) {
    case 1: return "\101\154\154\157\143\105\162\162\157\162";
    case 2: return "\123\160\141\167\156\105\162\162\157\162";
    default: abort();
    }
}
static struct qcore_task_result qcore_task_fn_0(const struct qcore_task_value *, struct qcore_task_context *);
static struct qcore_task_result qcore_task_fn_1(const struct qcore_task_value *, struct qcore_task_context *);
static struct qcore_task_result qcore_task_fn_0(const struct qcore_task_value *args, struct qcore_task_context *context) {
    (void)args; (void)context;
    struct qcore_task_slot s_2 = {0}; (void)&s_2;
    struct qcore_task_slot s_3 = {0}; (void)&s_3;
    s_2.value = args[0];
    goto qcore_block_0;
qcore_block_0: ;
    s_3.value.buffer = qcore_buffer_new(s_2.value.scalar, context);
    if (s_3.value.buffer == NULL) goto qcore_block_2;
    goto qcore_block_1;
qcore_block_1: ;
    { struct qcore_task_result returned = {2, s_3.value, 0};
    s_3.value.buffer = NULL;
    return returned; }
qcore_block_2: ;
    return (struct qcore_task_result){0, {0, NULL}, 1};
}
static struct qcore_task_result qcore_task_fn_1(const struct qcore_task_value *args, struct qcore_task_context *context) {
    (void)args; (void)context;
    struct qcore_task_slot s_4 = {0}; (void)&s_4;
    struct qcore_task_slot s_6 = {0}; (void)&s_6;
    struct qcore_task_slot s_7 = {0}; (void)&s_7;
    struct qcore_task_slot s_8 = {0}; (void)&s_8;
    struct qcore_task_slot s_9 = {0}; (void)&s_9;
    struct qcore_task_slot s_10 = {0}; (void)&s_10;
    struct qcore_task_slot s_11 = {0}; (void)&s_11;
    struct qcore_task_slot s_12 = {0}; (void)&s_12;
    struct qcore_task_slot s_13 = {0}; (void)&s_13;
    struct qcore_task_slot s_14 = {0}; (void)&s_14;
    struct qcore_task_slot s_16 = {0}; (void)&s_16;
    struct qcore_task_slot s_17 = {0}; (void)&s_17;
    struct qcore_task_slot s_18 = {0}; (void)&s_18;
    struct qcore_task_slot s_19 = {0}; (void)&s_19;
    struct qcore_task_slot s_20 = {0}; (void)&s_20;
    struct qcore_task_slot s_21 = {0}; (void)&s_21;
    goto qcore_block_0;
qcore_block_0: ;
    s_4.value = (struct qcore_task_value){INT32_C(42), NULL};
    /* checked scope 5 begins */
    {
        struct qcore_task_value captures[QCORE_TASK_ARGUMENT_CAPACITY] = {{0}};
        captures[0] = (struct qcore_task_value){s_4.value.scalar, NULL};
        s_6.handle = qcore_task_start(qcore_task_fn_0, captures, 1, context, 0);
        if (s_6.handle == NULL) goto qcore_block_2;
        goto qcore_block_1;
    }
qcore_block_1: ;
    {
        struct qcore_task_value captures[QCORE_TASK_ARGUMENT_CAPACITY] = {{0}};
        captures[0] = (struct qcore_task_value){s_4.value.scalar, NULL};
        s_7.handle = qcore_task_start(qcore_task_fn_0, captures, 1, context, 0);
        if (s_7.handle == NULL) goto qcore_block_4;
        goto qcore_block_3;
    }
qcore_block_2: ;
    /* checked scope 5 exits without tasks */
    return (struct qcore_task_result){0, {0, NULL}, 2};
qcore_block_3: ;
    s_18.result = qcore_task_collect(s_7.handle);
    s_7.handle = NULL;
    if (s_18.result.error != 0) {
        s_12.error = s_18.result.error;
        goto qcore_block_6;
    }
    s_8.value = s_18.result.value; s_18.result.value.buffer = NULL;
    goto qcore_block_5;
qcore_block_4: ;
    s_21.result = qcore_task_collect(s_6.handle);
    s_6.handle = NULL;
    if (s_21.result.error != 0) {
        s_17.error = s_21.result.error;
        goto qcore_block_12;
    }
    s_16.value = s_21.result.value; s_21.result.value.buffer = NULL;
    goto qcore_block_11;
qcore_block_5: ;
    s_19.result = qcore_task_collect(s_6.handle);
    s_6.handle = NULL;
    if (s_19.result.error != 0) {
        s_11.error = s_19.result.error;
        goto qcore_block_8;
    }
    s_9.value = s_19.result.value; s_19.result.value.buffer = NULL;
    goto qcore_block_7;
qcore_block_6: ;
    s_20.result = qcore_task_collect(s_6.handle);
    s_6.handle = NULL;
    if (s_20.result.error != 0) {
        s_14.error = s_20.result.error;
        goto qcore_block_10;
    }
    s_13.value = s_20.result.value; s_20.result.value.buffer = NULL;
    goto qcore_block_9;
qcore_block_7: ;
    qcore_buffer_drop(s_9.value.buffer, context); s_9.value.buffer = NULL;
    s_10.value.scalar = qcore_buffer_read(s_8.value.buffer, context);
    qcore_buffer_drop(s_8.value.buffer, context); s_8.value.buffer = NULL;
    /* checked scope 5 exits without tasks */
    { struct qcore_task_result returned = {1, (struct qcore_task_value){s_10.value.scalar, NULL}, 0};
    return returned; }
qcore_block_8: ;
    qcore_buffer_drop(s_8.value.buffer, context); s_8.value.buffer = NULL;
    /* checked scope 5 exits without tasks */
    return (struct qcore_task_result){0, {0, NULL}, s_11.error};
qcore_block_9: ;
    qcore_buffer_drop(s_13.value.buffer, context); s_13.value.buffer = NULL;
    /* checked scope 5 exits without tasks */
    return (struct qcore_task_result){0, {0, NULL}, s_12.error};
qcore_block_10: ;
    /* checked scope 5 exits without tasks */
    return (struct qcore_task_result){0, {0, NULL}, s_12.error};
qcore_block_11: ;
    qcore_buffer_drop(s_16.value.buffer, context); s_16.value.buffer = NULL;
    /* checked scope 5 exits without tasks */
    return (struct qcore_task_result){0, {0, NULL}, 2};
qcore_block_12: ;
    /* checked scope 5 exits without tasks */
    return (struct qcore_task_result){0, {0, NULL}, 2};
}
int main(void) {
    (void)&qcore_task_start; (void)&qcore_task_collect; (void)&qcore_buffer_new; (void)&qcore_buffer_read; (void)&qcore_buffer_drop;
    (void)&qcore_task_fn_0;
    (void)&qcore_task_fn_1;
    struct qcore_task_context context = {0}; context.next_task = 1; context.next_buffer = 1;
    struct qcore_task_result result = qcore_task_fn_1(NULL, &context);
    qcore_task_print_result(0, result);
    return 0;
}
