
#include <stdint.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <threads.h>
#include <unistd.h>
static atomic_int second_allocated;
static void *ordered_allocate(size_t size, uint64_t task, uint64_t attempt) {
    if (attempt != 1 || (task != 1 && task != 2)) abort();
    if (task == 1) {
        alarm(5);
        while (!atomic_load_explicit(&second_allocated, memory_order_acquire)) thrd_yield();
    }
    void *pointer = malloc(size);
    if (!pointer) abort();
    fprintf(stderr, "ALLOC_TASK %llu\n", (unsigned long long)task);
    if (task == 2) atomic_store_explicit(&second_allocated, 1, memory_order_release);
    return pointer;
}
static int checked_create(thrd_t *thread, thrd_start_t worker, void *argument) {
    int status=thrd_create(thread,worker,argument);
    if(status!=thrd_success) abort();
    return status;
}
#define QCORE_BUFFER_MALLOC_FOR_TASK ordered_allocate
#define QCORE_TASK_CREATE checked_create
