typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef long int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino_t ino_t;
typedef __dev_t dev_t;
typedef __gid_t gid_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __uid_t uid_t;
typedef __off_t off_t;
typedef __pid_t pid_t;
typedef __id_t id_t;
typedef __ssize_t ssize_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;

typedef __clockid_t clockid_t;
typedef __time_t time_t;
typedef __timer_t timer_t;
typedef long unsigned int size_t;
typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef int register_t __attribute__ ((__mode__ (__word__)));
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{
  return ((__uint16_t) ((((__bsx) >> 8) & 0xff) | (((__bsx) & 0xff) << 8)));
}
static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{
  return ((((__bsx) & 0xff000000u) >> 24) | (((__bsx) & 0x00ff0000u) >> 8) | (((__bsx) & 0x0000ff00u) << 8) | (((__bsx) & 0x000000ffu) << 24));
}
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return ((((__bsx) & 0xff00000000000000ull) >> 56) | (((__bsx) & 0x00ff000000000000ull) >> 40) | (((__bsx) & 0x0000ff0000000000ull) >> 24) | (((__bsx) & 0x000000ff00000000ull) >> 8) | (((__bsx) & 0x00000000ff000000ull) << 8) | (((__bsx) & 0x0000000000ff0000ull) << 24) | (((__bsx) & 0x000000000000ff00ull) << 40) | (((__bsx) & 0x00000000000000ffull) << 56));
}
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}
static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}
static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
typedef __sigset_t sigset_t;
struct timeval
{
  __time_t tv_sec;
  __suseconds_t tv_usec;
};

struct timespec
{
  __time_t tv_sec;
  __syscall_slong_t tv_nsec;
};
typedef __suseconds_t suseconds_t;
typedef long int __fd_mask;
typedef struct
  {
    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];
  } fd_set;
typedef __fd_mask fd_mask;
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
typedef __blksize_t blksize_t;
typedef __blkcnt_t blkcnt_t;
typedef __fsblkcnt_t fsblkcnt_t;
typedef __fsfilcnt_t fsfilcnt_t;

typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;
typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
struct __pthread_mutex_s
{
  int __lock;
  unsigned int __count;
  int __owner;
  unsigned int __nusers;
  int __kind;
  short __spins;
  short __unused;
  __pthread_list_t __list;
};
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_size[2] ;
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
  unsigned int __unused_initialized_1;
  unsigned int __unused_initialized_2;
};
typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;
typedef struct
{
  int __data ;
} __once_flag;
typedef unsigned long int pthread_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
union pthread_attr_t
{
  char __size[56];
  long int __align;
};
typedef union pthread_attr_t pthread_attr_t;
typedef union
{
  struct __pthread_mutex_s __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;
typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;
typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;
typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;
typedef volatile int pthread_spinlock_t;
typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;
struct stat
  {
    __dev_t st_dev;
    __ino_t st_ino;
    __nlink_t st_nlink;
    __mode_t st_mode;
    __uid_t st_uid;
    __gid_t st_gid;
    int __pad0;
    __dev_t st_rdev;
    __off_t st_size;
    __blksize_t st_blksize;
    __blkcnt_t st_blocks;
    struct timespec st_atim;
    struct timespec st_mtim;
    struct timespec st_ctim;
    __syscall_slong_t __glibc_reserved[3];
  };
extern int stat (const char *__restrict __file,
   struct stat *__restrict __buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int fstat (int __fd, struct stat *__buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int fstatat (int __fd, const char *__restrict __file,
      struct stat *__restrict __buf, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));
extern int lstat (const char *__restrict __file,
    struct stat *__restrict __buf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int chmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int lchmod (const char *__file, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int fchmod (int __fd, __mode_t __mode) __attribute__ ((__nothrow__ ));
extern int fchmodat (int __fd, const char *__file, __mode_t __mode,
       int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
extern __mode_t umask (__mode_t __mask) __attribute__ ((__nothrow__ ));
extern int mkdir (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int mkdirat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int mknod (const char *__path, __mode_t __mode, __dev_t __dev)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int mknodat (int __fd, const char *__path, __mode_t __mode,
      __dev_t __dev) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int mkfifo (const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int mkfifoat (int __fd, const char *__path, __mode_t __mode)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int utimensat (int __fd, const char *__path,
        const struct timespec __times[2],
        int __flags)
     __attribute__ ((__nothrow__ ));
extern int futimens (int __fd, const struct timespec __times[2]) __attribute__ ((__nothrow__ ));
struct flock
  {
    short int l_type;
    short int l_whence;
    __off_t l_start;
    __off_t l_len;
    __pid_t l_pid;
  };
extern int fcntl (int __fd, int __cmd, ...);
extern int open (const char *__file, int __oflag, ...) __attribute__ ((__nonnull__ (1)));
extern int openat (int __fd, const char *__file, int __oflag, ...)
     __attribute__ ((__nonnull__ (2)));
extern int creat (const char *__file, mode_t __mode) __attribute__ ((__nonnull__ (1)));
extern int lockf (int __fd, int __cmd, off_t __len) ;
extern int posix_fadvise (int __fd, off_t __offset, off_t __len,
     int __advise) __attribute__ ((__nothrow__ ));
extern int posix_fallocate (int __fd, off_t __offset, off_t __len);
struct tm
{
  int tm_sec;
  int tm_min;
  int tm_hour;
  int tm_mday;
  int tm_mon;
  int tm_year;
  int tm_wday;
  int tm_yday;
  int tm_isdst;
  long int tm_gmtoff;
  const char *tm_zone;
};
struct itimerspec
  {
    struct timespec it_interval;
    struct timespec it_value;
  };
struct sigevent;
struct __locale_struct
{
  struct __locale_data *__locales[13];
  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;
  const char *__names[13];
};
typedef struct __locale_struct *__locale_t;

typedef __locale_t locale_t;
extern clock_t clock (void) __attribute__ ((__nothrow__ ));
extern time_t time (time_t *__timer) __attribute__ ((__nothrow__ ));
extern double difftime (time_t __time1, time_t __time0);
extern time_t mktime (struct tm *__tp) __attribute__ ((__nothrow__ ));
extern size_t strftime (char *__restrict __s, size_t __maxsize,
   const char *__restrict __format,
   const struct tm *__restrict __tp)
   __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3, 4)));
extern size_t strftime_l (char *__restrict __s, size_t __maxsize,
     const char *__restrict __format,
     const struct tm *__restrict __tp,
     locale_t __loc) __attribute__ ((__nothrow__ ));
extern struct tm *gmtime (const time_t *__timer) __attribute__ ((__nothrow__ ));
extern struct tm *localtime (const time_t *__timer) __attribute__ ((__nothrow__ ));
extern struct tm *gmtime_r (const time_t *__restrict __timer,
       struct tm *__restrict __tp) __attribute__ ((__nothrow__ ));
extern struct tm *localtime_r (const time_t *__restrict __timer,
          struct tm *__restrict __tp) __attribute__ ((__nothrow__ ));
extern char *asctime (const struct tm *__tp) __attribute__ ((__nothrow__ ));
extern char *ctime (const time_t *__timer) __attribute__ ((__nothrow__ ));
extern char *asctime_r (const struct tm *__restrict __tp,
   char *__restrict __buf) __attribute__ ((__nothrow__ ));
extern char *ctime_r (const time_t *__restrict __timer,
        char *__restrict __buf) __attribute__ ((__nothrow__ ));
extern char *__tzname[2];
extern int __daylight;
extern long int __timezone;
extern char *tzname[2];
extern void tzset (void) __attribute__ ((__nothrow__ ));
extern int daylight;
extern long int timezone;
extern time_t timegm (struct tm *__tp) __attribute__ ((__nothrow__ ));
extern time_t timelocal (struct tm *__tp) __attribute__ ((__nothrow__ ));
extern int dysize (int __year) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int nanosleep (const struct timespec *__requested_time,
        struct timespec *__remaining);
extern int clock_getres (clockid_t __clock_id, struct timespec *__res) __attribute__ ((__nothrow__ ));
extern int clock_gettime (clockid_t __clock_id, struct timespec *__tp)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int clock_settime (clockid_t __clock_id, const struct timespec *__tp)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int clock_nanosleep (clockid_t __clock_id, int __flags,
       const struct timespec *__req,
       struct timespec *__rem);
extern int clock_getcpuclockid (pid_t __pid, clockid_t *__clock_id) __attribute__ ((__nothrow__ ));
extern int timer_create (clockid_t __clock_id,
    struct sigevent *__restrict __evp,
    timer_t *__restrict __timerid) __attribute__ ((__nothrow__ ));
extern int timer_delete (timer_t __timerid) __attribute__ ((__nothrow__ ));
extern int timer_settime (timer_t __timerid, int __flags,
     const struct itimerspec *__restrict __value,
     struct itimerspec *__restrict __ovalue) __attribute__ ((__nothrow__ ));
extern int timer_gettime (timer_t __timerid, struct itimerspec *__value)
     __attribute__ ((__nothrow__ ));
extern int timer_getoverrun (timer_t __timerid) __attribute__ ((__nothrow__ ));
extern int timespec_get (struct timespec *__ts, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));

typedef __useconds_t useconds_t;
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
extern int access (const char *__name, int __type) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
extern __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ ));
extern int close (int __fd);
extern void closefrom (int __lowfd) __attribute__ ((__nothrow__ ));
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
                                                  ;
extern ssize_t write (int __fd, const void *__buf, size_t __n)
                                         ;
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset)
                                                  ;
extern ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset)
                                         ;
extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ )) ;
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ ));
extern unsigned int sleep (unsigned int __seconds);
extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ ));
extern int usleep (__useconds_t __useconds);
extern int pause (void);
extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ )) ;
extern int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
extern int chdir (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int fchdir (int __fd) __attribute__ ((__nothrow__ )) ;
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ )) ;
extern char *getwd (char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__))
                                       ;
extern int dup (int __fd) __attribute__ ((__nothrow__ )) ;
extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ ));
extern char **__environ;
extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int nice (int __inc) __attribute__ ((__nothrow__ )) ;
extern void _exit (int __status) __attribute__ ((__noreturn__));
enum
  {
    _PC_LINK_MAX,
    _PC_MAX_CANON,
    _PC_MAX_INPUT,
    _PC_NAME_MAX,
    _PC_PATH_MAX,
    _PC_PIPE_BUF,
    _PC_CHOWN_RESTRICTED,
    _PC_NO_TRUNC,
    _PC_VDISABLE,
    _PC_SYNC_IO,
    _PC_ASYNC_IO,
    _PC_PRIO_IO,
    _PC_SOCK_MAXBUF,
    _PC_FILESIZEBITS,
    _PC_REC_INCR_XFER_SIZE,
    _PC_REC_MAX_XFER_SIZE,
    _PC_REC_MIN_XFER_SIZE,
    _PC_REC_XFER_ALIGN,
    _PC_ALLOC_SIZE_MIN,
    _PC_SYMLINK_MAX,
    _PC_2_SYMLINKS
  };
enum
  {
    _SC_ARG_MAX,
    _SC_CHILD_MAX,
    _SC_CLK_TCK,
    _SC_NGROUPS_MAX,
    _SC_OPEN_MAX,
    _SC_STREAM_MAX,
    _SC_TZNAME_MAX,
    _SC_JOB_CONTROL,
    _SC_SAVED_IDS,
    _SC_REALTIME_SIGNALS,
    _SC_PRIORITY_SCHEDULING,
    _SC_TIMERS,
    _SC_ASYNCHRONOUS_IO,
    _SC_PRIORITIZED_IO,
    _SC_SYNCHRONIZED_IO,
    _SC_FSYNC,
    _SC_MAPPED_FILES,
    _SC_MEMLOCK,
    _SC_MEMLOCK_RANGE,
    _SC_MEMORY_PROTECTION,
    _SC_MESSAGE_PASSING,
    _SC_SEMAPHORES,
    _SC_SHARED_MEMORY_OBJECTS,
    _SC_AIO_LISTIO_MAX,
    _SC_AIO_MAX,
    _SC_AIO_PRIO_DELTA_MAX,
    _SC_DELAYTIMER_MAX,
    _SC_MQ_OPEN_MAX,
    _SC_MQ_PRIO_MAX,
    _SC_VERSION,
    _SC_PAGESIZE,
    _SC_RTSIG_MAX,
    _SC_SEM_NSEMS_MAX,
    _SC_SEM_VALUE_MAX,
    _SC_SIGQUEUE_MAX,
    _SC_TIMER_MAX,
    _SC_BC_BASE_MAX,
    _SC_BC_DIM_MAX,
    _SC_BC_SCALE_MAX,
    _SC_BC_STRING_MAX,
    _SC_COLL_WEIGHTS_MAX,
    _SC_EQUIV_CLASS_MAX,
    _SC_EXPR_NEST_MAX,
    _SC_LINE_MAX,
    _SC_RE_DUP_MAX,
    _SC_CHARCLASS_NAME_MAX,
    _SC_2_VERSION,
    _SC_2_C_BIND,
    _SC_2_C_DEV,
    _SC_2_FORT_DEV,
    _SC_2_FORT_RUN,
    _SC_2_SW_DEV,
    _SC_2_LOCALEDEF,
    _SC_PII,
    _SC_PII_XTI,
    _SC_PII_SOCKET,
    _SC_PII_INTERNET,
    _SC_PII_OSI,
    _SC_POLL,
    _SC_SELECT,
    _SC_UIO_MAXIOV,
    _SC_IOV_MAX = _SC_UIO_MAXIOV,
    _SC_PII_INTERNET_STREAM,
    _SC_PII_INTERNET_DGRAM,
    _SC_PII_OSI_COTS,
    _SC_PII_OSI_CLTS,
    _SC_PII_OSI_M,
    _SC_T_IOV_MAX,
    _SC_THREADS,
    _SC_THREAD_SAFE_FUNCTIONS,
    _SC_GETGR_R_SIZE_MAX,
    _SC_GETPW_R_SIZE_MAX,
    _SC_LOGIN_NAME_MAX,
    _SC_TTY_NAME_MAX,
    _SC_THREAD_DESTRUCTOR_ITERATIONS,
    _SC_THREAD_KEYS_MAX,
    _SC_THREAD_STACK_MIN,
    _SC_THREAD_THREADS_MAX,
    _SC_THREAD_ATTR_STACKADDR,
    _SC_THREAD_ATTR_STACKSIZE,
    _SC_THREAD_PRIORITY_SCHEDULING,
    _SC_THREAD_PRIO_INHERIT,
    _SC_THREAD_PRIO_PROTECT,
    _SC_THREAD_PROCESS_SHARED,
    _SC_NPROCESSORS_CONF,
    _SC_NPROCESSORS_ONLN,
    _SC_PHYS_PAGES,
    _SC_AVPHYS_PAGES,
    _SC_ATEXIT_MAX,
    _SC_PASS_MAX,
    _SC_XOPEN_VERSION,
    _SC_XOPEN_XCU_VERSION,
    _SC_XOPEN_UNIX,
    _SC_XOPEN_CRYPT,
    _SC_XOPEN_ENH_I18N,
    _SC_XOPEN_SHM,
    _SC_2_CHAR_TERM,
    _SC_2_C_VERSION,
    _SC_2_UPE,
    _SC_XOPEN_XPG2,
    _SC_XOPEN_XPG3,
    _SC_XOPEN_XPG4,
    _SC_CHAR_BIT,
    _SC_CHAR_MAX,
    _SC_CHAR_MIN,
    _SC_INT_MAX,
    _SC_INT_MIN,
    _SC_LONG_BIT,
    _SC_WORD_BIT,
    _SC_MB_LEN_MAX,
    _SC_NZERO,
    _SC_SSIZE_MAX,
    _SC_SCHAR_MAX,
    _SC_SCHAR_MIN,
    _SC_SHRT_MAX,
    _SC_SHRT_MIN,
    _SC_UCHAR_MAX,
    _SC_UINT_MAX,
    _SC_ULONG_MAX,
    _SC_USHRT_MAX,
    _SC_NL_ARGMAX,
    _SC_NL_LANGMAX,
    _SC_NL_MSGMAX,
    _SC_NL_NMAX,
    _SC_NL_SETMAX,
    _SC_NL_TEXTMAX,
    _SC_XBS5_ILP32_OFF32,
    _SC_XBS5_ILP32_OFFBIG,
    _SC_XBS5_LP64_OFF64,
    _SC_XBS5_LPBIG_OFFBIG,
    _SC_XOPEN_LEGACY,
    _SC_XOPEN_REALTIME,
    _SC_XOPEN_REALTIME_THREADS,
    _SC_ADVISORY_INFO,
    _SC_BARRIERS,
    _SC_BASE,
    _SC_C_LANG_SUPPORT,
    _SC_C_LANG_SUPPORT_R,
    _SC_CLOCK_SELECTION,
    _SC_CPUTIME,
    _SC_THREAD_CPUTIME,
    _SC_DEVICE_IO,
    _SC_DEVICE_SPECIFIC,
    _SC_DEVICE_SPECIFIC_R,
    _SC_FD_MGMT,
    _SC_FIFO,
    _SC_PIPE,
    _SC_FILE_ATTRIBUTES,
    _SC_FILE_LOCKING,
    _SC_FILE_SYSTEM,
    _SC_MONOTONIC_CLOCK,
    _SC_MULTI_PROCESS,
    _SC_SINGLE_PROCESS,
    _SC_NETWORKING,
    _SC_READER_WRITER_LOCKS,
    _SC_SPIN_LOCKS,
    _SC_REGEXP,
    _SC_REGEX_VERSION,
    _SC_SHELL,
    _SC_SIGNALS,
    _SC_SPAWN,
    _SC_SPORADIC_SERVER,
    _SC_THREAD_SPORADIC_SERVER,
    _SC_SYSTEM_DATABASE,
    _SC_SYSTEM_DATABASE_R,
    _SC_TIMEOUTS,
    _SC_TYPED_MEMORY_OBJECTS,
    _SC_USER_GROUPS,
    _SC_USER_GROUPS_R,
    _SC_2_PBS,
    _SC_2_PBS_ACCOUNTING,
    _SC_2_PBS_LOCATE,
    _SC_2_PBS_MESSAGE,
    _SC_2_PBS_TRACK,
    _SC_SYMLOOP_MAX,
    _SC_STREAMS,
    _SC_2_PBS_CHECKPOINT,
    _SC_V6_ILP32_OFF32,
    _SC_V6_ILP32_OFFBIG,
    _SC_V6_LP64_OFF64,
    _SC_V6_LPBIG_OFFBIG,
    _SC_HOST_NAME_MAX,
    _SC_TRACE,
    _SC_TRACE_EVENT_FILTER,
    _SC_TRACE_INHERIT,
    _SC_TRACE_LOG,
    _SC_LEVEL1_ICACHE_SIZE,
    _SC_LEVEL1_ICACHE_ASSOC,
    _SC_LEVEL1_ICACHE_LINESIZE,
    _SC_LEVEL1_DCACHE_SIZE,
    _SC_LEVEL1_DCACHE_ASSOC,
    _SC_LEVEL1_DCACHE_LINESIZE,
    _SC_LEVEL2_CACHE_SIZE,
    _SC_LEVEL2_CACHE_ASSOC,
    _SC_LEVEL2_CACHE_LINESIZE,
    _SC_LEVEL3_CACHE_SIZE,
    _SC_LEVEL3_CACHE_ASSOC,
    _SC_LEVEL3_CACHE_LINESIZE,
    _SC_LEVEL4_CACHE_SIZE,
    _SC_LEVEL4_CACHE_ASSOC,
    _SC_LEVEL4_CACHE_LINESIZE,
    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,
    _SC_RAW_SOCKETS,
    _SC_V7_ILP32_OFF32,
    _SC_V7_ILP32_OFFBIG,
    _SC_V7_LP64_OFF64,
    _SC_V7_LPBIG_OFFBIG,
    _SC_SS_REPL_MAX,
    _SC_TRACE_EVENT_NAME_MAX,
    _SC_TRACE_NAME_MAX,
    _SC_TRACE_SYS_MAX,
    _SC_TRACE_USER_EVENT_MAX,
    _SC_XOPEN_STREAMS,
    _SC_THREAD_ROBUST_PRIO_INHERIT,
    _SC_THREAD_ROBUST_PRIO_PROTECT,
    _SC_MINSIGSTKSZ,
    _SC_SIGSTKSZ
  };
enum
  {
    _CS_PATH,
    _CS_V6_WIDTH_RESTRICTED_ENVS,
    _CS_GNU_LIBC_VERSION,
    _CS_GNU_LIBPTHREAD_VERSION,
    _CS_V5_WIDTH_RESTRICTED_ENVS,
    _CS_V7_WIDTH_RESTRICTED_ENVS,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS,
    _CS_LFS_LIBS,
    _CS_LFS_LINTFLAGS,
    _CS_LFS64_CFLAGS,
    _CS_LFS64_LDFLAGS,
    _CS_LFS64_LIBS,
    _CS_LFS64_LINTFLAGS,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS,
    _CS_XBS5_ILP32_OFF32_LIBS,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,
    _CS_XBS5_ILP32_OFFBIG_LIBS,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,
    _CS_XBS5_LP64_OFF64_CFLAGS,
    _CS_XBS5_LP64_OFF64_LDFLAGS,
    _CS_XBS5_LP64_OFF64_LIBS,
    _CS_XBS5_LP64_OFF64_LINTFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_LIBS,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_LIBS,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,
    _CS_POSIX_V6_LP64_OFF64_LIBS,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_LIBS,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,
    _CS_POSIX_V7_LP64_OFF64_LIBS,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,
    _CS_V6_ENV,
    _CS_V7_ENV
  };
extern long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ ));
extern long int sysconf (int __name) __attribute__ ((__nothrow__ ));
extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ ))
                                                  ;
extern __pid_t getpid (void) __attribute__ ((__nothrow__ ));
extern __pid_t getppid (void) __attribute__ ((__nothrow__ ));
extern __pid_t getpgrp (void) __attribute__ ((__nothrow__ ));
extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ ));
extern int setpgrp (void) __attribute__ ((__nothrow__ ));
extern __pid_t setsid (void) __attribute__ ((__nothrow__ ));
extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern __uid_t getuid (void) __attribute__ ((__nothrow__ ));
extern __uid_t geteuid (void) __attribute__ ((__nothrow__ ));
extern __gid_t getgid (void) __attribute__ ((__nothrow__ ));
extern __gid_t getegid (void) __attribute__ ((__nothrow__ ));
extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ ))
                                                  ;
extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__ )) ;
extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ )) ;
extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ )) ;
extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__ )) ;
extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ )) ;
extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__ )) ;
extern __pid_t fork (void) __attribute__ ((__nothrow__));
extern __pid_t vfork (void) __attribute__ ((__nothrow__ ));
extern char *ttyname (int __fd) __attribute__ ((__nothrow__ ));
extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                                   ;
extern int isatty (int __fd) __attribute__ ((__nothrow__ ));
extern int ttyslot (void) __attribute__ ((__nothrow__ ));
extern int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4))) ;
extern int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)))
                                                   ;
extern int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3))) ;
extern ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)))
                                                   ;
extern int unlink (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int rmdir (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ ));
extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ ));
extern char *getlogin (void);
extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern int setlogin (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *optarg;
extern int optind;
extern int opterr;
extern int optopt;
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int sethostid (long int __id) __attribute__ ((__nothrow__ )) ;
extern int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                   ;
extern int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int vhangup (void) __attribute__ ((__nothrow__ ));
extern int revoke (const char *__file) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int acct (const char *__name) __attribute__ ((__nothrow__ ));
extern char *getusershell (void) __attribute__ ((__nothrow__ ));
extern void endusershell (void) __attribute__ ((__nothrow__ ));
extern void setusershell (void) __attribute__ ((__nothrow__ ));
extern int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ )) ;
extern int chroot (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));
extern int fsync (int __fd);
extern long int gethostid (void);
extern void sync (void) __attribute__ ((__nothrow__ ));
extern int getpagesize (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int getdtablesize (void) __attribute__ ((__nothrow__ ));
extern int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ )) ;
extern int brk (void *__addr) __attribute__ ((__nothrow__ )) ;
extern void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ ));
extern long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ ));
extern int fdatasync (int __fildes);
extern char *crypt (const char *__key, const char *__salt)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
int getentropy (void *__buffer, size_t __length)
                                          ;
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void *memset_explicit (void *__s, int __c, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;
extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
                                         ;
extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                          ;
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;

typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;

struct sched_param
{
  int sched_priority;
};
typedef unsigned long int __cpu_mask;
typedef struct
{
  __cpu_mask __bits[1024 / (8 * sizeof (__cpu_mask))];
} cpu_set_t;
extern int __sched_cpucount (size_t __setsize, const cpu_set_t *__setp)
     __attribute__ ((__nothrow__ ));
extern cpu_set_t *__sched_cpualloc (size_t __count) __attribute__ ((__nothrow__ )) ;
extern void __sched_cpufree (cpu_set_t *__set) __attribute__ ((__nothrow__ ));
extern int sched_setparam (__pid_t __pid, const struct sched_param *__param)
     __attribute__ ((__nothrow__ ));
extern int sched_getparam (__pid_t __pid, struct sched_param *__param) __attribute__ ((__nothrow__ ));
extern int sched_setscheduler (__pid_t __pid, int __policy,
          const struct sched_param *__param) __attribute__ ((__nothrow__ ));
extern int sched_getscheduler (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern int sched_yield (void) __attribute__ ((__nothrow__ ));
extern int sched_get_priority_max (int __algorithm) __attribute__ ((__nothrow__ ));
extern int sched_get_priority_min (int __algorithm) __attribute__ ((__nothrow__ ));
extern int sched_rr_get_interval (__pid_t __pid, struct timespec *__t) __attribute__ ((__nothrow__ ));
typedef long int __jmp_buf[8];
struct __jmp_buf_tag
  {
    __jmp_buf __jmpbuf;
    int __mask_was_saved;
    __sigset_t __saved_mask;
  };

enum
{
  PTHREAD_CREATE_JOINABLE,
  PTHREAD_CREATE_DETACHED
};
enum
{
  PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_ADAPTIVE_NP
  ,
  PTHREAD_MUTEX_NORMAL = PTHREAD_MUTEX_TIMED_NP,
  PTHREAD_MUTEX_RECURSIVE = PTHREAD_MUTEX_RECURSIVE_NP,
  PTHREAD_MUTEX_ERRORCHECK = PTHREAD_MUTEX_ERRORCHECK_NP,
  PTHREAD_MUTEX_DEFAULT = PTHREAD_MUTEX_NORMAL
};
enum
{
  PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_STALLED_NP = PTHREAD_MUTEX_STALLED,
  PTHREAD_MUTEX_ROBUST,
  PTHREAD_MUTEX_ROBUST_NP = PTHREAD_MUTEX_ROBUST
};
enum
{
  PTHREAD_PRIO_NONE,
  PTHREAD_PRIO_INHERIT,
  PTHREAD_PRIO_PROTECT
};
enum
{
  PTHREAD_RWLOCK_PREFER_READER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NP,
  PTHREAD_RWLOCK_PREFER_WRITER_NONRECURSIVE_NP,
  PTHREAD_RWLOCK_DEFAULT_NP = PTHREAD_RWLOCK_PREFER_READER_NP
};
enum
{
  PTHREAD_INHERIT_SCHED,
  PTHREAD_EXPLICIT_SCHED
};
enum
{
  PTHREAD_SCOPE_SYSTEM,
  PTHREAD_SCOPE_PROCESS
};
enum
{
  PTHREAD_PROCESS_PRIVATE,
  PTHREAD_PROCESS_SHARED
};
struct _pthread_cleanup_buffer
{
  void (*__routine) (void *);
  void *__arg;
  int __canceltype;
  struct _pthread_cleanup_buffer *__prev;
};
enum
{
  PTHREAD_CANCEL_ENABLE,
  PTHREAD_CANCEL_DISABLE
};
enum
{
  PTHREAD_CANCEL_DEFERRED,
  PTHREAD_CANCEL_ASYNCHRONOUS
};
extern int pthread_create (pthread_t *__restrict __newthread,
      const pthread_attr_t *__restrict __attr,
      void *(*__start_routine) (void *),
      void *__restrict __arg) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 3)));
extern void pthread_exit (void *__retval) __attribute__ ((__noreturn__));
extern int pthread_join (pthread_t __th, void **__thread_return);
extern int pthread_detach (pthread_t __th) __attribute__ ((__nothrow__ ));
extern pthread_t pthread_self (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int pthread_equal (pthread_t __thread1, pthread_t __thread2)
  __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int pthread_attr_init (pthread_attr_t *__attr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_destroy (pthread_attr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getdetachstate (const pthread_attr_t *__attr,
     int *__detachstate)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setdetachstate (pthread_attr_t *__attr,
     int __detachstate)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getguardsize (const pthread_attr_t *__attr,
          size_t *__guardsize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setguardsize (pthread_attr_t *__attr,
          size_t __guardsize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getschedparam (const pthread_attr_t *__restrict __attr,
           struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setschedparam (pthread_attr_t *__restrict __attr,
           const struct sched_param *__restrict
           __param) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_getschedpolicy (const pthread_attr_t *__restrict
     __attr, int *__restrict __policy)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setschedpolicy (pthread_attr_t *__attr, int __policy)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getinheritsched (const pthread_attr_t *__restrict
      __attr, int *__restrict __inherit)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setinheritsched (pthread_attr_t *__attr,
      int __inherit)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getscope (const pthread_attr_t *__restrict __attr,
      int *__restrict __scope)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setscope (pthread_attr_t *__attr, int __scope)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getstackaddr (const pthread_attr_t *__restrict
          __attr, void **__restrict __stackaddr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) __attribute__ ((__deprecated__));
extern int pthread_attr_setstackaddr (pthread_attr_t *__attr,
          void *__stackaddr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__));
extern int pthread_attr_getstacksize (const pthread_attr_t *__restrict
          __attr, size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_attr_setstacksize (pthread_attr_t *__attr,
          size_t __stacksize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_attr_getstack (const pthread_attr_t *__restrict __attr,
      void **__restrict __stackaddr,
      size_t *__restrict __stacksize)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int pthread_attr_setstack (pthread_attr_t *__attr, void *__stackaddr,
      size_t __stacksize) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_setschedparam (pthread_t __target_thread, int __policy,
      const struct sched_param *__param)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3)));
extern int pthread_getschedparam (pthread_t __target_thread,
      int *__restrict __policy,
      struct sched_param *__restrict __param)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern int pthread_setschedprio (pthread_t __target_thread, int __prio)
     __attribute__ ((__nothrow__ ));
extern int pthread_once (pthread_once_t *__once_control,
    void (*__init_routine) (void)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_setcancelstate (int __state, int *__oldstate);
extern int pthread_setcanceltype (int __type, int *__oldtype);
extern int pthread_cancel (pthread_t __th);
extern void pthread_testcancel (void);
struct __cancel_jmp_buf_tag
{
  __jmp_buf __cancel_jmp_buf;
  int __mask_was_saved;
};
typedef struct
{
  struct __cancel_jmp_buf_tag __cancel_jmp_buf[1];
  void *__pad[4];
} __pthread_unwind_buf_t __attribute__ ((__aligned__));
struct __pthread_cleanup_frame
{
  void (*__cancel_routine) (void *);
  void *__cancel_arg;
  int __do_it;
  int __cancel_type;
};
extern void __pthread_register_cancel (__pthread_unwind_buf_t *__buf)
                            ;
extern void __pthread_unregister_cancel (__pthread_unwind_buf_t *__buf)
                         ;
extern void __pthread_unwind_next (__pthread_unwind_buf_t *__buf)
                             __attribute__ ((__noreturn__))
     __attribute__ ((__weak__))
     ;
extern int __sigsetjmp (struct __jmp_buf_tag __env[1],
   int __savemask) __attribute__ ((__nothrow__));
extern int pthread_mutex_init (pthread_mutex_t *__mutex,
          const pthread_mutexattr_t *__mutexattr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_destroy (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_trylock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_lock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_timedlock (pthread_mutex_t *__restrict __mutex,
        const struct timespec *__restrict
        __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutex_unlock (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutex_getprioceiling (const pthread_mutex_t *
      __restrict __mutex,
      int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutex_setprioceiling (pthread_mutex_t *__restrict __mutex,
      int __prioceiling,
      int *__restrict __old_ceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3)));
extern int pthread_mutex_consistent (pthread_mutex_t *__mutex)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_init (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_destroy (pthread_mutexattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getpshared (const pthread_mutexattr_t *
      __restrict __attr,
      int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setpshared (pthread_mutexattr_t *__attr,
      int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_gettype (const pthread_mutexattr_t *__restrict
          __attr, int *__restrict __kind)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getprotocol (const pthread_mutexattr_t *
       __restrict __attr,
       int *__restrict __protocol)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setprotocol (pthread_mutexattr_t *__attr,
       int __protocol)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getprioceiling (const pthread_mutexattr_t *
          __restrict __attr,
          int *__restrict __prioceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setprioceiling (pthread_mutexattr_t *__attr,
          int __prioceiling)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_mutexattr_getrobust (const pthread_mutexattr_t *__attr,
     int *__robustness)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_mutexattr_setrobust (pthread_mutexattr_t *__attr,
     int __robustness)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_init (pthread_rwlock_t *__restrict __rwlock,
    const pthread_rwlockattr_t *__restrict
    __attr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_destroy (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_rdlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_tryrdlock (pthread_rwlock_t *__rwlock)
  __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_timedrdlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlock_wrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_trywrlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlock_timedwrlock (pthread_rwlock_t *__restrict __rwlock,
           const struct timespec *__restrict
           __abstime) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlock_unlock (pthread_rwlock_t *__rwlock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_init (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_destroy (pthread_rwlockattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_getpshared (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlockattr_setpshared (pthread_rwlockattr_t *__attr,
       int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_rwlockattr_getkind_np (const pthread_rwlockattr_t *
       __restrict __attr,
       int *__restrict __pref)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_rwlockattr_setkind_np (pthread_rwlockattr_t *__attr,
       int __pref) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_init (pthread_cond_t *__restrict __cond,
         const pthread_condattr_t *__restrict __cond_attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_destroy (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_signal (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_broadcast (pthread_cond_t *__cond)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_cond_wait (pthread_cond_t *__restrict __cond,
         pthread_mutex_t *__restrict __mutex)
     __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_cond_timedwait (pthread_cond_t *__restrict __cond,
       pthread_mutex_t *__restrict __mutex,
       const struct timespec *__restrict __abstime)
     __attribute__ ((__nonnull__ (1, 2, 3)));
extern int pthread_condattr_init (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_condattr_destroy (pthread_condattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_condattr_getpshared (const pthread_condattr_t *
     __restrict __attr,
     int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_condattr_setpshared (pthread_condattr_t *__attr,
     int __pshared) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_condattr_getclock (const pthread_condattr_t *
          __restrict __attr,
          __clockid_t *__restrict __clock_id)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_condattr_setclock (pthread_condattr_t *__attr,
          __clockid_t __clock_id)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_init (pthread_spinlock_t *__lock, int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_destroy (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_lock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_trylock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_spin_unlock (pthread_spinlock_t *__lock)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrier_init (pthread_barrier_t *__restrict __barrier,
     const pthread_barrierattr_t *__restrict
     __attr, unsigned int __count)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrier_destroy (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrier_wait (pthread_barrier_t *__barrier)
     __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrierattr_init (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrierattr_destroy (pthread_barrierattr_t *__attr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_barrierattr_getpshared (const pthread_barrierattr_t *
        __restrict __attr,
        int *__restrict __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int pthread_barrierattr_setpshared (pthread_barrierattr_t *__attr,
        int __pshared)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_key_create (pthread_key_t *__key,
          void (*__destr_function) (void *))
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pthread_key_delete (pthread_key_t __key) __attribute__ ((__nothrow__ ));
extern void *pthread_getspecific (pthread_key_t __key) __attribute__ ((__nothrow__ ));
extern int pthread_setspecific (pthread_key_t __key,
    const void *__pointer)
  __attribute__ ((__nothrow__ )) ;
extern int pthread_getcpuclockid (pthread_t __thread_id,
      __clockid_t *__clock_id)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int pthread_atfork (void (*__prepare) (void),
      void (*__parent) (void),
      void (*__child) (void)) __attribute__ ((__nothrow__ ));
typedef __builtin_va_list __gnuc_va_list;
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
struct _IO_FILE;
typedef struct _IO_FILE __FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;
typedef void _IO_lock_t;
struct _IO_FILE
{
  int _flags;
  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;
  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;
  struct _IO_marker *_markers;
  struct _IO_FILE *_chain;
  int _fileno;
  int _flags2:24;
  char _short_backupbuf[1];
  __off_t _old_offset;
  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];
  _IO_lock_t *_lock;
  __off64_t _offset;
  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;
  int _unused3;
  __uint64_t _total_written;
  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);
typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);
typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);
typedef int cookie_close_function_t (void *__cookie);
typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
typedef __gnuc_va_list va_list;
typedef __fpos_t fpos_t;
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;
extern int remove (const char *__filename) __attribute__ ((__nothrow__ ));
extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ ));
extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ ));
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) ;
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ )) ;
extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ )) ;
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;
extern int fflush (FILE *__stream);
extern int fflush_unlocked (FILE *__stream);
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) ;
extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;
extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ ))
  __attribute__ ((__nonnull__ (1)));
extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));
extern int printf (const char *__restrict __format, ...);
extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));
extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));
extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);
extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));
extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));
extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) ;
extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ ));
typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__)));
typedef __float128 _Float128;
typedef float _Float32;
typedef double _Float64;
typedef double _Float32x;
typedef long double _Float64x;
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf") __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf") ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ ));
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__format__ (__scanf__, 2, 0)));
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ ))
     __attribute__ ((__format__ (__scanf__, 2, 0)));
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar (void);
extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar (int __c);
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
                                                          __attribute__ ((__nonnull__ (3)));
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));
extern int puts (const char *__s);
extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int feof (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void perror (const char *__s) __attribute__ ((__cold__));
extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) ;
extern char *ctermid (char *__s) __attribute__ ((__nothrow__ ))
                                     ;
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
struct iovec
  {
    void *iov_base;
    size_t iov_len;
  };
extern ssize_t readv (int __fd, const struct iovec *__iovec, int __count)
                                             ;
extern ssize_t writev (int __fd, const struct iovec *__iovec, int __count)
                                             ;
extern ssize_t preadv (int __fd, const struct iovec *__iovec, int __count,
         __off_t __offset)
                                             ;
extern ssize_t pwritev (int __fd, const struct iovec *__iovec, int __count,
   __off_t __offset)
                                             ;
typedef int wchar_t;
typedef struct
  {
    int quot;
    int rem;
  } div_t;
typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;
__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ )) ;
extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *l64a (long int __n) __attribute__ ((__nothrow__ )) ;
extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern long int random (void) __attribute__ ((__nothrow__ ));
extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ ));
extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };
extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)));
extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int rand (void) __attribute__ ((__nothrow__ ));
extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ ));
extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ ));
extern double drand48 (void) __attribute__ ((__nothrow__ ));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int lrand48 (void) __attribute__ ((__nothrow__ ));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int mrand48 (void) __attribute__ ((__nothrow__ ));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ ));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;
  };
extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ )) ;
extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ )) ;
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;
extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;
extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__)) ;
extern void free (void *__ptr) __attribute__ ((__nothrow__ ));
extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__))
                       ;
extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) ;
extern void *alloca (size_t __size) __attribute__ ((__nothrow__ ));
extern void *valloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
                                         ;
extern void abort (void) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__)) __attribute__ ((__cold__));
extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));
extern void quick_exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));
extern void _Exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));
extern char *getenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int putenv (char *__string) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int clearenv (void) __attribute__ ((__nothrow__ ));
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int system (const char *__command) ;
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ )) ;
typedef int (*__compar_fn_t) (const void *, const void *);
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
extern int abs (int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;
extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;
extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ ));
extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ));
extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ ));
extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ))
                                      ;
extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ ))
                                    ;
extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3))) ;
extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int *__errno_location (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
void mk_print(int type, const char *format, ...) __attribute__ ((format (printf, 2, 3)));
extern pthread_key_t mk_utils_error_key;
static inline void mk_utils_libc_error(char *caller, char *file, int line)
{
    char buf[128]; int _err; _err = (*__errno_location ()); if (strerror_r(_err, buf, 128) != 0) { mk_print(0X1001, "strerror_r() failed"); };
    mk_print(0X1001, "%s: %s, errno=%i at %s:%i", caller, buf, _err, file, line);
}
static inline void mk_utils_libc_warn(char *caller, char *file, int line)
{
    char buf[128]; int _err; _err = (*__errno_location ()); if (strerror_r(_err, buf, 128) != 0) { mk_print(0X1001, "strerror_r() failed"); };
    mk_print(0x1002, "%s: %s, errno=%i at %s:%i", caller, buf, _err, file, line);
}
int mk_utils_worker_spawn(void (*func) (void *), void *arg, pthread_t *tid);
int mk_utils_worker_rename(const char *title);
int mk_utils_set_daemon();
int mk_utils_register_pid(char *path);
int mk_utils_remove_pid(char *path);
int mk_core_init();
typedef struct
{
    char *data;
    unsigned long len;
} mk_ptr_t;
static inline
void *mk_mem_alloc(const size_t size)
{
    void *aux = malloc(size);
    if (__builtin_expect((!aux && size),0)) {
        perror("malloc");
        return ((void*)0);
    }
    return aux;
}
static inline
void *mk_mem_alloc_z(const size_t size)
{
    void *buf = calloc(1, size);
    if (__builtin_expect((!buf),0)) {
        return ((void*)0);
    }
    return buf;
}
static inline
void *mk_mem_realloc(void *ptr, const size_t size)
{
    void *aux = realloc(ptr, size);
    if (__builtin_expect((!aux && size),0)) {
        perror("realloc");
        return ((void*)0);
    }
    return aux;
}
static inline void mk_mem_free(void *ptr)
{
    free(ptr);
}
void mk_mem_free(void *ptr);
void mk_mem_pointers_init(void);
mk_ptr_t mk_ptr_create(char *buf, long init, long end);
void mk_ptr_free(mk_ptr_t * p);
void mk_ptr_print(mk_ptr_t p);
char *mk_ptr_to_buf(mk_ptr_t p);
void mk_ptr_set(mk_ptr_t * p, char *data);
static inline void mk_ptr_reset(mk_ptr_t * p)
{
    p->data = ((void*)0);
    p->len = 0;
}

extern const mk_ptr_t mk_iov_crlf;
extern const mk_ptr_t mk_iov_lf;
extern const mk_ptr_t mk_iov_space;
extern const mk_ptr_t mk_iov_slash;
extern const mk_ptr_t mk_iov_none;
extern const mk_ptr_t mk_iov_equal;
struct mk_iov {
    int iov_idx;
    int buf_idx;
    int size;
    unsigned long total_len;
    struct iovec *io;
    void **buf_to_free;
};
struct mk_iov *mk_iov_create(int n, int offset);
struct mk_iov *mk_iov_realloc(struct mk_iov *mk_io, int new_size);
int mk_iov_add_separator(struct mk_iov *mk_io, mk_ptr_t sep);
ssize_t mk_iov_send(int fd, struct mk_iov *mk_io);
void mk_iov_free(struct mk_iov *mk_io);
int _mk_iov_add(struct mk_iov *mk_io, void *buf, int len,
                mk_ptr_t sep, int free, int idx);
int mk_iov_set_entry(struct mk_iov *mk_io, void *buf, int len,
                     int free, int idx);
void mk_iov_separators_init(void);
void mk_iov_free_marked(struct mk_iov *mk_io);
void mk_iov_print(struct mk_iov *mk_io);
int mk_iov_consume(struct mk_iov *mk_io, size_t bytes);
static inline int mk_iov_init(struct mk_iov *iov, int n, int offset)
{
    int i;
    iov->iov_idx = offset;
    iov->buf_idx = 0;
    iov->total_len = 0;
    iov->size = n;
    if (offset > 0) {
        for (i = 0; i < offset; i++) {
            iov->io[i].iov_base = ((void*)0);
            iov->io[i].iov_len = 0;
        }
    }
    return 0;
}
static inline void _mk_iov_set_free(struct mk_iov *mk_io, void *buf)
{
    mk_io->buf_to_free[mk_io->buf_idx] = (void *) buf;
    mk_io->buf_idx++;
}
static inline int mk_iov_add(struct mk_iov *mk_io, void *buf, int len,
                             int free)
{
    mk_io->io[mk_io->iov_idx].iov_base = (unsigned char *) buf;
    mk_io->io[mk_io->iov_idx].iov_len = len;
    mk_io->iov_idx++;
    mk_io->total_len += len;
    if (free == !0) {
        _mk_iov_set_free(mk_io, buf);
    }
    if (mk_io->iov_idx > mk_io->size) {
        do {} while (0);
        return -1;
    }
    return mk_io->iov_idx;
}

typedef long int ptrdiff_t;
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
struct mk_list
{
    struct mk_list *prev, *next;
};
static inline void mk_list_init(struct mk_list *list)
{
    list->next = list;
    list->prev = list;
}
static inline void __mk_list_add(struct mk_list *_new, struct mk_list *prev,
                                 struct mk_list *next)
{
    next->prev = _new;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
}
static inline void mk_list_add(struct mk_list *_new, struct mk_list *head)
{
    __mk_list_add(_new, head->prev, head);
}
static inline void mk_list_add_after(struct mk_list *_new,
                                     struct mk_list *prev,
                                     struct mk_list *head)
{
    struct mk_list *next;
    if (head->prev == head->next || head->prev == prev) {
        mk_list_add(_new, head);
        return;
    }
    next = prev->next;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
    next->prev = _new;
}
static inline int mk_list_is_empty(struct mk_list *head)
{
    if (head->next == head) return 0;
    else return -1;
}
static inline void mk_list_add_before(struct mk_list *_new,
                                      struct mk_list *next,
                                      struct mk_list *head)
{
    struct mk_list *prev;
    if (_new == ((void*)0) || next == ((void*)0) || head == ((void*)0)) {
        return;
    }
    if (mk_list_is_empty(head) == 0 ||
        next == head) {
        mk_list_add(_new, head);
        return;
    }
    prev = next->prev;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
    next->prev = _new;
}
static inline void mk_list_append(struct mk_list *_new, struct mk_list *head)
{
    if (mk_list_is_empty(head) == 0) {
        __mk_list_add(_new, head->prev, head);
    }
    else {
        mk_list_add_after(_new,
                          head->prev,
                          head);
    }
}
static inline void mk_list_prepend(struct mk_list *_new, struct mk_list *head)
{
    if (mk_list_is_empty(head) == 0) {
        __mk_list_add(_new, head->prev, head);
    }
    else {
        mk_list_add_before(_new,
                           head->next,
                           head);
    }
}
static inline void __mk_list_del(struct mk_list *prev, struct mk_list *next)
{
    prev->next = next;
    next->prev = prev;
}
static inline void mk_list_del(struct mk_list *entry)
{
    __mk_list_del(entry->prev, entry->next);
    entry->prev = ((void*)0);
    entry->next = ((void*)0);
}
static inline int mk_list_is_set(struct mk_list *head)
{
    if (head->next && head->prev) {
        return 0;
    }
    return -1;
}
static inline int mk_list_size(struct mk_list *head)
{
    int ret = 0;
    struct mk_list *it;
    for (it = head->next; it != head; it = it->next, ret++);
    return ret;
}
static inline void mk_list_entry_init(struct mk_list *list)
{
    list->next = ((void*)0);
    list->prev = ((void*)0);
}
static inline int mk_list_entry_is_orphan(struct mk_list *head)
{
    if (head->next != ((void*)0) &&
        head->prev != ((void*)0)) {
        return 0;
    }
    return !0;
}
static inline int mk_list_entry_orphan(struct mk_list *head)
{
    if (head->next && head->prev) {
        return 0;
    }
    return -1;
}
static inline void mk_list_cat(struct mk_list *list, struct mk_list *head)
{
    struct mk_list *last;
    last = head->prev;
    last->next = list->next;
    list->next->prev = last;
    list->prev->next = head;
    head->prev = list->prev;
}

struct option
{
  const char *name;
  int has_arg;
  int *flag;
  int val;
};
extern int getopt_long (int ___argc, char *const *___argv,
   const char *__shortopts,
          const struct option *__longopts, int *__longind)
       __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern int getopt_long_only (int ___argc, char *const *___argv,
        const char *__shortopts,
               const struct option *__longopts, int *__longind)
       __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
struct file_info
{
    size_t size;
    time_t last_modification;
    int flags_read_only;
    unsigned char exists;
    unsigned char is_file;
    unsigned char is_link;
    unsigned char is_directory;
    unsigned char exec_access;
    unsigned char read_access;
};
int mk_file_get_info(const char *path, struct file_info *f_info, int mode);
char *mk_file_to_buffer(const char *path);

struct winsize
  {
    unsigned short int ws_row;
    unsigned short int ws_col;
    unsigned short int ws_xpixel;
    unsigned short int ws_ypixel;
  };
extern int ioctl (int __fd, unsigned long int __request, ...) __attribute__ ((__nothrow__ ));
enum
  {
    EPOLL_CLOEXEC = 02000000
  };
enum EPOLL_EVENTS
  {
    EPOLLIN = 0x001,
    EPOLLPRI = 0x002,
    EPOLLOUT = 0x004,
    EPOLLRDNORM = 0x040,
    EPOLLRDBAND = 0x080,
    EPOLLWRNORM = 0x100,
    EPOLLWRBAND = 0x200,
    EPOLLMSG = 0x400,
    EPOLLERR = 0x008,
    EPOLLHUP = 0x010,
    EPOLLRDHUP = 0x2000,
    EPOLLEXCLUSIVE = 1u << 28,
    EPOLLWAKEUP = 1u << 29,
    EPOLLONESHOT = 1u << 30,
    EPOLLET = 1u << 31
  };
typedef union epoll_data
{
  void *ptr;
  int fd;
  uint32_t u32;
  uint64_t u64;
} epoll_data_t;
struct epoll_event
{
  uint32_t events;
  epoll_data_t data;
} __attribute__ ((__packed__));
struct epoll_params
{
  uint32_t busy_poll_usecs;
  uint16_t busy_poll_budget;
  uint8_t prefer_busy_poll;
  uint8_t __pad;
};
extern int epoll_create (int __size) __attribute__ ((__nothrow__ ));
extern int epoll_create1 (int __flags) __attribute__ ((__nothrow__ ));
extern int epoll_ctl (int __epfd, int __op, int __fd,
        struct epoll_event *__event) __attribute__ ((__nothrow__ ));
extern int epoll_wait (int __epfd, struct epoll_event *__events,
         int __maxevents, int __timeout)
                                        __attribute__ ((__nonnull__ (2)));
extern int epoll_pwait (int __epfd, struct epoll_event *__events,
   int __maxevents, int __timeout,
   const __sigset_t *__ss)
                                        __attribute__ ((__nonnull__ (2)));
extern int epoll_pwait2 (int __epfd, struct epoll_event *__events,
    int __maxevents, const struct timespec *__timeout,
    const __sigset_t *__ss)
                                        __attribute__ ((__nonnull__ (2)));
struct mk_event_ctx {
    int efd;
    int queue_size;
    struct epoll_event *events;
};
struct mk_event {
    int fd;
    int type;
    uint32_t mask;
    uint8_t status;
    void *data;
    int (*handler)(void *data);
    struct mk_list _head;
    struct mk_list _priority_head;
    char priority;
};
struct mk_event_loop {
    int size;
    int n_events;
    struct mk_event *events;
    void *data;
};
static inline void MK_EVENT_INIT(struct mk_event *ev, int fd, void *data,
                                 int (*callback)(void *))
{
    ev->fd = fd;
    ev->type = 4;
    ev->mask = 0;
    ev->status = 1;
    ev->data = data;
    ev->handler = callback;
}
static inline void MK_EVENT_ZERO(struct mk_event *e)
{
    MK_EVENT_INIT(e, -1, ((void*)0), ((void*)0));
}
static inline void MK_EVENT_NEW(struct mk_event *e)
{
    e->mask = 0;
    e->status = 1;
}
int mk_event_init();
int mk_event_initialize();
struct mk_event_loop *mk_event_loop_create(int size);
void mk_event_loop_destroy(struct mk_event_loop *loop);
int mk_event_add(struct mk_event_loop *loop, int fd,
                 int type, uint32_t mask, void *data);
int mk_event_del(struct mk_event_loop *loop, struct mk_event *event);
int mk_event_inject(struct mk_event_loop *loop, struct mk_event *event,
                    int flags, int prevent_duplication);
int mk_event_timeout_create(struct mk_event_loop *loop,
                            time_t sec, long nsec,void *data);
int mk_event_timeout_disable(struct mk_event_loop *loop, void *data);
int mk_event_timeout_destroy(struct mk_event_loop *loop, void *data);
int mk_event_channel_create(struct mk_event_loop *loop,
                            int *r_fd, int *w_fd, void *data);
int mk_event_channel_destroy(struct mk_event_loop *loop,
                             int r_fd, int w_fd, void *data);
int mk_event_wait(struct mk_event_loop *loop);
int mk_event_wait_2(struct mk_event_loop *loop, int timeout);
int mk_event_translate(struct mk_event_loop *loop);
char *mk_event_backend();
struct mk_event_fdt *mk_event_get_fdt();
struct mk_rconf_section
{
    char *name;
    struct mk_list entries;
    struct mk_list _head;
};
struct mk_rconf_entry
{
    char *key;
    char *val;
    struct mk_list _head;
};
struct mk_rconf_file
{
    char *path;
    struct mk_list _head;
};
struct mk_rconf
{
    int level;
    time_t created;
    char *file;
    char *root_path;
    struct mk_list includes;
    struct mk_list metas;
    struct mk_list sections;
};
void mk_rconf_free(struct mk_rconf *conf);
void mk_rconf_free_entries(struct mk_rconf_section *section);
struct mk_rconf *mk_rconf_open(const char *path);
struct mk_rconf *mk_rconf_create(const char *path);
struct mk_rconf_section *mk_rconf_section_add(struct mk_rconf *conf,
                                              char *name);
struct mk_rconf_section *mk_rconf_section_get(struct mk_rconf *conf,
                                              const char *name);
void *mk_rconf_section_get_key(struct mk_rconf_section *section,
                               char *key, int mode);
char *mk_rconf_meta_get(struct mk_rconf *conf, char *key);
struct mk_string_line
{
    char *val;
    int len;
    struct mk_list _head;
};
int mk_string_char_search(const char *string, int c, int len);
int mk_string_char_search_r(const char *string, int c, int len);
int mk_string_search(const char *haystack, const char *needle, int sensitive);
int mk_string_search_n(const char *haystack, const char *needle, int sensitive, int len);
char *mk_string_remove_space(char *buf);
char *mk_string_casestr(char *heystack, char *needle);
char *mk_string_dup(const char *s);
struct mk_list *mk_string_split_line(const char *line);
void mk_string_split_free(struct mk_list *list);
int mk_string_trim(char **str);
char *mk_string_build(char **buffer, unsigned long *len,
                      const char *format, ...) __attribute__ ((format (printf, 3, 4)));
char *mk_string_html_escape(const char *str);
int mk_string_itop(uint64_t value, mk_ptr_t *p);
char *mk_string_copy_substr(const char *string, int pos_init, int pos_end);
char *mk_string_tolower(const char *in);
enum __socket_type
{
  SOCK_STREAM = 1,
  SOCK_DGRAM = 2,
  SOCK_RAW = 3,
  SOCK_RDM = 4,
  SOCK_SEQPACKET = 5,
  SOCK_DCCP = 6,
  SOCK_PACKET = 10,
  SOCK_CLOEXEC = 02000000,
  SOCK_NONBLOCK = 00004000
};
typedef unsigned short int sa_family_t;
struct __attribute__ ((__may_alias__)) sockaddr
  {
    sa_family_t sa_family;
    char sa_data[14];
  };
struct __attribute__ ((__may_alias__)) sockaddr_storage
  {
    sa_family_t ss_family;
    char __ss_padding[(128 - (sizeof (unsigned short int)) - sizeof (unsigned long int))];
    unsigned long int __ss_align;
  };
enum
  {
    MSG_OOB = 0x01,
    MSG_PEEK = 0x02,
    MSG_DONTROUTE = 0x04,
    MSG_CTRUNC = 0x08,
    MSG_PROXY = 0x10,
    MSG_TRUNC = 0x20,
    MSG_DONTWAIT = 0x40,
    MSG_EOR = 0x80,
    MSG_WAITALL = 0x100,
    MSG_FIN = 0x200,
    MSG_SYN = 0x400,
    MSG_CONFIRM = 0x800,
    MSG_RST = 0x1000,
    MSG_ERRQUEUE = 0x2000,
    MSG_NOSIGNAL = 0x4000,
    MSG_MORE = 0x8000,
    MSG_WAITFORONE = 0x10000,
    MSG_BATCH = 0x40000,
    MSG_SOCK_DEVMEM = 0x2000000,
    MSG_ZEROCOPY = 0x4000000,
    MSG_FASTOPEN = 0x20000000,
    MSG_CMSG_CLOEXEC = 0x40000000
  };
struct msghdr
  {
    void *msg_name;
    socklen_t msg_namelen;
    struct iovec *msg_iov;
    size_t msg_iovlen;
    void *msg_control;
    size_t msg_controllen;
    int msg_flags;
  };
struct cmsghdr
  {
    size_t cmsg_len;
    int cmsg_level;
    int cmsg_type;
    __extension__ unsigned char __cmsg_data [];
  };
extern struct cmsghdr *__cmsg_nxthdr (struct msghdr *__mhdr,
          struct cmsghdr *__cmsg) __attribute__ ((__nothrow__ ));
enum
  {
    SCM_RIGHTS = 0x01
  };
typedef struct {
 unsigned long fds_bits[1024 / (8 * sizeof(long))];
} __kernel_fd_set;
typedef void (*__kernel_sighandler_t)(int);
typedef int __kernel_key_t;
typedef int __kernel_mqd_t;
typedef unsigned short __kernel_old_uid_t;
typedef unsigned short __kernel_old_gid_t;
typedef unsigned long __kernel_old_dev_t;
typedef long __kernel_long_t;
typedef unsigned long __kernel_ulong_t;
typedef __kernel_ulong_t __kernel_ino_t;
typedef unsigned int __kernel_mode_t;
typedef int __kernel_pid_t;
typedef int __kernel_ipc_pid_t;
typedef unsigned int __kernel_uid_t;
typedef unsigned int __kernel_gid_t;
typedef __kernel_long_t __kernel_suseconds_t;
typedef int __kernel_daddr_t;
typedef unsigned int __kernel_uid32_t;
typedef unsigned int __kernel_gid32_t;
typedef __kernel_ulong_t __kernel_size_t;
typedef __kernel_long_t __kernel_ssize_t;
typedef __kernel_long_t __kernel_ptrdiff_t;
typedef struct {
 int val[2];
} __kernel_fsid_t;
typedef __kernel_long_t __kernel_off_t;
typedef long long __kernel_loff_t;
typedef unsigned long long __kernel_uoff_t;
typedef __kernel_long_t __kernel_old_time_t;
typedef __kernel_long_t __kernel_time_t;
typedef long long __kernel_time64_t;
typedef __kernel_long_t __kernel_clock_t;
typedef int __kernel_timer_t;
typedef int __kernel_clockid_t;
typedef char * __kernel_caddr_t;
typedef unsigned short __kernel_uid16_t;
typedef unsigned short __kernel_gid16_t;
struct linger
  {
    int l_onoff;
    int l_linger;
  };
struct osockaddr
{
  unsigned short int sa_family;
  unsigned char sa_data[14];
};
enum
{
  SHUT_RD = 0,
  SHUT_WR,
  SHUT_RDWR
};
extern int socket (int __domain, int __type, int __protocol) __attribute__ ((__nothrow__ ));
extern int socketpair (int __domain, int __type, int __protocol,
         int __fds[2]) __attribute__ ((__nothrow__ ));
extern int bind (int __fd, const struct sockaddr * __addr, socklen_t __len)
     __attribute__ ((__nothrow__ ));
extern int getsockname (int __fd, struct sockaddr *__restrict __addr,
   socklen_t *__restrict __len) __attribute__ ((__nothrow__ ));
extern int connect (int __fd, const struct sockaddr * __addr, socklen_t __len);
extern int getpeername (int __fd, struct sockaddr *__restrict __addr,
   socklen_t *__restrict __len) __attribute__ ((__nothrow__ ));
extern ssize_t send (int __fd, const void *__buf, size_t __n, int __flags);
extern ssize_t recv (int __fd, void *__buf, size_t __n, int __flags);
extern ssize_t sendto (int __fd, const void *__buf, size_t __n,
         int __flags, const struct sockaddr * __addr,
         socklen_t __addr_len);
extern ssize_t recvfrom (int __fd, void *__restrict __buf, size_t __n,
    int __flags, struct sockaddr *__restrict __addr,
    socklen_t *__restrict __addr_len);
extern ssize_t sendmsg (int __fd, const struct msghdr *__message,
   int __flags);
extern ssize_t recvmsg (int __fd, struct msghdr *__message, int __flags);
extern int getsockopt (int __fd, int __level, int __optname,
         void *__restrict __optval,
         socklen_t *__restrict __optlen) __attribute__ ((__nothrow__ ));
extern int setsockopt (int __fd, int __level, int __optname,
         const void *__optval, socklen_t __optlen) __attribute__ ((__nothrow__ ));
extern int listen (int __fd, int __n) __attribute__ ((__nothrow__ ));
extern int accept (int __fd, struct sockaddr *__restrict __addr,
     socklen_t *__restrict __addr_len);
extern int shutdown (int __fd, int __how) __attribute__ ((__nothrow__ ));
extern int sockatmark (int __fd) __attribute__ ((__nothrow__ ));
extern int isfdtype (int __fd, int __fdtype) __attribute__ ((__nothrow__ ));
typedef uint32_t in_addr_t;
struct in_addr
  {
    in_addr_t s_addr;
  };
struct ip_opts
  {
    struct in_addr ip_dst;
    char ip_opts[40];
  };
struct in_pktinfo
  {
    int ipi_ifindex;
    struct in_addr ipi_spec_dst;
    struct in_addr ipi_addr;
  };
enum
  {
    IPPROTO_IP = 0,
    IPPROTO_ICMP = 1,
    IPPROTO_IGMP = 2,
    IPPROTO_IPIP = 4,
    IPPROTO_TCP = 6,
    IPPROTO_EGP = 8,
    IPPROTO_PUP = 12,
    IPPROTO_UDP = 17,
    IPPROTO_IDP = 22,
    IPPROTO_TP = 29,
    IPPROTO_DCCP = 33,
    IPPROTO_IPV6 = 41,
    IPPROTO_RSVP = 46,
    IPPROTO_GRE = 47,
    IPPROTO_ESP = 50,
    IPPROTO_AH = 51,
    IPPROTO_MTP = 92,
    IPPROTO_BEETPH = 94,
    IPPROTO_ENCAP = 98,
    IPPROTO_PIM = 103,
    IPPROTO_COMP = 108,
    IPPROTO_L2TP = 115,
    IPPROTO_SCTP = 132,
    IPPROTO_UDPLITE = 136,
    IPPROTO_MPLS = 137,
    IPPROTO_ETHERNET = 143,
    IPPROTO_RAW = 255,
    IPPROTO_SMC = 256,
    IPPROTO_MPTCP = 262,
    IPPROTO_MAX
  };
enum
  {
    IPPROTO_HOPOPTS = 0,
    IPPROTO_ROUTING = 43,
    IPPROTO_FRAGMENT = 44,
    IPPROTO_ICMPV6 = 58,
    IPPROTO_NONE = 59,
    IPPROTO_DSTOPTS = 60,
    IPPROTO_MH = 135
  };
typedef uint16_t in_port_t;
enum
  {
    IPPORT_ECHO = 7,
    IPPORT_DISCARD = 9,
    IPPORT_SYSTAT = 11,
    IPPORT_DAYTIME = 13,
    IPPORT_NETSTAT = 15,
    IPPORT_FTP = 21,
    IPPORT_TELNET = 23,
    IPPORT_SMTP = 25,
    IPPORT_TIMESERVER = 37,
    IPPORT_NAMESERVER = 42,
    IPPORT_WHOIS = 43,
    IPPORT_MTP = 57,
    IPPORT_TFTP = 69,
    IPPORT_RJE = 77,
    IPPORT_FINGER = 79,
    IPPORT_TTYLINK = 87,
    IPPORT_SUPDUP = 95,
    IPPORT_EXECSERVER = 512,
    IPPORT_LOGINSERVER = 513,
    IPPORT_CMDSERVER = 514,
    IPPORT_EFSSERVER = 520,
    IPPORT_BIFFUDP = 512,
    IPPORT_WHOSERVER = 513,
    IPPORT_ROUTESERVER = 520,
    IPPORT_RESERVED = 1024,
    IPPORT_USERRESERVED = 5000
  };
struct in6_addr
  {
    union
      {
 uint8_t __u6_addr8[16];
 uint16_t __u6_addr16[8];
 uint32_t __u6_addr32[4];
      } __in6_u;
  };
extern const struct in6_addr in6addr_any;
extern const struct in6_addr in6addr_loopback;
struct __attribute__ ((__may_alias__)) sockaddr_in
  {
    sa_family_t sin_family;
    in_port_t sin_port;
    struct in_addr sin_addr;
    unsigned char sin_zero[sizeof (struct sockaddr)
      - (sizeof (unsigned short int))
      - sizeof (in_port_t)
      - sizeof (struct in_addr)];
  };
struct __attribute__ ((__may_alias__)) sockaddr_in6
  {
    sa_family_t sin6_family;
    in_port_t sin6_port;
    uint32_t sin6_flowinfo;
    struct in6_addr sin6_addr;
    uint32_t sin6_scope_id;
  };
struct ip_mreq
  {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
  };
struct ip_mreqn
  {
    struct in_addr imr_multiaddr;
    struct in_addr imr_address;
    int imr_ifindex;
  };
struct ip_mreq_source
  {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
    struct in_addr imr_sourceaddr;
  };
struct ipv6_mreq
  {
    struct in6_addr ipv6mr_multiaddr;
    unsigned int ipv6mr_interface;
  };
struct group_req
  {
    uint32_t gr_interface;
    struct sockaddr_storage gr_group;
  };
struct group_source_req
  {
    uint32_t gsr_interface;
    struct sockaddr_storage gsr_group;
    struct sockaddr_storage gsr_source;
  };
struct ip_msfilter
  {
    struct in_addr imsf_multiaddr;
    struct in_addr imsf_interface;
    uint32_t imsf_fmode;
    uint32_t imsf_numsrc;
    struct in_addr imsf_slist[1];
  };
struct group_filter
  {
    uint32_t gf_interface;
    struct sockaddr_storage gf_group;
    uint32_t gf_fmode;
    uint32_t gf_numsrc;
    struct sockaddr_storage gf_slist[1];
};
extern uint32_t ntohl (uint32_t __netlong) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern uint16_t ntohs (uint16_t __netshort)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern uint32_t htonl (uint32_t __hostlong)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern uint16_t htons (uint16_t __hostshort)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int bindresvport (int __sockfd, struct sockaddr_in *__sock_in) __attribute__ ((__nothrow__ ));
extern int bindresvport6 (int __sockfd, struct sockaddr_in6 *__sock_in)
     __attribute__ ((__nothrow__ ));
struct rpcent
{
  char *r_name;
  char **r_aliases;
  int r_number;
};
extern void setrpcent (int __stayopen) __attribute__ ((__nothrow__ ));
extern void endrpcent (void) __attribute__ ((__nothrow__ ));
extern struct rpcent *getrpcbyname (const char *__name) __attribute__ ((__nothrow__ ));
extern struct rpcent *getrpcbynumber (int __number) __attribute__ ((__nothrow__ ));
extern struct rpcent *getrpcent (void) __attribute__ ((__nothrow__ ));
extern int getrpcbyname_r (const char *__name, struct rpcent *__result_buf,
      char *__buffer, size_t __buflen,
      struct rpcent **__result) __attribute__ ((__nothrow__ ));
extern int getrpcbynumber_r (int __number, struct rpcent *__result_buf,
        char *__buffer, size_t __buflen,
        struct rpcent **__result) __attribute__ ((__nothrow__ ));
extern int getrpcent_r (struct rpcent *__result_buf, char *__buffer,
   size_t __buflen, struct rpcent **__result) __attribute__ ((__nothrow__ ));
struct netent
{
  char *n_name;
  char **n_aliases;
  int n_addrtype;
  uint32_t n_net;
};
extern int *__h_errno_location (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern void herror (const char *__str) __attribute__ ((__nothrow__ ));
extern const char *hstrerror (int __err_num) __attribute__ ((__nothrow__ ));
struct hostent
{
  char *h_name;
  char **h_aliases;
  int h_addrtype;
  int h_length;
  char **h_addr_list;
};
extern void sethostent (int __stay_open);
extern void endhostent (void);
extern struct hostent *gethostent (void);
extern struct hostent *gethostbyaddr (const void *__addr, __socklen_t __len,
          int __type);
extern struct hostent *gethostbyname (const char *__name);
extern struct hostent *gethostbyname2 (const char *__name, int __af);
extern int gethostent_r (struct hostent *__restrict __result_buf,
    char *__restrict __buf, size_t __buflen,
    struct hostent **__restrict __result,
    int *__restrict __h_errnop);
extern int gethostbyaddr_r (const void *__restrict __addr, __socklen_t __len,
       int __type,
       struct hostent *__restrict __result_buf,
       char *__restrict __buf, size_t __buflen,
       struct hostent **__restrict __result,
       int *__restrict __h_errnop);
extern int gethostbyname_r (const char *__restrict __name,
       struct hostent *__restrict __result_buf,
       char *__restrict __buf, size_t __buflen,
       struct hostent **__restrict __result,
       int *__restrict __h_errnop);
extern int gethostbyname2_r (const char *__restrict __name, int __af,
        struct hostent *__restrict __result_buf,
        char *__restrict __buf, size_t __buflen,
        struct hostent **__restrict __result,
        int *__restrict __h_errnop);
extern void setnetent (int __stay_open);
extern void endnetent (void);
extern struct netent *getnetent (void);
extern struct netent *getnetbyaddr (uint32_t __net, int __type);
extern struct netent *getnetbyname (const char *__name);
extern int getnetent_r (struct netent *__restrict __result_buf,
   char *__restrict __buf, size_t __buflen,
   struct netent **__restrict __result,
   int *__restrict __h_errnop);
extern int getnetbyaddr_r (uint32_t __net, int __type,
      struct netent *__restrict __result_buf,
      char *__restrict __buf, size_t __buflen,
      struct netent **__restrict __result,
      int *__restrict __h_errnop);
extern int getnetbyname_r (const char *__restrict __name,
      struct netent *__restrict __result_buf,
      char *__restrict __buf, size_t __buflen,
      struct netent **__restrict __result,
      int *__restrict __h_errnop);
struct servent
{
  char *s_name;
  char **s_aliases;
  int s_port;
  char *s_proto;
};
extern void setservent (int __stay_open);
extern void endservent (void);
extern struct servent *getservent (void);
extern struct servent *getservbyname (const char *__name, const char *__proto);
extern struct servent *getservbyport (int __port, const char *__proto);
extern int getservent_r (struct servent *__restrict __result_buf,
    char *__restrict __buf, size_t __buflen,
    struct servent **__restrict __result);
extern int getservbyname_r (const char *__restrict __name,
       const char *__restrict __proto,
       struct servent *__restrict __result_buf,
       char *__restrict __buf, size_t __buflen,
       struct servent **__restrict __result);
extern int getservbyport_r (int __port, const char *__restrict __proto,
       struct servent *__restrict __result_buf,
       char *__restrict __buf, size_t __buflen,
       struct servent **__restrict __result);
struct protoent
{
  char *p_name;
  char **p_aliases;
  int p_proto;
};
extern void setprotoent (int __stay_open);
extern void endprotoent (void);
extern struct protoent *getprotoent (void);
extern struct protoent *getprotobyname (const char *__name);
extern struct protoent *getprotobynumber (int __proto);
extern int getprotoent_r (struct protoent *__restrict __result_buf,
     char *__restrict __buf, size_t __buflen,
     struct protoent **__restrict __result);
extern int getprotobyname_r (const char *__restrict __name,
        struct protoent *__restrict __result_buf,
        char *__restrict __buf, size_t __buflen,
        struct protoent **__restrict __result);
extern int getprotobynumber_r (int __proto,
          struct protoent *__restrict __result_buf,
          char *__restrict __buf, size_t __buflen,
          struct protoent **__restrict __result);
extern int setnetgrent (const char *__netgroup);
extern void endnetgrent (void);
extern int getnetgrent (char **__restrict __hostp,
   char **__restrict __userp,
   char **__restrict __domainp);
extern int innetgr (const char *__netgroup, const char *__host,
      const char *__user, const char *__domain);
extern int getnetgrent_r (char **__restrict __hostp,
     char **__restrict __userp,
     char **__restrict __domainp,
     char *__restrict __buffer, size_t __buflen);
extern int rcmd (char **__restrict __ahost, unsigned short int __rport,
   const char *__restrict __locuser,
   const char *__restrict __remuser,
   const char *__restrict __cmd, int *__restrict __fd2p);
extern int rcmd_af (char **__restrict __ahost, unsigned short int __rport,
      const char *__restrict __locuser,
      const char *__restrict __remuser,
      const char *__restrict __cmd, int *__restrict __fd2p,
      sa_family_t __af);
extern int rexec (char **__restrict __ahost, int __rport,
    const char *__restrict __name,
    const char *__restrict __pass,
    const char *__restrict __cmd, int *__restrict __fd2p);
extern int rexec_af (char **__restrict __ahost, int __rport,
       const char *__restrict __name,
       const char *__restrict __pass,
       const char *__restrict __cmd, int *__restrict __fd2p,
       sa_family_t __af);
extern int ruserok (const char *__rhost, int __suser,
      const char *__remuser, const char *__locuser);
extern int ruserok_af (const char *__rhost, int __suser,
         const char *__remuser, const char *__locuser,
         sa_family_t __af);
extern int iruserok (uint32_t __raddr, int __suser,
       const char *__remuser, const char *__locuser);
extern int iruserok_af (const void *__raddr, int __suser,
   const char *__remuser, const char *__locuser,
   sa_family_t __af);
extern int rresvport (int *__alport);
extern int rresvport_af (int *__alport, sa_family_t __af);
struct addrinfo
{
  int ai_flags;
  int ai_family;
  int ai_socktype;
  int ai_protocol;
  socklen_t ai_addrlen;
  struct sockaddr *ai_addr;
  char *ai_canonname;
  struct addrinfo *ai_next;
};
extern int getaddrinfo (const char *__restrict __name,
   const char *__restrict __service,
   const struct addrinfo *__restrict __req,
   struct addrinfo **__restrict __pai);
extern void freeaddrinfo (struct addrinfo *__ai) __attribute__ ((__nothrow__ ));
extern const char *gai_strerror (int __ecode) __attribute__ ((__nothrow__ ));
extern int getnameinfo (const struct sockaddr *__restrict __sa,
   socklen_t __salen, char *__restrict __host,
   socklen_t __hostlen, char *__restrict __serv,
   socklen_t __servlen, int __flags);

typedef uint32_t tcp_seq;
struct tcphdr
  {
    __extension__ union
    {
      struct
      {
 uint16_t th_sport;
 uint16_t th_dport;
 tcp_seq th_seq;
 tcp_seq th_ack;
 uint8_t th_x2:4;
 uint8_t th_off:4;
 uint8_t th_flags;
 uint16_t th_win;
 uint16_t th_sum;
 uint16_t th_urp;
      };
      struct
      {
 uint16_t source;
 uint16_t dest;
 uint32_t seq;
 uint32_t ack_seq;
 uint16_t res1:4;
 uint16_t doff:4;
 uint16_t fin:1;
 uint16_t syn:1;
 uint16_t rst:1;
 uint16_t psh:1;
 uint16_t ack:1;
 uint16_t urg:1;
 uint16_t res2:2;
 uint16_t window;
 uint16_t check;
 uint16_t urg_ptr;
      };
    };
};
enum
{
  TCP_ESTABLISHED = 1,
  TCP_SYN_SENT,
  TCP_SYN_RECV,
  TCP_FIN_WAIT1,
  TCP_FIN_WAIT2,
  TCP_TIME_WAIT,
  TCP_CLOSE,
  TCP_CLOSE_WAIT,
  TCP_LAST_ACK,
  TCP_LISTEN,
  TCP_CLOSING
};
enum tcp_ca_state
{
  TCP_CA_Open = 0,
  TCP_CA_Disorder = 1,
  TCP_CA_CWR = 2,
  TCP_CA_Recovery = 3,
  TCP_CA_Loss = 4
};
struct tcp_info
{
  uint8_t tcpi_state;
  uint8_t tcpi_ca_state;
  uint8_t tcpi_retransmits;
  uint8_t tcpi_probes;
  uint8_t tcpi_backoff;
  uint8_t tcpi_options;
  uint8_t tcpi_snd_wscale : 4, tcpi_rcv_wscale : 4;
  uint32_t tcpi_rto;
  uint32_t tcpi_ato;
  uint32_t tcpi_snd_mss;
  uint32_t tcpi_rcv_mss;
  uint32_t tcpi_unacked;
  uint32_t tcpi_sacked;
  uint32_t tcpi_lost;
  uint32_t tcpi_retrans;
  uint32_t tcpi_fackets;
  uint32_t tcpi_last_data_sent;
  uint32_t tcpi_last_ack_sent;
  uint32_t tcpi_last_data_recv;
  uint32_t tcpi_last_ack_recv;
  uint32_t tcpi_pmtu;
  uint32_t tcpi_rcv_ssthresh;
  uint32_t tcpi_rtt;
  uint32_t tcpi_rttvar;
  uint32_t tcpi_snd_ssthresh;
  uint32_t tcpi_snd_cwnd;
  uint32_t tcpi_advmss;
  uint32_t tcpi_reordering;
  uint32_t tcpi_rcv_rtt;
  uint32_t tcpi_rcv_space;
  uint32_t tcpi_total_retrans;
  uint64_t tcpi_pacing_rate;
  uint64_t tcpi_max_pacing_rate;
  uint64_t tcpi_bytes_acked;
  uint64_t tcpi_bytes_received;
  uint32_t tcpi_segs_out;
  uint32_t tcpi_segs_in;
  uint32_t tcpi_notsent_bytes;
  uint32_t tcpi_min_rtt;
  uint32_t tcpi_data_segs_in;
  uint32_t tcpi_data_segs_out;
  uint64_t tcpi_delivery_rate;
  uint64_t tcpi_busy_time;
  uint64_t tcpi_rwnd_limited;
  uint64_t tcpi_sndbuf_limited;
  uint32_t tcpi_delivered;
  uint32_t tcpi_delivered_ce;
  uint64_t tcpi_bytes_sent;
  uint64_t tcpi_bytes_retrans;
  uint32_t tcpi_dsack_dups;
  uint32_t tcpi_reord_seen;
  uint32_t tcpi_rcv_ooopack;
  uint32_t tcpi_snd_wnd;
  uint32_t tcpi_rcv_wnd;
  uint32_t tcpi_rehash;
  uint16_t tcpi_total_rto;
  uint16_t tcpi_total_rto_recoveries;
  uint32_t tcpi_total_rto_time;
  uint32_t tcpi_received_ce;
  uint32_t tcpi_delivered_e1_bytes;
  uint32_t tcpi_delivered_e0_bytes;
  uint32_t tcpi_delivered_ce_bytes;
  uint32_t tcpi_received_e1_bytes;
  uint32_t tcpi_received_e0_bytes;
  uint32_t tcpi_received_ce_bytes;
  uint16_t tcpi_accecn_fail_mode;
  uint16_t tcpi_accecn_opt_seen;
};
enum {
  TCP_NLA_PAD,
  TCP_NLA_BUSY,
  TCP_NLA_RWND_LIMITED,
  TCP_NLA_SNDBUF_LIMITED,
  TCP_NLA_DATA_SEGS_OUT,
  TCP_NLA_TOTAL_RETRANS,
  TCP_NLA_PACING_RATE,
  TCP_NLA_DELIVERY_RATE,
  TCP_NLA_SND_CWND,
  TCP_NLA_REORDERING,
  TCP_NLA_MIN_RTT,
  TCP_NLA_RECUR_RETRANS,
  TCP_NLA_DELIVERY_RATE_APP_LMT,
  TCP_NLA_SNDQ_SIZE,
  TCP_NLA_CA_STATE,
  TCP_NLA_SND_SSTHRESH,
  TCP_NLA_DELIVERED,
  TCP_NLA_DELIVERED_CE,
  TCP_NLA_BYTES_SENT,
  TCP_NLA_BYTES_RETRANS,
  TCP_NLA_DSACK_DUPS,
  TCP_NLA_REORD_SEEN,
  TCP_NLA_SRTT,
  TCP_NLA_TIMEOUT_REHASH,
  TCP_NLA_BYTES_NOTSENT,
  TCP_NLA_EDT,
  TCP_NLA_TTL,
  TCP_NLA_REHASH,
};
struct tcp_md5sig
{
  struct sockaddr_storage tcpm_addr;
  uint8_t tcpm_flags;
  uint8_t tcpm_prefixlen;
  uint16_t tcpm_keylen;
  int tcpm_ifindex;
  uint8_t tcpm_key[80];
};
struct tcp_diag_md5sig {
  uint8_t tcpm_family;
  uint8_t tcpm_prefixlen;
  uint16_t tcpm_keylen;
  uint32_t tcpm_addr[4];
  uint8_t tcpm_key[80];
};
struct tcp_ao_add {
  struct sockaddr_storage addr;
  int8_t alg_name[64];
  int32_t ifindex;
  uint32_t set_current :1,
            set_rnext :1,
            reserved :30;
  uint16_t reserved2;
  uint8_t prefix;
  uint8_t sndid;
  uint8_t rcvid;
  uint8_t maclen;
  uint8_t keyflags;
  uint8_t keylen;
  uint8_t key[80];
} __attribute__((aligned(8)));
struct tcp_ao_del {
  struct sockaddr_storage addr;
  int32_t ifindex;
  uint32_t set_current :1,
           set_rnext :1,
           del_async :1,
           reserved :29;
  uint16_t reserved2;
  uint8_t prefix;
  uint8_t sndid;
  uint8_t rcvid;
  uint8_t current_key;
  uint8_t rnext;
  uint8_t keyflags;
} __attribute__((aligned(8)));
struct tcp_ao_info_opt {
  uint32_t set_current :1,
            set_rnext :1,
            ao_required :1,
            set_counters :1,
            accept_icmps :1,
            reserved :27;
  uint16_t reserved2;
  uint8_t current_key;
  uint8_t rnext;
  uint64_t pkt_good;
  uint64_t pkt_bad;
  uint64_t pkt_key_not_found;
  uint64_t pkt_ao_required;
  uint64_t pkt_dropped_icmp;
} __attribute__((aligned(8)));
struct tcp_ao_getsockopt {
  struct sockaddr_storage addr;
  uint8_t alg_name[64];
  uint8_t key[80];
  uint32_t nkeys;
  uint16_t is_current :1,
            is_rnext :1,
            get_all :1,
            reserved :13;
  uint8_t sndid;
  uint8_t rcvid;
  uint8_t prefix;
  uint8_t maclen;
  uint8_t keyflags;
  uint8_t keylen;
  int32_t ifindex;
  uint64_t pkt_good;
  uint64_t pkt_bad;
} __attribute__((aligned(8)));
struct tcp_ao_repair {
  uint32_t snt_isn;
  uint32_t rcv_isn;
  uint32_t snd_sne;
  uint32_t rcv_sne;
} __attribute__((aligned(8)));
struct tcp_repair_opt
{
  uint32_t opt_code;
  uint32_t opt_val;
};
enum
{
  TCP_NO_QUEUE,
  TCP_RECV_QUEUE,
  TCP_SEND_QUEUE,
  TCP_QUEUES_NR,
};
struct tcp_cookie_transactions
{
  uint16_t tcpct_flags;
  uint8_t __tcpct_pad1;
  uint8_t tcpct_cookie_desired;
  uint16_t tcpct_s_data_desired;
  uint16_t tcpct_used;
  uint8_t tcpct_value[536U];
};
struct tcp_repair_window
{
  uint32_t snd_wl1;
  uint32_t snd_wnd;
  uint32_t max_window;
  uint32_t rcv_wnd;
  uint32_t rcv_wup;
};
struct tcp_zerocopy_receive
{
  uint64_t address;
  uint32_t length;
  uint32_t recv_skip_hint;
  uint32_t inq;
  int32_t err;
  uint64_t copybuf_address;
  int32_t copybuf_len;
  uint32_t flags;
  uint64_t msg_control;
  uint64_t msg_controllen;
  uint32_t msg_flags;
  uint32_t reserved;
};

extern in_addr_t inet_addr (const char *__cp) __attribute__ ((__nothrow__ ));
extern in_addr_t inet_lnaof (struct in_addr __in) __attribute__ ((__nothrow__ ));
extern struct in_addr inet_makeaddr (in_addr_t __net, in_addr_t __host)
     __attribute__ ((__nothrow__ ));
extern in_addr_t inet_netof (struct in_addr __in) __attribute__ ((__nothrow__ ));
extern in_addr_t inet_network (const char *__cp) __attribute__ ((__nothrow__ ));
extern char *inet_ntoa (struct in_addr __in) __attribute__ ((__nothrow__ ));
extern int inet_pton (int __af, const char *__restrict __cp,
        void *__restrict __buf) __attribute__ ((__nothrow__ ));
extern const char *inet_ntop (int __af, const void *__restrict __cp,
         char *__restrict __buf, socklen_t __len)
     __attribute__ ((__nothrow__ ));
extern int inet_aton (const char *__cp, struct in_addr *__inp) __attribute__ ((__nothrow__ ));
extern char *inet_neta (in_addr_t __net, char *__buf, size_t __len) __attribute__ ((__nothrow__ ))
  __attribute__ ((__deprecated__ ("Use inet_ntop instead")));
extern char *inet_net_ntop (int __af, const void *__cp, int __bits,
       char *__buf, size_t __len) __attribute__ ((__nothrow__ ));
extern int inet_net_pton (int __af, const char *__cp,
     void *__buf, size_t __len) __attribute__ ((__nothrow__ ));
extern unsigned int inet_nsap_addr (const char *__cp,
        unsigned char *__buf, int __len) __attribute__ ((__nothrow__ ));
extern char *inet_nsap_ntoa (int __len, const unsigned char *__cp,
        char *__buf) __attribute__ ((__nothrow__ ));
extern char *dirname (char *__path) __attribute__ ((__nothrow__ ));
extern char *__xpg_basename (char *__path) __attribute__ ((__nothrow__ ));
extern void *dlopen (const char *__file, int __mode) __attribute__ ((__nothrow__));
extern int dlclose (void *__handle) __attribute__ ((__nothrow__)) __attribute__ ((__nonnull__ (1)));
extern void *dlsym (void *__restrict __handle,
      const char *__restrict __name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *dlerror (void) __attribute__ ((__nothrow__ ));
struct __attribute__ ((__may_alias__)) sockaddr_un
  {
    sa_family_t sun_family;
    char sun_path[108];
  };
static inline uint32_t FLB_ALIGNED_DWORD_READ(unsigned char *source)
{
    uint32_t result;
    memcpy(&result, source, sizeof(result));
    return result;
}
int flb_pipe_create(int pipefd[2]);
void flb_pipe_destroy(int pipefd[2]);
int flb_pipe_close(int fd);
int flb_pipe_set_nonblocking(int fd);
ssize_t flb_pipe_read_all(int fd, void *buf, size_t count);
ssize_t flb_pipe_write_all(int fd, const void *buf, size_t count);
void flb_pipe_log_last_error();

extern __thread struct flb_worker *flb_worker_ctx;;
typedef int __gwchar_t;
typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ ));
extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ ));
extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));
extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));
typedef char *flb_sds_t;
#pragma pack(push, 1)
struct flb_sds {
    uint64_t len;
    uint64_t alloc;
    char buf[];
};
#pragma pack(pop)
static inline size_t flb_sds_len(flb_sds_t s)
{
    return (size_t) ((struct flb_sds *) (s - (sizeof(uint64_t) + sizeof(uint64_t))))->len;
}
static inline int flb_sds_is_empty(flb_sds_t s)
{
    if (flb_sds_len(s) == 0) {
        return 1;
    }
    return 0;
}
static inline void flb_sds_len_set(flb_sds_t s, size_t len)
{
    ((struct flb_sds *) (s - (sizeof(uint64_t) + sizeof(uint64_t))))->len = len;
}
static inline size_t flb_sds_alloc(flb_sds_t s)
{
    return (size_t) ((struct flb_sds *) (s - (sizeof(uint64_t) + sizeof(uint64_t))))->alloc;
}
static inline size_t flb_sds_avail(flb_sds_t s)
{
    struct flb_sds *h;
    h = ((struct flb_sds *) (s - (sizeof(uint64_t) + sizeof(uint64_t))));
    return (size_t) (h->alloc - h->len);
}
static inline int flb_sds_cmp(flb_sds_t s, const char *str, int len)
{
    if (flb_sds_len(s) != len) {
        return -1;
    }
    return strncmp(s, str, len);
}
static inline int flb_sds_casecmp(flb_sds_t s, const char *str, int len)
{
    if (flb_sds_len(s) != len) {
        return -1;
    }
    return strncasecmp(s, str, len);
}
flb_sds_t flb_sds_create(const char *str);
flb_sds_t flb_sds_create_len(const char *str, int len);
flb_sds_t flb_sds_create_size(size_t size);
int flb_sds_trim(flb_sds_t s);
flb_sds_t flb_sds_cat(flb_sds_t s, const char *str, int len);
flb_sds_t flb_sds_cat_esc(flb_sds_t s, const char *str, int len,
                                       char *esc, size_t esc_size);
flb_sds_t flb_sds_cat_utf8(flb_sds_t *sds, const char *str, int len);
int flb_sds_cat_safe(flb_sds_t *buf, const char *str, int len);
flb_sds_t flb_sds_increase(flb_sds_t s, size_t len);
flb_sds_t flb_sds_copy(flb_sds_t s, const char *str, int len);
void flb_sds_destroy(flb_sds_t s);
flb_sds_t flb_sds_printf(flb_sds_t *sds, const char *fmt, ...) __attribute__ ((format (printf, 2, 3)));
int flb_sds_snprintf(flb_sds_t *str, size_t size, const char *fmt, ...) __attribute__ ((format (printf, 3, 4)));

struct flb_task_map {
    void *task;
};
int cfl_atomic_initialize();
int cfl_atomic_compare_exchange(uint64_t *storage, uint64_t old_value,
                                uint64_t new_value);
void cfl_atomic_store(uint64_t *storage, uint64_t new_value);
uint64_t cfl_atomic_load(uint64_t *storage);
int cfl_report_runtime_error_impl(int errnum, char *file, int line);

typedef char *cfl_sds_t;
struct cfl_arena;
#pragma pack(push, 1)
struct cfl_sds {
    uint64_t len;
    uint64_t alloc;
    char buf[];
};
#pragma pack(pop)
size_t cfl_sds_alloc(cfl_sds_t s);
static inline void cfl_sds_len_set(cfl_sds_t s, size_t len)
{
    struct cfl_sds *head;
    if (s == ((void*)0)) {
        return;
    }
    head = ((struct cfl_sds *) (s - (sizeof(uint64_t) + sizeof(uint64_t))));
    if (len > cfl_sds_alloc(s)) {
        return;
    }
    head->len = len;
    s[len] = '\0';
}
size_t cfl_sds_avail(cfl_sds_t s);
cfl_sds_t cfl_sds_increase(cfl_sds_t s, size_t len);
size_t cfl_sds_len(cfl_sds_t s);
cfl_sds_t cfl_sds_create_len(const char *str, int len);
cfl_sds_t cfl_sds_create_len_in(struct cfl_arena *arena,
                                const char *str, int len);
cfl_sds_t cfl_sds_create(const char *str);
void cfl_sds_destroy(cfl_sds_t s);
cfl_sds_t cfl_sds_cat(cfl_sds_t s, const char *str, int len);
cfl_sds_t cfl_sds_create_size(size_t size);
void cfl_sds_set_len(cfl_sds_t s, size_t len);
void cfl_sds_cat_safe(cfl_sds_t *buf, const char *str, int len);
cfl_sds_t cfl_sds_printf(cfl_sds_t *sds, const char *fmt, ...);
struct cfl_list {
    struct cfl_list *prev, *next;
};
static inline int cfl_list_is_empty(struct cfl_list *head)
{
    if (head == ((void*)0)) {
        return 1;
    }
    if (head->next == head) {
        return 1;
    }
    return 0;
}
static inline void cfl_list_init(struct cfl_list *list)
{
    if (list == ((void*)0)) {
        return;
    }
    list->next = list;
    list->prev = list;
}
static inline void __cfl_list_del(struct cfl_list *prev,
                                  struct cfl_list *next)
{
    if (prev == ((void*)0) || next == ((void*)0)) {
        return;
    }
    prev->next = next;
    next->prev = prev;
}
static inline void cfl_list_del(struct cfl_list *entry)
{
    if (entry == ((void*)0)) {
        return;
    }
    __cfl_list_del(entry->prev, entry->next);
    entry->prev = ((void*)0);
    entry->next = ((void*)0);
}
static inline void __cfl_list_add(struct cfl_list *_new,
                                  struct cfl_list *prev,
                                  struct cfl_list *next)
{
    if (_new == ((void*)0) || prev == ((void*)0) || next == ((void*)0)) {
        return;
    }
    next->prev = _new;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
}
static inline void cfl_list_add(struct cfl_list *_new,
                                struct cfl_list *head)
{
    if (_new == ((void*)0) || head == ((void*)0)) {
        return;
    }
    __cfl_list_add(_new, head->prev, head);
}
static inline void cfl_list_add_after(struct cfl_list *_new,
                                      struct cfl_list *prev,
                                      struct cfl_list *head)
{
    struct cfl_list *next;
    if (_new == ((void*)0) || prev == ((void*)0) || head == ((void*)0)) {
        return;
    }
    next = prev->next;
    next->prev = prev;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
}
static inline void cfl_list_add_before(struct cfl_list *_new,
                                       struct cfl_list *next,
                                       struct cfl_list *head)
{
    struct cfl_list *prev;
    if (_new == ((void*)0) || next == ((void*)0) || head == ((void*)0)) {
        return;
    }
    prev = next->prev;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
    next->prev = _new;
}
static inline void cfl_list_append(struct cfl_list *_new,
                                   struct cfl_list *head)
{
    if (_new == ((void*)0) || head == ((void*)0)) {
        return;
    }
    if (cfl_list_is_empty(head)) {
        __cfl_list_add(_new, head->prev, head);
    }
    else {
        cfl_list_add_after(_new,
                           head->prev,
                           head);
    }
}
static inline void cfl_list_prepend(struct cfl_list *_new,
                                    struct cfl_list *head)
{
    if (_new == ((void*)0) || head == ((void*)0)) {
        return;
    }
    if (cfl_list_is_empty(head)) {
        __cfl_list_add(_new, head->prev, head);
    }
    else {
        cfl_list_add_before(_new,
                           head->next,
                           head);
    }
}
static inline int cfl_list_size(struct cfl_list *head)
{
    int ret = 0;
    struct cfl_list *it;
    if (head == ((void*)0)) {
        return 0;
    }
    for (it = head->next; it != head; it = it->next, ret++);
    return ret;
}
static inline void cfl_list_entry_init(struct cfl_list *entry)
{
    entry->next = ((void*)0);
    entry->prev = ((void*)0);
}
static inline int cfl_list_entry_is_orphan(struct cfl_list *entry)
{
    if (entry == ((void*)0)) {
        return !0;
    }
    if (entry->next != ((void*)0) &&
        entry->prev != ((void*)0)) {
        return 0;
    }
    return !0;
}
static inline void cfl_list_cat(struct cfl_list *list, struct cfl_list *head)
{
    struct cfl_list *last;
    if (list == ((void*)0) || head == ((void*)0)) {
        return;
    }
    last = head->prev;
    last->next = list->next;
    list->next->prev = last;
    list->prev->next = head;
    head->prev = list->prev;
}
static __inline __attribute__((__unused__)) __attribute__((__const__)) unsigned XXH_INLINE_XXH_versionNumber (void);
typedef enum {
    XXH_NAMESPACEXXH_OK = 0,
    XXH_NAMESPACEXXH_ERROR
} XXH_NAMESPACEXXH_errorcode;
    typedef uint32_t XXH32_hash_t;
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH32_hash_t XXH_INLINE_XXH32 (const void* input, size_t length, XXH32_hash_t seed);
typedef struct XXH_NAMESPACEXXH32_state_s XXH_NAMESPACEXXH32_state_t;
static __inline __attribute__((__unused__)) __attribute__((__malloc__)) XXH_NAMESPACEXXH32_state_t* XXH_INLINE_XXH32_createState(void);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_freeState(XXH_NAMESPACEXXH32_state_t* statePtr);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_copyState(XXH_NAMESPACEXXH32_state_t* dst_state, const XXH_NAMESPACEXXH32_state_t* src_state);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_reset (XXH_NAMESPACEXXH32_state_t* statePtr, XXH32_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_update (XXH_NAMESPACEXXH32_state_t* statePtr, const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH32_hash_t XXH_INLINE_XXH32_digest (const XXH_NAMESPACEXXH32_state_t* statePtr);
typedef struct {
    unsigned char digest[4];
} XXH_NAMESPACEXXH32_canonical_t;
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_canonicalFromHash(XXH_NAMESPACEXXH32_canonical_t* dst, XXH32_hash_t hash);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH32_hash_t XXH_INLINE_XXH32_hashFromCanonical(const XXH_NAMESPACEXXH32_canonical_t* src);
   typedef uint64_t XXH64_hash_t;
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH64(__attribute__((__noescape__)) const void* input, size_t length, XXH64_hash_t seed);
typedef struct XXH_NAMESPACEXXH64_state_s XXH_NAMESPACEXXH64_state_t;
static __inline __attribute__((__unused__)) __attribute__((__malloc__)) XXH_NAMESPACEXXH64_state_t* XXH_INLINE_XXH64_createState(void);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_freeState(XXH_NAMESPACEXXH64_state_t* statePtr);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* dst_state, const XXH_NAMESPACEXXH64_state_t* src_state);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_reset (__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* statePtr, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* statePtr, __attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH64_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_state_t* statePtr);
typedef struct { unsigned char digest[sizeof(XXH64_hash_t)]; } XXH_NAMESPACEXXH64_canonical_t;
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_canonical_t* dst, XXH64_hash_t hash);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH64_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_canonical_t* src);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits(__attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_withSeed(__attribute__((__noescape__)) const void* input, size_t length, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_withSecret(__attribute__((__noescape__)) const void* data, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize);
typedef struct XXH_NAMESPACEXXH3_state_s XXH_NAMESPACEXXH3_state_t;
static __inline __attribute__((__unused__)) __attribute__((__malloc__)) XXH_NAMESPACEXXH3_state_t* XXH_INLINE_XXH3_createState(void);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_freeState(XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH3_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* dst_state, __attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* src_state);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* statePtr);
typedef struct {
    XXH64_hash_t low64;
    XXH64_hash_t high64;
} XXH_NAMESPACEXXH128_hash_t;
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits(__attribute__((__noescape__)) const void* data, size_t len);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_withSeed(__attribute__((__noescape__)) const void* data, size_t len, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_withSecret(__attribute__((__noescape__)) const void* data, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) int XXH_INLINE_XXH128_isEqual(XXH_NAMESPACEXXH128_hash_t h1, XXH_NAMESPACEXXH128_hash_t h2);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) int XXH_INLINE_XXH128_cmp(__attribute__((__noescape__)) const void* h128_1, __attribute__((__noescape__)) const void* h128_2);
typedef struct { unsigned char digest[sizeof(XXH_NAMESPACEXXH128_hash_t)]; } XXH_NAMESPACEXXH128_canonical_t;
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH128_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH128_canonical_t* dst, XXH_NAMESPACEXXH128_hash_t hash);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH128_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH128_canonical_t* src);
struct XXH_NAMESPACEXXH32_state_s {
   XXH32_hash_t total_len_32;
   XXH32_hash_t large_len;
   XXH32_hash_t acc[4];
   unsigned char buffer[16];
   XXH32_hash_t bufferedSize;
   XXH32_hash_t reserved;
};
struct XXH_NAMESPACEXXH64_state_s {
   XXH64_hash_t total_len;
   XXH64_hash_t acc[4];
   unsigned char buffer[32];
   XXH32_hash_t bufferedSize;
   XXH32_hash_t reserved32;
   XXH64_hash_t reserved64;
};
struct XXH_NAMESPACEXXH3_state_s {
   _Alignas(64) XXH64_hash_t acc[8];
   _Alignas(64) unsigned char customSecret[192];
   _Alignas(64) unsigned char buffer[256];
   XXH32_hash_t bufferedSize;
   XXH32_hash_t useSeed;
   size_t nbStripesSoFar;
   XXH64_hash_t totalLen;
   size_t nbStripesPerBlock;
   size_t secretLimit;
   XXH64_hash_t seed;
   XXH64_hash_t reserved64;
   const unsigned char* extSecret;
};
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH128(__attribute__((__noescape__)) const void* data, size_t len, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_generateSecret(__attribute__((__noescape__)) void* secretBuffer, size_t secretSize, __attribute__((__noescape__)) const void* customSeed, size_t customSeedSize);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH3_generateSecret_fromSeed(__attribute__((__noescape__)) void* secretBuffer, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSecretandSeed(__attribute__((__noescape__)) const void* data, size_t len,
                              __attribute__((__noescape__)) const void* secret, size_t secretSize,
                              XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSecretandSeed(__attribute__((__noescape__)) const void* input, size_t length,
                               __attribute__((__noescape__)) const void* secret, size_t secretSize,
                               XXH64_hash_t seed64);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr,
                                    __attribute__((__noescape__)) const void* secret, size_t secretSize,
                                    XXH64_hash_t seed64);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr,
                                     __attribute__((__noescape__)) const void* secret, size_t secretSize,
                                     XXH64_hash_t seed64);
static __attribute__((__malloc__)) void* XXH_malloc(size_t s) { return malloc(s); }
static void XXH_free(void* p) { free(p); }
 typedef uint8_t xxh_u8;
typedef XXH32_hash_t xxh_u32;
static xxh_u32 XXH_read32(const void* ptr)
{
    typedef __attribute__((__aligned__(1))) xxh_u32 xxh_unalign32;
    return *((const xxh_unalign32*)ptr);
}
static xxh_u32 XXH_swap32 (xxh_u32 x)
{
    return ((x << 24) & 0xff000000 ) |
            ((x << 8) & 0x00ff0000 ) |
            ((x >> 8) & 0x0000ff00 ) |
            ((x >> 24) & 0x000000ff );
}
typedef enum {
    XXH_aligned,
    XXH_unaligned
} XXH_alignment;
static __attribute__((__unused__)) xxh_u32 XXH_readLE32(const void* ptr)
{
    return 1 ? XXH_read32(ptr) : XXH_swap32(XXH_read32(ptr));
}
static xxh_u32 XXH_readBE32(const void* ptr)
{
    return 1 ? XXH_swap32(XXH_read32(ptr)) : XXH_read32(ptr);
}
static __attribute__((__unused__)) xxh_u32
XXH_readLE32_align(const void* ptr, XXH_alignment align)
{
    if (align==XXH_unaligned) {
        return XXH_readLE32(ptr);
    } else {
        return 1 ? *(const xxh_u32*)ptr : XXH_swap32(*(const xxh_u32*)ptr);
    }
}
static __inline __attribute__((__unused__)) unsigned XXH_INLINE_XXH_versionNumber (void) { return (0 *100*100 + 8 *100 + 3); }
static xxh_u32 XXH32_round(xxh_u32 acc, xxh_u32 input)
{
    acc += input * 0x85EBCA77U;
    acc = __builtin_rotateleft32(acc, 13);
    acc *= 0x9E3779B1U;
    return acc;
}
static xxh_u32 XXH32_avalanche(xxh_u32 hash)
{
    hash ^= hash >> 15;
    hash *= 0x85EBCA77U;
    hash ^= hash >> 13;
    hash *= 0xC2B2AE3DU;
    hash ^= hash >> 16;
    return hash;
}
static __attribute__((__unused__)) void
XXH32_initAccs(xxh_u32 *acc, xxh_u32 seed)
{
    __builtin_assume(acc != ((void*)0));
    acc[0] = seed + 0x9E3779B1U + 0x85EBCA77U;
    acc[1] = seed + 0x85EBCA77U;
    acc[2] = seed + 0;
    acc[3] = seed - 0x9E3779B1U;
}
static __attribute__((__unused__)) const xxh_u8 *
XXH32_consumeLong(
    xxh_u32 *restrict acc,
    xxh_u8 const *restrict input,
    size_t len,
    XXH_alignment align
)
{
    const xxh_u8* const bEnd = input + len;
    const xxh_u8* const limit = bEnd - 15;
    __builtin_assume(acc != ((void*)0));
    __builtin_assume(input != ((void*)0));
    __builtin_assume(len >= 16);
    do {
        acc[0] = XXH32_round(acc[0], XXH_readLE32_align(input, align)); input += 4;
        acc[1] = XXH32_round(acc[1], XXH_readLE32_align(input, align)); input += 4;
        acc[2] = XXH32_round(acc[2], XXH_readLE32_align(input, align)); input += 4;
        acc[3] = XXH32_round(acc[3], XXH_readLE32_align(input, align)); input += 4;
    } while (input < limit);
    return input;
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u32
XXH32_mergeAccs(const xxh_u32 *acc)
{
    __builtin_assume(acc != ((void*)0));
    return __builtin_rotateleft32(acc[0], 1) + __builtin_rotateleft32(acc[1], 7)
         + __builtin_rotateleft32(acc[2], 12) + __builtin_rotateleft32(acc[3], 18);
}
static __attribute__((__pure__)) xxh_u32
XXH32_finalize(xxh_u32 hash, const xxh_u8* ptr, size_t len, XXH_alignment align)
{
    if (ptr==((void*)0)) __builtin_assume(len == 0);
    if (!0) {
        len &= 15;
        while (len >= 4) {
            do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
            len -= 4;
        }
        while (len > 0) {
            do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
            --len;
        }
        return XXH32_avalanche(hash);
    } else {
         switch(len&15) {
           case 12: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 8: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 4: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         return XXH32_avalanche(hash);
           case 13: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 9: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 5: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         return XXH32_avalanche(hash);
           case 14: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 10: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 6: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         return XXH32_avalanche(hash);
           case 15: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 11: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 7: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 3: do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         __attribute__ ((__fallthrough__));
           case 2: do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         __attribute__ ((__fallthrough__));
           case 1: do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         __attribute__ ((__fallthrough__));
           case 0: return XXH32_avalanche(hash);
        }
        __builtin_assume(0);
        return hash;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u32
XXH32_endian_align(const xxh_u8* input, size_t len, xxh_u32 seed, XXH_alignment align)
{
    xxh_u32 h32;
    if (input==((void*)0)) __builtin_assume(len == 0);
    if (len>=16) {
        xxh_u32 acc[4];
        XXH32_initAccs(acc, seed);
        input = XXH32_consumeLong(acc, input, len, align);
        h32 = XXH32_mergeAccs(acc);
    } else {
        h32 = seed + 0x165667B1U;
    }
    h32 += (xxh_u32)len;
    return XXH32_finalize(h32, input, len&15, align);
}
static __inline __attribute__((__unused__)) XXH32_hash_t XXH_INLINE_XXH32 (const void* input, size_t len, XXH32_hash_t seed)
{
    if (0) {
        if ((((size_t)input) & 3) == 0) {
            return XXH32_endian_align((const xxh_u8*)input, len, seed, XXH_aligned);
    } }
    return XXH32_endian_align((const xxh_u8*)input, len, seed, XXH_unaligned);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH32_state_t* XXH_INLINE_XXH32_createState(void)
{
    return (XXH_NAMESPACEXXH32_state_t*)XXH_malloc(sizeof(XXH_NAMESPACEXXH32_state_t));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_freeState(XXH_NAMESPACEXXH32_state_t* statePtr)
{
    XXH_free(statePtr);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_copyState(XXH_NAMESPACEXXH32_state_t* dstState, const XXH_NAMESPACEXXH32_state_t* srcState)
{
    memcpy(dstState, srcState, sizeof(*dstState));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_reset(XXH_NAMESPACEXXH32_state_t* statePtr, XXH32_hash_t seed)
{
    __builtin_assume(statePtr != ((void*)0));
    memset(statePtr, 0, sizeof(*statePtr));
    XXH32_initAccs(statePtr->acc, seed);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH32_update(XXH_NAMESPACEXXH32_state_t* state, const void* input, size_t len)
{
    if (input==((void*)0)) {
        __builtin_assume(len == 0);
        return XXH_NAMESPACEXXH_OK;
    }
    state->total_len_32 += (XXH32_hash_t)len;
    state->large_len |= (XXH32_hash_t)((len>=16) | (state->total_len_32>=16));
    __builtin_assume(state->bufferedSize < sizeof(state->buffer));
    if (len < sizeof(state->buffer) - state->bufferedSize) {
        memcpy(state->buffer + state->bufferedSize, input, len);
        state->bufferedSize += (XXH32_hash_t)len;
        return XXH_NAMESPACEXXH_OK;
    }
    { const xxh_u8* xinput = (const xxh_u8*)input;
        const xxh_u8* const bEnd = xinput + len;
        if (state->bufferedSize) {
            memcpy(state->buffer + state->bufferedSize, xinput, sizeof(state->buffer) - state->bufferedSize);
            xinput += sizeof(state->buffer) - state->bufferedSize;
            (void)XXH32_consumeLong(state->acc, state->buffer, sizeof(state->buffer), XXH_aligned);
            state->bufferedSize = 0;
        }
        __builtin_assume(xinput <= bEnd);
        if ((size_t)(bEnd - xinput) >= sizeof(state->buffer)) {
            xinput = XXH32_consumeLong(state->acc, xinput, (size_t)(bEnd - xinput), XXH_unaligned);
        }
        if (xinput < bEnd) {
            memcpy(state->buffer, xinput, (size_t)(bEnd-xinput));
            state->bufferedSize = (unsigned)(bEnd-xinput);
        }
    }
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH32_hash_t XXH_INLINE_XXH32_digest(const XXH_NAMESPACEXXH32_state_t* state)
{
    xxh_u32 h32;
    if (state->large_len) {
        h32 = XXH32_mergeAccs(state->acc);
    } else {
        h32 = state->acc[2] + 0x165667B1U;
    }
    h32 += state->total_len_32;
    return XXH32_finalize(h32, state->buffer, state->bufferedSize, XXH_aligned);
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_canonicalFromHash(XXH_NAMESPACEXXH32_canonical_t* dst, XXH32_hash_t hash)
{
    do { _Static_assert(((sizeof(XXH_NAMESPACEXXH32_canonical_t) == sizeof(XXH32_hash_t))),"sizeof(XXH32_canonical_t) == sizeof(XXH32_hash_t)"); } while(0);
    if (1) hash = XXH_swap32(hash);
    memcpy(dst, &hash, sizeof(*dst));
}
static __inline __attribute__((__unused__)) XXH32_hash_t XXH_INLINE_XXH32_hashFromCanonical(const XXH_NAMESPACEXXH32_canonical_t* src)
{
    return XXH_readBE32(src);
}
typedef XXH64_hash_t xxh_u64;
static xxh_u64 XXH_read64(const void* ptr)
{
    typedef __attribute__((__aligned__(1))) xxh_u64 xxh_unalign64;
    return *((const xxh_unalign64*)ptr);
}
static xxh_u64 XXH_swap64(xxh_u64 x)
{
    return ((x << 56) & 0xff00000000000000ULL) |
            ((x << 40) & 0x00ff000000000000ULL) |
            ((x << 24) & 0x0000ff0000000000ULL) |
            ((x << 8) & 0x000000ff00000000ULL) |
            ((x >> 8) & 0x00000000ff000000ULL) |
            ((x >> 24) & 0x0000000000ff0000ULL) |
            ((x >> 40) & 0x000000000000ff00ULL) |
            ((x >> 56) & 0x00000000000000ffULL);
}
static __attribute__((__unused__)) xxh_u64 XXH_readLE64(const void* ptr)
{
    return 1 ? XXH_read64(ptr) : XXH_swap64(XXH_read64(ptr));
}
static xxh_u64 XXH_readBE64(const void* ptr)
{
    return 1 ? XXH_swap64(XXH_read64(ptr)) : XXH_read64(ptr);
}
static __attribute__((__unused__)) xxh_u64
XXH_readLE64_align(const void* ptr, XXH_alignment align)
{
    if (align==XXH_unaligned)
        return XXH_readLE64(ptr);
    else
        return 1 ? *(const xxh_u64*)ptr : XXH_swap64(*(const xxh_u64*)ptr);
}
static xxh_u64 XXH64_round(xxh_u64 acc, xxh_u64 input)
{
    acc += input * 0xC2B2AE3D27D4EB4FULL;
    acc = __builtin_rotateleft64(acc, 31);
    acc *= 0x9E3779B185EBCA87ULL;
    return acc;
}
static xxh_u64 XXH64_mergeRound(xxh_u64 acc, xxh_u64 val)
{
    val = XXH64_round(0, val);
    acc ^= val;
    acc = acc * 0x9E3779B185EBCA87ULL + 0x85EBCA77C2B2AE63ULL;
    return acc;
}
static xxh_u64 XXH64_avalanche(xxh_u64 hash)
{
    hash ^= hash >> 33;
    hash *= 0xC2B2AE3D27D4EB4FULL;
    hash ^= hash >> 29;
    hash *= 0x165667B19E3779F9ULL;
    hash ^= hash >> 32;
    return hash;
}
static __attribute__((__unused__)) void
XXH64_initAccs(xxh_u64 *acc, xxh_u64 seed)
{
    __builtin_assume(acc != ((void*)0));
    acc[0] = seed + 0x9E3779B185EBCA87ULL + 0xC2B2AE3D27D4EB4FULL;
    acc[1] = seed + 0xC2B2AE3D27D4EB4FULL;
    acc[2] = seed + 0;
    acc[3] = seed - 0x9E3779B185EBCA87ULL;
}
static __attribute__((__unused__)) const xxh_u8 *
XXH64_consumeLong(
    xxh_u64 *restrict acc,
    xxh_u8 const *restrict input,
    size_t len,
    XXH_alignment align
)
{
    const xxh_u8* const bEnd = input + len;
    const xxh_u8* const limit = bEnd - 31;
    __builtin_assume(acc != ((void*)0));
    __builtin_assume(input != ((void*)0));
    __builtin_assume(len >= 32);
    do {
        if (sizeof(void *) < sizeof(xxh_u64)) {
            size_t i;
            for (i = 0; i < 4; i++) {
                acc[i] = XXH64_round(acc[i], XXH_readLE64_align(input, align));
                input += 8;
            }
        } else {
            acc[0] = XXH64_round(acc[0], XXH_readLE64_align(input, align)); input += 8;
            acc[1] = XXH64_round(acc[1], XXH_readLE64_align(input, align)); input += 8;
            acc[2] = XXH64_round(acc[2], XXH_readLE64_align(input, align)); input += 8;
            acc[3] = XXH64_round(acc[3], XXH_readLE64_align(input, align)); input += 8;
        }
    } while (input < limit);
    return input;
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u64
XXH64_mergeAccs(const xxh_u64 *acc)
{
    __builtin_assume(acc != ((void*)0));
    {
        xxh_u64 h64 = __builtin_rotateleft64(acc[0], 1) + __builtin_rotateleft64(acc[1], 7)
                    + __builtin_rotateleft64(acc[2], 12) + __builtin_rotateleft64(acc[3], 18);
        if (sizeof(void *) < sizeof(xxh_u64)) {
            size_t i;
            for (i = 0; i < 4; i++) {
                h64 = XXH64_mergeRound(h64, acc[i]);
            }
        } else {
            h64 = XXH64_mergeRound(h64, acc[0]);
            h64 = XXH64_mergeRound(h64, acc[1]);
            h64 = XXH64_mergeRound(h64, acc[2]);
            h64 = XXH64_mergeRound(h64, acc[3]);
        }
        return h64;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u64
XXH64_finalize(xxh_u64 hash, const xxh_u8* ptr, size_t len, XXH_alignment align)
{
    if (ptr==((void*)0)) __builtin_assume(len == 0);
    len &= 31;
    while (len >= 8) {
        xxh_u64 const k1 = XXH64_round(0, XXH_readLE64_align(ptr, align));
        ptr += 8;
        hash ^= k1;
        hash = __builtin_rotateleft64(hash,27) * 0x9E3779B185EBCA87ULL + 0x85EBCA77C2B2AE63ULL;
        len -= 8;
    }
    if (len >= 4) {
        hash ^= (xxh_u64)(XXH_readLE32_align(ptr, align)) * 0x9E3779B185EBCA87ULL;
        ptr += 4;
        hash = __builtin_rotateleft64(hash, 23) * 0xC2B2AE3D27D4EB4FULL + 0x165667B19E3779F9ULL;
        len -= 4;
    }
    while (len > 0) {
        hash ^= (*ptr++) * 0x27D4EB2F165667C5ULL;
        hash = __builtin_rotateleft64(hash, 11) * 0x9E3779B185EBCA87ULL;
        --len;
    }
    return XXH64_avalanche(hash);
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u64
XXH64_endian_align(const xxh_u8* input, size_t len, xxh_u64 seed, XXH_alignment align)
{
    xxh_u64 h64;
    if (input==((void*)0)) __builtin_assume(len == 0);
    if (len>=32) {
        xxh_u64 acc[4];
        XXH64_initAccs(acc, seed);
        input = XXH64_consumeLong(acc, input, len, align);
        h64 = XXH64_mergeAccs(acc);
    } else {
        h64 = seed + 0x27D4EB2F165667C5ULL;
    }
    h64 += (xxh_u64) len;
    return XXH64_finalize(h64, input, len, align);
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH64 (__attribute__((__noescape__)) const void* input, size_t len, XXH64_hash_t seed)
{
    if (0) {
        if ((((size_t)input) & 7)==0) {
            return XXH64_endian_align((const xxh_u8*)input, len, seed, XXH_aligned);
    } }
    return XXH64_endian_align((const xxh_u8*)input, len, seed, XXH_unaligned);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH64_state_t* XXH_INLINE_XXH64_createState(void)
{
    return (XXH_NAMESPACEXXH64_state_t*)XXH_malloc(sizeof(XXH_NAMESPACEXXH64_state_t));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_freeState(XXH_NAMESPACEXXH64_state_t* statePtr)
{
    XXH_free(statePtr);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* dstState, const XXH_NAMESPACEXXH64_state_t* srcState)
{
    memcpy(dstState, srcState, sizeof(*dstState));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* statePtr, XXH64_hash_t seed)
{
    __builtin_assume(statePtr != ((void*)0));
    memset(statePtr, 0, sizeof(*statePtr));
    XXH64_initAccs(statePtr->acc, seed);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH64_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    if (input==((void*)0)) {
        __builtin_assume(len == 0);
        return XXH_NAMESPACEXXH_OK;
    }
    state->total_len += len;
    __builtin_assume(state->bufferedSize <= sizeof(state->buffer));
    if (len < sizeof(state->buffer) - state->bufferedSize) {
        memcpy(state->buffer + state->bufferedSize, input, len);
        state->bufferedSize += (XXH32_hash_t)len;
        return XXH_NAMESPACEXXH_OK;
    }
    { const xxh_u8* xinput = (const xxh_u8*)input;
        const xxh_u8* const bEnd = xinput + len;
        if (state->bufferedSize) {
            memcpy(state->buffer + state->bufferedSize, xinput, sizeof(state->buffer) - state->bufferedSize);
            xinput += sizeof(state->buffer) - state->bufferedSize;
            (void)XXH64_consumeLong(state->acc, state->buffer, sizeof(state->buffer), XXH_aligned);
            state->bufferedSize = 0;
        }
        __builtin_assume(xinput <= bEnd);
        if ((size_t)(bEnd - xinput) >= sizeof(state->buffer)) {
            xinput = XXH64_consumeLong(state->acc, xinput, (size_t)(bEnd - xinput), XXH_unaligned);
        }
        if (xinput < bEnd) {
            memcpy(state->buffer, xinput, (size_t)(bEnd-xinput));
            state->bufferedSize = (unsigned)(bEnd-xinput);
        }
    }
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH64_digest(__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_state_t* state)
{
    xxh_u64 h64;
    if (state->total_len >= 32) {
        h64 = XXH64_mergeAccs(state->acc);
    } else {
        h64 = state->acc[2] + 0x27D4EB2F165667C5ULL;
    }
    h64 += (xxh_u64) state->total_len;
    return XXH64_finalize(h64, state->buffer, (size_t)state->total_len, XXH_aligned);
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_canonical_t* dst, XXH64_hash_t hash)
{
    do { _Static_assert(((sizeof(XXH_NAMESPACEXXH64_canonical_t) == sizeof(XXH64_hash_t))),"sizeof(XXH64_canonical_t) == sizeof(XXH64_hash_t)"); } while(0);
    if (1) hash = XXH_swap64(hash);
    memcpy(dst, &hash, sizeof(*dst));
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH64_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_canonical_t* src)
{
    return XXH_readBE64(src);
}
typedef long long __m64 __attribute__((__vector_size__(8), __aligned__(8)));
typedef long long __v1di __attribute__((__vector_size__(8)));
typedef int __v2si __attribute__((__vector_size__(8)));
typedef short __v4hi __attribute__((__vector_size__(8)));
typedef char __v8qi __attribute__((__vector_size__(8)));
typedef unsigned long long __v1du __attribute__ ((__vector_size__ (8)));
typedef unsigned int __v2su __attribute__ ((__vector_size__ (8)));
typedef unsigned short __v4hu __attribute__((__vector_size__(8)));
typedef unsigned char __v8qu __attribute__((__vector_size__(8)));
typedef signed char __v8qs __attribute__((__vector_size__(8)));
typedef long long __m128i __attribute__((__vector_size__(16), __aligned__(16)));
typedef long long __v2di __attribute__ ((__vector_size__ (16)));
typedef int __v4si __attribute__((__vector_size__(16)));
typedef short __v8hi __attribute__((__vector_size__(16)));
typedef char __v16qi __attribute__((__vector_size__(16)));
static __inline__ void __attribute__((__always_inline__, __nodebug__,
                                      __target__("mmx,no-evex512")))
_mm_empty(void) {
  __builtin_ia32_emms();
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi32_si64(int __i)
{
    return __extension__ (__m64)(__v2si){__i, 0};
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi64_si32(__m64 __m)
{
    return ((__v2si)__m)[0];
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi64_m64(long long __i)
{
    return (__m64)__i;
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtm64_si64(__m64 __m)
{
    return (long long)__m;
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_packs_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packsswb128( (__v8hi)__builtin_shufflevector(__m1, __m2, 0, 1), (__v8hi){})), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_packs_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packssdw128( (__v4si)__builtin_shufflevector(__m1, __m2, 0, 1), (__v4si){})), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_packs_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packuswb128( (__v8hi)__builtin_shufflevector(__m1, __m2, 0, 1), (__v8hi){})), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v8qi)__m1, (__v8qi)__m2,
                                          4, 12, 5, 13, 6, 14, 7, 15);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v4hi)__m1, (__v4hi)__m2,
                                          2, 6, 3, 7);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v2si)__m1, (__v2si)__m2, 1, 3);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v8qi)__m1, (__v8qi)__m2,
                                          0, 8, 1, 9, 2, 10, 3, 11);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v4hi)__m1, (__v4hi)__m2,
                                          0, 4, 1, 5);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v2si)__m1, (__v2si)__m2, 0, 2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v8qu)__m1) + ((__v8qu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hu)__m1) + ((__v4hu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v2su)__m1) + ((__v2su)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v8qs)__m1, (__v8qs)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v4hi)__m1, (__v4hi)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pu8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v8qu)__m1, (__v8qu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v4hu)__m1, (__v4hu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v8qu)__m1) - ((__v8qu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hu)__m1) - ((__v4hu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v2su)__m1) - ((__v2su)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v8qs)__m1, (__v8qs)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v4hi)__m1, (__v4hi)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pu8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v8qu)__m1, (__v8qu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v4hu)__m1, (__v4hu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_madd_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmaddwd128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m1), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m2), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_mulhi_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmulhw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m1), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m2), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_mullo_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hu)__m1) * ((__v4hu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sll_pi16(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_slli_pi16(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllwi128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sll_pi32(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pslld128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_slli_pi32(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pslldi128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sll_si64(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllq128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v2di)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_slli_si64(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllqi128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sra_pi16(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psraw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srai_pi16(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrawi128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sra_pi32(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrad128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srai_pi32(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psradi128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srl_pi16(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srli_pi16(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlwi128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srl_pi32(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrld128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srli_pi32(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrldi128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srl_si64(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlq128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v2di)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srli_si64(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlqi128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_and_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v1du)__m1) & ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_andnot_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(~((__v1du)__m1) & ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_or_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v1du)__m1) | ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_xor_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v1du)__m1) ^ ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpeq_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v8qi)__m1) == ((__v8qi)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpeq_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hi)__m1) == ((__v4hi)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpeq_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v2si)__m1) == ((__v2si)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpgt_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)((__v8qs)__m1 > (__v8qs)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpgt_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)((__v4hi)__m1 > (__v4hi)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpgt_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)((__v2si)__m1 > (__v2si)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setzero_si64(void) {
  return __extension__(__m64){0LL};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_pi32(int __i1, int __i0) {
  return __extension__(__m64)(__v2si){__i0, __i1};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_pi16(short __s3, short __s2, short __s1, short __s0) {
  return __extension__(__m64)(__v4hi){__s0, __s1, __s2, __s3};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_pi8(char __b7, char __b6, char __b5, char __b4, char __b3, char __b2,
            char __b1, char __b0) {
  return __extension__(__m64)(__v8qi){__b0, __b1, __b2, __b3,
                                      __b4, __b5, __b6, __b7};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_pi32(int __i) {
  return _mm_set_pi32(__i, __i);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_pi16(short __w) {
  return _mm_set_pi16(__w, __w, __w, __w);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_pi8(char __b) {
  return _mm_set_pi8(__b, __b, __b, __b, __b, __b, __b, __b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_pi32(int __i0, int __i1) {
  return _mm_set_pi32(__i1, __i0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_pi16(short __w0, short __w1, short __w2, short __w3) {
  return _mm_set_pi16(__w3, __w2, __w1, __w0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_pi8(char __b0, char __b1, char __b2, char __b3, char __b4, char __b5,
             char __b6, char __b7) {
  return _mm_set_pi8(__b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}

typedef int __v4si __attribute__((__vector_size__(16)));
typedef float __v4sf __attribute__((__vector_size__(16)));
typedef float __m128 __attribute__((__vector_size__(16), __aligned__(16)));
typedef float __m128_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef unsigned int __v4su __attribute__((__vector_size__(16)));
extern int posix_memalign(void **__memptr, size_t __alignment, size_t __size);
static __inline__ void *__attribute__((__always_inline__, __nodebug__,
                                       __malloc__, __alloc_size__(1),
                                       __alloc_align__(2)))
_mm_malloc(size_t __size, size_t __align) {
  if (__align == 1) {
    return malloc(__size);
  }
  if (!(__align & (__align - 1)) && __align < sizeof(void *))
    __align = sizeof(void *);
  void *__mallocedMemory;
  if (posix_memalign(&__mallocedMemory, __align, __size))
    return 0;
  return __mallocedMemory;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_free(void *__p)
{
  free(__p);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_add_ss(__m128 __a, __m128 __b) {
  __a[0] += __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_add_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a + (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sub_ss(__m128 __a, __m128 __b) {
  __a[0] -= __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sub_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a - (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_mul_ss(__m128 __a, __m128 __b) {
  __a[0] *= __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_mul_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a * (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_div_ss(__m128 __a, __m128 __b) {
  __a[0] /= __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_div_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a / (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sqrt_ss(__m128 __a)
{
  return (__m128)__builtin_ia32_sqrtss((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sqrt_ps(__m128 __a)
{
  return __builtin_ia32_sqrtps((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rcp_ss(__m128 __a)
{
  return (__m128)__builtin_ia32_rcpss((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rcp_ps(__m128 __a)
{
  return (__m128)__builtin_ia32_rcpps((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rsqrt_ss(__m128 __a)
{
  return __builtin_ia32_rsqrtss((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rsqrt_ps(__m128 __a)
{
  return __builtin_ia32_rsqrtps((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_min_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_minss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_min_ps(__m128 __a, __m128 __b)
{
  return __builtin_ia32_minps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_max_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_maxss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_max_ps(__m128 __a, __m128 __b)
{
  return __builtin_ia32_maxps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_and_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4su)__a & (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_andnot_ps(__m128 __a, __m128 __b) {
  return (__m128)(~(__v4su)__a & (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_or_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4su)__a | (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_xor_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4su)__a ^ (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpeq_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpeqss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpeq_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpeqps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmplt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmplt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmple_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpless((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmple_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpleps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpgt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpltss((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpgt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpge_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpless((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpge_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpleps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpneq_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpneqss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpneq_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpneqps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnlt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnlt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnle_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnless((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnle_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnleps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpngt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpnltss((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpngt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnge_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpnless((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnge_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnleps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpord_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpordss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpord_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpordps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpunord_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpunordss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpunord_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpunordps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comieq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comieq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comilt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comilt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comile_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comile((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comigt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comigt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comige_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comige((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comineq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comineq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomieq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomieq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomilt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomilt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomile_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomile((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomigt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomigt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomige_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomige((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomineq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomineq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtss_si32(__m128 __a)
{
  return __builtin_ia32_cvtss2si((__v4sf)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvt_ss2si(__m128 __a)
{
  return _mm_cvtss_si32(__a);
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtss_si64(__m128 __a)
{
  return __builtin_ia32_cvtss2si64((__v4sf)__a);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pi32(__m128 __a)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvtps2dq((__v4sf)(__m128i) __builtin_shufflevector((__v4si)(__a), __extension__(__v4si){}, 0, 1, 4, 5))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvt_ps2pi(__m128 __a)
{
  return _mm_cvtps_pi32(__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvttss_si32(__m128 __a)
{
  return __builtin_ia32_cvttss2si((__v4sf)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtt_ss2si(__m128 __a)
{
  return _mm_cvttss_si32(__a);
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvttss_si64(__m128 __a)
{
  return __builtin_ia32_cvttss2si64((__v4sf)__a);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvttps_pi32(__m128 __a)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvttps2dq((__v4sf)(__m128i) __builtin_shufflevector((__v4si)(__a), __extension__(__v4si){}, 0, 1, 4, 5))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtt_ps2pi(__m128 __a)
{
  return _mm_cvttps_pi32(__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128))) _mm_cvtsi32_ss(__m128 __a,
                                                                     int __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128))) _mm_cvt_si2ss(__m128 __a,
                                                                    int __b) {
  return _mm_cvtsi32_ss(__a, __b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtsi64_ss(__m128 __a, long long __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi32_ps(__m128 __a, __m64 __b)
{
  return (__m128)__builtin_shufflevector(
      (__v4sf)__a,
      __builtin_convertvector((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, 2, 3), __v4sf),
      4, 5, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvt_pi2ps(__m128 __a, __m64 __b)
{
  return _mm_cvtpi32_ps(__a, __b);
}
static __inline__ float __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtss_f32(__m128 __a) {
  return __a[0];
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadh_pi(__m128 __a, const __m64 *__p)
{
  typedef float __mm_loadh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_loadh_pi_struct {
    __mm_loadh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  __mm_loadh_pi_v2f32 __b = ((const struct __mm_loadh_pi_struct*)__p)->__u;
  __m128 __bb = __builtin_shufflevector(__b, __b, 0, 1, 0, 1);
  return __builtin_shufflevector(__a, __bb, 0, 1, 4, 5);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadl_pi(__m128 __a, const __m64 *__p)
{
  typedef float __mm_loadl_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_loadl_pi_struct {
    __mm_loadl_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  __mm_loadl_pi_v2f32 __b = ((const struct __mm_loadl_pi_struct*)__p)->__u;
  __m128 __bb = __builtin_shufflevector(__b, __b, 0, 1, 0, 1);
  return __builtin_shufflevector(__a, __bb, 4, 5, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_load_ss(const float *__p)
{
  struct __mm_load_ss_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  float __u = ((const struct __mm_load_ss_struct*)__p)->__u;
  return __extension__ (__m128){ __u, 0, 0, 0 };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_load1_ps(const float *__p)
{
  struct __mm_load1_ps_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  float __u = ((const struct __mm_load1_ps_struct*)__p)->__u;
  return __extension__ (__m128){ __u, __u, __u, __u };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_load_ps(const float *__p)
{
  return *(const __m128*)__p;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadu_ps(const float *__p)
{
  struct __loadu_ps {
    __m128_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_ps*)__p)->__v;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadr_ps(const float *__p)
{
  __m128 __a = _mm_load_ps(__p);
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 3, 2, 1, 0);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_undefined_ps(void)
{
  return (__m128)__builtin_ia32_undef128();
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set_ss(float __w) {
  return __extension__ (__m128){ __w, 0.0f, 0.0f, 0.0f };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set1_ps(float __w) {
  return __extension__ (__m128){ __w, __w, __w, __w };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set_ps1(float __w) {
    return _mm_set1_ps(__w);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set_ps(float __z, float __y, float __x, float __w) {
  return __extension__ (__m128){ __w, __x, __y, __z };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_setr_ps(float __z, float __y, float __x, float __w) {
  return __extension__ (__m128){ __z, __y, __x, __w };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_setzero_ps(void) {
  return __extension__ (__m128){ 0.0f, 0.0f, 0.0f, 0.0f };
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storeh_pi(__m64 *__p, __m128 __a)
{
  typedef float __mm_storeh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_storeh_pi_struct {
    __mm_storeh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pi_struct*)__p)->__u = __builtin_shufflevector(__a, __a, 2, 3);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storel_pi(__m64 *__p, __m128 __a)
{
  typedef float __mm_storeh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_storeh_pi_struct {
    __mm_storeh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pi_struct*)__p)->__u = __builtin_shufflevector(__a, __a, 0, 1);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store_ss(float *__p, __m128 __a)
{
  struct __mm_store_ss_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store_ss_struct*)__p)->__u = __a[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storeu_ps(float *__p, __m128 __a)
{
  struct __storeu_ps {
    __m128_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_ps*)__p)->__v = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store_ps(float *__p, __m128 __a)
{
  *(__m128*)__p = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store1_ps(float *__p, __m128 __a)
{
  __a = __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 0, 0, 0, 0);
  _mm_store_ps(__p, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store_ps1(float *__p, __m128 __a)
{
  _mm_store1_ps(__p, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storer_ps(float *__p, __m128 __a)
{
  __a = __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 3, 2, 1, 0);
  _mm_store_ps(__p, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_stream_pi(void *__p, __m64 __a)
{
  __builtin_nontemporal_store(__a, (__m64 *)__p);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_stream_ps(void *__p, __m128 __a)
{
  __builtin_nontemporal_store((__v4sf)__a, (__v4sf*)__p);
}
void _mm_sfence(void);
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_max_pi16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_max((__v4hi)__a, (__v4hi)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_max_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_max((__v8qu)__a, (__v8qu)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_min_pi16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_min((__v4hi)__a, (__v4hi)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_min_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_min((__v8qu)__a, (__v8qu)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_movemask_pi8(__m64 __a)
{
  return __builtin_ia32_pmovmskb128((__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, 2, 3));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_mulhi_pu16(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmulhuw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_maskmove_si64(__m64 __d, __m64 __n, char *__p)
{
  __m128i __d128 = (__m128i) __builtin_shufflevector((__v2si)(__d), __extension__(__v2si){}, 0, 1, -1, -1);
  __m128i __n128 = (__m128i) __builtin_shufflevector((__v2si)(__n), __extension__(__v2si){}, 0, 1, 2, 3);
  if (((long unsigned int)__p & 0xfff) >= 4096-15 &&
      ((long unsigned int)__p & 0xfff) <= 4096-8) {
    __p -= 8;
    __d128 = __builtin_ia32_pslldqi128_byteshift((__v2di)__d128, 8);
    __n128 = __builtin_ia32_pslldqi128_byteshift((__v2di)__n128, 8);
  }
  __builtin_ia32_maskmovdqu((__v16qi)__d128, (__v16qi)__n128, __p);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_avg_pu8(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pavgb128((__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_avg_pu16(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pavgw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sad_pu8(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psadbw128((__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, 2, 3), (__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, 2, 3))), __extension__(__v2di){}, 0);
}
unsigned int _mm_getcsr(void);
void _mm_setcsr(unsigned int __i);
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_unpackhi_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 2, 6, 3, 7);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_unpacklo_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 0, 4, 1, 5);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_move_ss(__m128 __a, __m128 __b) {
  __a[0] = __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_movehl_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 6, 7, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_movelh_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 0, 1, 4, 5);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi16_ps(__m64 __a)
{
  return __builtin_convertvector((__v4hi)__a, __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpu16_ps(__m64 __a)
{
  return __builtin_convertvector((__v4hu)__a, __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi8_ps(__m64 __a)
{
  return __builtin_convertvector(
      __builtin_shufflevector((__v8qs)__a, __extension__ (__v8qs){},
                              0, 1, 2, 3), __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpu8_ps(__m64 __a)
{
  return __builtin_convertvector(
      __builtin_shufflevector((__v8qu)__a, __extension__ (__v8qu){},
                              0, 1, 2, 3), __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi32x2_ps(__m64 __a, __m64 __b)
{
  return __builtin_convertvector(
      __builtin_shufflevector((__v2si)__a, (__v2si)__b,
                              0, 1, 2, 3), __v4sf);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pi16(__m128 __a)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packssdw128( (__v4si)__builtin_ia32_cvtps2dq((__v4sf)__a), (__v4si)_mm_setzero_ps())), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pi8(__m128 __a)
{
  __m64 __b, __c;
  __b = _mm_cvtps_pi16(__a);
  __c = _mm_setzero_si64();
  return _mm_packs_pi16(__b, __c);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_movemask_ps(__m128 __a)
{
  return __builtin_ia32_movmskps((__v4sf)__a);
}

typedef double __m128d __attribute__((__vector_size__(16), __aligned__(16)));
typedef long long __m128i __attribute__((__vector_size__(16), __aligned__(16)));
typedef double __m128d_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef long long __m128i_u
    __attribute__((__vector_size__(16), __aligned__(1)));
typedef double __v2df __attribute__((__vector_size__(16)));
typedef long long __v2di __attribute__((__vector_size__(16)));
typedef short __v8hi __attribute__((__vector_size__(16)));
typedef char __v16qi __attribute__((__vector_size__(16)));
typedef unsigned long long __v2du __attribute__((__vector_size__(16)));
typedef unsigned short __v8hu __attribute__((__vector_size__(16)));
typedef unsigned char __v16qu __attribute__((__vector_size__(16)));
typedef signed char __v16qs __attribute__((__vector_size__(16)));
typedef _Float16 __v8hf __attribute__((__vector_size__(16), __aligned__(16)));
typedef _Float16 __m128h __attribute__((__vector_size__(16), __aligned__(16)));
typedef _Float16 __m128h_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef __bf16 __v8bf __attribute__((__vector_size__(16), __aligned__(16)));
typedef __bf16 __m128bh __attribute__((__vector_size__(16), __aligned__(16)));
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] += __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a + (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] -= __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a - (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] *= __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a * (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_div_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] /= __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_div_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a / (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sqrt_sd(__m128d __a,
                                                         __m128d __b) {
  __m128d __c = __builtin_ia32_sqrtsd((__v2df)__b);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sqrt_pd(__m128d __a) {
  return __builtin_ia32_sqrtpd((__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_minsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_pd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_minpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_maxsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_pd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_maxpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_and_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2du)__a & (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_andnot_pd(__m128d __a, __m128d __b) {
  return (__m128d)(~(__v2du)__a & (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_or_pd(__m128d __a,
                                                                 __m128d __b) {
  return (__m128d)((__v2du)__a | (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_xor_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2du)__a ^ (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpeqpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmple_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplepd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltpd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpge_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplepd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpord_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpordpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpunord_pd(__m128d __a,
                                                             __m128d __b) {
  return (__m128d)__builtin_ia32_cmpunordpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpneq_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpneqpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnlt_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnle_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlepd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpngt_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltpd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnge_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlepd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpeqsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmple_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplesd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_sd(__m128d __a,
                                                          __m128d __b) {
  __m128d __c = __builtin_ia32_cmpltsd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpge_sd(__m128d __a,
                                                          __m128d __b) {
  __m128d __c = __builtin_ia32_cmplesd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpord_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpordsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpunord_sd(__m128d __a,
                                                             __m128d __b) {
  return (__m128d)__builtin_ia32_cmpunordsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpneq_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpneqsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnlt_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnle_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlesd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpngt_sd(__m128d __a,
                                                           __m128d __b) {
  __m128d __c = __builtin_ia32_cmpnltsd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnge_sd(__m128d __a,
                                                           __m128d __b) {
  __m128d __c = __builtin_ia32_cmpnlesd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comieq_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdeq((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comilt_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdlt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comile_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdle((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comigt_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdgt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comige_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdge((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comineq_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_comisdneq((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomieq_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdeq((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomilt_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdlt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomile_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdle((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomigt_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdgt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomige_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdge((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomineq_sd(__m128d __a,
                                                         __m128d __b) {
  return __builtin_ia32_ucomisdneq((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtpd_ps(__m128d __a) {
  return __builtin_ia32_cvtpd2ps((__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pd(__m128 __a) {
  return (__m128d) __builtin_convertvector(
      __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 0, 1), __v2df);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtepi32_pd(__m128i __a) {
  return (__m128d) __builtin_convertvector(
      __builtin_shufflevector((__v4si)__a, (__v4si)__a, 0, 1), __v2df);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtpd_epi32(__m128d __a) {
  return __builtin_ia32_cvtpd2dq((__v2df)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsd_si32(__m128d __a) {
  return __builtin_ia32_cvtsd2si((__v2df)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsd_ss(__m128 __a,
                                                         __m128d __b) {
  return (__m128)__builtin_ia32_cvtsd2ss((__v4sf)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi32_sd(__m128d __a, int __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtss_sd(__m128d __a, __m128 __b) {
  __a[0] = __b[0];
  return __a;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttpd_epi32(__m128d __a) {
  return (__m128i)__builtin_ia32_cvttpd2dq((__v2df)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttsd_si32(__m128d __a) {
  return __builtin_ia32_cvttsd2si((__v2df)__a);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtpd_pi32(__m128d __a) {
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvtpd2dq((__v2df)__a)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttpd_pi32(__m128d __a) {
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvttpd2dq((__v2df)__a)), __extension__(__v2di){}, 0);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi32_pd(__m64 __a) {
  return (__m128d) __builtin_convertvector((__v2si)__a, __v2df);
}
static __inline__ double __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsd_f64(__m128d __a) {
  return __a[0];
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_load_pd(double const *__dp) {
  return *(const __m128d *)__dp;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_load1_pd(double const *__dp) {
  struct __mm_load1_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_load1_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, __u};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadr_pd(double const *__dp) {
  __m128d __u = *(const __m128d *)__dp;
  return __builtin_shufflevector((__v2df)__u, (__v2df)__u, 1, 0);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_pd(double const *__dp) {
  struct __loadu_pd {
    __m128d_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_pd *)__dp)->__v;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_si64(void const *__a) {
  struct __loadu_si64 {
    long long __v;
  } __attribute__((__packed__, __may_alias__));
  long long __u = ((const struct __loadu_si64 *)__a)->__v;
  return __extension__(__m128i)(__v2di){__u, 0LL};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_si32(void const *__a) {
  struct __loadu_si32 {
    int __v;
  } __attribute__((__packed__, __may_alias__));
  int __u = ((const struct __loadu_si32 *)__a)->__v;
  return __extension__(__m128i)(__v4si){__u, 0, 0, 0};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_si16(void const *__a) {
  struct __loadu_si16 {
    short __v;
  } __attribute__((__packed__, __may_alias__));
  short __u = ((const struct __loadu_si16 *)__a)->__v;
  return __extension__(__m128i)(__v8hi){__u, 0, 0, 0, 0, 0, 0, 0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_load_sd(double const *__dp) {
  struct __mm_load_sd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_load_sd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, 0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadh_pd(__m128d __a,
                                                          double const *__dp) {
  struct __mm_loadh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_loadh_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__a[0], __u};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadl_pd(__m128d __a,
                                                          double const *__dp) {
  struct __mm_loadl_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_loadl_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_undefined_pd(void) {
  return (__m128d)__builtin_ia32_undef128();
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_sd(double __w) {
  return __extension__(__m128d){__w, 0.0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set1_pd(double __w) {
  return __extension__(__m128d){__w, __w};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_pd1(double __w) {
  return _mm_set1_pd(__w);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_pd(double __w,
                                                                  double __x) {
  return __extension__(__m128d){__x, __w};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_setr_pd(double __w,
                                                                   double __x) {
  return __extension__(__m128d){__w, __x};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_setzero_pd(void) {
  return __extension__(__m128d){0.0, 0.0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_move_sd(__m128d __a, __m128d __b) {
  __a[0] = __b[0];
  return __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_sd(double *__dp,
                                                       __m128d __a) {
  struct __mm_store_sd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store_sd_struct *)__dp)->__u = __a[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_pd(double *__dp,
                                                       __m128d __a) {
  *(__m128d *)__dp = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store1_pd(double *__dp,
                                                        __m128d __a) {
  __a = __builtin_shufflevector((__v2df)__a, (__v2df)__a, 0, 0);
  _mm_store_pd(__dp, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_pd1(double *__dp,
                                                        __m128d __a) {
  _mm_store1_pd(__dp, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_pd(double *__dp,
                                                        __m128d __a) {
  struct __storeu_pd {
    __m128d_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_pd *)__dp)->__v = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storer_pd(double *__dp,
                                                        __m128d __a) {
  __a = __builtin_shufflevector((__v2df)__a, (__v2df)__a, 1, 0);
  *(__m128d *)__dp = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeh_pd(double *__dp,
                                                        __m128d __a) {
  struct __mm_storeh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pd_struct *)__dp)->__u = __a[1];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storel_pd(double *__dp,
                                                        __m128d __a) {
  struct __mm_storeh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pd_struct *)__dp)->__u = __a[0];
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_epi8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v16qu)__a + (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v8hu)__a + (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_epi32(__m128i __a, __m128i __b) {
  return (__m128i)((__v4su)__a + (__v4su)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_si64(__m64 __a, __m64 __b) {
  return (__m64)(((unsigned long long)__a) + ((unsigned long long)__b));
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_epi64(__m128i __a, __m128i __b) {
  return (__m128i)((__v2du)__a + (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epi8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v16qs)__a, (__v16qs)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epu8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epu16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v8hu)__a, (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_avg_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_ia32_pavgb128((__v16qi)__a, (__v16qi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_avg_epu16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_ia32_pavgw128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_madd_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_ia32_pmaddwd128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_max((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_elementwise_max((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_min((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_elementwise_min((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mulhi_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_pmulhw128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mulhi_epu16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_pmulhuw128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mullo_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hu)__a * (__v8hu)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_su32(__m64 __a, __m64 __b) {
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmuludq128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_epu32(__m128i __a,
                                                           __m128i __b) {
  return __builtin_ia32_pmuludq128((__v4si)__a, (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sad_epu8(__m128i __a,
                                                          __m128i __b) {
  return __builtin_ia32_psadbw128((__v16qi)__a, (__v16qi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_epi8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v16qu)__a - (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v8hu)__a - (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_epi32(__m128i __a, __m128i __b) {
  return (__m128i)((__v4su)__a - (__v4su)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_si64(__m64 __a, __m64 __b) {
  return (__m64)((unsigned long long)__a - (unsigned long long)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_epi64(__m128i __a, __m128i __b) {
  return (__m128i)((__v2du)__a - (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epi8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v16qs)__a, (__v16qs)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epu8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epu16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v8hu)__a, (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_and_si128(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a & (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_andnot_si128(__m128i __a,
                                                              __m128i __b) {
  return (__m128i)(~(__v2du)__a & (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_or_si128(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v2du)__a | (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_xor_si128(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a ^ (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_slli_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psllwi128((__v8hi)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sll_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psllw128((__v8hi)__a, (__v8hi)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_slli_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_pslldi128((__v4si)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sll_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_pslld128((__v4si)__a, (__v4si)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_slli_epi64(__m128i __a,
                                                            int __count) {
  return __builtin_ia32_psllqi128((__v2di)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sll_epi64(__m128i __a,
                                                           __m128i __count) {
  return __builtin_ia32_psllq128((__v2di)__a, (__v2di)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srai_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrawi128((__v8hi)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sra_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psraw128((__v8hi)__a, (__v8hi)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srai_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psradi128((__v4si)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sra_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrad128((__v4si)__a, (__v4si)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srli_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrlwi128((__v8hi)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srl_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrlw128((__v8hi)__a, (__v8hi)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srli_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrldi128((__v4si)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srl_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrld128((__v4si)__a, (__v4si)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srli_epi64(__m128i __a,
                                                            int __count) {
  return __builtin_ia32_psrlqi128((__v2di)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srl_epi64(__m128i __a,
                                                           __m128i __count) {
  return __builtin_ia32_psrlq128((__v2di)__a, (__v2di)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_epi8(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)((__v16qi)__a == (__v16qi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hi)__a == (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v4si)__a == (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_epi8(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)((__v16qs)__a > (__v16qs)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hi)__a > (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v4si)__a > (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_epi8(__m128i __a,
                                                            __m128i __b) {
  return _mm_cmpgt_epi8(__b, __a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_epi16(__m128i __a,
                                                             __m128i __b) {
  return _mm_cmpgt_epi16(__b, __a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_epi32(__m128i __a,
                                                             __m128i __b) {
  return _mm_cmpgt_epi32(__b, __a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi64_sd(__m128d __a, long long __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsd_si64(__m128d __a) {
  return __builtin_ia32_cvtsd2si64((__v2df)__a);
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttsd_si64(__m128d __a) {
  return __builtin_ia32_cvttsd2si64((__v2df)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtepi32_ps(__m128i __a) {
  return (__m128) __builtin_convertvector((__v4si)__a, __v4sf);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtps_epi32(__m128 __a) {
  return (__m128i)__builtin_ia32_cvtps2dq((__v4sf)__a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttps_epi32(__m128 __a) {
  return (__m128i)__builtin_ia32_cvttps2dq((__v4sf)__a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi32_si128(int __a) {
  return __extension__(__m128i)(__v4si){__a, 0, 0, 0};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi64_si128(long long __a) {
  return __extension__(__m128i)(__v2di){__a, 0};
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi128_si32(__m128i __a) {
  __v4si __b = (__v4si)__a;
  return __b[0];
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi128_si64(__m128i __a) {
  return __a[0];
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_load_si128(__m128i const *__p) {
  return *__p;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_loadu_si128(__m128i_u const *__p) {
  struct __loadu_si128 {
    __m128i_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_si128 *)__p)->__v;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_loadl_epi64(__m128i_u const *__p) {
  struct __mm_loadl_epi64_struct {
    long long __u;
  } __attribute__((__packed__, __may_alias__));
  return __extension__(__m128i){
      ((const struct __mm_loadl_epi64_struct *)__p)->__u, 0};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_undefined_si128(void) {
  return (__m128i)__builtin_ia32_undef128();
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi64x(long long __q1, long long __q0) {
  return __extension__(__m128i)(__v2di){__q0, __q1};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi64(__m64 __q1, __m64 __q0) {
  return _mm_set_epi64x((long long)__q1[0], (long long)__q0[0]);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_epi32(int __i3,
                                                                     int __i2,
                                                                     int __i1,
                                                                     int __i0) {
  return __extension__(__m128i)(__v4si){__i0, __i1, __i2, __i3};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi16(short __w7, short __w6, short __w5, short __w4, short __w3,
              short __w2, short __w1, short __w0) {
  return __extension__(__m128i)(__v8hi){__w0, __w1, __w2, __w3,
                                        __w4, __w5, __w6, __w7};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi8(char __b15, char __b14, char __b13, char __b12, char __b11,
             char __b10, char __b9, char __b8, char __b7, char __b6, char __b5,
             char __b4, char __b3, char __b2, char __b1, char __b0) {
  return __extension__(__m128i)(__v16qi){
      __b0, __b1, __b2, __b3, __b4, __b5, __b6, __b7,
      __b8, __b9, __b10, __b11, __b12, __b13, __b14, __b15};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_epi64x(long long __q) {
  return _mm_set_epi64x(__q, __q);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_epi64(__m64 __q) {
  return _mm_set_epi64(__q, __q);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set1_epi32(int __i) {
  return _mm_set_epi32(__i, __i, __i, __i);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_epi16(short __w) {
  return _mm_set_epi16(__w, __w, __w, __w, __w, __w, __w, __w);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set1_epi8(char __b) {
  return _mm_set_epi8(__b, __b, __b, __b, __b, __b, __b, __b, __b, __b, __b,
                      __b, __b, __b, __b, __b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi64(__m64 __q0, __m64 __q1) {
  return _mm_set_epi64(__q1, __q0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi32(int __i0, int __i1, int __i2, int __i3) {
  return _mm_set_epi32(__i3, __i2, __i1, __i0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi16(short __w0, short __w1, short __w2, short __w3, short __w4,
               short __w5, short __w6, short __w7) {
  return _mm_set_epi16(__w7, __w6, __w5, __w4, __w3, __w2, __w1, __w0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi8(char __b0, char __b1, char __b2, char __b3, char __b4, char __b5,
              char __b6, char __b7, char __b8, char __b9, char __b10,
              char __b11, char __b12, char __b13, char __b14, char __b15) {
  return _mm_set_epi8(__b15, __b14, __b13, __b12, __b11, __b10, __b9, __b8,
                      __b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_setzero_si128(void) {
  return __extension__(__m128i)(__v2di){0LL, 0LL};
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_si128(__m128i *__p,
                                                          __m128i __b) {
  *__p = __b;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si128(__m128i_u *__p,
                                                           __m128i __b) {
  struct __storeu_si128 {
    __m128i_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si128 *)__p)->__v = __b;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si64(void *__p,
                                                          __m128i __b) {
  struct __storeu_si64 {
    long long __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si64 *)__p)->__v = ((__v2di)__b)[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si32(void *__p,
                                                          __m128i __b) {
  struct __storeu_si32 {
    int __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si32 *)__p)->__v = ((__v4si)__b)[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si16(void *__p,
                                                          __m128i __b) {
  struct __storeu_si16 {
    short __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si16 *)__p)->__v = ((__v8hi)__b)[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_maskmoveu_si128(__m128i __d,
                                                              __m128i __n,
                                                              char *__p) {
  __builtin_ia32_maskmovdqu((__v16qi)__d, (__v16qi)__n, __p);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storel_epi64(__m128i_u *__p,
                                                           __m128i __a) {
  struct __mm_storel_epi64_struct {
    long long __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storel_epi64_struct *)__p)->__u = __a[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_stream_pd(void *__p,
                                                        __m128d __a) {
  __builtin_nontemporal_store((__v2df)__a, (__v2df *)__p);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_stream_si128(void *__p,
                                                           __m128i __a) {
  __builtin_nontemporal_store((__v2di)__a, (__v2di *)__p);
}
static __inline__ void
    __attribute__((__always_inline__, __nodebug__, __target__("sse2")))
    _mm_stream_si32(void *__p, int __a) {
  __builtin_ia32_movnti((int *)__p, __a);
}
static __inline__ void
    __attribute__((__always_inline__, __nodebug__, __target__("sse2")))
    _mm_stream_si64(void *__p, long long __a) {
  __builtin_ia32_movnti64((long long *)__p, __a);
}
void _mm_clflush(void const *__p);
void _mm_lfence(void);
void _mm_mfence(void);
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_packs_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_packsswb128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_packs_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_packssdw128((__v4si)__a, (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_packus_epi16(__m128i __a,
                                                              __m128i __b) {
  return (__m128i)__builtin_ia32_packuswb128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_movemask_epi8(__m128i __a) {
  return __builtin_ia32_pmovmskb128((__v16qi)__a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi8(__m128i __a,
                                                               __m128i __b) {
  return (__m128i)__builtin_shufflevector(
      (__v16qi)__a, (__v16qi)__b, 8, 16 + 8, 9, 16 + 9, 10, 16 + 10, 11,
      16 + 11, 12, 16 + 12, 13, 16 + 13, 14, 16 + 14, 15, 16 + 15);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi16(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v8hi)__a, (__v8hi)__b, 4, 8 + 4, 5,
                                          8 + 5, 6, 8 + 6, 7, 8 + 7);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi32(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v4si)__a, (__v4si)__b, 2, 4 + 2, 3,
                                          4 + 3);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi64(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v2di)__a, (__v2di)__b, 1, 2 + 1);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi8(__m128i __a,
                                                               __m128i __b) {
  return (__m128i)__builtin_shufflevector(
      (__v16qi)__a, (__v16qi)__b, 0, 16 + 0, 1, 16 + 1, 2, 16 + 2, 3, 16 + 3, 4,
      16 + 4, 5, 16 + 5, 6, 16 + 6, 7, 16 + 7);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi16(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v8hi)__a, (__v8hi)__b, 0, 8 + 0, 1,
                                          8 + 1, 2, 8 + 2, 3, 8 + 3);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi32(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v4si)__a, (__v4si)__b, 0, 4 + 0, 1,
                                          4 + 1);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi64(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v2di)__a, (__v2di)__b, 0, 2 + 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_movepi64_pi64(__m128i __a) {
  return (__m64)__a[0];
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_movpi64_epi64(__m64 __a) {
  return __builtin_shufflevector((__v1di)__a, _mm_setzero_si64(), 0, 1);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_move_epi64(__m128i __a) {
  return __builtin_shufflevector((__v2di)__a, _mm_setzero_si128(), 0, 2);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pd(__m128d __a, __m128d __b) {
  return __builtin_shufflevector((__v2df)__a, (__v2df)__b, 1, 2 + 1);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pd(__m128d __a, __m128d __b) {
  return __builtin_shufflevector((__v2df)__a, (__v2df)__b, 0, 2 + 0);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_movemask_pd(__m128d __a) {
  return __builtin_ia32_movmskpd((__v2df)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castpd_ps(__m128d __a) {
  return (__m128)__a;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castpd_si128(__m128d __a) {
  return (__m128i)__a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castps_pd(__m128 __a) {
  return (__m128d)__a;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castps_si128(__m128 __a) {
  return (__m128i)__a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castsi128_ps(__m128i __a) {
  return (__m128)__a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castsi128_pd(__m128i __a) {
  return (__m128d)__a;
}
void _mm_pause(void);
_Alignas(64) static const xxh_u8 XXH3_kSecret[192] = {
    0xb8, 0xfe, 0x6c, 0x39, 0x23, 0xa4, 0x4b, 0xbe, 0x7c, 0x01, 0x81, 0x2c, 0xf7, 0x21, 0xad, 0x1c,
    0xde, 0xd4, 0x6d, 0xe9, 0x83, 0x90, 0x97, 0xdb, 0x72, 0x40, 0xa4, 0xa4, 0xb7, 0xb3, 0x67, 0x1f,
    0xcb, 0x79, 0xe6, 0x4e, 0xcc, 0xc0, 0xe5, 0x78, 0x82, 0x5a, 0xd0, 0x7d, 0xcc, 0xff, 0x72, 0x21,
    0xb8, 0x08, 0x46, 0x74, 0xf7, 0x43, 0x24, 0x8e, 0xe0, 0x35, 0x90, 0xe6, 0x81, 0x3a, 0x26, 0x4c,
    0x3c, 0x28, 0x52, 0xbb, 0x91, 0xc3, 0x00, 0xcb, 0x88, 0xd0, 0x65, 0x8b, 0x1b, 0x53, 0x2e, 0xa3,
    0x71, 0x64, 0x48, 0x97, 0xa2, 0x0d, 0xf9, 0x4e, 0x38, 0x19, 0xef, 0x46, 0xa9, 0xde, 0xac, 0xd8,
    0xa8, 0xfa, 0x76, 0x3f, 0xe3, 0x9c, 0x34, 0x3f, 0xf9, 0xdc, 0xbb, 0xc7, 0xc7, 0x0b, 0x4f, 0x1d,
    0x8a, 0x51, 0xe0, 0x4b, 0xcd, 0xb4, 0x59, 0x31, 0xc8, 0x9f, 0x7e, 0xc9, 0xd9, 0x78, 0x73, 0x64,
    0xea, 0xc5, 0xac, 0x83, 0x34, 0xd3, 0xeb, 0xc3, 0xc5, 0x81, 0xa0, 0xff, 0xfa, 0x13, 0x63, 0xeb,
    0x17, 0x0d, 0xdd, 0x51, 0xb7, 0xf0, 0xda, 0x49, 0xd3, 0x16, 0x55, 0x26, 0x29, 0xd4, 0x68, 0x9e,
    0x2b, 0x16, 0xbe, 0x58, 0x7d, 0x47, 0xa1, 0xfc, 0x8f, 0xf8, 0xb8, 0xd1, 0x7a, 0xd0, 0x31, 0xce,
    0x45, 0xcb, 0x3a, 0x8f, 0x95, 0x16, 0x04, 0x28, 0xaf, 0xd7, 0xfb, 0xca, 0xbb, 0x4b, 0x40, 0x7e,
};
static const xxh_u64 PRIME_MX1 = 0x165667919E3779F9ULL;
static const xxh_u64 PRIME_MX2 = 0x9FB21C651E98DF25ULL;
static XXH_NAMESPACEXXH128_hash_t
XXH_mult64to128(xxh_u64 lhs, xxh_u64 rhs)
{
    __uint128_t const product = (__uint128_t)lhs * (__uint128_t)rhs;
    XXH_NAMESPACEXXH128_hash_t r128;
    r128.low64 = (xxh_u64)(product);
    r128.high64 = (xxh_u64)(product >> 64);
    return r128;
}
static xxh_u64
XXH3_mul128_fold64(xxh_u64 lhs, xxh_u64 rhs)
{
    XXH_NAMESPACEXXH128_hash_t product = XXH_mult64to128(lhs, rhs);
    return product.low64 ^ product.high64;
}
static __attribute__((__unused__)) __attribute__((__const__)) xxh_u64 XXH_xorshift64(xxh_u64 v64, int shift)
{
    __builtin_assume(0 <= shift && shift < 64);
    return v64 ^ (v64 >> shift);
}
static XXH64_hash_t XXH3_avalanche(xxh_u64 h64)
{
    h64 = XXH_xorshift64(h64, 37);
    h64 *= PRIME_MX1;
    h64 = XXH_xorshift64(h64, 32);
    return h64;
}
static XXH64_hash_t XXH3_rrmxmx(xxh_u64 h64, xxh_u64 len)
{
    h64 ^= __builtin_rotateleft64(h64, 49) ^ __builtin_rotateleft64(h64, 24);
    h64 *= PRIME_MX2;
    h64 ^= (h64 >> 35) + len ;
    h64 *= PRIME_MX2;
    return XXH_xorshift64(h64, 28);
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_1to3_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(1 <= len && len <= 3);
    __builtin_assume(secret != ((void*)0));
    { xxh_u8 const c1 = input[0];
        xxh_u8 const c2 = input[len >> 1];
        xxh_u8 const c3 = input[len - 1];
        xxh_u32 const combined = ((xxh_u32)c1 << 16) | ((xxh_u32)c2 << 24)
                               | ((xxh_u32)c3 << 0) | ((xxh_u32)len << 8);
        xxh_u64 const bitflip = (XXH_readLE32(secret) ^ XXH_readLE32(secret+4)) + seed;
        xxh_u64 const keyed = (xxh_u64)combined ^ bitflip;
        return XXH64_avalanche(keyed);
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_4to8_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(4 <= len && len <= 8);
    seed ^= (xxh_u64)XXH_swap32((xxh_u32)seed) << 32;
    { xxh_u32 const input1 = XXH_readLE32(input);
        xxh_u32 const input2 = XXH_readLE32(input + len - 4);
        xxh_u64 const bitflip = (XXH_readLE64(secret+8) ^ XXH_readLE64(secret+16)) - seed;
        xxh_u64 const input64 = input2 + (((xxh_u64)input1) << 32);
        xxh_u64 const keyed = input64 ^ bitflip;
        return XXH3_rrmxmx(keyed, len);
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_9to16_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(9 <= len && len <= 16);
    { xxh_u64 const bitflip1 = (XXH_readLE64(secret+24) ^ XXH_readLE64(secret+32)) + seed;
        xxh_u64 const bitflip2 = (XXH_readLE64(secret+40) ^ XXH_readLE64(secret+48)) - seed;
        xxh_u64 const input_lo = XXH_readLE64(input) ^ bitflip1;
        xxh_u64 const input_hi = XXH_readLE64(input + len - 8) ^ bitflip2;
        xxh_u64 const acc = len
                          + XXH_swap64(input_lo) + input_hi
                          + XXH3_mul128_fold64(input_lo, input_hi);
        return XXH3_avalanche(acc);
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_0to16_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(len <= 16);
    { if (__builtin_expect(len > 8, 1)) return XXH3_len_9to16_64b(input, len, secret, seed);
        if (__builtin_expect(len >= 4, 1)) return XXH3_len_4to8_64b(input, len, secret, seed);
        if (len) return XXH3_len_1to3_64b(input, len, secret, seed);
        return XXH64_avalanche(seed ^ (XXH_readLE64(secret+56) ^ XXH_readLE64(secret+64)));
    }
}
static __attribute__((__unused__)) xxh_u64 XXH3_mix16B(const xxh_u8* restrict input,
                                     const xxh_u8* restrict secret, xxh_u64 seed64)
{
    { xxh_u64 const input_lo = XXH_readLE64(input);
        xxh_u64 const input_hi = XXH_readLE64(input+8);
        return XXH3_mul128_fold64(
            input_lo ^ (XXH_readLE64(secret) + seed64),
            input_hi ^ (XXH_readLE64(secret+8) - seed64)
        );
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_17to128_64b(const xxh_u8* restrict input, size_t len,
                     const xxh_u8* restrict secret, size_t secretSize,
                     XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(16 < len && len <= 128);
    { xxh_u64 acc = len * 0x9E3779B185EBCA87ULL;
        if (len > 32) {
            if (len > 64) {
                if (len > 96) {
                    acc += XXH3_mix16B(input+48, secret+96, seed);
                    acc += XXH3_mix16B(input+len-64, secret+112, seed);
                }
                acc += XXH3_mix16B(input+32, secret+64, seed);
                acc += XXH3_mix16B(input+len-48, secret+80, seed);
            }
            acc += XXH3_mix16B(input+16, secret+32, seed);
            acc += XXH3_mix16B(input+len-32, secret+48, seed);
        }
        acc += XXH3_mix16B(input+0, secret+0, seed);
        acc += XXH3_mix16B(input+len-16, secret+16, seed);
        return XXH3_avalanche(acc);
    }
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_len_129to240_64b(const xxh_u8* restrict input, size_t len,
                      const xxh_u8* restrict secret, size_t secretSize,
                      XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(128 < len && len <= 240);
    { xxh_u64 acc = len * 0x9E3779B185EBCA87ULL;
        xxh_u64 acc_end;
        unsigned int const nbRounds = (unsigned int)len / 16;
        unsigned int i;
        __builtin_assume(128 < len && len <= 240);
        for (i=0; i<8; i++) {
            acc += XXH3_mix16B(input+(16*i), secret+(16*i), seed);
        }
        acc_end = XXH3_mix16B(input + len - 16, secret + 136 - 17, seed);
        __builtin_assume(nbRounds >= 8);
        acc = XXH3_avalanche(acc);
        for (i=8 ; i < nbRounds; i++) {
            __asm__("" : "+r" (acc));
            acc_end += XXH3_mix16B(input+(16*i), secret+(16*(i-8)) + 3, seed);
        }
        return XXH3_avalanche(acc + acc_end);
    }
}
static __attribute__((__unused__)) void XXH_writeLE64(void* dst, xxh_u64 v64)
{
    if (!1) v64 = XXH_swap64(v64);
    memcpy(dst, &v64, sizeof(v64));
}
    typedef int64_t xxh_i64;
static __attribute__((__unused__)) void
XXH3_accumulate_512_sse2( void* restrict acc,
                    const void* restrict input,
                    const void* restrict secret)
{
    __builtin_assume((((size_t)acc) & 15) == 0);
    { __m128i* const xacc = (__m128i *) acc;
        const __m128i* const xinput = (const __m128i *) input;
        const __m128i* const xsecret = (const __m128i *) secret;
        size_t i;
        for (i=0; i < 64/sizeof(__m128i); i++) {
            __m128i const data_vec = _mm_loadu_si128 (xinput+i);
            __m128i const key_vec = _mm_loadu_si128 (xsecret+i);
            __m128i const data_key = _mm_xor_si128 (data_vec, key_vec);
            __m128i const data_key_lo = ((__m128i)__builtin_ia32_pshufd((__v4si)(__m128i)(data_key), (int)((((0) << 6) | ((3) << 4) | ((0) << 2) | (1)))));
            __m128i const product = _mm_mul_epu32 (data_key, data_key_lo);
            __m128i const data_swap = ((__m128i)__builtin_ia32_pshufd((__v4si)(__m128i)(data_vec), (int)((((1) << 6) | ((0) << 4) | ((3) << 2) | (2)))));
            __m128i const sum = _mm_add_epi64(xacc[i], data_swap);
            xacc[i] = _mm_add_epi64(product, sum);
    } }
}
static __attribute__((__unused__)) void XXH3_accumulate_sse2(xxh_u64* restrict acc, const xxh_u8* restrict input, const xxh_u8* restrict secret, size_t nbStripes) { size_t n; for (n = 0; n < nbStripes; n++ ) { const xxh_u8* const in = input + n*64; __builtin_prefetch((in + 320), 0 , 3 ); XXH3_accumulate_512_sse2( acc, in, secret + n*8); } }
static __attribute__((__unused__)) void
XXH3_scrambleAcc_sse2(void* restrict acc, const void* restrict secret)
{
    __builtin_assume((((size_t)acc) & 15) == 0);
    { __m128i* const xacc = (__m128i*) acc;
        const __m128i* const xsecret = (const __m128i *) secret;
        const __m128i prime32 = _mm_set1_epi32((int)0x9E3779B1U);
        size_t i;
        for (i=0; i < 64/sizeof(__m128i); i++) {
            __m128i const acc_vec = xacc[i];
            __m128i const shifted = _mm_srli_epi64 (acc_vec, 47);
            __m128i const data_vec = _mm_xor_si128 (acc_vec, shifted);
            __m128i const key_vec = _mm_loadu_si128 (xsecret+i);
            __m128i const data_key = _mm_xor_si128 (data_vec, key_vec);
            __m128i const data_key_hi = ((__m128i)__builtin_ia32_pshufd((__v4si)(__m128i)(data_key), (int)((((0) << 6) | ((3) << 4) | ((0) << 2) | (1)))));
            __m128i const prod_lo = _mm_mul_epu32 (data_key, prime32);
            __m128i const prod_hi = _mm_mul_epu32 (data_key_hi, prime32);
            xacc[i] = _mm_add_epi64(prod_lo, _mm_slli_epi64(prod_hi, 32));
        }
    }
}
static __attribute__((__unused__)) void XXH3_initCustomSecret_sse2(void* restrict customSecret, xxh_u64 seed64)
{
    do { _Static_assert((((192 & 15) == 0)),"(XXH_SECRET_DEFAULT_SIZE & 15) == 0"); } while(0);
    (void)(&XXH_writeLE64);
    { int const nbRounds = 192 / sizeof(__m128i);
        __m128i const seed = _mm_set_epi64x((xxh_i64)(0U - seed64), (xxh_i64)seed64);
        int i;
        const void* const src16 = XXH3_kSecret;
        __m128i* dst16 = (__m128i*) customSecret;
        __asm__("" : "+r" (dst16));
        __builtin_assume(((size_t)src16 & 15) == 0);
        __builtin_assume(((size_t)dst16 & 15) == 0);
        for (i=0; i < nbRounds; ++i) {
            dst16[i] = _mm_add_epi64(_mm_load_si128((const __m128i *)src16+i), seed);
    } }
}
static __attribute__((__unused__)) xxh_u64
XXH_mult32to64_add64(xxh_u64 lhs, xxh_u64 rhs, xxh_u64 acc)
{
    return ((xxh_u64)(xxh_u32)((xxh_u32)lhs) * (xxh_u64)(xxh_u32)((xxh_u32)rhs)) + acc;
}
static __attribute__((__unused__)) void
XXH3_scalarRound(void* restrict acc,
                 void const* restrict input,
                 void const* restrict secret,
                 size_t lane)
{
    xxh_u64* xacc = (xxh_u64*) acc;
    xxh_u8 const* xinput = (xxh_u8 const*) input;
    xxh_u8 const* xsecret = (xxh_u8 const*) secret;
    __builtin_assume(lane < (64 / sizeof(xxh_u64)));
    __builtin_assume(((size_t)acc & (16 -1)) == 0);
    {
        xxh_u64 const data_val = XXH_readLE64(xinput + lane * 8);
        xxh_u64 const data_key = data_val ^ XXH_readLE64(xsecret + lane * 8);
        xacc[lane ^ 1] += data_val;
        xacc[lane] = XXH_mult32to64_add64(data_key , data_key >> 32, xacc[lane]);
    }
}
static __attribute__((__unused__)) void
XXH3_accumulate_512_scalar(void* restrict acc,
                     const void* restrict input,
                     const void* restrict secret)
{
    size_t i;
    for (i=0; i < (64 / sizeof(xxh_u64)); i++) {
        XXH3_scalarRound(acc, input, secret, i);
    }
}
static __attribute__((__unused__)) void XXH3_accumulate_scalar(xxh_u64* restrict acc, const xxh_u8* restrict input, const xxh_u8* restrict secret, size_t nbStripes) { size_t n; for (n = 0; n < nbStripes; n++ ) { const xxh_u8* const in = input + n*64; __builtin_prefetch((in + 320), 0 , 3 ); XXH3_accumulate_512_scalar( acc, in, secret + n*8); } }
static __attribute__((__unused__)) void
XXH3_scalarScrambleRound(void* restrict acc,
                         void const* restrict secret,
                         size_t lane)
{
    xxh_u64* const xacc = (xxh_u64*) acc;
    const xxh_u8* const xsecret = (const xxh_u8*) secret;
    __builtin_assume((((size_t)acc) & (16 -1)) == 0);
    __builtin_assume(lane < (64 / sizeof(xxh_u64)));
    {
        xxh_u64 const key64 = XXH_readLE64(xsecret + lane * 8);
        xxh_u64 acc64 = xacc[lane];
        acc64 = XXH_xorshift64(acc64, 47);
        acc64 ^= key64;
        acc64 *= 0x9E3779B1U;
        xacc[lane] = acc64;
    }
}
static __attribute__((__unused__)) void
XXH3_scrambleAcc_scalar(void* restrict acc, const void* restrict secret)
{
    size_t i;
    for (i=0; i < (64 / sizeof(xxh_u64)); i++) {
        XXH3_scalarScrambleRound(acc, secret, i);
    }
}
static __attribute__((__unused__)) void
XXH3_initCustomSecret_scalar(void* restrict customSecret, xxh_u64 seed64)
{
    const xxh_u8* kSecretPtr = XXH3_kSecret;
    do { _Static_assert((((192 & 15) == 0)),"(XXH_SECRET_DEFAULT_SIZE & 15) == 0"); } while(0);
    { int const nbRounds = 192 / 16;
        int i;
        for (i=0; i < nbRounds; i++) {
            xxh_u64 lo = XXH_readLE64(kSecretPtr + 16*i) + seed64;
            xxh_u64 hi = XXH_readLE64(kSecretPtr + 16*i + 8) - seed64;
            XXH_writeLE64((xxh_u8*)customSecret + 16*i, lo);
            XXH_writeLE64((xxh_u8*)customSecret + 16*i + 8, hi);
    } }
}
typedef void (*XXH3_f_accumulate)(xxh_u64* restrict, const xxh_u8* restrict, const xxh_u8* restrict, size_t);
typedef void (*XXH3_f_scrambleAcc)(void* restrict, const void*);
typedef void (*XXH3_f_initCustomSecret)(void* restrict, xxh_u64);
static __attribute__((__unused__)) void
XXH3_hashLong_internal_loop(xxh_u64* restrict acc,
                      const xxh_u8* restrict input, size_t len,
                      const xxh_u8* restrict secret, size_t secretSize,
                            XXH3_f_accumulate f_acc,
                            XXH3_f_scrambleAcc f_scramble)
{
    size_t const nbStripesPerBlock = (secretSize - 64) / 8;
    size_t const block_len = 64 * nbStripesPerBlock;
    size_t const nb_blocks = (len - 1) / block_len;
    size_t n;
    __builtin_assume(secretSize >= 136);
    for (n = 0; n < nb_blocks; n++) {
        f_acc(acc, input + n*block_len, secret, nbStripesPerBlock);
        f_scramble(acc, secret + secretSize - 64);
    }
    __builtin_assume(len > 64);
    { size_t const nbStripes = ((len - 1) - (block_len * nb_blocks)) / 64;
        __builtin_assume(nbStripes <= (secretSize / 8));
        f_acc(acc, input + nb_blocks*block_len, secret, nbStripes);
        { const xxh_u8* const p = input + len - 64;
            XXH3_accumulate_512_sse2(acc, p, secret + secretSize - 64 - 7);
    } }
}
static __attribute__((__unused__)) xxh_u64
XXH3_mix2Accs(const xxh_u64* restrict acc, const xxh_u8* restrict secret)
{
    return XXH3_mul128_fold64(
               acc[0] ^ XXH_readLE64(secret),
               acc[1] ^ XXH_readLE64(secret+8) );
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_mergeAccs(const xxh_u64* restrict acc, const xxh_u8* restrict secret, xxh_u64 start)
{
    xxh_u64 result64 = start;
    size_t i = 0;
    for (i = 0; i < 4; i++) {
        result64 += XXH3_mix2Accs(acc+2*i, secret + 16*i);
    }
    return XXH3_avalanche(result64);
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_finalizeLong_64b(const xxh_u64* restrict acc, const xxh_u8* restrict secret, xxh_u64 len)
{
    return XXH3_mergeAccs(acc, secret + 11, len * 0x9E3779B185EBCA87ULL);
}
static __attribute__((__unused__)) XXH64_hash_t
XXH3_hashLong_64b_internal(const void* restrict input, size_t len,
                           const void* restrict secret, size_t secretSize,
                           XXH3_f_accumulate f_acc,
                           XXH3_f_scrambleAcc f_scramble)
{
    _Alignas(16) xxh_u64 acc[(64 / sizeof(xxh_u64))] = { 0xC2B2AE3DU, 0x9E3779B185EBCA87ULL, 0xC2B2AE3D27D4EB4FULL, 0x165667B19E3779F9ULL, 0x85EBCA77C2B2AE63ULL, 0x85EBCA77U, 0x27D4EB2F165667C5ULL, 0x9E3779B1U };
    XXH3_hashLong_internal_loop(acc, (const xxh_u8*)input, len, (const xxh_u8*)secret, secretSize, f_acc, f_scramble);
    do { _Static_assert(((sizeof(acc) == 64)),"sizeof(acc) == 64"); } while(0);
    __builtin_assume(secretSize >= sizeof(acc) + 11);
    return XXH3_finalizeLong_64b(acc, (const xxh_u8*)secret, (xxh_u64)len);
}
static __attribute__((__unused__)) XXH64_hash_t
XXH3_hashLong_64b_withSecret(const void* restrict input, size_t len,
                             XXH64_hash_t seed64, const xxh_u8* restrict secret, size_t secretLen)
{
    (void)seed64;
    return XXH3_hashLong_64b_internal(input, len, secret, secretLen, XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_hashLong_64b_default(const void* restrict input, size_t len,
                          XXH64_hash_t seed64, const xxh_u8* restrict secret, size_t secretLen)
{
    (void)seed64; (void)secret; (void)secretLen;
    return XXH3_hashLong_64b_internal(input, len, XXH3_kSecret, sizeof(XXH3_kSecret), XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__unused__)) XXH64_hash_t
XXH3_hashLong_64b_withSeed_internal(const void* input, size_t len,
                                    XXH64_hash_t seed,
                                    XXH3_f_accumulate f_acc,
                                    XXH3_f_scrambleAcc f_scramble,
                                    XXH3_f_initCustomSecret f_initSec)
{
    if (seed == 0)
        return XXH3_hashLong_64b_internal(input, len,
                                          XXH3_kSecret, sizeof(XXH3_kSecret),
                                          f_acc, f_scramble);
    { _Alignas(16) xxh_u8 secret[192];
        f_initSec(secret, seed);
        return XXH3_hashLong_64b_internal(input, len, secret, sizeof(secret),
                                          f_acc, f_scramble);
    }
}
static XXH64_hash_t
XXH3_hashLong_64b_withSeed(const void* restrict input, size_t len,
                           XXH64_hash_t seed, const xxh_u8* restrict secret, size_t secretLen)
{
    (void)secret; (void)secretLen;
    return XXH3_hashLong_64b_withSeed_internal(input, len, seed,
                XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2, XXH3_initCustomSecret_sse2);
}
typedef XXH64_hash_t (*XXH3_hashLong64_f)(const void* restrict, size_t,
                                          XXH64_hash_t, const xxh_u8* restrict, size_t);
static __attribute__((__unused__)) XXH64_hash_t
XXH3_64bits_internal(const void* restrict input, size_t len,
                     XXH64_hash_t seed64, const void* restrict secret, size_t secretLen,
                     XXH3_hashLong64_f f_hashLong)
{
    __builtin_assume(secretLen >= 136);
    if (len <= 16)
        return XXH3_len_0to16_64b((const xxh_u8*)input, len, (const xxh_u8*)secret, seed64);
    if (len <= 128)
        return XXH3_len_17to128_64b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    if (len <= 240)
        return XXH3_len_129to240_64b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    return f_hashLong(input, len, seed64, (const xxh_u8*)secret, secretLen);
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH3_64bits(__attribute__((__noescape__)) const void* input, size_t length)
{
    return XXH3_64bits_internal(input, length, 0, XXH3_kSecret, sizeof(XXH3_kSecret), XXH3_hashLong_64b_default);
}
static __inline __attribute__((__unused__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSecret(__attribute__((__noescape__)) const void* input, size_t length, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    return XXH3_64bits_internal(input, length, 0, secret, secretSize, XXH3_hashLong_64b_withSecret);
}
static __inline __attribute__((__unused__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSeed(__attribute__((__noescape__)) const void* input, size_t length, XXH64_hash_t seed)
{
    return XXH3_64bits_internal(input, length, seed, XXH3_kSecret, sizeof(XXH3_kSecret), XXH3_hashLong_64b_withSeed);
}
static __inline __attribute__((__unused__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSecretandSeed(__attribute__((__noescape__)) const void* input, size_t length, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed)
{
    if (length <= 240)
        return XXH3_64bits_internal(input, length, seed, XXH3_kSecret, sizeof(XXH3_kSecret), ((void*)0));
    return XXH3_hashLong_64b_withSecret(input, length, seed, (const xxh_u8*)secret, secretSize);
}
static __attribute__((__malloc__)) void* XXH_alignedMalloc(size_t s, size_t align)
{
    __builtin_assume(align <= 128 && align >= 8);
    __builtin_assume((align & (align-1)) == 0);
    __builtin_assume(s != 0 && s < (s + align));
    {
        xxh_u8* base = (xxh_u8*)XXH_malloc(s + align);
        if (base != ((void*)0)) {
            size_t offset = align - ((size_t)base & (align - 1));
            xxh_u8* ptr = base + offset;
            __builtin_assume((size_t)ptr % align == 0);
            ptr[-1] = (xxh_u8)offset;
            return ptr;
        }
        return ((void*)0);
    }
}
static void XXH_alignedFree(void* p)
{
    if (p != ((void*)0)) {
        xxh_u8* ptr = (xxh_u8*)p;
        xxh_u8 offset = ptr[-1];
        xxh_u8* base = ptr - offset;
        XXH_free(base);
    }
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH3_state_t* XXH_INLINE_XXH3_createState(void)
{
    XXH_NAMESPACEXXH3_state_t* const state = (XXH_NAMESPACEXXH3_state_t*)XXH_alignedMalloc(sizeof(XXH_NAMESPACEXXH3_state_t), 64);
    if (state==((void*)0)) return ((void*)0);
    do { XXH_NAMESPACEXXH3_state_t* tmp_xxh3_state_ptr = (state); tmp_xxh3_state_ptr->seed = 0; tmp_xxh3_state_ptr->extSecret = ((void*)0); } while(0);
    return state;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_freeState(XXH_NAMESPACEXXH3_state_t* statePtr)
{
    XXH_alignedFree(statePtr);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void
XXH_INLINE_XXH3_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* dst_state, __attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* src_state)
{
    memcpy(dst_state, src_state, sizeof(*dst_state));
}
static void
XXH3_reset_internal(XXH_NAMESPACEXXH3_state_t* statePtr,
                    XXH64_hash_t seed,
                    const void* secret, size_t secretSize)
{
    size_t const initStart = __builtin_offsetof(XXH_NAMESPACEXXH3_state_t, bufferedSize);
    size_t const initLength = __builtin_offsetof(XXH_NAMESPACEXXH3_state_t, nbStripesPerBlock) - initStart;
    __builtin_assume(__builtin_offsetof(XXH_NAMESPACEXXH3_state_t, nbStripesPerBlock) > initStart);
    __builtin_assume(statePtr != ((void*)0));
    memset((char*)statePtr + initStart, 0, initLength);
    statePtr->acc[0] = 0xC2B2AE3DU;
    statePtr->acc[1] = 0x9E3779B185EBCA87ULL;
    statePtr->acc[2] = 0xC2B2AE3D27D4EB4FULL;
    statePtr->acc[3] = 0x165667B19E3779F9ULL;
    statePtr->acc[4] = 0x85EBCA77C2B2AE63ULL;
    statePtr->acc[5] = 0x85EBCA77U;
    statePtr->acc[6] = 0x27D4EB2F165667C5ULL;
    statePtr->acc[7] = 0x9E3779B1U;
    statePtr->seed = seed;
    statePtr->useSeed = (seed != 0);
    statePtr->extSecret = (const unsigned char*)secret;
    __builtin_assume(secretSize >= 136);
    statePtr->secretLimit = secretSize - 64;
    statePtr->nbStripesPerBlock = statePtr->secretLimit / 8;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    XXH3_reset_internal(statePtr, 0, XXH3_kSecret, 192);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    XXH3_reset_internal(statePtr, 0, secret, secretSize);
    if (secret == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secretSize < 136) return XXH_NAMESPACEXXH_ERROR;
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (seed==0) return XXH_INLINE_XXH3_64bits_reset(statePtr);
    if ((seed != statePtr->seed) || (statePtr->extSecret != ((void*)0)))
        XXH3_initCustomSecret_sse2(statePtr->customSecret, seed);
    XXH3_reset_internal(statePtr, seed, ((void*)0), 192);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed64)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secret == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secretSize < 136) return XXH_NAMESPACEXXH_ERROR;
    XXH3_reset_internal(statePtr, seed64, secret, secretSize);
    statePtr->useSeed = 1;
    return XXH_NAMESPACEXXH_OK;
}
static __attribute__((__unused__)) const xxh_u8 *
XXH3_consumeStripes(xxh_u64* restrict acc,
                    size_t* restrict nbStripesSoFarPtr, size_t nbStripesPerBlock,
                    const xxh_u8* restrict input, size_t nbStripes,
                    const xxh_u8* restrict secret, size_t secretLimit,
                    XXH3_f_accumulate f_acc,
                    XXH3_f_scrambleAcc f_scramble)
{
    const xxh_u8* initialSecret = secret + *nbStripesSoFarPtr * 8;
    if (nbStripes >= (nbStripesPerBlock - *nbStripesSoFarPtr)) {
        size_t nbStripesThisIter = nbStripesPerBlock - *nbStripesSoFarPtr;
        do {
            f_acc(acc, input, initialSecret, nbStripesThisIter);
            f_scramble(acc, secret + secretLimit);
            input += nbStripesThisIter * 64;
            nbStripes -= nbStripesThisIter;
            nbStripesThisIter = nbStripesPerBlock;
            initialSecret = secret;
        } while (nbStripes >= nbStripesPerBlock);
        *nbStripesSoFarPtr = 0;
    }
    if (nbStripes > 0) {
        f_acc(acc, input, initialSecret, nbStripes);
        input += nbStripes * 64;
        *nbStripesSoFarPtr += nbStripes;
    }
    return input;
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH3_update(XXH_NAMESPACEXXH3_state_t* restrict const state,
            const xxh_u8* restrict input, size_t len,
            XXH3_f_accumulate f_acc,
            XXH3_f_scrambleAcc f_scramble)
{
    if (input==((void*)0)) {
        __builtin_assume(len == 0);
        return XXH_NAMESPACEXXH_OK;
    }
    __builtin_assume(state != ((void*)0));
    { const xxh_u8* const bEnd = input + len;
        const unsigned char* const secret = (state->extSecret == ((void*)0)) ? state->customSecret : state->extSecret;
        xxh_u64* restrict const acc = state->acc;
        state->totalLen += len;
        __builtin_assume(state->bufferedSize <= 256);
        if (len <= 256 - state->bufferedSize) {
            memcpy(state->buffer + state->bufferedSize, input, len);
            state->bufferedSize += (XXH32_hash_t)len;
            return XXH_NAMESPACEXXH_OK;
        }
        do { _Static_assert(((256 % 64 == 0)),"XXH3_INTERNALBUFFER_SIZE % XXH_STRIPE_LEN == 0"); } while(0);
        if (state->bufferedSize) {
            size_t const loadSize = 256 - state->bufferedSize;
            memcpy(state->buffer + state->bufferedSize, input, loadSize);
            input += loadSize;
            XXH3_consumeStripes(acc,
                               &state->nbStripesSoFar, state->nbStripesPerBlock,
                                state->buffer, (256 / 64),
                                secret, state->secretLimit,
                                f_acc, f_scramble);
            state->bufferedSize = 0;
        }
        __builtin_assume(input < bEnd);
        if (bEnd - input > 256) {
            size_t nbStripes = (size_t)(bEnd - 1 - input) / 64;
            input = XXH3_consumeStripes(acc,
                                       &state->nbStripesSoFar, state->nbStripesPerBlock,
                                       input, nbStripes,
                                       secret, state->secretLimit,
                                       f_acc, f_scramble);
            memcpy(state->buffer + sizeof(state->buffer) - 64, input - 64, 64);
        }
        __builtin_assume(input < bEnd);
        __builtin_assume(bEnd - input <= 256);
        __builtin_assume(state->bufferedSize == 0);
        memcpy(state->buffer, input, (size_t)(bEnd-input));
        state->bufferedSize = (XXH32_hash_t)(bEnd-input);
    }
    return XXH_NAMESPACEXXH_OK;
}
static XXH_NAMESPACEXXH_errorcode
XXH3_update_regular(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_update(state, (const xxh_u8*)input, len,
                       XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_update(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_update_regular(state, input, len);
}
static __attribute__((__unused__)) void
XXH3_digest_long (XXH64_hash_t* acc,
                  const XXH_NAMESPACEXXH3_state_t* state,
                  const unsigned char* secret)
{
    xxh_u8 lastStripe[64];
    const xxh_u8* lastStripePtr;
    memcpy(acc, state->acc, sizeof(state->acc));
    if (state->bufferedSize >= 64) {
        size_t const nbStripes = (state->bufferedSize - 1) / 64;
        size_t nbStripesSoFar = state->nbStripesSoFar;
        XXH3_consumeStripes(acc,
                           &nbStripesSoFar, state->nbStripesPerBlock,
                            state->buffer, nbStripes,
                            secret, state->secretLimit,
                            XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
        lastStripePtr = state->buffer + state->bufferedSize - 64;
    } else {
        size_t const catchupSize = 64 - state->bufferedSize;
        __builtin_assume(state->bufferedSize > 0);
        memcpy(lastStripe, state->buffer + sizeof(state->buffer) - catchupSize, catchupSize);
        memcpy(lastStripe + catchupSize, state->buffer, state->bufferedSize);
        lastStripePtr = lastStripe;
    }
    XXH3_accumulate_512_sse2(acc,
                        lastStripePtr,
                        secret + state->secretLimit - 7);
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* state)
{
    const unsigned char* const secret = (state->extSecret == ((void*)0)) ? state->customSecret : state->extSecret;
    if (state->totalLen > 240) {
        _Alignas(16) XXH64_hash_t acc[(64 / sizeof(xxh_u64))];
        XXH3_digest_long(acc, state, secret);
        return XXH3_finalizeLong_64b(acc, secret, (xxh_u64)state->totalLen);
    }
    if (state->useSeed)
        return XXH_INLINE_XXH3_64bits_withSeed(state->buffer, (size_t)state->totalLen, state->seed);
    return XXH_INLINE_XXH3_64bits_withSecret(state->buffer, (size_t)(state->totalLen),
                                  secret, state->secretLimit + 64);
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_1to3_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(1 <= len && len <= 3);
    __builtin_assume(secret != ((void*)0));
    { xxh_u8 const c1 = input[0];
        xxh_u8 const c2 = input[len >> 1];
        xxh_u8 const c3 = input[len - 1];
        xxh_u32 const combinedl = ((xxh_u32)c1 <<16) | ((xxh_u32)c2 << 24)
                                | ((xxh_u32)c3 << 0) | ((xxh_u32)len << 8);
        xxh_u32 const combinedh = __builtin_rotateleft32(XXH_swap32(combinedl), 13);
        xxh_u64 const bitflipl = (XXH_readLE32(secret) ^ XXH_readLE32(secret+4)) + seed;
        xxh_u64 const bitfliph = (XXH_readLE32(secret+8) ^ XXH_readLE32(secret+12)) - seed;
        xxh_u64 const keyed_lo = (xxh_u64)combinedl ^ bitflipl;
        xxh_u64 const keyed_hi = (xxh_u64)combinedh ^ bitfliph;
        XXH_NAMESPACEXXH128_hash_t h128;
        h128.low64 = XXH64_avalanche(keyed_lo);
        h128.high64 = XXH64_avalanche(keyed_hi);
        return h128;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_4to8_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(4 <= len && len <= 8);
    seed ^= (xxh_u64)XXH_swap32((xxh_u32)seed) << 32;
    { xxh_u32 const input_lo = XXH_readLE32(input);
        xxh_u32 const input_hi = XXH_readLE32(input + len - 4);
        xxh_u64 const input_64 = input_lo + ((xxh_u64)input_hi << 32);
        xxh_u64 const bitflip = (XXH_readLE64(secret+16) ^ XXH_readLE64(secret+24)) + seed;
        xxh_u64 const keyed = input_64 ^ bitflip;
        XXH_NAMESPACEXXH128_hash_t m128 = XXH_mult64to128(keyed, 0x9E3779B185EBCA87ULL + (len << 2));
        m128.high64 += (m128.low64 << 1);
        m128.low64 ^= (m128.high64 >> 3);
        m128.low64 = XXH_xorshift64(m128.low64, 35);
        m128.low64 *= PRIME_MX2;
        m128.low64 = XXH_xorshift64(m128.low64, 28);
        m128.high64 = XXH3_avalanche(m128.high64);
        return m128;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_9to16_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(9 <= len && len <= 16);
    { xxh_u64 const bitflipl = (XXH_readLE64(secret+32) ^ XXH_readLE64(secret+40)) - seed;
        xxh_u64 const bitfliph = (XXH_readLE64(secret+48) ^ XXH_readLE64(secret+56)) + seed;
        xxh_u64 const input_lo = XXH_readLE64(input);
        xxh_u64 input_hi = XXH_readLE64(input + len - 8);
        XXH_NAMESPACEXXH128_hash_t m128 = XXH_mult64to128(input_lo ^ input_hi ^ bitflipl, 0x9E3779B185EBCA87ULL);
        m128.low64 += (xxh_u64)(len - 1) << 54;
        input_hi ^= bitfliph;
        if (sizeof(void *) < sizeof(xxh_u64)) {
            m128.high64 += (input_hi & 0xFFFFFFFF00000000ULL) + ((xxh_u64)(xxh_u32)((xxh_u32)input_hi) * (xxh_u64)(xxh_u32)(0x85EBCA77U));
        } else {
            m128.high64 += input_hi + ((xxh_u64)(xxh_u32)((xxh_u32)input_hi) * (xxh_u64)(xxh_u32)(0x85EBCA77U - 1));
        }
        m128.low64 ^= XXH_swap64(m128.high64);
        {
            XXH_NAMESPACEXXH128_hash_t h128 = XXH_mult64to128(m128.low64, 0xC2B2AE3D27D4EB4FULL);
            h128.high64 += m128.high64 * 0xC2B2AE3D27D4EB4FULL;
            h128.low64 = XXH3_avalanche(h128.low64);
            h128.high64 = XXH3_avalanche(h128.high64);
            return h128;
    } }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_0to16_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(len <= 16);
    { if (len > 8) return XXH3_len_9to16_128b(input, len, secret, seed);
        if (len >= 4) return XXH3_len_4to8_128b(input, len, secret, seed);
        if (len) return XXH3_len_1to3_128b(input, len, secret, seed);
        { XXH_NAMESPACEXXH128_hash_t h128;
            xxh_u64 const bitflipl = XXH_readLE64(secret+64) ^ XXH_readLE64(secret+72);
            xxh_u64 const bitfliph = XXH_readLE64(secret+80) ^ XXH_readLE64(secret+88);
            h128.low64 = XXH64_avalanche(seed ^ bitflipl);
            h128.high64 = XXH64_avalanche( seed ^ bitfliph);
            return h128;
    } }
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH128_mix32B(XXH_NAMESPACEXXH128_hash_t acc, const xxh_u8* input_1, const xxh_u8* input_2,
              const xxh_u8* secret, XXH64_hash_t seed)
{
    acc.low64 += XXH3_mix16B (input_1, secret+0, seed);
    acc.low64 ^= XXH_readLE64(input_2) + XXH_readLE64(input_2 + 8);
    acc.high64 += XXH3_mix16B (input_2, secret+16, seed);
    acc.high64 ^= XXH_readLE64(input_1) + XXH_readLE64(input_1 + 8);
    return acc;
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_17to128_128b(const xxh_u8* restrict input, size_t len,
                      const xxh_u8* restrict secret, size_t secretSize,
                      XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(16 < len && len <= 128);
    { XXH_NAMESPACEXXH128_hash_t acc;
        acc.low64 = len * 0x9E3779B185EBCA87ULL;
        acc.high64 = 0;
        if (len > 32) {
            if (len > 64) {
                if (len > 96) {
                    acc = XXH128_mix32B(acc, input+48, input+len-64, secret+96, seed);
                }
                acc = XXH128_mix32B(acc, input+32, input+len-48, secret+64, seed);
            }
            acc = XXH128_mix32B(acc, input+16, input+len-32, secret+32, seed);
        }
        acc = XXH128_mix32B(acc, input, input+len-16, secret, seed);
        { XXH_NAMESPACEXXH128_hash_t h128;
            h128.low64 = acc.low64 + acc.high64;
            h128.high64 = (acc.low64 * 0x9E3779B185EBCA87ULL)
                        + (acc.high64 * 0x85EBCA77C2B2AE63ULL)
                        + ((len - seed) * 0xC2B2AE3D27D4EB4FULL);
            h128.low64 = XXH3_avalanche(h128.low64);
            h128.high64 = (XXH64_hash_t)0 - XXH3_avalanche(h128.high64);
            return h128;
        }
    }
}
static __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_129to240_128b(const xxh_u8* restrict input, size_t len,
                       const xxh_u8* restrict secret, size_t secretSize,
                       XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(128 < len && len <= 240);
    { XXH_NAMESPACEXXH128_hash_t acc;
        unsigned i;
        acc.low64 = len * 0x9E3779B185EBCA87ULL;
        acc.high64 = 0;
        for (i = 32; i < 160; i += 32) {
            acc = XXH128_mix32B(acc,
                                input + i - 32,
                                input + i - 16,
                                secret + i - 32,
                                seed);
        }
        acc.low64 = XXH3_avalanche(acc.low64);
        acc.high64 = XXH3_avalanche(acc.high64);
        for (i=160; i <= len; i += 32) {
            acc = XXH128_mix32B(acc,
                                input + i - 32,
                                input + i - 16,
                                secret + 3 + i - 160,
                                seed);
        }
        acc = XXH128_mix32B(acc,
                            input + len - 16,
                            input + len - 32,
                            secret + 136 - 17 - 16,
                            (XXH64_hash_t)0 - seed);
        { XXH_NAMESPACEXXH128_hash_t h128;
            h128.low64 = acc.low64 + acc.high64;
            h128.high64 = (acc.low64 * 0x9E3779B185EBCA87ULL)
                        + (acc.high64 * 0x85EBCA77C2B2AE63ULL)
                        + ((len - seed) * 0xC2B2AE3D27D4EB4FULL);
            h128.low64 = XXH3_avalanche(h128.low64);
            h128.high64 = (XXH64_hash_t)0 - XXH3_avalanche(h128.high64);
            return h128;
        }
    }
}
static __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_finalizeLong_128b(const xxh_u64* restrict acc, const xxh_u8* restrict secret, size_t secretSize, xxh_u64 len)
{
    XXH_NAMESPACEXXH128_hash_t h128;
    h128.low64 = XXH3_finalizeLong_64b(acc, secret, len);
    h128.high64 = XXH3_mergeAccs(acc, secret + secretSize
                                             - 64 - 11,
                                             ~(len * 0xC2B2AE3D27D4EB4FULL));
    return h128;
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_internal(const void* restrict input, size_t len,
                            const xxh_u8* restrict secret, size_t secretSize,
                            XXH3_f_accumulate f_acc,
                            XXH3_f_scrambleAcc f_scramble)
{
    _Alignas(16) xxh_u64 acc[(64 / sizeof(xxh_u64))] = { 0xC2B2AE3DU, 0x9E3779B185EBCA87ULL, 0xC2B2AE3D27D4EB4FULL, 0x165667B19E3779F9ULL, 0x85EBCA77C2B2AE63ULL, 0x85EBCA77U, 0x27D4EB2F165667C5ULL, 0x9E3779B1U };
    XXH3_hashLong_internal_loop(acc, (const xxh_u8*)input, len, secret, secretSize, f_acc, f_scramble);
    do { _Static_assert(((sizeof(acc) == 64)),"sizeof(acc) == 64"); } while(0);
    __builtin_assume(secretSize >= sizeof(acc) + 11);
    return XXH3_finalizeLong_128b(acc, secret, secretSize, (xxh_u64)len);
}
static __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_default(const void* restrict input, size_t len,
                           XXH64_hash_t seed64,
                           const void* restrict secret, size_t secretLen)
{
    (void)seed64; (void)secret; (void)secretLen;
    return XXH3_hashLong_128b_internal(input, len, XXH3_kSecret, sizeof(XXH3_kSecret),
                                       XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_withSecret(const void* restrict input, size_t len,
                              XXH64_hash_t seed64,
                              const void* restrict secret, size_t secretLen)
{
    (void)seed64;
    return XXH3_hashLong_128b_internal(input, len, (const xxh_u8*)secret, secretLen,
                                       XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_withSeed_internal(const void* restrict input, size_t len,
                                XXH64_hash_t seed64,
                                XXH3_f_accumulate f_acc,
                                XXH3_f_scrambleAcc f_scramble,
                                XXH3_f_initCustomSecret f_initSec)
{
    if (seed64 == 0)
        return XXH3_hashLong_128b_internal(input, len,
                                           XXH3_kSecret, sizeof(XXH3_kSecret),
                                           f_acc, f_scramble);
    { _Alignas(16) xxh_u8 secret[192];
        f_initSec(secret, seed64);
        return XXH3_hashLong_128b_internal(input, len, (const xxh_u8*)secret, sizeof(secret),
                                           f_acc, f_scramble);
    }
}
static XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_withSeed(const void* input, size_t len,
                            XXH64_hash_t seed64, const void* restrict secret, size_t secretLen)
{
    (void)secret; (void)secretLen;
    return XXH3_hashLong_128b_withSeed_internal(input, len, seed64,
                XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2, XXH3_initCustomSecret_sse2);
}
typedef XXH_NAMESPACEXXH128_hash_t (*XXH3_hashLong128_f)(const void* restrict, size_t,
                                            XXH64_hash_t, const void* restrict, size_t);
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_128bits_internal(const void* input, size_t len,
                      XXH64_hash_t seed64, const void* restrict secret, size_t secretLen,
                      XXH3_hashLong128_f f_hl128)
{
    __builtin_assume(secretLen >= 136);
    if (len <= 16)
        return XXH3_len_0to16_128b((const xxh_u8*)input, len, (const xxh_u8*)secret, seed64);
    if (len <= 128)
        return XXH3_len_17to128_128b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    if (len <= 240)
        return XXH3_len_129to240_128b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    return f_hl128(input, len, seed64, secret, secretLen);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits(__attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_128bits_internal(input, len, 0,
                                 XXH3_kSecret, sizeof(XXH3_kSecret),
                                 XXH3_hashLong_128b_default);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSecret(__attribute__((__noescape__)) const void* input, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    return XXH3_128bits_internal(input, len, 0,
                                 (const xxh_u8*)secret, secretSize,
                                 XXH3_hashLong_128b_withSecret);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSeed(__attribute__((__noescape__)) const void* input, size_t len, XXH64_hash_t seed)
{
    return XXH3_128bits_internal(input, len, seed,
                                 XXH3_kSecret, sizeof(XXH3_kSecret),
                                 XXH3_hashLong_128b_withSeed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSecretandSeed(__attribute__((__noescape__)) const void* input, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed)
{
    if (len <= 240)
        return XXH3_128bits_internal(input, len, seed, XXH3_kSecret, sizeof(XXH3_kSecret), ((void*)0));
    return XXH3_hashLong_128b_withSecret(input, len, seed, secret, secretSize);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH128(__attribute__((__noescape__)) const void* input, size_t len, XXH64_hash_t seed)
{
    return XXH_INLINE_XXH3_128bits_withSeed(input, len, seed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr)
{
    return XXH_INLINE_XXH3_64bits_reset(statePtr);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    return XXH_INLINE_XXH3_64bits_reset_withSecret(statePtr, secret, secretSize);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed)
{
    return XXH_INLINE_XXH3_64bits_reset_withSeed(statePtr, seed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed)
{
    return XXH_INLINE_XXH3_64bits_reset_withSecretandSeed(statePtr, secret, secretSize, seed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_update(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_update_regular(state, input, len);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* state)
{
    const unsigned char* const secret = (state->extSecret == ((void*)0)) ? state->customSecret : state->extSecret;
    if (state->totalLen > 240) {
        _Alignas(16) XXH64_hash_t acc[(64 / sizeof(xxh_u64))];
        XXH3_digest_long(acc, state, secret);
        __builtin_assume(state->secretLimit + 64 >= sizeof(acc) + 11);
        return XXH3_finalizeLong_128b(acc, secret, state->secretLimit + 64, (xxh_u64)state->totalLen);
    }
    if (state->useSeed)
        return XXH_INLINE_XXH3_128bits_withSeed(state->buffer, (size_t)state->totalLen, state->seed);
    return XXH_INLINE_XXH3_128bits_withSecret(state->buffer, (size_t)(state->totalLen),
                                   secret, state->secretLimit + 64);
}
static __inline __attribute__((__unused__)) int XXH_INLINE_XXH128_isEqual(XXH_NAMESPACEXXH128_hash_t h1, XXH_NAMESPACEXXH128_hash_t h2)
{
    return !(memcmp(&h1, &h2, sizeof(h1)));
}
static __inline __attribute__((__unused__)) int XXH_INLINE_XXH128_cmp(__attribute__((__noescape__)) const void* h128_1, __attribute__((__noescape__)) const void* h128_2)
{
    XXH_NAMESPACEXXH128_hash_t const h1 = *(const XXH_NAMESPACEXXH128_hash_t*)h128_1;
    XXH_NAMESPACEXXH128_hash_t const h2 = *(const XXH_NAMESPACEXXH128_hash_t*)h128_2;
    int const hcmp = (h1.high64 > h2.high64) - (h2.high64 > h1.high64);
    if (hcmp) return hcmp;
    return (h1.low64 > h2.low64) - (h2.low64 > h1.low64);
}
static __inline __attribute__((__unused__)) void
XXH_INLINE_XXH128_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH128_canonical_t* dst, XXH_NAMESPACEXXH128_hash_t hash)
{
    do { _Static_assert(((sizeof(XXH_NAMESPACEXXH128_canonical_t) == sizeof(XXH_NAMESPACEXXH128_hash_t))),"sizeof(XXH128_canonical_t) == sizeof(XXH128_hash_t)"); } while(0);
    if (1) {
        hash.high64 = XXH_swap64(hash.high64);
        hash.low64 = XXH_swap64(hash.low64);
    }
    memcpy(dst, &hash.high64, sizeof(hash.high64));
    memcpy((char*)dst + sizeof(hash.high64), &hash.low64, sizeof(hash.low64));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH128_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH128_canonical_t* src)
{
    XXH_NAMESPACEXXH128_hash_t h;
    h.high64 = XXH_readBE64(src);
    h.low64 = XXH_readBE64(src->digest + 8);
    return h;
}
static __attribute__((__unused__)) void XXH3_combine16(void* dst, XXH_NAMESPACEXXH128_hash_t h128)
{
    XXH_writeLE64( dst, XXH_readLE64(dst) ^ h128.low64 );
    XXH_writeLE64( (char*)dst+8, XXH_readLE64((char*)dst+8) ^ h128.high64 );
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_generateSecret(__attribute__((__noescape__)) void* secretBuffer, size_t secretSize, __attribute__((__noescape__)) const void* customSeed, size_t customSeedSize)
{
    if (secretBuffer == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secretSize < 136) return XXH_NAMESPACEXXH_ERROR;
    if (customSeedSize == 0) {
        customSeed = XXH3_kSecret;
        customSeedSize = 192;
    }
    if (customSeed == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    { size_t pos = 0;
        while (pos < secretSize) {
            size_t const toCopy = ((((secretSize - pos)) > (customSeedSize)) ? (customSeedSize) : ((secretSize - pos)));
            memcpy((char*)secretBuffer + pos, customSeed, toCopy);
            pos += toCopy;
    } }
    { size_t const nbSeg16 = secretSize / 16;
        size_t n;
        XXH_NAMESPACEXXH128_canonical_t scrambler;
        XXH_INLINE_XXH128_canonicalFromHash(&scrambler, XXH_INLINE_XXH128(customSeed, customSeedSize, 0));
        for (n=0; n<nbSeg16; n++) {
            XXH_NAMESPACEXXH128_hash_t const h128 = XXH_INLINE_XXH128(&scrambler, sizeof(scrambler), n);
            XXH3_combine16((char*)secretBuffer + n*16, h128);
        }
        XXH3_combine16((char*)secretBuffer + secretSize - 16, XXH_INLINE_XXH128_hashFromCanonical(&scrambler));
    }
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void
XXH_INLINE_XXH3_generateSecret_fromSeed(__attribute__((__noescape__)) void* secretBuffer, XXH64_hash_t seed)
{
    _Alignas(16) xxh_u8 secret[192];
    XXH3_initCustomSecret_sse2(secret, seed);
    __builtin_assume(secretBuffer != ((void*)0));
    memcpy(secretBuffer, secret, 192);
}
struct cfl_array;
struct cfl_kvlist;
struct cfl_arena;
struct cfl_variant {
    int type;
    size_t size;
    uint8_t referenced;
    uint8_t owned;
    union {
        cfl_sds_t as_string;
        cfl_sds_t as_bytes;
        unsigned int as_bool;
        int64_t as_int64;
        uint64_t as_uint64;
        double as_double;
        void *as_reference;
        struct cfl_array *as_array;
        struct cfl_kvlist *as_kvlist;
    } data;
    struct cfl_arena *arena;
};
int cfl_variant_print(FILE *fp, struct cfl_variant *val);
struct cfl_variant *cfl_variant_create_from_string(char *value);
struct cfl_variant *cfl_variant_create_from_string_s(char *value, size_t value_length, int referenced);
struct cfl_variant *cfl_variant_create_from_bytes(char *value, size_t length, int referenced);
struct cfl_variant *cfl_variant_create_from_bool(int value);
struct cfl_variant *cfl_variant_create_from_int64(int64_t value);
struct cfl_variant *cfl_variant_create_from_uint64(uint64_t value);
struct cfl_variant *cfl_variant_create_from_double(double value);
struct cfl_variant *cfl_variant_create_from_array(struct cfl_array *value);
struct cfl_variant *cfl_variant_create_from_null();
struct cfl_variant *cfl_variant_create_from_kvlist(struct cfl_kvlist *value);
struct cfl_variant *cfl_variant_create_from_reference(void *value);
struct cfl_variant *cfl_variant_create();
struct cfl_variant *cfl_variant_create_in(struct cfl_arena *arena);
struct cfl_variant *cfl_variant_create_from_string_in(struct cfl_arena *arena,
                                                       char *value);
struct cfl_variant *cfl_variant_create_from_string_s_in(struct cfl_arena *arena,
                                                         char *value,
                                                         size_t value_length,
                                                         int referenced);
struct cfl_variant *cfl_variant_create_from_bytes_in(struct cfl_arena *arena,
                                                      char *value, size_t length,
                                                      int referenced);
struct cfl_variant *cfl_variant_create_from_bool_in(struct cfl_arena *arena,
                                                     int value);
struct cfl_variant *cfl_variant_create_from_int64_in(struct cfl_arena *arena,
                                                      int64_t value);
struct cfl_variant *cfl_variant_create_from_uint64_in(struct cfl_arena *arena,
                                                       uint64_t value);
struct cfl_variant *cfl_variant_create_from_double_in(struct cfl_arena *arena,
                                                       double value);
struct cfl_variant *cfl_variant_create_from_null_in(struct cfl_arena *arena);
struct cfl_variant *cfl_variant_create_from_reference_in(struct cfl_arena *arena,
                                                          void *value);
struct cfl_variant *cfl_variant_create_from_array_in(struct cfl_arena *arena,
                                                      struct cfl_array *value);
struct cfl_variant *cfl_variant_create_from_kvlist_in(struct cfl_arena *arena,
                                                       struct cfl_kvlist *value);
void cfl_variant_destroy(struct cfl_variant *instance);
void cfl_variant_size_set(struct cfl_variant *var, size_t size);
size_t cfl_variant_size_get(struct cfl_variant *var);

struct cfl_kvlist;
struct cfl_arena;
struct cfl_array {
    int resizable;
    struct cfl_variant **entries;
    size_t slot_count;
    size_t entry_count;
    struct cfl_variant *owner;
    struct cfl_array *parent_array;
    struct cfl_kvlist *parent_kvlist;
    struct cfl_arena *arena;
};
struct cfl_array *cfl_array_create(size_t slot_count);
struct cfl_array *cfl_array_create_in(struct cfl_arena *arena,
                                      size_t slot_count);
struct cfl_array *cfl_array_create_like(struct cfl_array *parent,
                                        size_t slot_count);
void cfl_array_destroy(struct cfl_array *array);
static inline struct cfl_variant *cfl_array_fetch_by_index(struct cfl_array *array,
                                                           size_t position)
{
    if (array == ((void*)0)) {
        return ((void*)0);
    }
    if (position >= array->entry_count) {
        return ((void*)0);
    }
    return array->entries[position];
}
static inline size_t cfl_array_size(struct cfl_array *array)
{
    if (array == ((void*)0)) {
        return 0;
    }
    return array->entry_count;
}
int cfl_array_append(struct cfl_array *array, struct cfl_variant *value);
int cfl_array_append_string(struct cfl_array *array, char *value);
int cfl_array_append_string_s(struct cfl_array *array, char *str, size_t str_len, int referenced);
int cfl_array_append_bytes(struct cfl_array *array, char *value, size_t length, int referenced);
int cfl_array_append_reference(struct cfl_array *array, void *value);
int cfl_array_append_bool(struct cfl_array *array, int value);
int cfl_array_append_int64(struct cfl_array *array, int64_t value);
int cfl_array_append_uint64(struct cfl_array *array, uint64_t value);
int cfl_array_append_double(struct cfl_array *array, double value);
int cfl_array_append_null(struct cfl_array *array);
int cfl_array_append_array(struct cfl_array *array, struct cfl_array *value);
int cfl_array_append_new_array(struct cfl_array *array, size_t size);
int cfl_array_append_kvlist(struct cfl_array *array, struct cfl_kvlist *value);
int cfl_array_resizable(struct cfl_array *array, int v);
int cfl_array_remove_by_index(struct cfl_array *array, size_t position);
int cfl_array_remove_by_reference(struct cfl_array *array, struct cfl_variant *value);
int cfl_array_print(FILE *fp, struct cfl_array *array);
struct cfl_kv {
  cfl_sds_t key;
  cfl_sds_t val;
  struct cfl_list _head;
};
void cfl_kv_init(struct cfl_list *list);
struct cfl_kv *cfl_kv_item_create_len(struct cfl_list *list,
                                      char *k_buf, size_t k_len,
                                      char *v_buf, size_t v_len);
struct cfl_kv *cfl_kv_item_create(struct cfl_list *list,
                                  char *k_buf, char *v_buf);
void cfl_kv_item_destroy(struct cfl_kv *kv);
void cfl_kv_release(struct cfl_list *list);
const char *cfl_kv_get_key_value(const char *key, struct cfl_list *list);
struct cfl_array;
struct cfl_arena;
enum cfl_kvlist_match_mode {
    CFL_KVLIST_MATCH_CASE_INSENSITIVE = 0,
    CFL_KVLIST_MATCH_CASE_SENSITIVE
};
struct cfl_kvpair {
    cfl_sds_t key;
    struct cfl_variant *val;
    struct cfl_list _head;
    struct cfl_arena *arena;
};
struct cfl_kvlist {
    struct cfl_list list;
    struct cfl_variant *owner;
    struct cfl_array *parent_array;
    struct cfl_kvlist *parent_kvlist;
    struct cfl_arena *arena;
};
struct cfl_kvlist *cfl_kvlist_create();
struct cfl_kvlist *cfl_kvlist_create_in(struct cfl_arena *arena);
struct cfl_kvlist *cfl_kvlist_create_like(struct cfl_kvlist *parent);
void cfl_kvlist_destroy(struct cfl_kvlist *list);
int cfl_kvlist_insert_string(struct cfl_kvlist *list,
                             char *key, char *value);
int cfl_kvlist_insert_bytes(struct cfl_kvlist *list,
                             char *key, char *value,
                             size_t value_length,
                             int referenced);
int cfl_kvlist_insert_reference(struct cfl_kvlist *list,
                                char *key, void *value);
int cfl_kvlist_insert_bool(struct cfl_kvlist *list,
                           char *key, int value);
int cfl_kvlist_insert_int64(struct cfl_kvlist *list,
                            char *key, int64_t value);
int cfl_kvlist_insert_uint64(struct cfl_kvlist *list,
                            char *key, uint64_t value);
int cfl_kvlist_insert_double(struct cfl_kvlist *list,
                             char *key, double value);
int cfl_kvlist_insert_array(struct cfl_kvlist *list,
                            char *key, struct cfl_array *value);
int cfl_kvlist_insert_new_array(struct cfl_kvlist *list,
                                char *key, size_t size);
int cfl_kvlist_insert_kvlist(struct cfl_kvlist *list,
                             char *key, struct cfl_kvlist *value);
int cfl_kvlist_insert(struct cfl_kvlist *list,
                      char *key, struct cfl_variant *value);
int cfl_kvlist_count(struct cfl_kvlist *list);
struct cfl_variant *cfl_kvlist_fetch(struct cfl_kvlist *list, char *key);
int cfl_kvlist_print(FILE *fp, struct cfl_kvlist *list);
int cfl_kvlist_insert_string_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               char *value, size_t value_size,
                               int referenced);
int cfl_kvlist_insert_bytes_s(struct cfl_kvlist *list,
                              char *key, size_t key_size,
                              char *value,
                              size_t value_length,
                              int referenced);
int cfl_kvlist_insert_reference_s(struct cfl_kvlist *list,
                                  char *key, size_t key_size,
                                  void *value);
int cfl_kvlist_insert_bool_s(struct cfl_kvlist *list,
                             char *key, size_t key_size, int value);
int cfl_kvlist_insert_int64_s(struct cfl_kvlist *list,
                              char *key, size_t key_size,
                              int64_t value);
int cfl_kvlist_insert_uint64_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               uint64_t value);
int cfl_kvlist_insert_double_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               double value);
int cfl_kvlist_insert_array_s(struct cfl_kvlist *list,
                              char *key, size_t key_size,
                              struct cfl_array *value);
int cfl_kvlist_insert_new_array_s(struct cfl_kvlist *list,
                                  char *key, size_t key_size,
                                  size_t size);
int cfl_kvlist_insert_kvlist_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               struct cfl_kvlist *value);
int cfl_kvlist_insert_s(struct cfl_kvlist *list,
                        char *key, size_t key_size,
                        struct cfl_variant *value);
struct cfl_variant *cfl_kvlist_fetch_s(struct cfl_kvlist *list,
                                       char *key, size_t key_size);
struct cfl_variant *cfl_kvlist_fetch_ex(struct cfl_kvlist *list,
                                        char *key,
                                        enum cfl_kvlist_match_mode mode);
struct cfl_variant *cfl_kvlist_fetch_s_ex(struct cfl_kvlist *list,
                                          char *key, size_t key_size,
                                          enum cfl_kvlist_match_mode mode);
struct cfl_variant *cfl_kvlist_fetch_case_s(struct cfl_kvlist *list,
                                            char *key, size_t key_size);
int cfl_kvlist_contains(struct cfl_kvlist *kvlist, char *name);
int cfl_kvlist_contains_ex(struct cfl_kvlist *kvlist, char *name,
                           enum cfl_kvlist_match_mode mode);
int cfl_kvlist_remove(struct cfl_kvlist *kvlist, char *name);
int cfl_kvlist_remove_ex(struct cfl_kvlist *kvlist, char *name,
                         enum cfl_kvlist_match_mode mode);
void cfl_kvpair_destroy(struct cfl_kvpair *pair);
struct cfl_variant *cfl_kvpair_take_value(struct cfl_kvpair *pair);
int cfl_kvpair_key_set_s(struct cfl_kvpair *pair,
                         char *key, size_t key_size);
int cfl_kvlist_rename_s(struct cfl_kvlist *list,
                        char *old_key, size_t old_key_size,
                        char *new_key, size_t new_key_size);
uint32_t cfl_checksum_crc32c(unsigned char *buffer, size_t length);
uint64_t cfl_time_now();


struct cfl_arena;
typedef void *(*cfl_arena_malloc_fn)(void *context, size_t size);
typedef void (*cfl_arena_free_fn)(void *context, void *pointer);
struct cfl_arena_options {
    size_t struct_size;
    size_t chunk_size;
    size_t maximum_chunk_size;
    size_t large_object_threshold;
    cfl_arena_malloc_fn malloc_fn;
    cfl_arena_free_fn free_fn;
    void *allocator_context;
};
struct cfl_arena *cfl_arena_create(size_t chunk_size);
struct cfl_arena *cfl_arena_create_ex(size_t chunk_size,
                                      size_t large_object_threshold);
void cfl_arena_options_init(struct cfl_arena_options *options);
struct cfl_arena *cfl_arena_create_with_options(
    const struct cfl_arena_options *options);
void cfl_arena_destroy(struct cfl_arena *arena);
void cfl_arena_reset(struct cfl_arena *arena);
void *cfl_arena_malloc(struct cfl_arena *arena, size_t size);
void *cfl_arena_calloc(struct cfl_arena *arena,
                       size_t count, size_t size);
void *cfl_arena_memdup(struct cfl_arena *arena,
                       const void *source, size_t size);
char *cfl_arena_strndup(struct cfl_arena *arena,
                        const char *source, size_t length);
size_t cfl_arena_bytes_reserved(struct cfl_arena *arena);
size_t cfl_arena_bytes_used(struct cfl_arena *arena);
size_t cfl_arena_large_object_threshold(struct cfl_arena *arena);
void cfl_arena_external_cache_limit_set(struct cfl_arena *arena,
                                        size_t limit);
size_t cfl_arena_external_cache_limit_get(struct cfl_arena *arena);
size_t cfl_arena_external_cache_bytes(struct cfl_arena *arena);
enum {
    CFL_OBJECT_NONE = 0,
    CFL_OBJECT_KVLIST = 1,
    CFL_OBJECT_VARIANT,
    CFL_OBJECT_ARRAY
};
struct cfl_object {
    int type;
    struct cfl_variant *variant;
    struct cfl_list _head;
};
struct cfl_object *cfl_object_create();
void cfl_object_destroy(struct cfl_object *obj);
int cfl_object_set(struct cfl_object *o, int type, void *ptr);
int cfl_object_print(FILE *stream, struct cfl_object *o);
struct cfl_split_entry {
    char *value;
    int len;
    off_t last_pos;
    struct cfl_list _head;
};
struct cfl_list *cfl_utils_split_quoted(const char *line, int separator, int max_split);
struct cfl_list *cfl_utils_split(const char *line, int separator, int max_split);
void cfl_utils_split_free_entry(struct cfl_split_entry *entry);
void cfl_utils_split_free(struct cfl_list *list);

int cfl_init();
char *cfl_version();
struct flb_router;
struct flb_hash_table;
struct flb_config {
    struct mk_event ch_event;
    int support_mode;
    int is_ingestion_active;
    int is_shutting_down;
    int is_running;
    double flush;
    int flush_adaptive;
    double flush_adaptive_min_interval;
    double flush_adaptive_max_interval;
    double flush_adaptive_low_pressure;
    double flush_adaptive_medium_pressure;
    double flush_adaptive_high_pressure;
    int flush_adaptive_up_steps;
    int flush_adaptive_down_steps;
    int flush_adaptive_level;
    int flush_adaptive_hits;
    int flush_adaptive_direction;
    double flush_adaptive_current_interval;
    int grace;
    int grace_count;
    int grace_input;
    int flush_fd;
    int convert_nan_to_null;
    int daemon;
    int shutdown_fd;
    int verbose;
    time_t init_time;
    pthread_t worker;
    int ch_data[2];
    int ch_manager[2];
    int ch_notif[2];
    int ch_self_events[2];
    int notification_channels_initialized;
    int notification_channels[2];
    struct mk_event notification_event;
    struct mk_event_loop *ch_evl;
    struct mk_rconf *file;
    struct flb_cf *cf_main;
    struct flb_cf *cf_opts;
    struct mk_list cf_parsers_list;
    flb_sds_t program_name;
    char *conf_path;
    flb_sds_t conf_path_file;
    struct mk_list external_plugins;
    struct mk_event event_flush;
    struct mk_event event_shutdown;
    struct mk_event event_thread_init;
    pthread_mutex_t collectors_mutex;
    void *dso_plugins;
    struct mk_list processor_plugins;
    struct mk_list custom_plugins;
    struct mk_list in_plugins;
    struct mk_list parser_plugins;
    struct mk_list filter_plugins;
    struct mk_list out_plugins;
    struct mk_list customs;
    struct mk_list inputs;
    struct mk_list parsers;
    struct mk_list multiline_parsers;
    char *multiline_buffer_limit;
    struct mk_list outputs;
    struct mk_list filters;
    struct mk_event_loop *evl;
    struct flb_bucket_queue *evl_bktq;
    struct mk_list proxies;
    struct flb_kernel *kernel;
    char *log_file;
    struct flb_log *log;
    char *parsers_file;
    char *plugins_file;
    void *env;
    char *workdir;
    int exit_status_code;
    struct mk_list workers;
    void *metrics;
    struct mk_list cmetrics;
    int telemetry_metrics_logs_tag_records;
    int telemetry_metrics_logs_tag_records_max_series;
    int telemetry_metrics_logs_tag_records_max_tag_length;
    size_t telemetry_metrics_logs_tag_records_series_count;
    struct flb_hash_table *telemetry_metrics_logs_tag_records_ht;
    pthread_mutex_t telemetry_metrics_logs_tag_records_lock;
    int telemetry_metrics_logs_tag_records_lock_inited;
    int http_server;
    char *http_port;
    char *http_listen;
    void *http_ctx;
    int health_check;
    int hc_errors_count;
    int hc_retry_failure_count;
    int health_check_period;
    char *http_proxy;
    char *no_proxy;
    char *dns_mode;
    char *dns_resolver;
    int dns_prefer_ipv4;
    int dns_prefer_ipv6;
    void *cio;
    char *storage_path;
    void *storage_input_plugin;
    char *storage_sync;
    int storage_metrics;
    int storage_checksum;
    int storage_max_chunks_up;
    int storage_del_bad_chunks;
    char *storage_bl_mem_limit;
    int storage_bl_flush_on_shutdown;
    struct flb_storage_metrics *storage_metrics_ctx;
    int storage_trim_files;
    char *storage_type;
    int storage_inherit;
    int storage_keep_rejected;
    char *storage_rejected_path;
    char *storage_rejected_limit;
    void *storage_rejected_stream;
    struct mk_list sqldb_list;
    struct mk_list luajit_list;
    struct mk_list wasm_list;
    char *stream_processor_file;
    void *stream_processor_ctx;
    int stream_processor_str_conv;
    struct mk_list stream_processor_tasks;
    int enable_chunk_trace;
    int fips_mode;
    int fips_mode_active;
    int enable_hot_reload;
    int ensure_thread_safety_on_hot_reloading;
    unsigned int hot_reloaded_count;
    int shutdown_by_hot_reloading;
    int hot_reloading;
    int hot_reload_succeeded;
    int hot_reload_watchdog_timeout_seconds;
    struct flb_router *router;
    unsigned int coro_stack_size;
    struct mk_list upstreams;
    struct mk_list downstreams;
    uint16_t in_table_id[512];
    void *sched;
    unsigned int sched_cap;
    unsigned int sched_base;
    struct flb_task_map *task_map;
    size_t task_map_size;
    int flush_in_flight;
    int flush_in_flight_limit;
    int json_escape_unicode;
    int dry_run;
    struct cfl_list input_routes;
};
struct flb_config *flb_config_init();
void flb_config_exit(struct flb_config *config);
const char *flb_config_prop_get(const char *key, struct mk_list *list);
int flb_config_service_property_is_valid(const char *k);
int flb_config_set_property(struct flb_config *config,
                            const char *k, const char *v);
int flb_config_set_program_name(struct flb_config *config, char *name);
int flb_config_load_config_format(struct flb_config *config, struct flb_cf *cf);
int flb_config_task_map_resize(struct flb_config *config, size_t new_size);
int flb_config_task_map_grow(struct flb_config *config);
int set_log_level_from_env(struct flb_config *config);
struct flb_service_config {
    char *key;
    int type;
    size_t offset;
};
enum conf_type {
    FLB_CONF_TYPE_INT,
    FLB_CONF_TYPE_DOUBLE,
    FLB_CONF_TYPE_BOOL,
    FLB_CONF_TYPE_STR,
    FLB_CONF_TYPE_OTHER,
};

struct flb_config;
struct flb_worker {
    struct mk_event event;
    void (*func) (void *);
    void *data;
    pthread_t tid;
    struct flb_log_cache *log_cache;
    int log[2];
    void *config;
    void *log_ctx;
    pthread_mutex_t mutex;
    struct mk_list _head;
};
int flb_worker_init(struct flb_config *config);
struct flb_worker *flb_worker_get();
struct flb_worker *flb_worker_context_create(void (*func) (void *), void *arg,
                                             struct flb_config *config);
int flb_worker_create(void (*func) (void *), void *arg, pthread_t *tid,
                      struct flb_config *config);
struct flb_worker *flb_worker_lookup(pthread_t tid, struct flb_config *config);
int flb_worker_exit(struct flb_config *config);
int flb_worker_log_level(struct flb_worker *worker);
void cmt_log_print(void *ctx, int level, const char *file, int line,
                     const char *fmt, ...);
int cmt_errno_print(int errnum, const char *file, int line);
static inline struct tm *cmt_platform_gmtime_r(const time_t *timep, struct tm *result)
{
    return gmtime_r(timep, result) ;
}
union val_union {
    uint64_t u;
    double d;
};
static inline uint64_t cmt_math_d64_to_uint64(double val)
{
    union val_union u;
    u.d = val;
    return u.u;
}
static inline double cmt_math_uint64_to_d64(uint64_t val)
{
    union val_union u;
    u.u = val;
    return u.d;
}
static inline uint64_t cmt_math_sum_native_uint64_as_d64(uint64_t dst, uint64_t src)
{
    double val;
    val = cmt_math_uint64_to_d64(dst);
    val += cmt_math_uint64_to_d64(src);
    return cmt_math_d64_to_uint64(val);
}
void cmt_time_from_ns(struct timespec *tm, uint64_t ns);

struct cmt_label {
    cfl_sds_t key;
    cfl_sds_t val;
    struct cfl_list _head;
};
struct cmt_labels {
    struct cfl_list list;
};
struct cmt_labels *cmt_labels_create();
void cmt_labels_destroy(struct cmt_labels *labels);
int cmt_labels_add_kv(struct cmt_labels *labels, char *key, char *val);
int cmt_labels_count(struct cmt_labels *labels);

struct cmt {
    int log_level;
    void (*log_cb)(void *, int, const char *, int, const char *);
    struct cfl_kvlist *internal_metadata;
    struct cfl_kvlist *external_metadata;
    struct cmt_labels *static_labels;
    struct cfl_list counters;
    struct cfl_list gauges;
    struct cfl_list histograms;
    struct cfl_list exp_histograms;
    struct cfl_list summaries;
    struct cfl_list untypeds;
    struct cfl_list _head;
};
void cmt_initialize();
struct cmt *cmt_create();
void cmt_destroy(struct cmt *cmt);
int cmt_label_add(struct cmt *cmt, char *key, char *val);
char *cmt_version();
void cmt_expire(struct cmt *cmt, uint64_t expiration);
struct cmt_opts {
    cfl_sds_t ns;
    cfl_sds_t subsystem;
    cfl_sds_t name;
    cfl_sds_t description;
    cfl_sds_t fqname;
    int resource_index;
};
int cmt_opts_init(struct cmt_opts *opts,
                  char *ns, char *subsystem, char *name, char *help);
void cmt_opts_exit(struct cmt_opts *opts);

struct cmt_counter {
    struct cmt_opts opts;
    struct cmt_map *map;
    struct cfl_list _head;
    struct cmt *cmt;
    int allow_reset;
    int aggregation_type;
};
struct cmt_counter *cmt_counter_create(struct cmt *cmt,
                                       char *ns, char *subsystem,
                                       char *name, char *help,
                                       int label_count, char **label_keys);
void cmt_counter_allow_reset(struct cmt_counter *counter);
int cmt_counter_destroy(struct cmt_counter *counter);
int cmt_counter_inc(struct cmt_counter *counter, uint64_t timestamp,
                    int labels_count, char **label_vals);
int cmt_counter_add(struct cmt_counter *counter, uint64_t timestamp,
                    double val, int labels_count, char **label_vals);
int cmt_counter_set(struct cmt_counter *counter, uint64_t timestamp, double val,
                    int labels_count, char **label_vals);
int cmt_counter_get_val(struct cmt_counter *counter,
                        int labels_count, char **label_vals, double *out_val);

typedef __builtin_va_list va_list;
extern __thread struct flb_log *flb_log_ctx;;
struct flb_log_record {
    int type;
    uint64_t timestamp_sec;
    uint32_t timestamp_nsec;
    size_t size;
    struct flb_log_record *next;
    char msg[];
};
struct flb_log_queue {
    size_t length;
    size_t limit;
    int signal_pending;
    struct flb_log_record *head;
    struct flb_log_record *tail;
    pthread_mutex_t mutex;
};
struct flb_log {
    struct mk_event event;
    int ch_mng[2];
    uint16_t type;
    uint16_t level;
    int out_fd;
    char *out;
    pthread_t tid;
    struct flb_worker *worker;
    struct mk_event_loop *evl;
    struct flb_log_metrics *metrics;
    int pth_init;
    pthread_cond_t pth_cond;
    pthread_mutex_t pth_mutex;
    size_t queue_length;
    size_t queue_limit;
    size_t dropped_records;
    int queue_signal_pending;
    struct flb_log_record *queue_head;
    struct flb_log_record *queue_tail;
    pthread_mutex_t queue_mutex;
    int pipeline_enabled;
    int pipeline_ch[2];
    struct flb_log_queue pipeline_queue;
};
struct flb_log_cache_entry {
    flb_sds_t buf;
    uint64_t timestamp;
    int interval;
    struct mk_list _head;
};
struct flb_log_cache {
    int size;
    int timeout;
    struct mk_list entries;
};
struct flb_log_metrics {
    struct cmt *cmt;
    struct cmt_counter *logs_total_counter;
    struct cmt_counter *queue_enqueue_counter;
    struct cmt_counter *queue_drop_counter;
    struct cmt_counter *queue_drain_counter;
};
static inline int flb_log_check_level(int level_set, int msg_level)
{
    if (msg_level <= level_set) {
        return 1;
    }
    return 0;
}
static inline int flb_log_check(int l) {
    struct flb_worker *w;
    w = (struct flb_worker *) flb_worker_ctx;
    if (!w && l <= 3) {
        return 1;
    }
    if (w == ((void*)0) || flb_worker_log_level(w) < l) {
        return 0;
    }
    return 1;
}
struct flb_log *flb_log_create(struct flb_config *config, int type,
                               int level, char *out);
int flb_log_set_level(struct flb_config *config, int level);
int flb_log_get_level_str(char *str);
int flb_log_set_file(struct flb_config *config, char *out);
int flb_log_destroy(struct flb_log *log, struct flb_config *config);
void flb_log_print(int type, const char *file, int line, const char *fmt, ...) __attribute__ ((format (printf, 4, 5)));
int flb_log_is_truncated(int type, const char *file, int line, const char *fmt, ...) __attribute__ ((format (printf, 4, 5)));
void flb_log_record_destroy(struct flb_log_record *record);
int flb_log_pipeline_enable(struct flb_config *config);
void flb_log_pipeline_disable(struct flb_config *config);
int flb_log_pipeline_get_event_fd(struct flb_config *config);
struct flb_log_record *flb_log_pipeline_dequeue(struct flb_config *config);
struct flb_log_cache *flb_log_cache_create(int timeout_seconds, int size);
void flb_log_cache_destroy(struct flb_log_cache *cache);
struct flb_log_cache_entry *flb_log_cache_exists(struct flb_log_cache *cache, char *msg_buf, size_t msg_size);
struct flb_log_cache_entry *flb_log_cache_get_target(struct flb_log_cache *cache, uint64_t ts);
int flb_log_cache_check_suppress(struct flb_log_cache *cache, char *msg_buf, size_t msg_size);
int flb_log_cache_check_suppress_interval(struct flb_log_cache *cache,
                                          char *msg_buf, size_t msg_size,
                                          int interval_seconds);
static inline int flb_log_suppress_check(int log_suppress_interval, const char *fmt, ...)
{
    int ret;
    int written;
    size_t size;
    va_list args;
    char buf[4096];
    struct flb_worker *w;
    if (log_suppress_interval <= 0) {
        return 0;
    }
    __builtin_va_start(args, fmt);
    written = vsnprintf(buf, sizeof(buf) - 1, fmt, args);
    __builtin_va_end(args);
    if (written < 0) {
        return 0;
    }
    size = (size_t) written;
    if (size > sizeof(buf) - 2) {
        size = sizeof(buf) - 2;
    }
    w = flb_worker_get();
    if (!w) {
        return 0;
    }
    ret = flb_log_cache_check_suppress_interval(w->log_cache, buf, size,
                                                log_suppress_interval);
    return ret;
}
int flb_log_worker_init(struct flb_worker *worker);
int flb_log_worker_destroy(struct flb_worker *worker);
int flb_errno_print(int errnum, const char *file, int line);
static inline __attribute__ ((alloc_size(1)))
void *flb_malloc(const size_t size) {
    if (size == 0) {
        return ((void*)0);
    }
    return malloc(size);
}
static inline __attribute__ ((alloc_size(1, 2)))
void *flb_calloc(size_t n, const size_t size) {
    if (size == 0) {
        return ((void*)0);
    }
    return calloc(n, size);
}
static inline __attribute__ ((alloc_size(2)))
void *flb_realloc(void *ptr, const size_t size)
{
    return realloc(ptr, size);
}
static inline __attribute__ ((alloc_size(3)))
void *flb_realloc_z(void *ptr, const size_t old_size, const size_t new_size)
{
    void *tmp;
    void *p;
    size_t diff;
    tmp = flb_realloc(ptr, new_size);
    if (!tmp) {
        return ((void*)0);
    }
    if (new_size > old_size) {
        diff = new_size - old_size;
        p = ((char *) tmp + old_size);
        memset(p, 0, diff);
    }
    return tmp;
}
static inline void flb_free(void *ptr) {
    free(ptr);
}
typedef void* cothread_t;
cothread_t co_active();
cothread_t co_create(unsigned int, void (*)(void), size_t *);
void co_delete(cothread_t);
void co_switch(cothread_t);
typedef
   struct {
      unsigned long int nraddr;
   }
   OrigFn;
typedef
   enum { VG_USERREQ__RUNNING_ON_VALGRIND = 0x1001,
          VG_USERREQ__DISCARD_TRANSLATIONS = 0x1002,
          VG_USERREQ__CLIENT_CALL0 = 0x1101,
          VG_USERREQ__CLIENT_CALL1 = 0x1102,
          VG_USERREQ__CLIENT_CALL2 = 0x1103,
          VG_USERREQ__CLIENT_CALL3 = 0x1104,
          VG_USERREQ__COUNT_ERRORS = 0x1201,
          VG_USERREQ__GDB_MONITOR_COMMAND = 0x1202,
          VG_USERREQ__CLO_CHANGE = 0x1203,
          VG_USERREQ__MALLOCLIKE_BLOCK = 0x1301,
          VG_USERREQ__RESIZEINPLACE_BLOCK = 0x130b,
          VG_USERREQ__FREELIKE_BLOCK = 0x1302,
          VG_USERREQ__CREATE_MEMPOOL = 0x1303,
          VG_USERREQ__DESTROY_MEMPOOL = 0x1304,
          VG_USERREQ__MEMPOOL_ALLOC = 0x1305,
          VG_USERREQ__MEMPOOL_FREE = 0x1306,
          VG_USERREQ__MEMPOOL_TRIM = 0x1307,
          VG_USERREQ__MOVE_MEMPOOL = 0x1308,
          VG_USERREQ__MEMPOOL_CHANGE = 0x1309,
          VG_USERREQ__MEMPOOL_EXISTS = 0x130a,
          VG_USERREQ__PRINTF = 0x1401,
          VG_USERREQ__PRINTF_BACKTRACE = 0x1402,
          VG_USERREQ__PRINTF_VALIST_BY_REF = 0x1403,
          VG_USERREQ__PRINTF_BACKTRACE_VALIST_BY_REF = 0x1404,
          VG_USERREQ__STACK_REGISTER = 0x1501,
          VG_USERREQ__STACK_DEREGISTER = 0x1502,
          VG_USERREQ__STACK_CHANGE = 0x1503,
          VG_USERREQ__LOAD_PDB_DEBUGINFO = 0x1601,
          VG_USERREQ__MAP_IP_TO_SRCLOC = 0x1701,
          VG_USERREQ__CHANGE_ERR_DISABLEMENT = 0x1801,
          VG_USERREQ__VEX_INIT_FOR_IRI = 0x1901,
          VG_USERREQ__INNER_THREADS = 0x1902
   } Vg_ClientRequest;
static int VALGRIND_PRINTF(const char *format, ...)
   __attribute__((format(__printf__, 1, 2), __unused__));
static int
VALGRIND_PRINTF(const char *format, ...)
{
   unsigned long _qzz_res;
   va_list vargs;
   __builtin_va_start(vargs, format);
   _qzz_res = __extension__ ({ volatile unsigned long int _zzq_args[6]; volatile unsigned long int _zzq_result; _zzq_args[0] = (unsigned long int)(VG_USERREQ__PRINTF_VALIST_BY_REF); _zzq_args[1] = (unsigned long int)((unsigned long)format); _zzq_args[2] = (unsigned long int)((unsigned long)&vargs); _zzq_args[3] = (unsigned long int)(0); _zzq_args[4] = (unsigned long int)(0); _zzq_args[5] = (unsigned long int)(0); __asm__ volatile("rolq $3,  %%rdi ; rolq $13, %%rdi\n\t" "rolq $61, %%rdi ; rolq $51, %%rdi\n\t" "xchgq %%rbx,%%rbx" : "=d" (_zzq_result) : "a" (&_zzq_args[0]), "0" (0) : "cc", "memory" ); _zzq_result; });
   __builtin_va_end(vargs);
   return (int)_qzz_res;
}
static int VALGRIND_PRINTF_BACKTRACE(const char *format, ...)
   __attribute__((format(__printf__, 1, 2), __unused__));
static int
VALGRIND_PRINTF_BACKTRACE(const char *format, ...)
{
   unsigned long _qzz_res;
   va_list vargs;
   __builtin_va_start(vargs, format);
   _qzz_res = __extension__ ({ volatile unsigned long int _zzq_args[6]; volatile unsigned long int _zzq_result; _zzq_args[0] = (unsigned long int)(VG_USERREQ__PRINTF_BACKTRACE_VALIST_BY_REF); _zzq_args[1] = (unsigned long int)((unsigned long)format); _zzq_args[2] = (unsigned long int)((unsigned long)&vargs); _zzq_args[3] = (unsigned long int)(0); _zzq_args[4] = (unsigned long int)(0); _zzq_args[5] = (unsigned long int)(0); __asm__ volatile("rolq $3,  %%rdi ; rolq $13, %%rdi\n\t" "rolq $61, %%rdi ; rolq $51, %%rdi\n\t" "xchgq %%rbx,%%rbx" : "=d" (_zzq_result) : "a" (&_zzq_args[0]), "0" (0) : "cc", "memory" ); _zzq_result; });
   __builtin_va_end(vargs);
   return (int)_qzz_res;
}
struct flb_coro {
    unsigned int valgrind_stack_id;
    cothread_t caller;
    cothread_t callee;
    void *data;
};
static inline __attribute__((always_inline)) void flb_coro_yield(struct flb_coro *coro, int ended)
{
    co_switch(coro->caller);
}
static inline __attribute__((always_inline)) void flb_coro_destroy(struct flb_coro *coro)
{
    if (flb_log_check(5)) flb_log_print(5, "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_coro.h", 97, "[coro] destroy coroutine=%p data=%p", coro, (((char *) coro) + sizeof(struct flb_coro)));
    do { (void) __extension__ ({ volatile unsigned long int _zzq_args[6]; volatile unsigned long int _zzq_result; _zzq_args[0] = (unsigned long int)((VG_USERREQ__STACK_DEREGISTER)); _zzq_args[1] = (unsigned long int)((coro->valgrind_stack_id)); _zzq_args[2] = (unsigned long int)((0)); _zzq_args[3] = (unsigned long int)((0)); _zzq_args[4] = (unsigned long int)((0)); _zzq_args[5] = (unsigned long int)((0)); __asm__ volatile("rolq $3,  %%rdi ; rolq $13, %%rdi\n\t" "rolq $61, %%rdi ; rolq $51, %%rdi\n\t" "xchgq %%rbx,%%rbx" : "=d" (_zzq_result) : "a" (&_zzq_args[0]), "0" (0) : "cc", "memory" ); _zzq_result; }); } while (0);
    if (coro->callee != ((void*)0)) {
        co_delete(coro->callee);
    }
    flb_free(coro);
}
void flb_coro_init();
void flb_coro_thread_init();
struct flb_coro *flb_coro_get();
void flb_coro_set(struct flb_coro *coro);
static inline __attribute__((always_inline)) void flb_coro_resume(struct flb_coro *coro)
{
    flb_coro_set(coro);
    coro->caller = co_active();
    co_switch(coro->callee);
}
static inline __attribute__((always_inline)) struct flb_coro *flb_coro_create(void *data)
{
    struct flb_coro *coro;
    coro = (struct flb_coro *) flb_calloc(1, sizeof(struct flb_coro));
    if (!coro) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_coro.h", 132);
        return ((void*)0);
    }
    coro->data = data;
    return coro;
}

int flb_socket_error(int fd);

struct flb_uri_field {
    size_t length;
    char *value;
    struct mk_list _head;
};
struct flb_uri {
    char *full;
    uint8_t count;
    struct mk_list list;
    struct flb_uri_field *map;
};
static inline int flb_uri_to_encode(char c)
{
    if ((c >= 48 && c <= 57) ||
        (c >= 65 && c <= 90) ||
        (c >= 97 && c <= 122) ||
        (c == '?' || c == '&' || c == '-' || c == '_' || c == '.' ||
         c == '~' || c == '/' || c == '=')) {
        return 0;
    }
    return 1;
}
struct flb_uri_field *flb_uri_get(struct flb_uri *uri, int pos);
struct flb_uri *flb_uri_create(const char *full_uri);
void flb_uri_destroy(struct flb_uri *uri);
void flb_uri_dump(struct flb_uri *uri);
flb_sds_t flb_uri_encode(const char *uri, size_t len);
struct flb_net_setup;
struct flb_upstream;
struct flb_downstream;
struct flb_tls_session;
struct flb_connection;
typedef void (*flb_connection_drop_notification_callback)(
                 struct flb_connection *connection);
typedef int (*flb_connection_accept_callback)(
                 struct flb_connection *connection,
                 void *data);
typedef int (*flb_connection_event_callback)(void *data);
struct flb_connection {
    struct mk_event event;
    void *user_data;
    flb_connection_drop_notification_callback drop_notification_callback;
    flb_connection_accept_callback accept_callback;
    void *accept_callback_data;
    int event_registration_mask;
    int fd;
    struct sockaddr_storage raw_remote_host;
    char remote_host[39 + 1];
    unsigned short int remote_port;
    char user_friendly_remote_host[(39 + 5 + 7) + 1];
    struct flb_net_setup *net;
    int net_error;
    int busy_flag;
    int shutdown_flag;
    int recycle;
    int ka_count;
    time_t ts_assigned;
    time_t ts_created;
    time_t ts_available;
    time_t ts_io_timeout;
    int io_timeout_log_error;
    time_t ts_connect_start;
    time_t ts_connect_timeout;
    struct mk_event_loop *evl;
    union {
        struct flb_stream *stream;
        struct flb_upstream *upstream;
        struct flb_downstream *downstream;
    };
    struct flb_coro *coroutine;
    struct flb_coro *event_coroutine;
    flb_connection_event_callback event_callback;
    flb_connection_event_callback event_parent_callback;
    void *event_parent_callback_data;
    int event_parent_callback_result;
    int event_wakeup_pending;
    int event_release_pending;
    int flags;
    int type;
    int dynamically_allocated;
    struct mk_list _head;
    struct flb_tls_session *tls_session;
};
int flb_connection_setup(struct flb_connection *connection,
                         int socket,
                         int type,
                         void *stream,
                         struct mk_event_loop *event_loop,
                         struct flb_coro *coroutine);
struct flb_connection *flb_connection_create(int socket,
                                             int type,
                                             void *stream,
                                             struct mk_event_loop *event_loop,
                                             struct flb_coro *coroutine);
void flb_connection_destroy(struct flb_connection *connection);
void flb_connection_set_remote_host(struct flb_connection *connection,
                                    struct sockaddr *remote_host);
char *flb_connection_get_remote_address(struct flb_connection *connection);
int flb_connection_get_flags(struct flb_connection *connection);
void flb_connection_enable_flags(struct flb_connection *connection, int flags);
void flb_connection_disable_flags(struct flb_connection *connection, int flags);
void flb_connection_reset_connection_timeout(struct flb_connection *connection);
void flb_connection_unset_connection_timeout(struct flb_connection *connection);
void flb_connection_reset_io_timeout(struct flb_connection *connection);
void flb_connection_unset_io_timeout(struct flb_connection *connection);

int flb_upstream_conn_recycle(struct flb_connection *conn, int val);
struct flb_connection *flb_upstream_conn_get(struct flb_upstream *u);
int flb_upstream_conn_release(struct flb_connection *u_conn);
int flb_upstream_conn_timeouts(struct mk_list *list);
int flb_upstream_conn_pending_destroy(struct flb_upstream *u);
int flb_upstream_conn_pending_destroy_list(struct mk_list *list);
int flb_upstream_conn_active_destroy_list(struct mk_list *list);
struct flb_net_dns {
    struct mk_list lookups;
    struct mk_list lookups_drop;
};
struct flb_net_setup {
    int keepalive;
    int keepalive_idle_timeout;
    int connect_timeout;
    int accept_timeout;
    int accept_timeout_log_error;
    int io_timeout;
    int connect_timeout_log_error;
    flb_sds_t source_address;
    int keepalive_max_recycle;
    int tcp_keepalive;
    int tcp_keepalive_time;
    int tcp_keepalive_interval;
    int tcp_keepalive_probes;
    char *dns_mode;
    char *dns_resolver;
    int dns_prefer_ipv4;
    int dns_prefer_ipv6;
    int share_port;
    int backlog;
    int max_worker_connections;
    int proxy_env_ignore;
};
struct flb_net_host {
    int ipv6;
    flb_sds_t address;
    int port;
    flb_sds_t name;
    flb_sds_t listen;
    struct flb_uri *uri;
};
void flb_net_lib_init();
void flb_net_ctx_init(struct flb_net_dns *dns_ctx);
void flb_net_dns_ctx_init();
struct flb_net_dns *flb_net_dns_ctx_get();
void flb_net_dns_ctx_set(struct flb_net_dns *dns_ctx);
void flb_net_setup_init(struct flb_net_setup *net);
int flb_net_host_set(const char *plugin_name, struct flb_net_host *host, const char *address);
void flb_net_dns_lookup_context_cleanup(struct flb_net_dns *dns_ctx);
int flb_net_socket_reset(int fd);
int flb_net_socket_tcp_nodelay(int fd);
int flb_net_socket_blocking(int fd);
int flb_net_socket_nonblocking(int fd);
int flb_net_socket_set_rcvtimeout(int fd, int timeout_in_seconds);
int flb_net_socket_rcv_buffer(int fd, int rcvbuf);
int flb_net_socket_tcp_fastopen(int sockfd);
int flb_net_socket_tcp_keepalive(int fd, struct flb_net_setup *net);
int flb_net_socket_create(int family, int nonblock);
int flb_net_socket_create_udp(int family, int nonblock);
int flb_net_tcp_connect(const char *host, unsigned long port,
                                 char *source_addr, int connect_timeout,
                                 int is_async,
                                 void *async_ctx,
                                 struct flb_connection *u_conn);
int flb_net_udp_connect(const char *host, unsigned long port,
                                 char *source_addr);
int flb_net_tcp_fd_connect(int fd, const char *host, unsigned long port);
int flb_net_server(const char *port, const char *listen_addr,
                            int backlog, int share_port);
int flb_net_server_udp(const char *port, const char *listen_addr, int share_port);
int flb_net_server_unix(const char *listen_path, int stream_mode,
                                 int backlog, int share_port);
int flb_net_bind(int fd, const struct sockaddr *addr,
                 socklen_t addrlen, int backlog);
int flb_net_bind_udp(int fd, const struct sockaddr *addr,
                 socklen_t addrlen);
int flb_net_accept(int server_fd);
int flb_net_address_to_str(int family, const struct sockaddr *addr,
                           char *output_buffer, size_t output_buffer_size);
int flb_net_socket_peer_address(int fd,
                                struct sockaddr_storage *output_buffer);
int flb_net_socket_address_info(int fd,
                                struct sockaddr_storage *address,
                                unsigned short int *port_output_buffer,
                                char *str_output_buffer,
                                int str_output_buffer_size,
                                size_t *str_output_data_size);
int flb_net_socket_peer_ip_str(int fd,
                               char *output_buffer,
                               int output_buffer_size,
                               size_t *output_data_size,
                               int *output_address_family);
int flb_net_socket_peer_ip_raw(int fd,
                               char *output_buffer,
                               int output_buffer_size,
                               size_t *output_data_size,
                               int *output_address_family);
int flb_net_socket_peer_port(int fd,
                             unsigned short int *output_buffer);
int flb_net_socket_peer_info(int fd,
                             unsigned short int *port_output_buffer,
                             struct sockaddr_storage *raw_output_buffer,
                             char *str_output_buffer,
                             int str_output_buffer_size,
                             size_t *str_output_data_size);
size_t flb_network_address_size(struct sockaddr_storage *address);
uint64_t flb_net_htonll(uint64_t value);
struct flb_connection;
int flb_io_net_accept(struct flb_connection *connection,
                       struct flb_coro *th);
int flb_io_net_connect(struct flb_connection *u_conn,
                       struct flb_coro *th);
int flb_io_net_write(struct flb_connection *connection, const void *data,
                     size_t len, size_t *out_len);
ssize_t flb_io_net_read(struct flb_connection *connection, void *buf, size_t len);
int flb_io_fd_write(int fd, const void *data, size_t len, size_t *out_len);
ssize_t flb_io_fd_read(int fd, void *buf, size_t len);
struct flb_stream {
    int dynamically_allocated;
    int thread_safety_flag;
    int transport;
    int flags;
    int type;
    pthread_mutex_t list_mutex;
    struct flb_tls *tls_context;
    struct flb_config *config;
    struct flb_net_setup net;
    struct mk_list _head;
};
static inline int flb_stream_is_shutting_down(struct flb_stream *stream)
{
    return stream->config->is_shutting_down;
}
static inline void flb_stream_setup(struct flb_stream *stream,
                                    int type,
                                    int transport,
                                    int flags,
                                    struct flb_tls *tls_context,
                                    struct flb_config *config,
                                    struct flb_net_setup *net_setup)
{
    stream->thread_safety_flag = 0;
    stream->tls_context = tls_context;
    stream->transport = transport;
    stream->config = config;
    stream->flags = flags;
    stream->type = type;
    if (net_setup == ((void*)0)) {
        flb_net_setup_init(&stream->net);
    }
    else {
        memcpy(&stream->net, net_setup, sizeof(struct flb_net_setup));
    }
}
static inline int flb_stream_get_flags(struct flb_stream *stream)
{
    return stream->flags;
}
static inline void flb_stream_set_flags(struct flb_stream *stream, int flags)
{
    stream->flags = flags;
}
static inline int flb_stream_get_flag_status(struct flb_stream *stream, int flag)
{
    return ((flb_stream_get_flags(stream) & flag) != 0);
}
static inline void flb_stream_enable_flags(struct flb_stream *stream, int flag)
{
    flb_stream_set_flags(stream, flb_stream_get_flags(stream) | flag);
}
static inline void flb_stream_disable_flags(struct flb_stream *stream, int flag)
{
    flb_stream_set_flags(stream, flb_stream_get_flags(stream) & ~flag);
}
static inline void flb_stream_enable_async_mode(struct flb_stream *stream)
{
    flb_stream_enable_flags(stream, 8);
}
static inline void flb_stream_disable_async_mode(struct flb_stream *stream)
{
    flb_stream_disable_flags(stream, 8);
}
static inline int flb_stream_is_async(struct flb_stream *stream)
{
    return flb_stream_get_flag_status(stream, 8);
}
static inline void flb_stream_enable_keepalive(struct flb_stream *stream)
{
    flb_stream_enable_flags(stream, 16);
}
static inline void flb_stream_disable_keepalive(struct flb_stream *stream)
{
    flb_stream_disable_flags(stream, 16);
}
static inline int flb_stream_is_keepalive(struct flb_stream *stream)
{
    return flb_stream_get_flag_status(stream, 16);
}
static inline int flb_stream_is_secure(struct flb_stream *stream)
{
    return flb_stream_get_flag_status(stream, 2) ||
           flb_stream_get_flag_status(stream, 64);
}
static inline int flb_stream_is_thread_safe(struct flb_stream *stream)
{
    return stream->thread_safety_flag;
}
static inline void flb_stream_enable_thread_safety(struct flb_stream *stream)
{
    stream->thread_safety_flag = 1;
    pthread_mutex_init(&stream->list_mutex, ((void*)0));
    if (mk_list_entry_orphan(&stream->_head) == 0) {
        mk_list_del(&stream->_head);
    }
}
static inline int flb_stream_acquire_lock(struct flb_stream *stream,
                                          int wait_flag)
{
    int result;
    result = 0;
    if (stream->thread_safety_flag) {
        if (wait_flag) {
            result = pthread_mutex_lock(&stream->list_mutex);
        }
        else {
            result = pthread_mutex_trylock(&stream->list_mutex);
        }
    }
    if (result == 0) {
        result = 1;
    }
    else {
        result = 0;
    }
    return result;
}
static inline int flb_stream_release_lock(struct flb_stream *stream)
{
    int result;
    result = 0;
    if (stream->thread_safety_flag) {
        result = pthread_mutex_unlock(&stream->list_mutex);
    }
    if (result == 0) {
        result = 1;
    }
    else {
        result = 0;
    }
    return result;
}

struct flb_connection;
struct flb_downstream {
    struct flb_stream base;
    char *host;
    unsigned short int port;
    int server_fd;
    struct flb_connection *dgram_connection;
    struct mk_list busy_queue;
    struct mk_list destroy_queue;
    struct flb_net_setup *net_setup;
    int paused;
};
static inline int flb_downstream_is_shutting_down(struct flb_downstream *downstream)
{
    return flb_stream_is_shutting_down(&downstream->base);
}
void flb_downstream_init();
int flb_downstream_setup(struct flb_downstream *stream,
                         int transport, int flags,
                         const char *host,
                         unsigned short int port,
                         struct flb_tls *tls,
                         struct flb_config *config,
                         struct flb_net_setup *net_setup);
struct flb_downstream *flb_downstream_create(int transport, int flags,
                                             const char *host,
                                             unsigned short int port,
                                             struct flb_tls *tls,
                                             struct flb_config *config,
                                             struct flb_net_setup *net_setup);
void flb_downstream_destroy(struct flb_downstream *downstream);
int flb_downstream_set_property(struct flb_config *config,
                              struct flb_net_setup *net, char *k, char *v);
struct flb_connection *flb_downstream_conn_get(struct flb_downstream *stream);
void flb_downstream_pause(struct flb_downstream *stream);
void flb_downstream_resume(struct flb_downstream *stream);
int flb_downstream_conn_release(struct flb_connection *connection);
int flb_downstream_conn_release_all(struct flb_downstream *stream);
int flb_downstream_conn_event_accept(
        struct flb_downstream *stream,
        flb_connection_accept_callback accept_callback,
        void *accept_callback_data,
        flb_connection_event_callback event_callback,
        int mask);
int flb_downstream_conn_event_register(struct flb_connection *connection,
                                       int (*callback)(void *data),
                                       int mask);
int flb_downstream_conn_event_call_parent(
        struct flb_connection *connection,
        flb_connection_event_callback callback,
        void *callback_data);
void flb_downstream_conn_event_resume(struct flb_connection *connection);
int flb_downstream_conn_pending_destroy_list(struct mk_list *list);
int flb_downstream_conn_pending_destroy(struct flb_downstream *stream);
int flb_downstream_conn_timeouts(struct mk_list *list);
int flb_downstream_conn_timeouts_stream(struct flb_downstream *stream);
int flb_downstream_is_async(struct flb_downstream *downstream);
void flb_downstream_thread_safe(struct flb_downstream *stream);
struct mk_list *flb_downstream_get_config_map(struct flb_config *config);
struct flb_upstream_queue {
    struct mk_list av_queue;
    struct mk_list busy_queue;
    struct mk_list destroy_queue;
};
struct flb_tls;
struct flb_connection;
struct flb_tls_file_status {
    int exists;
    uint64_t size;
    uint64_t device;
    uint64_t inode;
    uint64_t mtime;
    uint64_t mtime_nsec;
    uint64_t ctime;
    uint64_t ctime_nsec;
};
struct flb_tls_session {
    void *ptr;
    struct flb_tls *tls;
    struct flb_connection *connection;
};
struct flb_tls_backend {
    char *name;
    void *(*context_create) (int, int, int,
                             const char *, const char *,
                             const char *, const char *,
                             const char *, const char *);
    int (*context_reload) (struct flb_tls *);
    void (*context_destroy) (void *);
    int (*context_alpn_set) (void *, const char *);
    int (*context_set_verify_client) (void *, int);
    int (*context_set_crl_file) (void *, const char *);
    int (*set_minmax_proto) (struct flb_tls *tls, const char *, const char *);
    int (*set_ciphers) (struct flb_tls *tls, const char *);
    void *(*session_create) (struct flb_tls *, int);
    void (*session_invalidate) (void *);
    int (*session_destroy) (void *);
    const char *(*session_alpn_get) (void *);
    int (*session_set_outer) (void *inner, void *outer);
    int (*net_read) (struct flb_tls_session *, void *, size_t);
    int (*net_write) (struct flb_tls_session *, const void *data,
                      size_t len);
    int (*net_handshake) (struct flb_tls *, char *, void *);
};
struct flb_tls {
    int verify;
    int verify_client;
    int debug;
    char *vhost;
    char *ca_path;
    char *ca_file;
    char *crt_file;
    char *key_file;
    char *key_passwd;
    char *crl_file;
    char *alpn;
    char *min_version;
    char *max_version;
    char *ciphers;
    struct flb_tls_file_status ca_path_status;
    struct flb_tls_file_status ca_file_status;
    struct flb_tls_file_status crt_file_status;
    struct flb_tls_file_status key_file_status;
    int mode;
    int verify_hostname;
    int system_certificates_loaded;
    void *ctx;
    struct flb_tls_backend *api;
    pthread_mutex_t reload_mutex;
};
int flb_tls_init();
struct flb_tls *flb_tls_create(int mode,
                               int verify,
                               int debug,
                               const char *vhost,
                               const char *ca_path,
                               const char *ca_file, const char *crt_file,
                               const char *key_file, const char *key_passwd);
int flb_tls_destroy(struct flb_tls *tls);
int flb_tls_reload_if_needed(struct flb_tls *tls);
int flb_tls_set_alpn(struct flb_tls *tls, const char *alpn);
int flb_tls_set_verify_client(struct flb_tls *tls, int verify_client);
int flb_tls_set_crl_file(struct flb_tls *tls, const char *crl_file);
int flb_tls_set_verify_hostname(struct flb_tls *tls, int verify_hostname);
int flb_tls_load_system_certificates(struct flb_tls *tls);
int flb_tls_set_minmax_proto(struct flb_tls *tls,
                             const char *min_version, const char *max_version);
int flb_tls_set_ciphers(struct flb_tls *tls, const char *ciphers);
struct mk_list *flb_tls_get_config_map(struct flb_config *config);
int flb_tls_session_destroy(struct flb_tls_session *session);
int flb_tls_session_invalidate(struct flb_tls_session *session);
int flb_tls_session_create(struct flb_tls *tls,
                           struct flb_connection *connection,
                           struct flb_coro *co);
const char *flb_tls_session_get_alpn(struct flb_tls_session *session);
int flb_tls_net_read(struct flb_tls_session *session,
                     void *buf,
                     size_t len);
int flb_tls_net_read_async(struct flb_coro *th,
                           struct flb_tls_session *session,
                           void *buf, size_t len);
int flb_tls_net_write(struct flb_tls_session *session,
                      const void *data, size_t len, size_t *out_len);
int flb_tls_net_write_async(struct flb_coro *th,
                            struct flb_tls_session *session,
                            const void *data, size_t len, size_t *out_len);
struct cmt_gauge {
    struct cmt_opts opts;
    struct cmt_map *map;
    struct cmt *cmt;
    struct cfl_list _head;
};
struct cmt_gauge *cmt_gauge_create(struct cmt *cmt,
                                   char *ns, char *subsystem, char *name,
                                   char *help, int label_count, char **label_keys);
int cmt_gauge_destroy(struct cmt_gauge *gauge);
int cmt_gauge_set(struct cmt_gauge *gauge, uint64_t timestamp, double val,
                  int labels_count, char **label_vals);
int cmt_gauge_inc(struct cmt_gauge *gauge, uint64_t timestamp,
                  int labels_count, char **label_vals);
int cmt_gauge_dec(struct cmt_gauge *gauge, uint64_t timestamp,
                  int labels_count, char **label_vals);
int cmt_gauge_add(struct cmt_gauge *gauge, uint64_t timestamp,
                  double val, int labels_count, char **label_vals);
int cmt_gauge_sub(struct cmt_gauge *gauge, uint64_t timestamp, double val,
                  int labels_count, char **label_vals);
int cmt_gauge_get_val(struct cmt_gauge *gauge,
                      int labels_count, char **label_vals, double *out_val);
struct flb_upstream {
    struct flb_stream base;
    char *tcp_host;
    int tcp_port;
    char *proxied_host;
    int proxied_port;
    char *proxy_username;
    char *proxy_password;
    struct flb_tls *proxy_tls_context;
    int ha_mode;
    void *ha_ctx;
    struct cmt_gauge *cmt_total_connections;
    struct cmt_gauge *cmt_busy_connections;
    const char *cmt_total_connections_label;
    const char *cmt_busy_connections_label;
    void *parent_upstream;
    struct flb_upstream_queue queue;
};
static inline int flb_upstream_is_shutting_down(struct flb_upstream *u)
{
    return flb_stream_is_shutting_down(&u->base);
}
void flb_upstream_queue_init(struct flb_upstream_queue *uq);
struct flb_upstream_queue *flb_upstream_queue_get(struct flb_upstream *u);
void flb_upstream_list_set(struct mk_list *list);
struct mk_list *flb_upstream_list_get();
void flb_upstream_init();
struct flb_upstream *flb_upstream_create(struct flb_config *config,
                                         const char *host, int port, int flags,
                                         struct flb_tls *tls);
struct flb_upstream *flb_upstream_create_url(struct flb_config *config,
                                             const char *url, int flags,
                                             struct flb_tls *tls);
int flb_upstream_destroy(struct flb_upstream *u);
int flb_upstream_proxy_tls_setup(struct flb_upstream *u,
                                 int verify, int verify_hostname,
                                 const char *ca_path, const char *ca_file);
int flb_upstream_set_property(struct flb_config *config,
                              struct flb_net_setup *net, char *k, char *v);
int flb_upstream_is_async(struct flb_upstream *u);
void flb_upstream_thread_safe(struct flb_upstream *u);
struct mk_list *flb_upstream_get_config_map(struct flb_config *config);
int flb_upstream_needs_proxy(const char *host, const char *proxy, const char *no_proxy);
void flb_upstream_set_total_connections_label(
        struct flb_upstream *stream,
        const char *label_value);
void flb_upstream_set_total_connections_gauge(
        struct flb_upstream *stream,
        struct cmt_gauge *gauge_instance);
void flb_upstream_set_busy_connections_label(
        struct flb_upstream *stream,
        const char *label_value);
void flb_upstream_set_busy_connections_gauge(
        struct flb_upstream *stream,
        struct cmt_gauge *gauge_instance);

static inline char *flb_strndup(const char *s, size_t n)
{
    char *str;
    str = (char *) flb_malloc(n + 1);
    if (!str) {
        return ((void*)0);
    }
    memcpy(str, s, n);
    str[n] = '\0';
    return str;
}
static inline char *flb_strdup(const char *s)
{
    return flb_strndup(s, strlen(s));
}
static inline int flb_str_emptyval(const char *s)
{
    if (s != ((void*)0) && strcmp(s, "") == 0) {
        return 1;
    }
    return 0;
}
static inline char *flb_rtrim(const char *str, char c) {
    ssize_t pos = strlen(str);
    while(c == str[--pos]);
    if (pos < 0){
        return ((void*)0);
    }
    return flb_strndup(str, pos+1);
}

struct flb_regex {
    void *regex;
};
struct flb_regex_search {
    int last_pos;
    void *region;
    const char *str;
    void (*cb_match) (const char *,
                      const char *, size_t,
                      void *);
    void *data;
};
int flb_regex_init();
struct flb_regex *flb_regex_create(const char *pattern);
ssize_t flb_regex_do(struct flb_regex *r, const char *str, size_t slen,
                     struct flb_regex_search *result);
int flb_regex_match(struct flb_regex *r, unsigned char *str, size_t slen);
int flb_regex_parse(struct flb_regex *r, struct flb_regex_search *result,
                    void (*cb_match) (const char *,
                                      const char *, size_t,
                                      void *),
                    void *data);
int flb_regex_destroy(struct flb_regex *r);
int flb_regex_results_get(struct flb_regex_search *result, int i,
                          ptrdiff_t *start, ptrdiff_t *end);
void flb_regex_results_release(struct flb_regex_search *result);
int flb_regex_results_size(struct flb_regex_search *result);
void flb_regex_exit();
struct cmt_untyped {
    struct cmt_opts opts;
    struct cmt_map *map;
    struct cmt *cmt;
    struct cfl_list _head;
};
struct cmt_untyped *cmt_untyped_create(struct cmt *cmt,
                                       char *ns, char *subsystem,
                                       char *name, char *help,
                                       int label_count, char **label_keys);
int cmt_untyped_destroy(struct cmt_untyped *counter);
int cmt_untyped_set(struct cmt_untyped *counter, uint64_t timestamp, double val,
                    int labels_count, char **label_vals);
int cmt_untyped_get_val(struct cmt_untyped *counter,
                        int labels_count, char **label_vals, double *out_val);
struct cmt_counter;
struct cmt_gauge;
struct cmt_untyped;
struct cmt_histogram;
struct cmt_exp_histogram;
struct cmt_summary;
int cmt_cat_copy_label_keys(struct cmt_map *map, char **out);
int cmt_cat_copy_map(struct cmt_opts *opts, struct cmt_map *dst, struct cmt_map *src);
int cmt_cat_counter(struct cmt *cmt, struct cmt_counter *counter, struct cmt_map *filtered_map);
int cmt_cat_gauge(struct cmt *cmt, struct cmt_gauge *gauge, struct cmt_map *filtered_map);
int cmt_cat_untyped(struct cmt *cmt, struct cmt_untyped *untyped, struct cmt_map *filtered_map);
int cmt_cat_histogram(struct cmt *cmt, struct cmt_histogram *histogram, struct cmt_map *filtered_map);
int cmt_cat_exp_histogram(struct cmt *cmt, struct cmt_exp_histogram *exp_histogram, struct cmt_map *filtered_map);
int cmt_cat_summary(struct cmt *cmt, struct cmt_summary *summary, struct cmt_map *filtered_map);
int cmt_cat(struct cmt *dst, struct cmt *src);
struct cmt_msgpack_temporary_bucket {
    double upper_bound;
    struct cfl_list _head;
};
struct cmt_msgpack_decode_context {
    struct cmt *cmt;
    struct cmt_map *map;
    struct cmt_metric *metric;
    double *bucket_list;
    size_t bucket_count;
    double *quantile_list;
    size_t quantile_count;
    uint64_t *summary_quantiles;
    size_t summary_quantiles_count;
    int aggregation_type;
    int metric_value_type_set;
};
int cmt_decode_msgpack_create(struct cmt **out_cmt, char *in_buf, size_t in_size,
                              size_t *offset);
void cmt_decode_msgpack_destroy(struct cmt *cmt);
cfl_sds_t cmt_encode_influx_create(struct cmt *cmt);
void cmt_encode_influx_destroy(cfl_sds_t text);
cfl_sds_t cmt_encode_text_create(struct cmt *cmt);
void cmt_encode_text_destroy(cfl_sds_t text);
cfl_sds_t cmt_encode_prometheus_create(struct cmt *cmt, int add_timestamp);
void cmt_encode_prometheus_destroy(cfl_sds_t text);
extern void __assert_fail (const char *__assertion, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__)) __attribute__ ((__cold__));
extern void __assert_perror_fail (int __errnum, const char *__file,
      unsigned int __line, const char *__function)
     __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__)) __attribute__ ((__cold__));
extern void __assert (const char *__assertion, const char *__file, int __line)
     __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__)) __attribute__ ((__cold__));
extern const char protobuf_c_empty_string[];
typedef enum {
 PROTOBUF_C_FIELD_FLAG_PACKED = (1 << 0),
 PROTOBUF_C_FIELD_FLAG_DEPRECATED = (1 << 1),
 PROTOBUF_C_FIELD_FLAG_ONEOF = (1 << 2),
} ProtobufCFieldFlag;
typedef enum {
 PROTOBUF_C_LABEL_REQUIRED,
 PROTOBUF_C_LABEL_OPTIONAL,
 PROTOBUF_C_LABEL_REPEATED,
 PROTOBUF_C_LABEL_NONE,
} ProtobufCLabel;
typedef enum {
 PROTOBUF_C_TYPE_INT32,
 PROTOBUF_C_TYPE_SINT32,
 PROTOBUF_C_TYPE_SFIXED32,
 PROTOBUF_C_TYPE_INT64,
 PROTOBUF_C_TYPE_SINT64,
 PROTOBUF_C_TYPE_SFIXED64,
 PROTOBUF_C_TYPE_UINT32,
 PROTOBUF_C_TYPE_FIXED32,
 PROTOBUF_C_TYPE_UINT64,
 PROTOBUF_C_TYPE_FIXED64,
 PROTOBUF_C_TYPE_FLOAT,
 PROTOBUF_C_TYPE_DOUBLE,
 PROTOBUF_C_TYPE_BOOL,
 PROTOBUF_C_TYPE_ENUM,
 PROTOBUF_C_TYPE_STRING,
 PROTOBUF_C_TYPE_BYTES,
 PROTOBUF_C_TYPE_MESSAGE,
} ProtobufCType;
typedef enum {
 PROTOBUF_C_WIRE_TYPE_VARINT = 0,
 PROTOBUF_C_WIRE_TYPE_64BIT = 1,
 PROTOBUF_C_WIRE_TYPE_LENGTH_PREFIXED = 2,
 PROTOBUF_C_WIRE_TYPE_32BIT = 5,
} ProtobufCWireType;
struct ProtobufCAllocator;
struct ProtobufCBinaryData;
struct ProtobufCBuffer;
struct ProtobufCBufferSimple;
struct ProtobufCEnumDescriptor;
struct ProtobufCEnumValue;
struct ProtobufCEnumValueIndex;
struct ProtobufCFieldDescriptor;
struct ProtobufCIntRange;
struct ProtobufCMessage;
struct ProtobufCMessageDescriptor;
struct ProtobufCMessageUnknownField;
struct ProtobufCMethodDescriptor;
struct ProtobufCService;
struct ProtobufCServiceDescriptor;
typedef struct ProtobufCAllocator ProtobufCAllocator;
typedef struct ProtobufCBinaryData ProtobufCBinaryData;
typedef struct ProtobufCBuffer ProtobufCBuffer;
typedef struct ProtobufCBufferSimple ProtobufCBufferSimple;
typedef struct ProtobufCEnumDescriptor ProtobufCEnumDescriptor;
typedef struct ProtobufCEnumValue ProtobufCEnumValue;
typedef struct ProtobufCEnumValueIndex ProtobufCEnumValueIndex;
typedef struct ProtobufCFieldDescriptor ProtobufCFieldDescriptor;
typedef struct ProtobufCIntRange ProtobufCIntRange;
typedef struct ProtobufCMessage ProtobufCMessage;
typedef struct ProtobufCMessageDescriptor ProtobufCMessageDescriptor;
typedef struct ProtobufCMessageUnknownField ProtobufCMessageUnknownField;
typedef struct ProtobufCMethodDescriptor ProtobufCMethodDescriptor;
typedef struct ProtobufCService ProtobufCService;
typedef struct ProtobufCServiceDescriptor ProtobufCServiceDescriptor;
typedef int protobuf_c_boolean;
typedef void (*ProtobufCClosure)(const ProtobufCMessage *, void *closure_data);
typedef void (*ProtobufCMessageInit)(ProtobufCMessage *);
typedef void (*ProtobufCServiceDestroy)(ProtobufCService *);
struct ProtobufCAllocator {
 void *(*alloc)(void *allocator_data, size_t size);
 void (*free)(void *allocator_data, void *pointer);
 void *allocator_data;
};
struct ProtobufCBinaryData {
 size_t len;
 uint8_t *data;
};
struct ProtobufCBuffer {
 void (*append)(ProtobufCBuffer *buffer,
      size_t len,
      const uint8_t *data);
};
struct ProtobufCBufferSimple {
 ProtobufCBuffer base;
 size_t alloced;
 size_t len;
 uint8_t *data;
 protobuf_c_boolean must_free_data;
 ProtobufCAllocator *allocator;
};
struct ProtobufCEnumDescriptor {
 uint32_t magic;
 const char *name;
 const char *short_name;
 const char *c_name;
 const char *package_name;
 unsigned n_values;
 const ProtobufCEnumValue *values;
 unsigned n_value_names;
 const ProtobufCEnumValueIndex *values_by_name;
 unsigned n_value_ranges;
 const ProtobufCIntRange *value_ranges;
 void *reserved1;
 void *reserved2;
 void *reserved3;
 void *reserved4;
};
struct ProtobufCEnumValue {
 const char *name;
 const char *c_name;
 int value;
};
struct ProtobufCEnumValueIndex {
 const char *name;
 unsigned index;
};
struct ProtobufCFieldDescriptor {
 const char *name;
 uint32_t id;
 ProtobufCLabel label;
 ProtobufCType type;
 unsigned quantifier_offset;
 unsigned offset;
 const void *descriptor;
 const void *default_value;
 uint32_t flags;
 unsigned reserved_flags;
 void *reserved2;
 void *reserved3;
};
struct ProtobufCIntRange {
 int start_value;
 unsigned orig_index;
};
struct ProtobufCMessage {
 const ProtobufCMessageDescriptor *descriptor;
 unsigned n_unknown_fields;
 ProtobufCMessageUnknownField *unknown_fields;
};
struct ProtobufCMessageDescriptor {
 uint32_t magic;
 const char *name;
 const char *short_name;
 const char *c_name;
 const char *package_name;
 size_t sizeof_message;
 unsigned n_fields;
 const ProtobufCFieldDescriptor *fields;
 const unsigned *fields_sorted_by_name;
 unsigned n_field_ranges;
 const ProtobufCIntRange *field_ranges;
 ProtobufCMessageInit message_init;
 void *reserved1;
 void *reserved2;
 void *reserved3;
};
struct ProtobufCMessageUnknownField {
 uint32_t tag;
 ProtobufCWireType wire_type;
 size_t len;
 uint8_t *data;
};
struct ProtobufCMethodDescriptor {
 const char *name;
 const ProtobufCMessageDescriptor *input;
 const ProtobufCMessageDescriptor *output;
};
struct ProtobufCService {
 const ProtobufCServiceDescriptor *descriptor;
 void (*invoke)(ProtobufCService *service,
         unsigned method_index,
         const ProtobufCMessage *input,
         ProtobufCClosure closure,
         void *closure_data);
 void (*destroy)(ProtobufCService *service);
};
struct ProtobufCServiceDescriptor {
 uint32_t magic;
 const char *name;
 const char *short_name;
 const char *c_name;
 const char *package;
 unsigned n_methods;
 const ProtobufCMethodDescriptor *methods;
 const unsigned *method_indices_by_name;
};
const char *
protobuf_c_version(void);
uint32_t
protobuf_c_version_number(void);
const ProtobufCEnumValue *
protobuf_c_enum_descriptor_get_value_by_name(
 const ProtobufCEnumDescriptor *desc,
 const char *name);
const ProtobufCEnumValue *
protobuf_c_enum_descriptor_get_value(
 const ProtobufCEnumDescriptor *desc,
 int value);
const ProtobufCFieldDescriptor *
protobuf_c_message_descriptor_get_field_by_name(
 const ProtobufCMessageDescriptor *desc,
 const char *name);
const ProtobufCFieldDescriptor *
protobuf_c_message_descriptor_get_field(
 const ProtobufCMessageDescriptor *desc,
 unsigned value);
size_t
protobuf_c_message_get_packed_size(const ProtobufCMessage *message);
size_t
protobuf_c_message_pack(const ProtobufCMessage *message, uint8_t *out);
size_t
protobuf_c_message_pack_to_buffer(
 const ProtobufCMessage *message,
 ProtobufCBuffer *buffer);
ProtobufCMessage *
protobuf_c_message_unpack(
 const ProtobufCMessageDescriptor *descriptor,
 ProtobufCAllocator *allocator,
 size_t len,
 const uint8_t *data);
void
protobuf_c_message_free_unpacked(
 ProtobufCMessage *message,
 ProtobufCAllocator *allocator);
protobuf_c_boolean
protobuf_c_message_check(const ProtobufCMessage *);
void
protobuf_c_message_init(
 const ProtobufCMessageDescriptor *descriptor,
 void *message);
void
protobuf_c_service_destroy(ProtobufCService *service);
const ProtobufCMethodDescriptor *
protobuf_c_service_descriptor_get_method_by_name(
 const ProtobufCServiceDescriptor *desc,
 const char *name);
void
protobuf_c_buffer_simple_append(
 ProtobufCBuffer *buffer,
 size_t len,
 const unsigned char *data);
void
protobuf_c_service_generated_init(
 ProtobufCService *service,
 const ProtobufCServiceDescriptor *descriptor,
 ProtobufCServiceDestroy destroy);
void
protobuf_c_service_invoke_internal(
 ProtobufCService *service,
 unsigned method_index,
 const ProtobufCMessage *input,
 ProtobufCClosure closure,
 void *closure_data);
typedef struct _Prometheus__MetricMetadata Prometheus__MetricMetadata;
typedef struct _Prometheus__Sample Prometheus__Sample;
typedef struct _Prometheus__Exemplar Prometheus__Exemplar;
typedef struct _Prometheus__Histogram Prometheus__Histogram;
typedef struct _Prometheus__BucketSpan Prometheus__BucketSpan;
typedef struct _Prometheus__TimeSeries Prometheus__TimeSeries;
typedef struct _Prometheus__Label Prometheus__Label;
typedef struct _Prometheus__Labels Prometheus__Labels;
typedef struct _Prometheus__LabelMatcher Prometheus__LabelMatcher;
typedef struct _Prometheus__ReadHints Prometheus__ReadHints;
typedef struct _Prometheus__Chunk Prometheus__Chunk;
typedef struct _Prometheus__ChunkedSeries Prometheus__ChunkedSeries;
typedef enum _Prometheus__MetricMetadata__MetricType {
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__UNKNOWN = 0,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__COUNTER = 1,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__GAUGE = 2,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__HISTOGRAM = 3,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__GAUGEHISTOGRAM = 4,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__SUMMARY = 5,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__INFO = 6,
  PROMETHEUS__METRIC_METADATA__METRIC_TYPE__STATESET = 7
    , _PROMETHEUS__METRIC_METADATA__METRIC_TYPE_IS_INT_SIZE = 2147483647
} Prometheus__MetricMetadata__MetricType;
typedef enum _Prometheus__Histogram__ResetHint {
  PROMETHEUS__HISTOGRAM__RESET_HINT__UNKNOWN = 0,
  PROMETHEUS__HISTOGRAM__RESET_HINT__YES = 1,
  PROMETHEUS__HISTOGRAM__RESET_HINT__NO = 2,
  PROMETHEUS__HISTOGRAM__RESET_HINT__GAUGE = 3
    , _PROMETHEUS__HISTOGRAM__RESET_HINT_IS_INT_SIZE = 2147483647
} Prometheus__Histogram__ResetHint;
typedef enum _Prometheus__LabelMatcher__Type {
  PROMETHEUS__LABEL_MATCHER__TYPE__EQ = 0,
  PROMETHEUS__LABEL_MATCHER__TYPE__NEQ = 1,
  PROMETHEUS__LABEL_MATCHER__TYPE__RE = 2,
  PROMETHEUS__LABEL_MATCHER__TYPE__NRE = 3
    , _PROMETHEUS__LABEL_MATCHER__TYPE_IS_INT_SIZE = 2147483647
} Prometheus__LabelMatcher__Type;
typedef enum _Prometheus__Chunk__Encoding {
  PROMETHEUS__CHUNK__ENCODING__UNKNOWN = 0,
  PROMETHEUS__CHUNK__ENCODING__XOR = 1,
  PROMETHEUS__CHUNK__ENCODING__HISTOGRAM = 2,
  PROMETHEUS__CHUNK__ENCODING__FLOAT_HISTOGRAM = 3
    , _PROMETHEUS__CHUNK__ENCODING_IS_INT_SIZE = 2147483647
} Prometheus__Chunk__Encoding;
struct _Prometheus__MetricMetadata
{
  ProtobufCMessage base;
  Prometheus__MetricMetadata__MetricType type;
  char *metric_family_name;
  char *help;
  char *unit;
};
struct _Prometheus__Sample
{
  ProtobufCMessage base;
  double value;
  int64_t timestamp;
};
struct _Prometheus__Exemplar
{
  ProtobufCMessage base;
  size_t n_labels;
  Prometheus__Label **labels;
  double value;
  int64_t timestamp;
};
typedef enum {
  PROMETHEUS__HISTOGRAM__COUNT__NOT_SET = 0,
  PROMETHEUS__HISTOGRAM__COUNT_COUNT_INT = 1,
  PROMETHEUS__HISTOGRAM__COUNT_COUNT_FLOAT = 2
    , _PROMETHEUS__HISTOGRAM__COUNT_IS_INT_SIZE = 2147483647
} Prometheus__Histogram__CountCase;
typedef enum {
  PROMETHEUS__HISTOGRAM__ZERO_COUNT__NOT_SET = 0,
  PROMETHEUS__HISTOGRAM__ZERO_COUNT_ZERO_COUNT_INT = 6,
  PROMETHEUS__HISTOGRAM__ZERO_COUNT_ZERO_COUNT_FLOAT = 7
    , _PROMETHEUS__HISTOGRAM__ZERO_COUNT_IS_INT_SIZE = 2147483647
} Prometheus__Histogram__ZeroCountCase;
struct _Prometheus__Histogram
{
  ProtobufCMessage base;
  double sum;
  int32_t schema;
  double zero_threshold;
  size_t n_negative_spans;
  Prometheus__BucketSpan **negative_spans;
  size_t n_negative_deltas;
  int64_t *negative_deltas;
  size_t n_negative_counts;
  double *negative_counts;
  size_t n_positive_spans;
  Prometheus__BucketSpan **positive_spans;
  size_t n_positive_deltas;
  int64_t *positive_deltas;
  size_t n_positive_counts;
  double *positive_counts;
  Prometheus__Histogram__ResetHint reset_hint;
  int64_t timestamp;
  Prometheus__Histogram__CountCase count_case;
  union {
    uint64_t count_int;
    double count_float;
  };
  Prometheus__Histogram__ZeroCountCase zero_count_case;
  union {
    uint64_t zero_count_int;
    double zero_count_float;
  };
};
struct _Prometheus__BucketSpan
{
  ProtobufCMessage base;
  int32_t offset;
  uint32_t length;
};
struct _Prometheus__TimeSeries
{
  ProtobufCMessage base;
  size_t n_labels;
  Prometheus__Label **labels;
  size_t n_samples;
  Prometheus__Sample **samples;
  size_t n_exemplars;
  Prometheus__Exemplar **exemplars;
  size_t n_histograms;
  Prometheus__Histogram **histograms;
};
struct _Prometheus__Label
{
  ProtobufCMessage base;
  char *name;
  char *value;
};
struct _Prometheus__Labels
{
  ProtobufCMessage base;
  size_t n_labels;
  Prometheus__Label **labels;
};
struct _Prometheus__LabelMatcher
{
  ProtobufCMessage base;
  Prometheus__LabelMatcher__Type type;
  char *name;
  char *value;
};
struct _Prometheus__ReadHints
{
  ProtobufCMessage base;
  int64_t step_ms;
  char *func;
  int64_t start_ms;
  int64_t end_ms;
  size_t n_grouping;
  char **grouping;
  protobuf_c_boolean by;
  int64_t range_ms;
};
struct _Prometheus__Chunk
{
  ProtobufCMessage base;
  int64_t min_time_ms;
  int64_t max_time_ms;
  Prometheus__Chunk__Encoding type;
  ProtobufCBinaryData data;
};
struct _Prometheus__ChunkedSeries
{
  ProtobufCMessage base;
  size_t n_labels;
  Prometheus__Label **labels;
  size_t n_chunks;
  Prometheus__Chunk **chunks;
};
void prometheus__metric_metadata__init
                     (Prometheus__MetricMetadata *message);
size_t prometheus__metric_metadata__get_packed_size
                     (const Prometheus__MetricMetadata *message);
size_t prometheus__metric_metadata__pack
                     (const Prometheus__MetricMetadata *message,
                      uint8_t *out);
size_t prometheus__metric_metadata__pack_to_buffer
                     (const Prometheus__MetricMetadata *message,
                      ProtobufCBuffer *buffer);
Prometheus__MetricMetadata *
       prometheus__metric_metadata__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__metric_metadata__free_unpacked
                     (Prometheus__MetricMetadata *message,
                      ProtobufCAllocator *allocator);
void prometheus__sample__init
                     (Prometheus__Sample *message);
size_t prometheus__sample__get_packed_size
                     (const Prometheus__Sample *message);
size_t prometheus__sample__pack
                     (const Prometheus__Sample *message,
                      uint8_t *out);
size_t prometheus__sample__pack_to_buffer
                     (const Prometheus__Sample *message,
                      ProtobufCBuffer *buffer);
Prometheus__Sample *
       prometheus__sample__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__sample__free_unpacked
                     (Prometheus__Sample *message,
                      ProtobufCAllocator *allocator);
void prometheus__exemplar__init
                     (Prometheus__Exemplar *message);
size_t prometheus__exemplar__get_packed_size
                     (const Prometheus__Exemplar *message);
size_t prometheus__exemplar__pack
                     (const Prometheus__Exemplar *message,
                      uint8_t *out);
size_t prometheus__exemplar__pack_to_buffer
                     (const Prometheus__Exemplar *message,
                      ProtobufCBuffer *buffer);
Prometheus__Exemplar *
       prometheus__exemplar__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__exemplar__free_unpacked
                     (Prometheus__Exemplar *message,
                      ProtobufCAllocator *allocator);
void prometheus__histogram__init
                     (Prometheus__Histogram *message);
size_t prometheus__histogram__get_packed_size
                     (const Prometheus__Histogram *message);
size_t prometheus__histogram__pack
                     (const Prometheus__Histogram *message,
                      uint8_t *out);
size_t prometheus__histogram__pack_to_buffer
                     (const Prometheus__Histogram *message,
                      ProtobufCBuffer *buffer);
Prometheus__Histogram *
       prometheus__histogram__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__histogram__free_unpacked
                     (Prometheus__Histogram *message,
                      ProtobufCAllocator *allocator);
void prometheus__bucket_span__init
                     (Prometheus__BucketSpan *message);
size_t prometheus__bucket_span__get_packed_size
                     (const Prometheus__BucketSpan *message);
size_t prometheus__bucket_span__pack
                     (const Prometheus__BucketSpan *message,
                      uint8_t *out);
size_t prometheus__bucket_span__pack_to_buffer
                     (const Prometheus__BucketSpan *message,
                      ProtobufCBuffer *buffer);
Prometheus__BucketSpan *
       prometheus__bucket_span__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__bucket_span__free_unpacked
                     (Prometheus__BucketSpan *message,
                      ProtobufCAllocator *allocator);
void prometheus__time_series__init
                     (Prometheus__TimeSeries *message);
size_t prometheus__time_series__get_packed_size
                     (const Prometheus__TimeSeries *message);
size_t prometheus__time_series__pack
                     (const Prometheus__TimeSeries *message,
                      uint8_t *out);
size_t prometheus__time_series__pack_to_buffer
                     (const Prometheus__TimeSeries *message,
                      ProtobufCBuffer *buffer);
Prometheus__TimeSeries *
       prometheus__time_series__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__time_series__free_unpacked
                     (Prometheus__TimeSeries *message,
                      ProtobufCAllocator *allocator);
void prometheus__label__init
                     (Prometheus__Label *message);
size_t prometheus__label__get_packed_size
                     (const Prometheus__Label *message);
size_t prometheus__label__pack
                     (const Prometheus__Label *message,
                      uint8_t *out);
size_t prometheus__label__pack_to_buffer
                     (const Prometheus__Label *message,
                      ProtobufCBuffer *buffer);
Prometheus__Label *
       prometheus__label__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__label__free_unpacked
                     (Prometheus__Label *message,
                      ProtobufCAllocator *allocator);
void prometheus__labels__init
                     (Prometheus__Labels *message);
size_t prometheus__labels__get_packed_size
                     (const Prometheus__Labels *message);
size_t prometheus__labels__pack
                     (const Prometheus__Labels *message,
                      uint8_t *out);
size_t prometheus__labels__pack_to_buffer
                     (const Prometheus__Labels *message,
                      ProtobufCBuffer *buffer);
Prometheus__Labels *
       prometheus__labels__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__labels__free_unpacked
                     (Prometheus__Labels *message,
                      ProtobufCAllocator *allocator);
void prometheus__label_matcher__init
                     (Prometheus__LabelMatcher *message);
size_t prometheus__label_matcher__get_packed_size
                     (const Prometheus__LabelMatcher *message);
size_t prometheus__label_matcher__pack
                     (const Prometheus__LabelMatcher *message,
                      uint8_t *out);
size_t prometheus__label_matcher__pack_to_buffer
                     (const Prometheus__LabelMatcher *message,
                      ProtobufCBuffer *buffer);
Prometheus__LabelMatcher *
       prometheus__label_matcher__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__label_matcher__free_unpacked
                     (Prometheus__LabelMatcher *message,
                      ProtobufCAllocator *allocator);
void prometheus__read_hints__init
                     (Prometheus__ReadHints *message);
size_t prometheus__read_hints__get_packed_size
                     (const Prometheus__ReadHints *message);
size_t prometheus__read_hints__pack
                     (const Prometheus__ReadHints *message,
                      uint8_t *out);
size_t prometheus__read_hints__pack_to_buffer
                     (const Prometheus__ReadHints *message,
                      ProtobufCBuffer *buffer);
Prometheus__ReadHints *
       prometheus__read_hints__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__read_hints__free_unpacked
                     (Prometheus__ReadHints *message,
                      ProtobufCAllocator *allocator);
void prometheus__chunk__init
                     (Prometheus__Chunk *message);
size_t prometheus__chunk__get_packed_size
                     (const Prometheus__Chunk *message);
size_t prometheus__chunk__pack
                     (const Prometheus__Chunk *message,
                      uint8_t *out);
size_t prometheus__chunk__pack_to_buffer
                     (const Prometheus__Chunk *message,
                      ProtobufCBuffer *buffer);
Prometheus__Chunk *
       prometheus__chunk__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__chunk__free_unpacked
                     (Prometheus__Chunk *message,
                      ProtobufCAllocator *allocator);
void prometheus__chunked_series__init
                     (Prometheus__ChunkedSeries *message);
size_t prometheus__chunked_series__get_packed_size
                     (const Prometheus__ChunkedSeries *message);
size_t prometheus__chunked_series__pack
                     (const Prometheus__ChunkedSeries *message,
                      uint8_t *out);
size_t prometheus__chunked_series__pack_to_buffer
                     (const Prometheus__ChunkedSeries *message,
                      ProtobufCBuffer *buffer);
Prometheus__ChunkedSeries *
       prometheus__chunked_series__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__chunked_series__free_unpacked
                     (Prometheus__ChunkedSeries *message,
                      ProtobufCAllocator *allocator);
typedef void (*Prometheus__MetricMetadata_Closure)
                 (const Prometheus__MetricMetadata *message,
                  void *closure_data);
typedef void (*Prometheus__Sample_Closure)
                 (const Prometheus__Sample *message,
                  void *closure_data);
typedef void (*Prometheus__Exemplar_Closure)
                 (const Prometheus__Exemplar *message,
                  void *closure_data);
typedef void (*Prometheus__Histogram_Closure)
                 (const Prometheus__Histogram *message,
                  void *closure_data);
typedef void (*Prometheus__BucketSpan_Closure)
                 (const Prometheus__BucketSpan *message,
                  void *closure_data);
typedef void (*Prometheus__TimeSeries_Closure)
                 (const Prometheus__TimeSeries *message,
                  void *closure_data);
typedef void (*Prometheus__Label_Closure)
                 (const Prometheus__Label *message,
                  void *closure_data);
typedef void (*Prometheus__Labels_Closure)
                 (const Prometheus__Labels *message,
                  void *closure_data);
typedef void (*Prometheus__LabelMatcher_Closure)
                 (const Prometheus__LabelMatcher *message,
                  void *closure_data);
typedef void (*Prometheus__ReadHints_Closure)
                 (const Prometheus__ReadHints *message,
                  void *closure_data);
typedef void (*Prometheus__Chunk_Closure)
                 (const Prometheus__Chunk *message,
                  void *closure_data);
typedef void (*Prometheus__ChunkedSeries_Closure)
                 (const Prometheus__ChunkedSeries *message,
                  void *closure_data);
extern const ProtobufCMessageDescriptor prometheus__metric_metadata__descriptor;
extern const ProtobufCEnumDescriptor prometheus__metric_metadata__metric_type__descriptor;
extern const ProtobufCMessageDescriptor prometheus__sample__descriptor;
extern const ProtobufCMessageDescriptor prometheus__exemplar__descriptor;
extern const ProtobufCMessageDescriptor prometheus__histogram__descriptor;
extern const ProtobufCEnumDescriptor prometheus__histogram__reset_hint__descriptor;
extern const ProtobufCMessageDescriptor prometheus__bucket_span__descriptor;
extern const ProtobufCMessageDescriptor prometheus__time_series__descriptor;
extern const ProtobufCMessageDescriptor prometheus__label__descriptor;
extern const ProtobufCMessageDescriptor prometheus__labels__descriptor;
extern const ProtobufCMessageDescriptor prometheus__label_matcher__descriptor;
extern const ProtobufCEnumDescriptor prometheus__label_matcher__type__descriptor;
extern const ProtobufCMessageDescriptor prometheus__read_hints__descriptor;
extern const ProtobufCMessageDescriptor prometheus__chunk__descriptor;
extern const ProtobufCEnumDescriptor prometheus__chunk__encoding__descriptor;
extern const ProtobufCMessageDescriptor prometheus__chunked_series__descriptor;
typedef struct _Prometheus__WriteRequest Prometheus__WriteRequest;
typedef struct _Prometheus__ReadRequest Prometheus__ReadRequest;
typedef struct _Prometheus__ReadResponse Prometheus__ReadResponse;
typedef struct _Prometheus__Query Prometheus__Query;
typedef struct _Prometheus__QueryResult Prometheus__QueryResult;
typedef struct _Prometheus__ChunkedReadResponse Prometheus__ChunkedReadResponse;
typedef enum _Prometheus__ReadRequest__ResponseType {
  PROMETHEUS__READ_REQUEST__RESPONSE_TYPE__SAMPLES = 0,
  PROMETHEUS__READ_REQUEST__RESPONSE_TYPE__STREAMED_XOR_CHUNKS = 1
    , _PROMETHEUS__READ_REQUEST__RESPONSE_TYPE_IS_INT_SIZE = 2147483647
} Prometheus__ReadRequest__ResponseType;
struct _Prometheus__WriteRequest
{
  ProtobufCMessage base;
  size_t n_timeseries;
  Prometheus__TimeSeries **timeseries;
  size_t n_metadata;
  Prometheus__MetricMetadata **metadata;
};
struct _Prometheus__ReadRequest
{
  ProtobufCMessage base;
  size_t n_queries;
  Prometheus__Query **queries;
  size_t n_accepted_response_types;
  Prometheus__ReadRequest__ResponseType *accepted_response_types;
};
struct _Prometheus__ReadResponse
{
  ProtobufCMessage base;
  size_t n_results;
  Prometheus__QueryResult **results;
};
struct _Prometheus__Query
{
  ProtobufCMessage base;
  int64_t start_timestamp_ms;
  int64_t end_timestamp_ms;
  size_t n_matchers;
  Prometheus__LabelMatcher **matchers;
  Prometheus__ReadHints *hints;
};
struct _Prometheus__QueryResult
{
  ProtobufCMessage base;
  size_t n_timeseries;
  Prometheus__TimeSeries **timeseries;
};
struct _Prometheus__ChunkedReadResponse
{
  ProtobufCMessage base;
  size_t n_chunked_series;
  Prometheus__ChunkedSeries **chunked_series;
  int64_t query_index;
};
void prometheus__write_request__init
                     (Prometheus__WriteRequest *message);
size_t prometheus__write_request__get_packed_size
                     (const Prometheus__WriteRequest *message);
size_t prometheus__write_request__pack
                     (const Prometheus__WriteRequest *message,
                      uint8_t *out);
size_t prometheus__write_request__pack_to_buffer
                     (const Prometheus__WriteRequest *message,
                      ProtobufCBuffer *buffer);
Prometheus__WriteRequest *
       prometheus__write_request__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__write_request__free_unpacked
                     (Prometheus__WriteRequest *message,
                      ProtobufCAllocator *allocator);
void prometheus__read_request__init
                     (Prometheus__ReadRequest *message);
size_t prometheus__read_request__get_packed_size
                     (const Prometheus__ReadRequest *message);
size_t prometheus__read_request__pack
                     (const Prometheus__ReadRequest *message,
                      uint8_t *out);
size_t prometheus__read_request__pack_to_buffer
                     (const Prometheus__ReadRequest *message,
                      ProtobufCBuffer *buffer);
Prometheus__ReadRequest *
       prometheus__read_request__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__read_request__free_unpacked
                     (Prometheus__ReadRequest *message,
                      ProtobufCAllocator *allocator);
void prometheus__read_response__init
                     (Prometheus__ReadResponse *message);
size_t prometheus__read_response__get_packed_size
                     (const Prometheus__ReadResponse *message);
size_t prometheus__read_response__pack
                     (const Prometheus__ReadResponse *message,
                      uint8_t *out);
size_t prometheus__read_response__pack_to_buffer
                     (const Prometheus__ReadResponse *message,
                      ProtobufCBuffer *buffer);
Prometheus__ReadResponse *
       prometheus__read_response__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__read_response__free_unpacked
                     (Prometheus__ReadResponse *message,
                      ProtobufCAllocator *allocator);
void prometheus__query__init
                     (Prometheus__Query *message);
size_t prometheus__query__get_packed_size
                     (const Prometheus__Query *message);
size_t prometheus__query__pack
                     (const Prometheus__Query *message,
                      uint8_t *out);
size_t prometheus__query__pack_to_buffer
                     (const Prometheus__Query *message,
                      ProtobufCBuffer *buffer);
Prometheus__Query *
       prometheus__query__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__query__free_unpacked
                     (Prometheus__Query *message,
                      ProtobufCAllocator *allocator);
void prometheus__query_result__init
                     (Prometheus__QueryResult *message);
size_t prometheus__query_result__get_packed_size
                     (const Prometheus__QueryResult *message);
size_t prometheus__query_result__pack
                     (const Prometheus__QueryResult *message,
                      uint8_t *out);
size_t prometheus__query_result__pack_to_buffer
                     (const Prometheus__QueryResult *message,
                      ProtobufCBuffer *buffer);
Prometheus__QueryResult *
       prometheus__query_result__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__query_result__free_unpacked
                     (Prometheus__QueryResult *message,
                      ProtobufCAllocator *allocator);
void prometheus__chunked_read_response__init
                     (Prometheus__ChunkedReadResponse *message);
size_t prometheus__chunked_read_response__get_packed_size
                     (const Prometheus__ChunkedReadResponse *message);
size_t prometheus__chunked_read_response__pack
                     (const Prometheus__ChunkedReadResponse *message,
                      uint8_t *out);
size_t prometheus__chunked_read_response__pack_to_buffer
                     (const Prometheus__ChunkedReadResponse *message,
                      ProtobufCBuffer *buffer);
Prometheus__ChunkedReadResponse *
       prometheus__chunked_read_response__unpack
                     (ProtobufCAllocator *allocator,
                      size_t len,
                      const uint8_t *data);
void prometheus__chunked_read_response__free_unpacked
                     (Prometheus__ChunkedReadResponse *message,
                      ProtobufCAllocator *allocator);
typedef void (*Prometheus__WriteRequest_Closure)
                 (const Prometheus__WriteRequest *message,
                  void *closure_data);
typedef void (*Prometheus__ReadRequest_Closure)
                 (const Prometheus__ReadRequest *message,
                  void *closure_data);
typedef void (*Prometheus__ReadResponse_Closure)
                 (const Prometheus__ReadResponse *message,
                  void *closure_data);
typedef void (*Prometheus__Query_Closure)
                 (const Prometheus__Query *message,
                  void *closure_data);
typedef void (*Prometheus__QueryResult_Closure)
                 (const Prometheus__QueryResult *message,
                  void *closure_data);
typedef void (*Prometheus__ChunkedReadResponse_Closure)
                 (const Prometheus__ChunkedReadResponse *message,
                  void *closure_data);
extern const ProtobufCMessageDescriptor prometheus__write_request__descriptor;
extern const ProtobufCMessageDescriptor prometheus__read_request__descriptor;
extern const ProtobufCEnumDescriptor prometheus__read_request__response_type__descriptor;
extern const ProtobufCMessageDescriptor prometheus__read_response__descriptor;
extern const ProtobufCMessageDescriptor prometheus__query__descriptor;
extern const ProtobufCMessageDescriptor prometheus__query_result__descriptor;
extern const ProtobufCMessageDescriptor prometheus__chunked_read_response__descriptor;
struct cmt_prometheus_metric_metadata {
    Prometheus__MetricMetadata data;
    struct cfl_list _head;
};
struct cmt_prometheus_time_series {
    uint64_t label_set_hash;
    size_t entries_set;
    Prometheus__TimeSeries data;
    struct cfl_list _head;
};
struct cmt_prometheus_remote_write_context
{
    struct cfl_list time_series_entries;
    struct cfl_list metadata_entries;
    uint64_t sequence_number;
    Prometheus__WriteRequest write_request;
    struct cmt *cmt;
};
cfl_sds_t cmt_encode_prometheus_remote_write_create(struct cmt *cmt);
void cmt_encode_prometheus_remote_write_destroy(cfl_sds_t text);
int cmt_encode_msgpack_create(struct cmt *cmt, char **out_buf, size_t *out_size);
void cmt_encode_msgpack_destroy(char *out_buf);
struct cmt_splunk_hec_context {
  const char *host;
  const char *index;
  const char *source;
  const char *source_type;
  struct cmt *cmt;
};
cfl_sds_t cmt_encode_splunk_hec_create(struct cmt *cmt, const char *host,
                                       const char *index, const char *source, const char *source_type);
void cmt_encode_splunk_hec_destroy(cfl_sds_t text);
int cmt_encode_cloudwatch_emf_create(struct cmt *cmt,
                                     char **out_buf, size_t *out_size,
                                     int wrap_array);
void cmt_encode_cloudwatch_emf_destroy(char *out_buf);
struct cmt_statsd_message {
    char *bucket;
    int bucket_len;
    char *value;
    char *labels;
    int value_len;
    int type;
    double sample_rate;
};
int cmt_decode_statsd_create(struct cmt **out_cmt, char *in_buf, size_t in_size, int flags);
void cmt_decode_statsd_destroy(struct cmt *cmt);
int cmt_filter(struct cmt *dst, struct cmt *src,
               const char *fqname, const char *label_key,
               void *compare_ctx, int (*compare)(void *compare_ctx, const char *str, size_t slen),
               int flags);
int cmt_filter_with_label_pair(struct cmt *dst, struct cmt *src,
                               const char *label_key,
                               const char *label_value);
struct flb_metric {
    int id;
    flb_sds_t title;
    size_t val;
    struct mk_list _head;
};
struct flb_metrics {
    int count;
    flb_sds_t title;
    struct mk_list list;
};
struct flb_metrics *flb_metrics_create(const char *title);
int flb_metrics_title(const char *title, struct flb_metrics *metrics);
struct flb_metric *flb_metrics_get_id(int id, struct flb_metrics *metrics);
int flb_metrics_add(int id, const char *title, struct flb_metrics *metrics);
int flb_metrics_sum(int id, size_t val, struct flb_metrics *metrics);
int flb_metrics_print(struct flb_metrics *metrics);
int flb_metrics_dump_values(char **out_buf, size_t *out_size,
                            struct flb_metrics *me);
int flb_metrics_destroy(struct flb_metrics *metrics);
int flb_metrics_fluentbit_add(struct flb_config *ctx, struct cmt *cmt);
_Bool flb_metrics_is_empty(struct cmt *cmt);
struct flb_slist_entry {
    flb_sds_t str;
    struct mk_list _head;
};
int flb_slist_create(struct mk_list *list);
int flb_slist_add(struct mk_list *head, const char *str);
int flb_slist_add_n(struct mk_list *head, const char *str, int len);
int flb_slist_add_sds(struct mk_list *head, flb_sds_t str);
void flb_slist_destroy(struct mk_list *list);
int flb_slist_split_string(struct mk_list *list, const char *str,
                           int separator, int max_split);
int flb_slist_split_tokens(struct mk_list *list, const char *str, int max_split);
void flb_slist_dump(struct mk_list *list);
struct flb_slist_entry *flb_slist_entry_get(struct mk_list *list, int n);
struct flb_config;
struct flb_config_map_val {
    union {
        int i_num;
        int boolean;
        double d_num;
        size_t s_num;
        flb_sds_t str;
        struct mk_list *list;
        struct cfl_variant *variant;
    } val;
    flb_sds_t raw;
    struct mk_list *mult;
    struct mk_list _head;
};
struct flb_config_map {
    int type;
    flb_sds_t name;
    flb_sds_t def_value;
    int flags;
    int set_property;
    uintptr_t offset;
    flb_sds_t desc;
    struct flb_config_map_val value;
    struct mk_list _head;
};
static inline int flb_config_map_mult_type(int type)
{
    if (type >= 30 && type <= 34) {
        return 30;
    }
    if (type >= 40 && type <= 44) {
        return 40;
    }
    return -1;
}
int flb_config_map_properties_check(char *context_name,
                                    struct mk_list *in_properties,
                                    struct mk_list *map);
struct mk_list *flb_config_map_create(struct flb_config *config,
                                      struct flb_config_map *map);
void flb_config_map_destroy(struct mk_list *list);
int flb_config_map_expected_values(int type);
int flb_config_map_set(struct flb_config *config, struct mk_list *properties, struct mk_list *map, void *context);
struct flb_config_map *flb_config_map_find(struct mk_list *map, const char *name);
const char *flb_config_map_get_raw(struct flb_config_map *map);
flb_sds_t flb_config_map_translate_dynamic(struct flb_config *config, struct flb_config_map *map);
static inline int flb_config_map_has_dynamic_env(struct flb_config_map *map)
{
    return (map->flags & 2) != 0;
}
static inline int flb_config_map_property_has_dynamic_env(struct flb_config_map *map,
                                                          const char *name)
{
    while (map && map->name) {
        if (strcasecmp(map->name, name) == 0) {
            return flb_config_map_has_dynamic_env(map);
        }
        map++;
    }
    return 0;
}
typedef uint64_t flb_route_mask_element;
struct flb_input_instance;
struct flb_config;
struct flb_router;
int flb_routes_mask_set_by_tag(flb_route_mask_element *routes_mask,
                               const char *tag,
                               int tag_len,
                               struct flb_input_instance *in);
int flb_routes_mask_get_bit(flb_route_mask_element *routes_mask, int value,
                            struct flb_router *router);
void flb_routes_mask_set_bit(flb_route_mask_element *routes_mask, int value,
                             struct flb_router *router);
void flb_routes_mask_clear_bit(flb_route_mask_element *routes_mask, int value,
                               struct flb_router *router);
int flb_routes_mask_is_empty(flb_route_mask_element *routes_mask,
                             struct flb_router *router);
int flb_routes_empty_mask_create(struct flb_router *router);
void flb_routes_empty_mask_destroy(struct flb_router *router);
int flb_routes_mask_set_size(size_t mask_size, struct flb_router *router);
size_t flb_routes_mask_get_size(struct flb_router *router);
size_t flb_routes_mask_get_slots(struct flb_router *router);
struct cio_chunk;
 typedef unsigned int _msgpack_atomic_counter_t;
typedef struct msgpack_zone_finalizer {
    void (*func)(void* data);
    void* data;
} msgpack_zone_finalizer;
typedef struct msgpack_zone_finalizer_array {
    msgpack_zone_finalizer* tail;
    msgpack_zone_finalizer* end;
    msgpack_zone_finalizer* array;
} msgpack_zone_finalizer_array;
struct msgpack_zone_chunk;
typedef struct msgpack_zone_chunk msgpack_zone_chunk;
typedef struct msgpack_zone_chunk_list {
    size_t free;
    char* ptr;
    msgpack_zone_chunk* head;
} msgpack_zone_chunk_list;
typedef struct msgpack_zone {
    msgpack_zone_chunk_list chunk_list;
    msgpack_zone_finalizer_array finalizer_array;
    size_t chunk_size;
} msgpack_zone;
_Bool msgpack_zone_init(msgpack_zone* zone, size_t chunk_size);
void msgpack_zone_destroy(msgpack_zone* zone);
msgpack_zone* msgpack_zone_new(size_t chunk_size);
void msgpack_zone_free(msgpack_zone* zone);
static inline void* msgpack_zone_malloc(msgpack_zone* zone, size_t size);
static inline void* msgpack_zone_malloc_no_align(msgpack_zone* zone, size_t size);
static inline _Bool msgpack_zone_push_finalizer(msgpack_zone* zone,
        void (*func)(void* data), void* data);
static inline void msgpack_zone_swap(msgpack_zone* a, msgpack_zone* b);
_Bool msgpack_zone_is_empty(msgpack_zone* zone);
void msgpack_zone_clear(msgpack_zone* zone);
void* msgpack_zone_malloc_expand(msgpack_zone* zone, size_t size);
static inline void* msgpack_zone_malloc_no_align(msgpack_zone* zone, size_t size)
{
    char* ptr;
    msgpack_zone_chunk_list* cl = &zone->chunk_list;
    if(zone->chunk_list.free < size) {
        return msgpack_zone_malloc_expand(zone, size);
    }
    ptr = cl->ptr;
    cl->free -= size;
    cl->ptr += size;
    return ptr;
}
static inline void* msgpack_zone_malloc(msgpack_zone* zone, size_t size)
{
    char* aligned =
        (char*)(
            (size_t)(
                zone->chunk_list.ptr + (sizeof(void*) - 1)
            ) / sizeof(void*) * sizeof(void*)
        );
    size_t adjusted_size = size + (size_t)(aligned - zone->chunk_list.ptr);
    if(zone->chunk_list.free >= adjusted_size) {
        zone->chunk_list.free -= adjusted_size;
        zone->chunk_list.ptr += adjusted_size;
        return aligned;
    }
    {
        void* ptr = msgpack_zone_malloc_expand(zone, size + (sizeof(void*) - 1));
        if (ptr) {
            return (char*)((size_t)(ptr) / sizeof(void*) * sizeof(void*));
        }
    }
    return ((void*)0);
}
_Bool msgpack_zone_push_finalizer_expand(msgpack_zone* zone,
        void (*func)(void* data), void* data);
static inline _Bool msgpack_zone_push_finalizer(msgpack_zone* zone,
        void (*func)(void* data), void* data)
{
    msgpack_zone_finalizer_array* const fa = &zone->finalizer_array;
    msgpack_zone_finalizer* fin = fa->tail;
    if(fin == fa->end) {
        return msgpack_zone_push_finalizer_expand(zone, func, data);
    }
    fin->func = func;
    fin->data = data;
    ++fa->tail;
    return 1;
}
static inline void msgpack_zone_swap(msgpack_zone* a, msgpack_zone* b)
{
    msgpack_zone tmp = *a;
    *a = *b;
    *b = tmp;
}
typedef enum {
    MSGPACK_OBJECT_NIL = 0x00,
    MSGPACK_OBJECT_BOOLEAN = 0x01,
    MSGPACK_OBJECT_POSITIVE_INTEGER = 0x02,
    MSGPACK_OBJECT_NEGATIVE_INTEGER = 0x03,
    MSGPACK_OBJECT_FLOAT32 = 0x0a,
    MSGPACK_OBJECT_FLOAT64 = 0x04,
    MSGPACK_OBJECT_FLOAT = 0x04,
    MSGPACK_OBJECT_STR = 0x05,
    MSGPACK_OBJECT_ARRAY = 0x06,
    MSGPACK_OBJECT_MAP = 0x07,
    MSGPACK_OBJECT_BIN = 0x08,
    MSGPACK_OBJECT_EXT = 0x09
} msgpack_object_type;
struct msgpack_object;
struct msgpack_object_kv;
typedef struct {
    uint32_t size;
    struct msgpack_object* ptr;
} msgpack_object_array;
typedef struct {
    uint32_t size;
    struct msgpack_object_kv* ptr;
} msgpack_object_map;
typedef struct {
    uint32_t size;
    const char* ptr;
} msgpack_object_str;
typedef struct {
    uint32_t size;
    const char* ptr;
} msgpack_object_bin;
typedef struct {
    int8_t type;
    uint32_t size;
    const char* ptr;
} msgpack_object_ext;
typedef union {
    _Bool boolean;
    uint64_t u64;
    int64_t i64;
    double f64;
    msgpack_object_array array;
    msgpack_object_map map;
    msgpack_object_str str;
    msgpack_object_bin bin;
    msgpack_object_ext ext;
} msgpack_object_union;
typedef struct msgpack_object {
    msgpack_object_type type;
    msgpack_object_union via;
} msgpack_object;
typedef struct msgpack_object_kv {
    msgpack_object key;
    msgpack_object val;
} msgpack_object_kv;
void msgpack_object_print(FILE* out, msgpack_object o);
int msgpack_object_print_buffer(char *buffer, size_t buffer_size, msgpack_object o);
_Bool msgpack_object_equal(const msgpack_object x, const msgpack_object y);


typedef struct msgpack_timestamp {
    int64_t tv_sec;
    uint32_t tv_nsec;
} msgpack_timestamp;
static inline _Bool msgpack_object_to_timestamp(const msgpack_object* obj, msgpack_timestamp* ts) {
    if (obj->type != MSGPACK_OBJECT_EXT) return 0;
    if (obj->via.ext.type != -1) return 0;
    switch (obj->via.ext.size) {
    case 4:
        ts->tv_nsec = 0;
        {
            uint32_t v;
            do { memcpy((uint32_t*)(&v), (obj->via.ext.ptr), sizeof(uint32_t)); *(&v) = (uint32_t)ntohl((uint32_t)*(&v)); } while (0);;
            ts->tv_sec = v;
        }
        return 1;
    case 8: {
        uint64_t value;
        do { memcpy((uint64_t*)(&value), (obj->via.ext.ptr), sizeof(uint64_t)); *(&value) = (uint64_t)__bswap_64 (*(&value)); } while (0);;
        ts->tv_nsec = (uint32_t)(value >> 34);
        ts->tv_sec = value & 0x00000003ffffffffLL;
        return 1;
    }
    case 12:
        do { memcpy((uint32_t*)(&ts->tv_nsec), (obj->via.ext.ptr), sizeof(uint32_t)); *(&ts->tv_nsec) = (uint32_t)ntohl((uint32_t)*(&ts->tv_nsec)); } while (0);;
        do { memcpy((int64_t*)(&ts->tv_sec), (obj->via.ext.ptr + 4), sizeof(int64_t)); *(&ts->tv_sec) = (int64_t)__bswap_64 (*(&ts->tv_sec)); } while (0);;
        return 1;
    default:
        return 0;
    }
}
typedef int (*msgpack_packer_write)(void* data, const char* buf, size_t len);
typedef struct msgpack_packer {
    void* data;
    msgpack_packer_write callback;
} msgpack_packer;
static void msgpack_packer_init(msgpack_packer* pk, void* data, msgpack_packer_write callback);
static msgpack_packer* msgpack_packer_new(void* data, msgpack_packer_write callback);
static void msgpack_packer_free(msgpack_packer* pk);
static int msgpack_pack_char(msgpack_packer* pk, char d);
static int msgpack_pack_signed_char(msgpack_packer* pk, signed char d);
static int msgpack_pack_short(msgpack_packer* pk, short d);
static int msgpack_pack_int(msgpack_packer* pk, int d);
static int msgpack_pack_long(msgpack_packer* pk, long d);
static int msgpack_pack_long_long(msgpack_packer* pk, long long d);
static int msgpack_pack_unsigned_char(msgpack_packer* pk, unsigned char d);
static int msgpack_pack_unsigned_short(msgpack_packer* pk, unsigned short d);
static int msgpack_pack_unsigned_int(msgpack_packer* pk, unsigned int d);
static int msgpack_pack_unsigned_long(msgpack_packer* pk, unsigned long d);
static int msgpack_pack_unsigned_long_long(msgpack_packer* pk, unsigned long long d);
static int msgpack_pack_uint8(msgpack_packer* pk, uint8_t d);
static int msgpack_pack_uint16(msgpack_packer* pk, uint16_t d);
static int msgpack_pack_uint32(msgpack_packer* pk, uint32_t d);
static int msgpack_pack_uint64(msgpack_packer* pk, uint64_t d);
static int msgpack_pack_int8(msgpack_packer* pk, int8_t d);
static int msgpack_pack_int16(msgpack_packer* pk, int16_t d);
static int msgpack_pack_int32(msgpack_packer* pk, int32_t d);
static int msgpack_pack_int64(msgpack_packer* pk, int64_t d);
static int msgpack_pack_fix_uint8(msgpack_packer* pk, uint8_t d);
static int msgpack_pack_fix_uint16(msgpack_packer* pk, uint16_t d);
static int msgpack_pack_fix_uint32(msgpack_packer* pk, uint32_t d);
static int msgpack_pack_fix_uint64(msgpack_packer* pk, uint64_t d);
static int msgpack_pack_fix_int8(msgpack_packer* pk, int8_t d);
static int msgpack_pack_fix_int16(msgpack_packer* pk, int16_t d);
static int msgpack_pack_fix_int32(msgpack_packer* pk, int32_t d);
static int msgpack_pack_fix_int64(msgpack_packer* pk, int64_t d);
static int msgpack_pack_float(msgpack_packer* pk, float d);
static int msgpack_pack_double(msgpack_packer* pk, double d);
static int msgpack_pack_nil(msgpack_packer* pk);
static int msgpack_pack_true(msgpack_packer* pk);
static int msgpack_pack_false(msgpack_packer* pk);
static int msgpack_pack_array(msgpack_packer* pk, size_t n);
static int msgpack_pack_map(msgpack_packer* pk, size_t n);
static int msgpack_pack_str(msgpack_packer* pk, size_t l);
static int msgpack_pack_str_body(msgpack_packer* pk, const void* b, size_t l);
static int msgpack_pack_str_with_body(msgpack_packer* pk, const void* b, size_t l);
static int msgpack_pack_v4raw(msgpack_packer* pk, size_t l);
static int msgpack_pack_v4raw_body(msgpack_packer* pk, const void* b, size_t l);
static int msgpack_pack_bin(msgpack_packer* pk, size_t l);
static int msgpack_pack_bin_body(msgpack_packer* pk, const void* b, size_t l);
static int msgpack_pack_bin_with_body(msgpack_packer* pk, const void* b, size_t l);
static int msgpack_pack_ext(msgpack_packer* pk, size_t l, int8_t type);
static int msgpack_pack_ext_body(msgpack_packer* pk, const void* b, size_t l);
static int msgpack_pack_ext_with_body(msgpack_packer* pk, const void* b, size_t l, int8_t type);
static int msgpack_pack_timestamp(msgpack_packer* pk, const msgpack_timestamp* d);
int msgpack_pack_object(msgpack_packer* pk, msgpack_object d);
inline int msgpack_pack_fix_uint8(msgpack_packer* x, uint8_t d)
{
    unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]};
    return (*(x)->callback)((x)->data, (const char*)buf, 2);
}
inline int msgpack_pack_fix_uint16(msgpack_packer* x, uint16_t d)
{
    unsigned char buf[3];
    buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)d); memcpy(&buf[1], &val, 2); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 3);
}
inline int msgpack_pack_fix_uint32(msgpack_packer* x, uint32_t d)
{
    unsigned char buf[5];
    buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)d); memcpy(&buf[1], &val, 4); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 5);
}
inline int msgpack_pack_fix_uint64(msgpack_packer* x, uint64_t d)
{
    unsigned char buf[9];
    buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 9);
}
inline int msgpack_pack_fix_int8(msgpack_packer* x, int8_t d)
{
    unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]};
    return (*(x)->callback)((x)->data, (const char*)buf, 2);
}
inline int msgpack_pack_fix_int16(msgpack_packer* x, int16_t d)
{
    unsigned char buf[3];
    buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)d); memcpy(&buf[1], &val, 2); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 3);
}
inline int msgpack_pack_fix_int32(msgpack_packer* x, int32_t d)
{
    unsigned char buf[5];
    buf[0] = 0xd2; do { uint32_t val = ntohl((uint32_t)d); memcpy(&buf[1], &val, 4); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 5);
}
inline int msgpack_pack_fix_int64(msgpack_packer* x, int64_t d)
{
    unsigned char buf[9];
    buf[0] = 0xd3; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 9);
}
inline int msgpack_pack_uint8(msgpack_packer* x, uint8_t d)
{
    do { if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } while(0);
}
inline int msgpack_pack_uint16(msgpack_packer* x, uint16_t d)
{
    do { if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } while(0);
}
inline int msgpack_pack_uint32(msgpack_packer* x, uint32_t d)
{
    do { if(d < (1<<8)) { if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else { if(d < (1<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } } while(0);
}
inline int msgpack_pack_uint64(msgpack_packer* x, uint64_t d)
{
    do { if(d < (1ULL<<8)) { if(d < (1ULL<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else { if(d < (1ULL<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else if(d < (1ULL<<32)) { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else { unsigned char buf[9]; buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } } } while(0);
}
inline int msgpack_pack_int8(msgpack_packer* x, int8_t d)
{
    do { if(d < -(1<<5)) { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } } while(0);
}
inline int msgpack_pack_int16(msgpack_packer* x, int16_t d)
{
    do { if(d < -(1<<5)) { if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } } while(0);
}
inline int msgpack_pack_int32(msgpack_packer* x, int32_t d)
{
    do { if(d < -(1<<5)) { if(d < -(1<<15)) { unsigned char buf[5]; buf[0] = 0xd2; do { uint32_t val = ntohl((uint32_t)(int32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else if(d < (1<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } } while(0);
}
inline int msgpack_pack_int64(msgpack_packer* x, int64_t d)
{
    do { if(d < -(1LL<<5)) { if(d < -(1LL<<15)) { if(d < -(1LL<<31)) { unsigned char buf[9]; buf[0] = 0xd3; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } else { unsigned char buf[5]; buf[0] = 0xd2; do { uint32_t val = ntohl((uint32_t)(int32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } else { if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1LL<<16)) { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } else { if(d < (1LL<<32)) { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else { unsigned char buf[9]; buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } } } } while(0);
}
inline int msgpack_pack_char(msgpack_packer* x, char d)
{
        do { if(d < -(1<<5)) { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } } while(0);
}
inline int msgpack_pack_signed_char(msgpack_packer* x, signed char d)
{
    do { if(d < -(1<<5)) { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } } while(0);
}
inline int msgpack_pack_unsigned_char(msgpack_packer* x, unsigned char d)
{
    do { if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } while(0);
}
inline int msgpack_pack_short(msgpack_packer* x, short d)
{
    do { if(d < -(1<<5)) { if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } } while(0);
}
inline int msgpack_pack_int(msgpack_packer* x, int d)
{
    do { if(d < -(1<<5)) { if(d < -(1<<15)) { unsigned char buf[5]; buf[0] = 0xd2; do { uint32_t val = ntohl((uint32_t)(int32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else if(d < (1<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } } while(0);
}
inline int msgpack_pack_long(msgpack_packer* x, long d)
{
    do { if(d < -(1LL<<5)) { if(d < -(1LL<<15)) { if(d < -(1LL<<31)) { unsigned char buf[9]; buf[0] = 0xd3; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } else { unsigned char buf[5]; buf[0] = 0xd2; do { uint32_t val = ntohl((uint32_t)(int32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } else { if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1LL<<16)) { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } else { if(d < (1LL<<32)) { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else { unsigned char buf[9]; buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } } } } while(0);
}
inline int msgpack_pack_long_long(msgpack_packer* x, long long d)
{
    do { if(d < -(1LL<<5)) { if(d < -(1LL<<15)) { if(d < -(1LL<<31)) { unsigned char buf[9]; buf[0] = 0xd3; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } else { unsigned char buf[5]; buf[0] = 0xd2; do { uint32_t val = ntohl((uint32_t)(int32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } else { if(d < -(1<<7)) { unsigned char buf[3]; buf[0] = 0xd1; do { uint16_t val = ntohs((uint16_t)(int16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[2] = {0xd0, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } } else if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { if(d < (1LL<<16)) { if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } else { if(d < (1LL<<32)) { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else { unsigned char buf[9]; buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } } } } while(0);
}
inline int msgpack_pack_unsigned_short(msgpack_packer* x, unsigned short d)
{
    do { if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else if(d < (1<<8)) { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } else { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } } while(0);
}
inline int msgpack_pack_unsigned_int(msgpack_packer* x, unsigned int d)
{
    do { if(d < (1<<8)) { if(d < (1<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else { if(d < (1<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } } } while(0);
}
inline int msgpack_pack_unsigned_long(msgpack_packer* x, unsigned long d)
{
    do { if(d < (1ULL<<8)) { if(d < (1ULL<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else { if(d < (1ULL<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else if(d < (1ULL<<32)) { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else { unsigned char buf[9]; buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } } } while(0);
}
inline int msgpack_pack_unsigned_long_long(msgpack_packer* x, unsigned long long d)
{
    do { if(d < (1ULL<<8)) { if(d < (1ULL<<7)) { return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1); } else { unsigned char buf[2] = {0xcc, ((uint8_t*)&d)[0]}; return (*(x)->callback)((x)->data, (const char*)buf, 2); } } else { if(d < (1ULL<<16)) { unsigned char buf[3]; buf[0] = 0xcd; do { uint16_t val = ntohs((uint16_t)(uint16_t)d); memcpy(&buf[1], &val, 2); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 3); } else if(d < (1ULL<<32)) { unsigned char buf[5]; buf[0] = 0xce; do { uint32_t val = ntohl((uint32_t)(uint32_t)d); memcpy(&buf[1], &val, 4); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 5); } else { unsigned char buf[9]; buf[0] = 0xcf; do { uint64_t val = __bswap_64 (d); memcpy(&buf[1], &val, 8); } while(0); return (*(x)->callback)((x)->data, (const char*)buf, 9); } } } while(0);
}
inline int msgpack_pack_float(msgpack_packer* x, float d)
{
    unsigned char buf[5];
    union { float f; uint32_t i; } mem;
    mem.f = d;
    buf[0] = 0xca; do { uint32_t val = ntohl((uint32_t)mem.i); memcpy(&buf[1], &val, 4); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 5);
}
inline int msgpack_pack_double(msgpack_packer* x, double d)
{
    unsigned char buf[9];
    union { double f; uint64_t i; } mem;
    mem.f = d;
    buf[0] = 0xcb;
    do { uint64_t val = __bswap_64 (mem.i); memcpy(&buf[1], &val, 8); } while(0);
    return (*(x)->callback)((x)->data, (const char*)buf, 9);
}
inline int msgpack_pack_nil(msgpack_packer* x)
{
    static const unsigned char d = 0xc0;
    return (*(x)->callback)((x)->data, (const char*)&d, 1);
}
inline int msgpack_pack_true(msgpack_packer* x)
{
    static const unsigned char d = 0xc3;
    return (*(x)->callback)((x)->data, (const char*)&d, 1);
}
inline int msgpack_pack_false(msgpack_packer* x)
{
    static const unsigned char d = 0xc2;
    return (*(x)->callback)((x)->data, (const char*)&d, 1);
}
inline int msgpack_pack_array(msgpack_packer* x, size_t n)
{
    if(n < 16) {
        unsigned char d = 0x90 | (uint8_t)n;
        return (*(x)->callback)((x)->data, (const char*)&d, 1);
    } else if(n < 65536) {
        unsigned char buf[3];
        buf[0] = 0xdc; do { uint16_t val = ntohs((uint16_t)(uint16_t)n); memcpy(&buf[1], &val, 2); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 3);
    } else {
        unsigned char buf[5];
        buf[0] = 0xdd; do { uint32_t val = ntohl((uint32_t)(uint32_t)n); memcpy(&buf[1], &val, 4); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 5);
    }
}
inline int msgpack_pack_map(msgpack_packer* x, size_t n)
{
    if(n < 16) {
        unsigned char d = 0x80 | (uint8_t)n;
        return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1);
    } else if(n < 65536) {
        unsigned char buf[3];
        buf[0] = 0xde; do { uint16_t val = ntohs((uint16_t)(uint16_t)n); memcpy(&buf[1], &val, 2); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 3);
    } else {
        unsigned char buf[5];
        buf[0] = 0xdf; do { uint32_t val = ntohl((uint32_t)(uint32_t)n); memcpy(&buf[1], &val, 4); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 5);
    }
}
inline int msgpack_pack_str(msgpack_packer* x, size_t l)
{
    if(l < 32) {
        unsigned char d = 0xa0 | (uint8_t)l;
        return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1);
    } else if(l < 256) {
        unsigned char buf[2];
        buf[0] = 0xd9; buf[1] = (uint8_t)l;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } else if(l < 65536) {
        unsigned char buf[3];
        buf[0] = 0xda; do { uint16_t val = ntohs((uint16_t)(uint16_t)l); memcpy(&buf[1], &val, 2); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 3);
    } else {
        unsigned char buf[5];
        buf[0] = 0xdb; do { uint32_t val = ntohl((uint32_t)(uint32_t)l); memcpy(&buf[1], &val, 4); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 5);
    }
}
inline int msgpack_pack_str_body(msgpack_packer* x, const void* b, size_t l)
{
    return (*(x)->callback)((x)->data, (const char*)(const unsigned char*)b, l);
}
inline int msgpack_pack_v4raw(msgpack_packer* x, size_t l)
{
    if(l < 32) {
        unsigned char d = 0xa0 | (uint8_t)l;
        return (*(x)->callback)((x)->data, (const char*)&((uint8_t*)&d)[0], 1);
    } else if(l < 65536) {
        unsigned char buf[3];
        buf[0] = 0xda; do { uint16_t val = ntohs((uint16_t)(uint16_t)l); memcpy(&buf[1], &val, 2); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 3);
    } else {
        unsigned char buf[5];
        buf[0] = 0xdb; do { uint32_t val = ntohl((uint32_t)(uint32_t)l); memcpy(&buf[1], &val, 4); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 5);
    }
}
inline int msgpack_pack_v4raw_body(msgpack_packer* x, const void* b, size_t l)
{
    return (*(x)->callback)((x)->data, (const char*)(const unsigned char*)b, l);
}
inline int msgpack_pack_bin(msgpack_packer* x, size_t l)
{
    if(l < 256) {
        unsigned char buf[2];
        buf[0] = 0xc4; buf[1] = (uint8_t)l;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } else if(l < 65536) {
        unsigned char buf[3];
        buf[0] = 0xc5; do { uint16_t val = ntohs((uint16_t)(uint16_t)l); memcpy(&buf[1], &val, 2); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 3);
    } else {
        unsigned char buf[5];
        buf[0] = 0xc6; do { uint32_t val = ntohl((uint32_t)(uint32_t)l); memcpy(&buf[1], &val, 4); } while(0);
        return (*(x)->callback)((x)->data, (const char*)buf, 5);
    }
}
inline int msgpack_pack_bin_body(msgpack_packer* x, const void* b, size_t l)
{
    return (*(x)->callback)((x)->data, (const char*)(const unsigned char*)b, l);
}
inline int msgpack_pack_ext(msgpack_packer* x, size_t l, int8_t type)
{
    switch(l) {
    case 1: {
        unsigned char buf[2];
        buf[0] = 0xd4;
        buf[1] = (unsigned char)type;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } break;
    case 2: {
        unsigned char buf[2];
        buf[0] = 0xd5;
        buf[1] = (unsigned char)type;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } break;
    case 4: {
        unsigned char buf[2];
        buf[0] = 0xd6;
        buf[1] = (unsigned char)type;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } break;
    case 8: {
        unsigned char buf[2];
        buf[0] = 0xd7;
        buf[1] = (unsigned char)type;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } break;
    case 16: {
        unsigned char buf[2];
        buf[0] = 0xd8;
        buf[1] = (unsigned char)type;
        return (*(x)->callback)((x)->data, (const char*)buf, 2);
    } break;
    default:
        if(l < 256) {
            unsigned char buf[3];
            buf[0] = 0xc7;
            buf[1] = (unsigned char)l;
            buf[2] = (unsigned char)type;
            return (*(x)->callback)((x)->data, (const char*)buf, 3);
        } else if(l < 65536) {
            unsigned char buf[4];
            buf[0] = 0xc8;
            do { uint16_t val = ntohs((uint16_t)l); memcpy(&buf[1], &val, 2); } while(0);
            buf[3] = (unsigned char)type;
            return (*(x)->callback)((x)->data, (const char*)buf, 4);
        } else {
            unsigned char buf[6];
            buf[0] = 0xc9;
            do { uint32_t val = ntohl((uint32_t)l); memcpy(&buf[1], &val, 4); } while(0);
            buf[5] = (unsigned char)type;
            return (*(x)->callback)((x)->data, (const char*)buf, 6);
        }
        break;
    }
}
inline int msgpack_pack_ext_body(msgpack_packer* x, const void* b, size_t l)
{
    return (*(x)->callback)((x)->data, (const char*)(const unsigned char*)b, l);
}
inline int msgpack_pack_timestamp(msgpack_packer* x, const msgpack_timestamp* d)
{
    if ((((int64_t)d->tv_sec) >> 34) == 0) {
        uint64_t data64 = ((uint64_t) d->tv_nsec << 34) | (uint64_t)d->tv_sec;
        if ((data64 & 0xffffffff00000000L) == 0) {
            char buf[4];
            uint32_t data32 = (uint32_t)data64;
            msgpack_pack_ext(x, 4, -1);
            do { uint32_t val = ntohl((uint32_t)data32); memcpy(buf, &val, 4); } while(0);
            return (*(x)->callback)((x)->data, (const char*)buf, 4);
        } else {
            char buf[8];
            msgpack_pack_ext(x, 8, -1);
            do { uint64_t val = __bswap_64 (data64); memcpy(buf, &val, 8); } while(0);
            return (*(x)->callback)((x)->data, (const char*)buf, 8);
        }
    } else {
        char buf[12];
        do { uint32_t val = ntohl((uint32_t)d->tv_nsec); memcpy(&buf[0], &val, 4); } while(0);
        do { uint64_t val = __bswap_64 (d->tv_sec); memcpy(&buf[4], &val, 8); } while(0);
        msgpack_pack_ext(x, 12, -1);
        return (*(x)->callback)((x)->data, (const char*)buf, 12);
    }
}

inline void msgpack_packer_init(msgpack_packer* pk, void* data, msgpack_packer_write callback)
{
    pk->data = data;
    pk->callback = callback;
}
inline msgpack_packer* msgpack_packer_new(void* data, msgpack_packer_write callback)
{
    msgpack_packer* pk = (msgpack_packer*)calloc(1, sizeof(msgpack_packer));
    if(!pk) { return ((void*)0); }
    msgpack_packer_init(pk, data, callback);
    return pk;
}
inline void msgpack_packer_free(msgpack_packer* pk)
{
    free(pk);
}
inline int msgpack_pack_str_with_body(msgpack_packer* pk, const void* b, size_t l)
 {
     int ret = msgpack_pack_str(pk, l);
     if (ret != 0) { return ret; }
     return msgpack_pack_str_body(pk, b, l);
 }
 inline int msgpack_pack_bin_with_body(msgpack_packer* pk, const void* b, size_t l)
 {
     int ret = msgpack_pack_bin(pk, l);
     if (ret != 0) { return ret; }
     return msgpack_pack_bin_body(pk, b, l);
 }
 inline int msgpack_pack_ext_with_body(msgpack_packer* pk, const void* b, size_t l, int8_t type)
 {
     int ret = msgpack_pack_ext(pk, l, type);
     if (ret != 0) { return ret; }
     return msgpack_pack_ext_body(pk, b, l);
 }
typedef struct msgpack_unpacked {
    msgpack_zone* zone;
    msgpack_object data;
} msgpack_unpacked;
typedef enum {
    MSGPACK_UNPACK_SUCCESS = 2,
    MSGPACK_UNPACK_EXTRA_BYTES = 1,
    MSGPACK_UNPACK_CONTINUE = 0,
    MSGPACK_UNPACK_PARSE_ERROR = -1,
    MSGPACK_UNPACK_NOMEM_ERROR = -2
} msgpack_unpack_return;
msgpack_unpack_return
msgpack_unpack_next(msgpack_unpacked* result,
        const char* data, size_t len, size_t* off);
typedef struct msgpack_unpacker {
    char* buffer;
    size_t used;
    size_t free;
    size_t off;
    size_t parsed;
    msgpack_zone* z;
    size_t initial_buffer_size;
    void* ctx;
} msgpack_unpacker;
_Bool msgpack_unpacker_init(msgpack_unpacker* mpac, size_t initial_buffer_size);
void msgpack_unpacker_destroy(msgpack_unpacker* mpac);
msgpack_unpacker* msgpack_unpacker_new(size_t initial_buffer_size);
void msgpack_unpacker_free(msgpack_unpacker* mpac);
static inline _Bool msgpack_unpacker_reserve_buffer(msgpack_unpacker* mpac, size_t size);
static inline char* msgpack_unpacker_buffer(msgpack_unpacker* mpac);
static inline size_t msgpack_unpacker_buffer_capacity(const msgpack_unpacker* mpac);
static inline void msgpack_unpacker_buffer_consumed(msgpack_unpacker* mpac, size_t size);
msgpack_unpack_return msgpack_unpacker_next(msgpack_unpacker* mpac, msgpack_unpacked* pac);
msgpack_unpack_return msgpack_unpacker_next_with_size(msgpack_unpacker* mpac,
                                                      msgpack_unpacked* result,
                                                      size_t *p_bytes);
static inline void msgpack_unpacked_init(msgpack_unpacked* result);
static inline void msgpack_unpacked_destroy(msgpack_unpacked* result);
static inline msgpack_zone* msgpack_unpacked_release_zone(msgpack_unpacked* result);
int msgpack_unpacker_execute(msgpack_unpacker* mpac);
msgpack_object msgpack_unpacker_data(msgpack_unpacker* mpac);
msgpack_zone* msgpack_unpacker_release_zone(msgpack_unpacker* mpac);
void msgpack_unpacker_reset_zone(msgpack_unpacker* mpac);
void msgpack_unpacker_reset(msgpack_unpacker* mpac);
static inline size_t msgpack_unpacker_message_size(const msgpack_unpacker* mpac);
msgpack_unpack_return
msgpack_unpack(const char* data, size_t len, size_t* off,
        msgpack_zone* result_zone, msgpack_object* result);
static inline size_t msgpack_unpacker_parsed_size(const msgpack_unpacker* mpac);
_Bool msgpack_unpacker_flush_zone(msgpack_unpacker* mpac);
_Bool msgpack_unpacker_expand_buffer(msgpack_unpacker* mpac, size_t size);
static inline _Bool msgpack_unpacker_reserve_buffer(msgpack_unpacker* mpac, size_t size)
{
    if(mpac->free >= size) { return 1; }
    return msgpack_unpacker_expand_buffer(mpac, size);
}
static inline char* msgpack_unpacker_buffer(msgpack_unpacker* mpac)
{
    return mpac->buffer + mpac->used;
}
static inline size_t msgpack_unpacker_buffer_capacity(const msgpack_unpacker* mpac)
{
    return mpac->free;
}
static inline void msgpack_unpacker_buffer_consumed(msgpack_unpacker* mpac, size_t size)
{
    mpac->used += size;
    mpac->free -= size;
}
static inline size_t msgpack_unpacker_message_size(const msgpack_unpacker* mpac)
{
    return mpac->parsed - mpac->off + mpac->used;
}
static inline size_t msgpack_unpacker_parsed_size(const msgpack_unpacker* mpac)
{
    return mpac->parsed;
}
static inline void msgpack_unpacked_init(msgpack_unpacked* result)
{
    memset(result, 0, sizeof(msgpack_unpacked));
}
static inline void msgpack_unpacked_destroy(msgpack_unpacked* result)
{
    if(result->zone != ((void*)0)) {
        msgpack_zone_free(result->zone);
        result->zone = ((void*)0);
        memset(&result->data, 0, sizeof(msgpack_object));
    }
}
static inline msgpack_zone* msgpack_unpacked_release_zone(msgpack_unpacked* result)
{
    if(result->zone != ((void*)0)) {
        msgpack_zone* z = result->zone;
        result->zone = ((void*)0);
        return z;
    }
    return ((void*)0);
}
typedef struct msgpack_sbuffer {
    size_t size;
    char* data;
    size_t alloc;
} msgpack_sbuffer;
static inline void msgpack_sbuffer_init(msgpack_sbuffer* sbuf)
{
    memset(sbuf, 0, sizeof(msgpack_sbuffer));
}
static inline void msgpack_sbuffer_destroy(msgpack_sbuffer* sbuf)
{
    free(sbuf->data);
}
static inline msgpack_sbuffer* msgpack_sbuffer_new(void)
{
    return (msgpack_sbuffer*)calloc(1, sizeof(msgpack_sbuffer));
}
static inline void msgpack_sbuffer_free(msgpack_sbuffer* sbuf)
{
    if(sbuf == ((void*)0)) { return; }
    msgpack_sbuffer_destroy(sbuf);
    free(sbuf);
}
static inline int msgpack_sbuffer_write(void* data, const char* buf, size_t len)
{
    msgpack_sbuffer* sbuf = (msgpack_sbuffer*)data;
    ((void) sizeof ((buf || len == 0) ? 1 : 0), __extension__ ({ if (buf || len == 0) ; else __assert_fail ("buf || len == 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/msgpack-c/include/msgpack/sbuffer.h", 64, __extension__ __PRETTY_FUNCTION__); }));
    if(!buf) return 0;
    if(sbuf->alloc - sbuf->size < len) {
        void* tmp;
        size_t nsize = (sbuf->alloc) ?
                sbuf->alloc * 2 : 8192;
        while(nsize < sbuf->size + len) {
            size_t tmp_nsize = nsize * 2;
            if (tmp_nsize <= nsize) {
                nsize = sbuf->size + len;
                break;
            }
            nsize = tmp_nsize;
        }
        tmp = realloc(sbuf->data, nsize);
        if(!tmp) { return -1; }
        sbuf->data = (char*)tmp;
        sbuf->alloc = nsize;
    }
    memcpy(sbuf->data + sbuf->size, buf, len);
    sbuf->size += len;
    return 0;
}
static inline char* msgpack_sbuffer_release(msgpack_sbuffer* sbuf)
{
    char* tmp = sbuf->data;
    sbuf->size = 0;
    sbuf->data = ((void*)0);
    sbuf->alloc = 0;
    return tmp;
}
static inline void msgpack_sbuffer_clear(msgpack_sbuffer* sbuf)
{
    sbuf->size = 0;
}
struct msgpack_vrefbuffer_chunk;
typedef struct msgpack_vrefbuffer_chunk msgpack_vrefbuffer_chunk;
typedef struct msgpack_vrefbuffer_inner_buffer {
    size_t free;
    char* ptr;
    msgpack_vrefbuffer_chunk* head;
} msgpack_vrefbuffer_inner_buffer;
typedef struct msgpack_vrefbuffer {
    struct iovec* tail;
    struct iovec* end;
    struct iovec* array;
    size_t chunk_size;
    size_t ref_size;
    msgpack_vrefbuffer_inner_buffer inner_buffer;
} msgpack_vrefbuffer;
_Bool msgpack_vrefbuffer_init(msgpack_vrefbuffer* vbuf,
        size_t ref_size, size_t chunk_size);
void msgpack_vrefbuffer_destroy(msgpack_vrefbuffer* vbuf);
static inline msgpack_vrefbuffer* msgpack_vrefbuffer_new(size_t ref_size, size_t chunk_size);
static inline void msgpack_vrefbuffer_free(msgpack_vrefbuffer* vbuf);
static inline int msgpack_vrefbuffer_write(void* data, const char* buf, size_t len);
static inline const struct iovec* msgpack_vrefbuffer_vec(const msgpack_vrefbuffer* vref);
static inline size_t msgpack_vrefbuffer_veclen(const msgpack_vrefbuffer* vref);
int msgpack_vrefbuffer_append_copy(msgpack_vrefbuffer* vbuf,
        const char* buf, size_t len);
int msgpack_vrefbuffer_append_ref(msgpack_vrefbuffer* vbuf,
        const char* buf, size_t len);
int msgpack_vrefbuffer_migrate(msgpack_vrefbuffer* vbuf, msgpack_vrefbuffer* to);
void msgpack_vrefbuffer_clear(msgpack_vrefbuffer* vref);
static inline msgpack_vrefbuffer* msgpack_vrefbuffer_new(size_t ref_size, size_t chunk_size)
{
    msgpack_vrefbuffer* vbuf = (msgpack_vrefbuffer*)malloc(sizeof(msgpack_vrefbuffer));
    if (vbuf == ((void*)0)) return ((void*)0);
    if(!msgpack_vrefbuffer_init(vbuf, ref_size, chunk_size)) {
        free(vbuf);
        return ((void*)0);
    }
    return vbuf;
}
static inline void msgpack_vrefbuffer_free(msgpack_vrefbuffer* vbuf)
{
    if(vbuf == ((void*)0)) { return; }
    msgpack_vrefbuffer_destroy(vbuf);
    free(vbuf);
}
static inline int msgpack_vrefbuffer_write(void* data, const char* buf, size_t len)
{
    msgpack_vrefbuffer* vbuf = (msgpack_vrefbuffer*)data;
    ((void) sizeof ((buf || len == 0) ? 1 : 0), __extension__ ({ if (buf || len == 0) ; else __assert_fail ("buf || len == 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/msgpack-c/include/msgpack/vrefbuffer.h", 118, __extension__ __PRETTY_FUNCTION__); }));
    if(!buf) return 0;
    if(len < vbuf->ref_size) {
        return msgpack_vrefbuffer_append_copy(vbuf, buf, len);
    } else {
        return msgpack_vrefbuffer_append_ref(vbuf, buf, len);
    }
}
static inline const struct iovec* msgpack_vrefbuffer_vec(const msgpack_vrefbuffer* vref)
{
    return vref->array;
}
static inline size_t msgpack_vrefbuffer_veclen(const msgpack_vrefbuffer* vref)
{
    return (size_t)(vref->tail - vref->array);
}
const char* msgpack_version(void);
int msgpack_version_major(void);
int msgpack_version_minor(void);
int msgpack_version_revision(void);
struct flb_output_instance;
struct flb_chunk_direct_route {
    uint32_t id;
    uint16_t label_length;
    const char *label;
    uint8_t label_is_alias;
    uint16_t plugin_name_length;
    const char *plugin_name;
};
struct flb_input_chunk {
    int event_type;
    _Bool fs_counted;
    int busy;
    int fs_backlog;
    int sp_done;
    int total_records;
    int added_records;
    void *chunk;
    off_t stream_off;
    msgpack_packer mp_pck;
    struct flb_input_instance *in;
    struct flb_task *task;
    struct flb_chunk_trace *trace;
    double create_time;
    flb_route_mask_element *routes_mask;
    struct mk_list _head;
};
struct flb_input_chunk *flb_input_chunk_create(struct flb_input_instance *in, int event_type,
                                               const char *tag, int tag_len);
int flb_input_chunk_destroy(struct flb_input_chunk *ic, int del);
void flb_input_chunk_destroy_all(struct flb_input_instance *in);
int flb_input_chunk_destroy_corrupted(struct flb_input_chunk *ic,
                                      const char *tag_buf, int tag_len,
                                      int del);
int flb_input_chunk_write(void *data, const char *buf, size_t len);
int flb_input_chunk_write_at(void *data, off_t offset,
                             const char *buf, size_t len);
int flb_input_chunk_append_obj(struct flb_input_instance *in,
                               const char *tag, int tag_len,
                               msgpack_object data);
int flb_input_chunk_append_raw(struct flb_input_instance *in,
                               int event_type,
                               size_t records,
                               const char *tag, size_t tag_len,
                               const void *buf, size_t buf_size);
int flb_input_chunk_append_raw_local(struct flb_input_instance *in,
                                     int event_type,
                                     size_t records,
                                     const char *tag, size_t tag_len,
                                     const void *buf, size_t buf_size);
int flb_input_chunk_ring_buffer_enqueue(struct flb_input_instance *in,
                                        int event_type,
                                        size_t records,
                                        const char *tag, size_t tag_len,
                                        const void *buf, size_t buf_size);
int flb_input_chunk_ring_buffer_enqueue_log_routing(struct flb_input_instance *in,
                                                    int event_type,
                                                    size_t records,
                                                    const char *tag, size_t tag_len,
                                                    const void *buf, size_t buf_size);
const void *flb_input_chunk_flush(struct flb_input_chunk *ic, size_t *size);
int flb_input_chunk_release_lock(struct flb_input_chunk *ic);
flb_sds_t flb_input_chunk_get_name(struct flb_input_chunk *ic);
int flb_input_chunk_get_event_type(struct flb_input_chunk *ic);
int flb_input_chunk_get_tag(struct flb_input_chunk *ic,
                            const char **tag_buf, int *tag_len);
int flb_input_chunk_write_header_v2(struct cio_chunk *chunk,
                                    int event_type,
                                    char *tag, int tag_len,
                                    const struct flb_chunk_direct_route *routes,
                                    int route_count);
int flb_chunk_route_plugin_matches(struct flb_output_instance *o_ins,
                                   const struct flb_chunk_direct_route *route);
int flb_input_chunk_has_direct_routes(struct flb_input_chunk *ic);
int flb_input_chunk_get_direct_routes(struct flb_input_chunk *ic,
                                      struct flb_chunk_direct_route **routes,
                                      int *route_count);
void flb_input_chunk_destroy_direct_routes(struct flb_chunk_direct_route *routes,
                                           int route_count);
void flb_input_chunk_ring_buffer_cleanup(struct flb_input_instance *ins);
void flb_input_chunk_ring_buffer_collector(struct flb_config *ctx, void *data);
ssize_t flb_input_chunk_get_size(struct flb_input_chunk *ic);
ssize_t flb_input_chunk_get_real_size(struct flb_input_chunk *ic);
int flb_input_chunk_release_route(struct flb_input_chunk *ic,
                                  struct flb_output_instance *o_ins);
void flb_input_chunk_output_size_subtract(struct flb_output_instance *o_ins,
                                          size_t bytes);
size_t flb_input_chunk_set_limits(struct flb_input_instance *in);
size_t flb_input_chunk_total_size(struct flb_input_instance *in);
struct flb_input_chunk *flb_input_chunk_map(struct flb_input_instance *in,
                                            int event_type,
                                            void *chunk);
int flb_input_chunk_set_up_down(struct flb_input_chunk *ic);
int flb_input_chunk_set_up(struct flb_input_chunk *ic);
int flb_input_chunk_down(struct flb_input_chunk *ic);
int flb_input_chunk_is_up(struct flb_input_chunk *ic);
int flb_input_chunk_find_space_new_data(struct flb_input_chunk *ic,
                                        size_t chunk_size);
int flb_input_chunk_has_overlimit_routes(struct flb_input_chunk *ic,
                                         size_t chunk_size);
void flb_input_chunk_update_output_instances(struct flb_input_chunk *ic,
                                             ssize_t chunk_size);
struct flb_input_instance;
struct flb_filter_instance;
struct flb_filter_plugin {
    int event_type;
    int flags;
    char *name;
    char *description;
    struct flb_config_map *config_map;
    int (*cb_pre_run) (struct flb_filter_instance *, struct flb_config *, void *);
    int (*cb_init) (struct flb_filter_instance *, struct flb_config *, void *);
    int (*cb_filter) (const void *, size_t,
                      const char *, int,
                      void **, size_t *,
                      struct flb_filter_instance *,
                      struct flb_input_instance *,
                      void *, struct flb_config *);
    int (*cb_exit) (void *, struct flb_config *);
    int (*cb_notification) (struct flb_filter_instance *, struct flb_config *, void *);
    struct mk_list _head;
};
struct flb_filter_instance {
    int event_type;
    int id;
    int log_level;
    int log_suppress_interval;
    char name[32];
    char *alias;
    char *match;
    struct flb_regex *match_regex;
    void *parent_processor;
    void *context;
    void *data;
    struct flb_filter_plugin *p;
    struct mk_list properties;
    struct mk_list *config_map;
    struct mk_list _head;
    struct cmt *cmt;
    struct cmt_counter *cmt_records;
    struct cmt_counter *cmt_bytes;
    struct cmt_counter *cmt_add_records;
    struct cmt_counter *cmt_drop_records;
    struct cmt_counter *cmt_drop_bytes;
    struct flb_metrics *metrics;
    int notification_channel;
    struct flb_config *config;
};
struct mk_list *flb_filter_get_global_config_map(struct flb_config *config);
static inline int flb_filter_config_map_set(struct flb_filter_instance *ins,
                                            void *context)
{
    return flb_config_map_set(ins->config, &ins->properties, ins->config_map, context);
}
int flb_filter_set_property(struct flb_filter_instance *ins,
                            const char *k, const char *v);
const char *flb_filter_get_property(const char *key,
                                    struct flb_filter_instance *ins);
struct flb_filter_instance *flb_filter_new(struct flb_config *config,
                                           const char *filter, void *data);
void flb_filter_instance_exit(struct flb_filter_instance *ins,
                              struct flb_config *config);
void flb_filter_exit(struct flb_config *config);
void flb_filter_do(struct flb_input_chunk *ic,
                   const void *data, size_t bytes,
                   void **out_data, size_t *out_bytes,
                   const char *tag, int tag_len,
                   struct flb_config *config);
const char *flb_filter_name(struct flb_filter_instance *ins);
int flb_filter_match_property_existence(struct flb_filter_instance *ins);
int flb_filter_plugin_property_check(struct flb_filter_instance *ins,
                                     struct flb_config *config);
int flb_filter_init(struct flb_config *config, struct flb_filter_instance *ins);
int flb_filter_init_all(struct flb_config *config);
void flb_filter_set_context(struct flb_filter_instance *ins, void *context);
void flb_filter_instance_destroy(struct flb_filter_instance *ins);

int flb_mp_count(const void *data, size_t bytes);
int flb_mp_count_log_records(const void *data, size_t bytes);
int flb_mp_normalize_log_buffer_groups_msgpack(const void *in_buf, size_t in_size,
                                               char **out_buf, size_t *out_size);
int flb_mp_normalize_log_buffer_groups(const void *in_buf, size_t in_size,
                                       char **out_buf, size_t *out_size);
int flb_mp_count_remaining(const void *data, size_t bytes, size_t *remaining_bytes);
int flb_mp_validate_log_chunk(const void *data, size_t bytes,
                              int *out_records, size_t *processed_bytes);
int flb_mp_validate_metric_chunk(const void *data, size_t bytes,
                                 int *out_series, size_t *processed_bytes);
void flb_mp_set_map_header_size(char *buf, int arr_size);
struct flb_mp_map_header {
    off_t offset;
    size_t entries;
    void *data;
};
struct flb_mp_accessor_match {
    int matched;
    msgpack_object *start_key;
    msgpack_object *key;
    msgpack_object *val;
    struct flb_record_accessor *ra;
};
struct flb_mp_accessor_ra {
    int is_active;
    struct flb_record_accessor *ra;
    struct mk_list _head;
};
struct flb_mp_accessor {
    int matches_size;
    struct flb_mp_accessor_match *matches;
    struct mk_list ra_list;
};
int flb_mp_map_header_init(struct flb_mp_map_header *mh, msgpack_packer *mp_pck);
int flb_mp_map_header_append(struct flb_mp_map_header *mh);
void flb_mp_map_header_end(struct flb_mp_map_header *mh);
int flb_mp_array_header_init(struct flb_mp_map_header *mh, msgpack_packer *mp_pck);
int flb_mp_array_header_append(struct flb_mp_map_header *mh);
void flb_mp_array_header_end(struct flb_mp_map_header *mh);
struct flb_mp_accessor *flb_mp_accessor_create(struct mk_list *slist_patterns);
void flb_mp_accessor_destroy(struct flb_mp_accessor *mpa);
int flb_mp_accessor_keys_remove(struct flb_mp_accessor *mpa,
                                msgpack_object *map,
                                void **out_buf, size_t *out_size);
void flb_mp_accessor_set_active(struct flb_mp_accessor *mpa, int status);
int flb_mp_accessor_set_active_by_pattern(struct flb_mp_accessor *mpa,
                                          const char *pattern, int status);
struct cfl_object *flb_mp_object_to_cfl(msgpack_object *o);
int flb_mp_cfl_to_msgpack(struct cfl_object *obj, char **out_buf, size_t *out_size);
struct flb_hash_table_entry {
    time_t created;
    uint64_t hits;
    uint64_t hash;
    char *key;
    size_t key_len;
    void *val;
    ssize_t val_size;
    struct flb_hash_table_chain *table;
    struct mk_list _head;
    struct mk_list _head_parent;
};
struct flb_hash_table_chain {
    int count;
    struct mk_list chains;
};
struct flb_hash_table {
    int evict_mode;
    int max_entries;
    int total_count;
    int cache_ttl;
    int case_sensitivity;
    size_t size;
    struct mk_list entries;
    struct flb_hash_table_chain *table;
};
struct flb_hash_table *flb_hash_table_create(int evict_mode, size_t size, int max_entries);
struct flb_hash_table *flb_hash_table_create_with_ttl(int cache_ttl, int evict_mode,
                                                      size_t size, int max_entries);
void flb_hash_table_destroy(struct flb_hash_table *ht);
void flb_hash_table_set_case_sensitivity(struct flb_hash_table *ht, int status);
int flb_hash_table_add(struct flb_hash_table *ht,
                       const char *key, int key_len,
                       void *val, ssize_t val_size);
int flb_hash_table_get(struct flb_hash_table *ht,
                       const char *key, int key_len,
                       void **out_buf, size_t *out_size);
int flb_hash_table_exists(struct flb_hash_table *ht, uint64_t hash);
int flb_hash_table_get_by_id(struct flb_hash_table *ht, int id,
                             const char *key,
                             const char **out_buf, size_t *out_size);
void *flb_hash_table_get_ptr(struct flb_hash_table *ht, const char *key, int key_len);
int flb_hash_table_del(struct flb_hash_table *ht, const char *key);
int flb_hash_table_del_ptr(struct flb_hash_table *ht, const char *key, int key_len,
                           void *ptr);



int flb_input_log_append(struct flb_input_instance *ins,
                         const char *tag, size_t tag_len,
                         const void *buf, size_t buf_size);
int flb_input_log_append_records(struct flb_input_instance *ins,
                                 size_t records,
                                 const char *tag, size_t tag_len,
                                 const void *buf, size_t buf_size);
int flb_input_log_append_skip_processor_stages(struct flb_input_instance *ins,
                                               size_t processor_starting_stage,
                                               const char *tag,
                                               size_t tag_len,
                                               const void *buf,
                                               size_t buf_size);
int flb_input_log_append_processed(struct flb_input_instance *ins,
                                   size_t records,
                                   const char *tag,
                                   size_t tag_len,
                                   const void *buf,
                                   size_t buf_size);
int flb_input_metrics_append(struct flb_input_instance *ins,
                             const char *tag, size_t tag_len,
                             struct cmt *cmt);
int flb_input_metrics_append_list(struct flb_input_instance *ins,
                                  const char *tag, size_t tag_len,
                                  struct cfl_list *contexts);
int flb_input_metrics_append_skip_processor_stages(
        struct flb_input_instance *ins,
        size_t processor_starting_stage,
        const char *tag, size_t tag_len,
        struct cmt *cmt);
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
        inline void* mpack_realloc(void* old_ptr, size_t used_size, size_t new_size) {
            ((void)(used_size));
            return realloc(old_ptr, new_size);
        }
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef enum mpack_error_t {
    mpack_ok = 0,
    mpack_error_io = 2,
    mpack_error_invalid,
    mpack_error_unsupported,
    mpack_error_type,
    mpack_error_too_big,
    mpack_error_memory,
    mpack_error_bug,
    mpack_error_data,
    mpack_error_eof,
} mpack_error_t;
const char* mpack_error_to_string(mpack_error_t error);
typedef enum mpack_type_t {
    mpack_type_missing = 0,
    mpack_type_nil,
    mpack_type_bool,
    mpack_type_int,
    mpack_type_uint,
    mpack_type_float,
    mpack_type_double,
    mpack_type_str,
    mpack_type_bin,
    mpack_type_array,
    mpack_type_map,
    mpack_type_ext,
} mpack_type_t;
const char* mpack_type_to_string(mpack_type_t type);
typedef struct mpack_timestamp_t {
    int64_t seconds;
    uint32_t nanoseconds;
} mpack_timestamp_t;
typedef struct mpack_tag_t mpack_tag_t;
struct mpack_tag_t {
    mpack_type_t type;
    int8_t exttype;
    union {
        uint64_t u;
        int64_t i;
        _Bool b;
        float f;
        double d;
        uint32_t l;
        uint32_t n;
    } v;
};
inline mpack_tag_t mpack_tag_make_nil(void) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_nil;
    return ret;
}
inline mpack_tag_t mpack_tag_make_bool(_Bool value) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bool;
    ret.v.b = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_true(void) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bool;
    ret.v.b = 1;
    return ret;
}
inline mpack_tag_t mpack_tag_make_false(void) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bool;
    ret.v.b = 0;
    return ret;
}
inline mpack_tag_t mpack_tag_make_int(int64_t value) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_int;
    ret.v.i = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_uint(uint64_t value) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_uint;
    ret.v.u = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_float(float value)
{
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_float;
    ret.v.f = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_double(double value)
{
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_double;
    ret.v.d = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_array(uint32_t count) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_array;
    ret.v.n = count;
    return ret;
}
inline mpack_tag_t mpack_tag_make_map(uint32_t count) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_map;
    ret.v.n = count;
    return ret;
}
inline mpack_tag_t mpack_tag_make_str(uint32_t length) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_str;
    ret.v.l = length;
    return ret;
}
inline mpack_tag_t mpack_tag_make_bin(uint32_t length) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bin;
    ret.v.l = length;
    return ret;
}
inline mpack_tag_t mpack_tag_make_ext(int8_t exttype, uint32_t length) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_ext;
    ret.exttype = exttype;
    ret.v.l = length;
    return ret;
}
inline mpack_type_t mpack_tag_type(mpack_tag_t* tag) {
    return tag->type;
}
inline _Bool mpack_tag_bool_value(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_bool)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.b;
}
inline int64_t mpack_tag_int_value(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_int)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.i;
}
inline uint64_t mpack_tag_uint_value(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_uint)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.u;
}
inline
float mpack_tag_float_value(mpack_tag_t* tag)
{
    ((!(tag->type == mpack_type_float)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.f;
}
inline
double mpack_tag_double_value(mpack_tag_t* tag)
{
    ((!(tag->type == mpack_type_double)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.d;
}
inline uint32_t mpack_tag_array_count(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_array)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.n;
}
inline uint32_t mpack_tag_map_count(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_map)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.n;
}
inline uint32_t mpack_tag_str_length(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_str)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
inline uint32_t mpack_tag_bin_length(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_bin)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
inline uint32_t mpack_tag_ext_length(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_ext)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
inline int8_t mpack_tag_ext_exttype(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_ext)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->exttype;
}
inline uint32_t mpack_tag_bytes(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_str || tag->type == mpack_type_bin || tag->type == mpack_type_ext)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
int mpack_tag_cmp(mpack_tag_t left, mpack_tag_t right);
inline _Bool mpack_tag_equal(mpack_tag_t left, mpack_tag_t right) {
    return mpack_tag_cmp(left, right) == 0;
}
inline mpack_tag_t mpack_tag_nil(void) {
    return mpack_tag_make_nil();
}
inline mpack_tag_t mpack_tag_bool(_Bool value) {
    return mpack_tag_make_bool(value);
}
inline mpack_tag_t mpack_tag_true(void) {
    return mpack_tag_make_true();
}
inline mpack_tag_t mpack_tag_false(void) {
    return mpack_tag_make_false();
}
inline mpack_tag_t mpack_tag_int(int64_t value) {
    return mpack_tag_make_int(value);
}
inline mpack_tag_t mpack_tag_uint(uint64_t value) {
    return mpack_tag_make_uint(value);
}
inline mpack_tag_t mpack_tag_float(float value) {
    return mpack_tag_make_float(value);
}
inline mpack_tag_t mpack_tag_double(double value) {
    return mpack_tag_make_double(value);
}
inline mpack_tag_t mpack_tag_array(int32_t count) {
    return mpack_tag_make_array((uint32_t)count);
}
inline mpack_tag_t mpack_tag_map(int32_t count) {
    return mpack_tag_make_map((uint32_t)count);
}
inline mpack_tag_t mpack_tag_str(int32_t length) {
    return mpack_tag_make_str((uint32_t)length);
}
inline mpack_tag_t mpack_tag_bin(int32_t length) {
    return mpack_tag_make_bin((uint32_t)length);
}
inline mpack_tag_t mpack_tag_ext(int8_t exttype, int32_t length) {
    return mpack_tag_make_ext(exttype, (uint32_t)length);
}
inline uint8_t mpack_load_u8(const char* p) {
    return (uint8_t)p[0];
}
inline uint16_t mpack_load_u16(const char* p) {
    uint16_t val;
    memcpy(&val, p, sizeof(val));
    return __builtin_bswap16(val);
}
inline uint32_t mpack_load_u32(const char* p) {
    uint32_t val;
    memcpy(&val, p, sizeof(val));
    return __builtin_bswap32(val);
}
inline uint64_t mpack_load_u64(const char* p) {
    uint64_t val;
    memcpy(&val, p, sizeof(val));
    return __builtin_bswap64(val);
}
inline void mpack_store_u8(char* p, uint8_t val) {
    uint8_t* u = (uint8_t*)p;
    u[0] = val;
}
inline void mpack_store_u16(char* p, uint16_t val) {
    val = __builtin_bswap16(val);
    memcpy(p, &val, sizeof(val));
}
inline void mpack_store_u32(char* p, uint32_t val) {
    val = __builtin_bswap32(val);
    memcpy(p, &val, sizeof(val));
}
inline void mpack_store_u64(char* p, uint64_t val) {
    val = __builtin_bswap64(val);
    memcpy(p, &val, sizeof(val));
}
inline int8_t mpack_load_i8 (const char* p) {return (int8_t) mpack_load_u8 (p);}
inline int16_t mpack_load_i16(const char* p) {return (int16_t)mpack_load_u16(p);}
inline int32_t mpack_load_i32(const char* p) {return (int32_t)mpack_load_u32(p);}
inline int64_t mpack_load_i64(const char* p) {return (int64_t)mpack_load_u64(p);}
inline void mpack_store_i8 (char* p, int8_t val) {mpack_store_u8 (p, (uint8_t) val);}
inline void mpack_store_i16(char* p, int16_t val) {mpack_store_u16(p, (uint16_t)val);}
inline void mpack_store_i32(char* p, int32_t val) {mpack_store_u32(p, (uint32_t)val);}
inline void mpack_store_i64(char* p, int64_t val) {mpack_store_u64(p, (uint64_t)val);}
inline float mpack_load_float(const char* p) {
                             ;
    _Static_assert(sizeof(float) == sizeof(uint32_t), "float is wrong size??");
    union {
        float f;
        uint32_t u;
    } v;
    v.u = mpack_load_u32(p);
    return v.f;
}
inline double mpack_load_double(const char* p) {
                             ;
    _Static_assert(sizeof(double) == sizeof(uint64_t), "double is wrong size??");
    union {
        double d;
        uint64_t u;
    } v;
    v.u = mpack_load_u64(p);
    return v.d;
}
inline void mpack_store_float(char* p, float value) {
                             ;
    union {
        float f;
        uint32_t u;
    } v;
    v.f = value;
    mpack_store_u32(p, v.u);
}
inline void mpack_store_double(char* p, double value) {
                             ;
    union {
        double d;
        uint64_t u;
    } v;
    v.d = value;
    mpack_store_u64(p, v.u);
}
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef struct mpack_writer_t mpack_writer_t;
typedef void (*mpack_writer_flush_t)(mpack_writer_t* writer, const char* buffer, size_t count);
typedef void (*mpack_writer_error_t)(mpack_writer_t* writer, mpack_error_t error);
typedef void (*mpack_writer_teardown_t)(mpack_writer_t* writer);
typedef struct mpack_builder_page_t {
    struct mpack_builder_page_t* next;
    size_t bytes_used;
} mpack_builder_page_t;
typedef struct mpack_build_t {
    struct mpack_build_t* parent;
    size_t bytes;
    uint32_t count;
    mpack_type_t type;
    uint32_t nested_compound_elements;
    _Bool key_needs_value;
} mpack_build_t;
typedef struct mpack_builder_t {
    mpack_build_t* current_build;
    mpack_build_t* latest_build;
    mpack_builder_page_t* current_page;
    mpack_builder_page_t* pages;
    char* stash_buffer;
    char* stash_position;
    char* stash_end;
} mpack_builder_t;
struct mpack_writer_t {
    mpack_writer_flush_t flush;
    mpack_writer_error_t error_fn;
    mpack_writer_teardown_t teardown;
    void* context;
    char* buffer;
    char* position;
    char* end;
    mpack_error_t error;
    void* reserved[2];
    mpack_builder_t builder;
};
inline void mpack_writer_track_push(mpack_writer_t* writer, mpack_type_t type, uint32_t count) {
    ((void)(writer));
    ((void)(type));
    ((void)(count));
}
inline void mpack_writer_track_push_builder(mpack_writer_t* writer, mpack_type_t type) {
    ((void)(writer));
    ((void)(type));
}
inline void mpack_writer_track_pop(mpack_writer_t* writer, mpack_type_t type) {
    ((void)(writer));
    ((void)(type));
}
inline void mpack_writer_track_pop_builder(mpack_writer_t* writer, mpack_type_t type) {
    ((void)(writer));
    ((void)(type));
}
inline void mpack_writer_track_bytes(mpack_writer_t* writer, size_t count) {
    ((void)(writer));
    ((void)(count));
}
void mpack_writer_init(mpack_writer_t* writer, char* buffer, size_t size);
void mpack_writer_init_growable(mpack_writer_t* writer, char** data, size_t* size);
void mpack_writer_init_error(mpack_writer_t* writer, mpack_error_t error);
void mpack_writer_init_filename(mpack_writer_t* writer, const char* filename);
inline void mpack_writer_init_file(mpack_writer_t* writer, const char* filename) {
    mpack_writer_init_filename(writer, filename);
}
void mpack_writer_init_stdfile(mpack_writer_t* writer, FILE* stdfile, _Bool close_when_done);
mpack_error_t mpack_writer_destroy(mpack_writer_t* writer);
inline void mpack_writer_set_context(mpack_writer_t* writer, void* context) {
    writer->context = context;
}
inline void* mpack_writer_context(mpack_writer_t* writer) {
    return writer->context;
}
void mpack_writer_set_flush(mpack_writer_t* writer, mpack_writer_flush_t flush);
inline void mpack_writer_set_error_handler(mpack_writer_t* writer, mpack_writer_error_t error_fn) {
    writer->error_fn = error_fn;
}
inline void mpack_writer_set_teardown(mpack_writer_t* writer, mpack_writer_teardown_t teardown) {
    writer->teardown = teardown;
}
void mpack_writer_flush_message(mpack_writer_t* writer);
inline size_t mpack_writer_buffer_used(mpack_writer_t* writer) {
    return (size_t)(writer->position - writer->buffer);
}
inline size_t mpack_writer_buffer_left(mpack_writer_t* writer) {
    return (size_t)(writer->end - writer->position);
}
inline size_t mpack_writer_buffer_size(mpack_writer_t* writer) {
    return (size_t)(writer->end - writer->buffer);
}
void mpack_writer_flag_error(mpack_writer_t* writer, mpack_error_t error);
inline mpack_error_t mpack_writer_error(mpack_writer_t* writer) {
    return writer->error;
}
void mpack_write_tag(mpack_writer_t* writer, mpack_tag_t tag);
void mpack_write_i8(mpack_writer_t* writer, int8_t value);
void mpack_write_i16(mpack_writer_t* writer, int16_t value);
void mpack_write_i32(mpack_writer_t* writer, int32_t value);
void mpack_write_i64(mpack_writer_t* writer, int64_t value);
inline void mpack_write_int(mpack_writer_t* writer, int64_t value) {
    mpack_write_i64(writer, value);
}
void mpack_write_u8(mpack_writer_t* writer, uint8_t value);
void mpack_write_u16(mpack_writer_t* writer, uint16_t value);
void mpack_write_u32(mpack_writer_t* writer, uint32_t value);
void mpack_write_u64(mpack_writer_t* writer, uint64_t value);
inline void mpack_write_uint(mpack_writer_t* writer, uint64_t value) {
    mpack_write_u64(writer, value);
}
void mpack_write_float(mpack_writer_t* writer, float value);
void mpack_write_double(mpack_writer_t* writer, double value);
void mpack_write_bool(mpack_writer_t* writer, _Bool value);
void mpack_write_true(mpack_writer_t* writer);
void mpack_write_false(mpack_writer_t* writer);
void mpack_write_nil(mpack_writer_t* writer);
void mpack_write_object_bytes(mpack_writer_t* writer, const char* data, size_t bytes);
void mpack_write_timestamp(mpack_writer_t* writer, int64_t seconds, uint32_t nanoseconds);
inline void mpack_write_timestamp_seconds(mpack_writer_t* writer, int64_t seconds) {
    mpack_write_timestamp(writer, seconds, 0);
}
inline void mpack_write_timestamp_struct(mpack_writer_t* writer, mpack_timestamp_t timestamp) {
    mpack_write_timestamp(writer, timestamp.seconds, timestamp.nanoseconds);
}
void mpack_start_array(mpack_writer_t* writer, uint32_t count);
void mpack_start_map(mpack_writer_t* writer, uint32_t count);
inline void mpack_builder_compound_push(mpack_writer_t* writer) {
    ((void)(writer));
    mpack_build_t* build = writer->builder.current_build;
    if (build != ((void*)0)) {
        ++build->nested_compound_elements;
    }
}
inline void mpack_builder_compound_pop(mpack_writer_t* writer) {
    ((void)(writer));
    mpack_build_t* build = writer->builder.current_build;
    if (build != ((void*)0)) {
        ((!(build->nested_compound_elements > 0)) ? (__builtin_unreachable(), (void)0) : (void)0);
        --build->nested_compound_elements;
    }
}
inline void mpack_finish_array(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_array);
    mpack_builder_compound_pop(writer);
}
inline void mpack_finish_map(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_map);
    mpack_builder_compound_pop(writer);
}
void mpack_build_array(struct mpack_writer_t* writer);
void mpack_build_map(struct mpack_writer_t* writer);
void mpack_complete_array(struct mpack_writer_t* writer);
void mpack_complete_map(struct mpack_writer_t* writer);
void mpack_write_str(mpack_writer_t* writer, const char* str, uint32_t length);
void mpack_write_utf8(mpack_writer_t* writer, const char* str, uint32_t length);
void mpack_write_cstr(mpack_writer_t* writer, const char* cstr);
void mpack_write_cstr_or_nil(mpack_writer_t* writer, const char* cstr);
void mpack_write_utf8_cstr(mpack_writer_t* writer, const char* cstr);
void mpack_write_utf8_cstr_or_nil(mpack_writer_t* writer, const char* cstr);
void mpack_write_bin(mpack_writer_t* writer, const char* data, uint32_t count);
void mpack_write_ext(mpack_writer_t* writer, int8_t exttype, const char* data, uint32_t count);
void mpack_start_str(mpack_writer_t* writer, uint32_t count);
void mpack_start_bin(mpack_writer_t* writer, uint32_t count);
void mpack_start_ext(mpack_writer_t* writer, int8_t exttype, uint32_t count);
void mpack_write_bytes(mpack_writer_t* writer, const char* data, size_t count);
inline void mpack_finish_str(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_str);
}
inline void mpack_finish_bin(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_bin);
}
inline void mpack_finish_ext(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_ext);
}
inline void mpack_finish_type(mpack_writer_t* writer, mpack_type_t type) {
    mpack_writer_track_pop(writer, type);
}
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef struct mpack_reader_t mpack_reader_t;
typedef size_t (*mpack_reader_fill_t)(mpack_reader_t* reader, char* buffer, size_t count);
typedef void (*mpack_reader_skip_t)(mpack_reader_t* reader, size_t count);
typedef void (*mpack_reader_error_t)(mpack_reader_t* reader, mpack_error_t error);
typedef void (*mpack_reader_teardown_t)(mpack_reader_t* reader);
struct mpack_reader_t {
    void* context;
    mpack_reader_fill_t fill;
    mpack_reader_error_t error_fn;
    mpack_reader_teardown_t teardown;
    mpack_reader_skip_t skip;
    char* buffer;
    size_t size;
    const char* data;
    const char* end;
    mpack_error_t error;
};
void mpack_reader_init(mpack_reader_t* reader, char* buffer, size_t size, size_t count);
void mpack_reader_init_error(mpack_reader_t* reader, mpack_error_t error);
void mpack_reader_init_data(mpack_reader_t* reader, const char* data, size_t count);
void mpack_reader_init_filename(mpack_reader_t* reader, const char* filename);
inline void mpack_reader_init_file(mpack_reader_t* reader, const char* filename) {
    mpack_reader_init_filename(reader, filename);
}
void mpack_reader_init_stdfile(mpack_reader_t* reader, FILE* stdfile, _Bool close_when_done);
mpack_error_t mpack_reader_destroy(mpack_reader_t* reader);
inline void mpack_reader_set_context(mpack_reader_t* reader, void* context) {
    reader->context = context;
}
inline void* mpack_reader_context(mpack_reader_t* reader) {
    return reader->context;
}
void mpack_reader_set_fill(mpack_reader_t* reader, mpack_reader_fill_t fill);
void mpack_reader_set_skip(mpack_reader_t* reader, mpack_reader_skip_t skip);
inline void mpack_reader_set_error_handler(mpack_reader_t* reader, mpack_reader_error_t error_fn) {
    reader->error_fn = error_fn;
}
inline void mpack_reader_set_teardown(mpack_reader_t* reader, mpack_reader_teardown_t teardown) {
    reader->teardown = teardown;
}
inline mpack_error_t mpack_reader_error(mpack_reader_t* reader) {
    return reader->error;
}
void mpack_reader_flag_error(mpack_reader_t* reader, mpack_error_t error);
inline mpack_error_t mpack_reader_flag_if_error(mpack_reader_t* reader, mpack_error_t error) {
    if (error != mpack_ok)
        mpack_reader_flag_error(reader, error);
    return mpack_reader_error(reader);
}
size_t mpack_reader_remaining(mpack_reader_t* reader, const char** data);
mpack_tag_t mpack_read_tag(mpack_reader_t* reader);
mpack_tag_t mpack_peek_tag(mpack_reader_t* reader);
void mpack_skip_bytes(mpack_reader_t* reader, size_t count);
void mpack_read_bytes(mpack_reader_t* reader, char* p, size_t count);
void mpack_read_utf8(mpack_reader_t* reader, char* p, size_t byte_count);
void mpack_read_cstr(mpack_reader_t* reader, char* buf, size_t buffer_size, size_t byte_count);
void mpack_read_utf8_cstr(mpack_reader_t* reader, char* buf, size_t buffer_size, size_t byte_count);
char* mpack_read_bytes_alloc_impl(mpack_reader_t* reader, size_t count, _Bool null_terminated);
inline char* mpack_read_bytes_alloc(mpack_reader_t* reader, size_t count) {
    return mpack_read_bytes_alloc_impl(reader, count, 0);
}
const char* mpack_read_bytes_inplace(mpack_reader_t* reader, size_t count);
const char* mpack_read_utf8_inplace(mpack_reader_t* reader, size_t count);
inline _Bool mpack_should_read_bytes_inplace(mpack_reader_t* reader, size_t count) {
    return (reader->size == 0 || count <= reader->size / 32);
}
mpack_timestamp_t mpack_read_timestamp(mpack_reader_t* reader, size_t size);
inline void mpack_done_type(mpack_reader_t* reader, mpack_type_t type) {
    ((void)(reader));
    ((void)(type));
}
inline void mpack_done_array(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_array);
}
inline void mpack_done_map(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_map);
}
inline void mpack_done_str(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_str);
}
inline void mpack_done_bin(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_bin);
}
inline void mpack_done_ext(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_ext);
}
void mpack_discard(mpack_reader_t* reader);
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
uint8_t mpack_expect_u8(mpack_reader_t* reader);
uint16_t mpack_expect_u16(mpack_reader_t* reader);
uint32_t mpack_expect_u32(mpack_reader_t* reader);
uint64_t mpack_expect_u64(mpack_reader_t* reader);
int8_t mpack_expect_i8(mpack_reader_t* reader);
int16_t mpack_expect_i16(mpack_reader_t* reader);
int32_t mpack_expect_i32(mpack_reader_t* reader);
int64_t mpack_expect_i64(mpack_reader_t* reader);
float mpack_expect_float(mpack_reader_t* reader);
double mpack_expect_double(mpack_reader_t* reader);
float mpack_expect_float_strict(mpack_reader_t* reader);
double mpack_expect_double_strict(mpack_reader_t* reader);
uint8_t mpack_expect_u8_range(mpack_reader_t* reader, uint8_t min_value, uint8_t max_value);
uint16_t mpack_expect_u16_range(mpack_reader_t* reader, uint16_t min_value, uint16_t max_value);
uint32_t mpack_expect_u32_range(mpack_reader_t* reader, uint32_t min_value, uint32_t max_value);
uint64_t mpack_expect_u64_range(mpack_reader_t* reader, uint64_t min_value, uint64_t max_value);
inline unsigned int mpack_expect_uint_range(mpack_reader_t* reader, unsigned int min_value, unsigned int max_value) {
    if (sizeof(unsigned int) == 4)
        return (unsigned int)mpack_expect_u32_range(reader, (uint32_t)min_value, (uint32_t)max_value);
    return (unsigned int)mpack_expect_u64_range(reader, min_value, max_value);
}
inline uint8_t mpack_expect_u8_max(mpack_reader_t* reader, uint8_t max_value) {
    return mpack_expect_u8_range(reader, 0, max_value);
}
inline uint16_t mpack_expect_u16_max(mpack_reader_t* reader, uint16_t max_value) {
    return mpack_expect_u16_range(reader, 0, max_value);
}
inline uint32_t mpack_expect_u32_max(mpack_reader_t* reader, uint32_t max_value) {
    return mpack_expect_u32_range(reader, 0, max_value);
}
inline uint64_t mpack_expect_u64_max(mpack_reader_t* reader, uint64_t max_value) {
    return mpack_expect_u64_range(reader, 0, max_value);
}
inline unsigned int mpack_expect_uint_max(mpack_reader_t* reader, unsigned int max_value) {
    return mpack_expect_uint_range(reader, 0, max_value);
}
int8_t mpack_expect_i8_range(mpack_reader_t* reader, int8_t min_value, int8_t max_value);
int16_t mpack_expect_i16_range(mpack_reader_t* reader, int16_t min_value, int16_t max_value);
int32_t mpack_expect_i32_range(mpack_reader_t* reader, int32_t min_value, int32_t max_value);
int64_t mpack_expect_i64_range(mpack_reader_t* reader, int64_t min_value, int64_t max_value);
inline int mpack_expect_int_range(mpack_reader_t* reader, int min_value, int max_value) {
    if (sizeof(int) == 4)
        return (int)mpack_expect_i32_range(reader, (int32_t)min_value, (int32_t)max_value);
    return (int)mpack_expect_i64_range(reader, min_value, max_value);
}
inline int8_t mpack_expect_i8_max(mpack_reader_t* reader, int8_t max_value) {
    return mpack_expect_i8_range(reader, 0, max_value);
}
inline int16_t mpack_expect_i16_max(mpack_reader_t* reader, int16_t max_value) {
    return mpack_expect_i16_range(reader, 0, max_value);
}
inline int32_t mpack_expect_i32_max(mpack_reader_t* reader, int32_t max_value) {
    return mpack_expect_i32_range(reader, 0, max_value);
}
inline int64_t mpack_expect_i64_max(mpack_reader_t* reader, int64_t max_value) {
    return mpack_expect_i64_range(reader, 0, max_value);
}
inline int mpack_expect_int_max(mpack_reader_t* reader, int max_value) {
    return mpack_expect_int_range(reader, 0, max_value);
}
float mpack_expect_float_range(mpack_reader_t* reader, float min_value, float max_value);
double mpack_expect_double_range(mpack_reader_t* reader, double min_value, double max_value);
inline unsigned int mpack_expect_uint(mpack_reader_t* reader) {
    if (sizeof(unsigned int) == 4)
        return (unsigned int)mpack_expect_u32(reader);
    return (unsigned int)mpack_expect_u64_max(reader, (2147483647 *2U +1U));
}
inline int mpack_expect_int(mpack_reader_t* reader) {
    if (sizeof(int) == 4)
        return (int)mpack_expect_i32(reader);
    return (int)mpack_expect_i64_range(reader, (-2147483647 -1), 2147483647);
}
void mpack_expect_uint_match(mpack_reader_t* reader, uint64_t value);
void mpack_expect_int_match(mpack_reader_t* reader, int64_t value);
void mpack_expect_nil(mpack_reader_t* reader);
_Bool mpack_expect_bool(mpack_reader_t* reader);
void mpack_expect_true(mpack_reader_t* reader);
void mpack_expect_false(mpack_reader_t* reader);
mpack_timestamp_t mpack_expect_timestamp(mpack_reader_t* reader);
int64_t mpack_expect_timestamp_truncate(mpack_reader_t* reader);
uint32_t mpack_expect_map(mpack_reader_t* reader);
uint32_t mpack_expect_map_range(mpack_reader_t* reader, uint32_t min_count, uint32_t max_count);
inline uint32_t mpack_expect_map_max(mpack_reader_t* reader, uint32_t max_count) {
    return mpack_expect_map_range(reader, 0, max_count);
}
void mpack_expect_map_match(mpack_reader_t* reader, uint32_t count);
_Bool mpack_expect_map_or_nil(mpack_reader_t* reader, uint32_t* count);
_Bool mpack_expect_map_max_or_nil(mpack_reader_t* reader, uint32_t max_count, uint32_t* count);
uint32_t mpack_expect_array(mpack_reader_t* reader);
uint32_t mpack_expect_array_range(mpack_reader_t* reader, uint32_t min_count, uint32_t max_count);
inline uint32_t mpack_expect_array_max(mpack_reader_t* reader, uint32_t max_count) {
    return mpack_expect_array_range(reader, 0, max_count);
}
void mpack_expect_array_match(mpack_reader_t* reader, uint32_t count);
_Bool mpack_expect_array_or_nil(mpack_reader_t* reader, uint32_t* count);
_Bool mpack_expect_array_max_or_nil(mpack_reader_t* reader, uint32_t max_count, uint32_t* count);
void* mpack_expect_array_alloc_impl(mpack_reader_t* reader,
        size_t element_size, uint32_t max_count, uint32_t* out_count, _Bool allow_nil);
uint32_t mpack_expect_str(mpack_reader_t* reader);
size_t mpack_expect_str_buf(mpack_reader_t* reader, char* buf, size_t bufsize);
size_t mpack_expect_utf8(mpack_reader_t* reader, char* buf, size_t bufsize);
inline uint32_t mpack_expect_str_max(mpack_reader_t* reader, uint32_t maxsize) {
    uint32_t length = mpack_expect_str(reader);
    if (length > maxsize) {
        mpack_reader_flag_error(reader, mpack_error_too_big);
        return 0;
    }
    return length;
}
inline void mpack_expect_str_length(mpack_reader_t* reader, uint32_t count) {
    if (mpack_expect_str(reader) != count)
        mpack_reader_flag_error(reader, mpack_error_type);
}
void mpack_expect_str_match(mpack_reader_t* reader, const char* str, size_t length);
void mpack_expect_cstr(mpack_reader_t* reader, char* buf, size_t size);
void mpack_expect_utf8_cstr(mpack_reader_t* reader, char* buf, size_t size);
char* mpack_expect_cstr_alloc(mpack_reader_t* reader, size_t maxsize);
char* mpack_expect_utf8_cstr_alloc(mpack_reader_t* reader, size_t maxsize);
inline void mpack_expect_cstr_match(mpack_reader_t* reader, const char* cstr) {
    ((!(cstr != ((void*)0))) ? (__builtin_unreachable(), (void)0) : (void)0);
    mpack_expect_str_match(reader, cstr, strlen(cstr));
}
uint32_t mpack_expect_bin(mpack_reader_t* reader);
inline uint32_t mpack_expect_bin_max(mpack_reader_t* reader, uint32_t maxsize) {
    uint32_t length = mpack_expect_bin(reader);
    if (length > maxsize) {
        mpack_reader_flag_error(reader, mpack_error_type);
        return 0;
    }
    return length;
}
inline void mpack_expect_bin_size(mpack_reader_t* reader, uint32_t count) {
    if (mpack_expect_bin(reader) != count)
        mpack_reader_flag_error(reader, mpack_error_type);
}
size_t mpack_expect_bin_buf(mpack_reader_t* reader, char* buf, size_t size);
void mpack_expect_bin_size_buf(mpack_reader_t* reader, char* buf, uint32_t size);
char* mpack_expect_bin_alloc(mpack_reader_t* reader, size_t maxsize, size_t* size);
uint32_t mpack_expect_ext(mpack_reader_t* reader, int8_t* type);
inline uint32_t mpack_expect_ext_max(mpack_reader_t* reader, int8_t* type, uint32_t maxsize) {
    uint32_t length = mpack_expect_ext(reader, type);
    if (length > maxsize) {
        mpack_reader_flag_error(reader, mpack_error_type);
        return 0;
    }
    return length;
}
inline void mpack_expect_ext_size(mpack_reader_t* reader, int8_t* type, uint32_t count) {
    if (mpack_expect_ext(reader, type) != count) {
        *type = 0;
        mpack_reader_flag_error(reader, mpack_error_type);
    }
}
size_t mpack_expect_ext_buf(mpack_reader_t* reader, int8_t* type, char* buf, size_t size);
char* mpack_expect_ext_alloc(mpack_reader_t* reader, int8_t* type, size_t maxsize, size_t* size);
void mpack_expect_tag(mpack_reader_t* reader, mpack_tag_t tag);
size_t mpack_expect_enum(mpack_reader_t* reader, const char* strings[], size_t count);
size_t mpack_expect_enum_optional(mpack_reader_t* reader, const char* strings[], size_t count);
size_t mpack_expect_key_uint(mpack_reader_t* reader, _Bool found[], size_t count);
size_t mpack_expect_key_cstr(mpack_reader_t* reader, const char* keys[],
        _Bool found[], size_t count);
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef struct mpack_node_t mpack_node_t;
typedef struct mpack_node_data_t mpack_node_data_t;
typedef struct mpack_tree_t mpack_tree_t;
typedef void (*mpack_tree_error_t)(mpack_tree_t* tree, mpack_error_t error);
typedef size_t (*mpack_tree_read_t)(mpack_tree_t* tree, char* buffer, size_t count);
typedef void (*mpack_tree_teardown_t)(mpack_tree_t* tree);
struct mpack_node_t {
    mpack_node_data_t* data;
    mpack_tree_t* tree;
};
struct mpack_node_data_t {
    mpack_type_t type;
    uint32_t len;
    union {
        _Bool b;
        float f;
        double d;
        int64_t i;
        uint64_t u;
        size_t offset;
        mpack_node_data_t* children;
    } value;
};
typedef struct mpack_tree_page_t {
    struct mpack_tree_page_t* next;
    mpack_node_data_t nodes[1];
} mpack_tree_page_t;
typedef enum mpack_tree_parse_state_t {
    mpack_tree_parse_state_not_started,
    mpack_tree_parse_state_in_progress,
    mpack_tree_parse_state_parsed,
} mpack_tree_parse_state_t;
typedef struct mpack_level_t {
    mpack_node_data_t* child;
    size_t left;
} mpack_level_t;
typedef struct mpack_tree_parser_t {
    mpack_tree_parse_state_t state;
    size_t possible_nodes_left;
    mpack_node_data_t* nodes;
    size_t nodes_left;
    size_t current_node_reserved;
    size_t level;
    mpack_level_t* stack;
    size_t stack_capacity;
    _Bool stack_owned;
    mpack_level_t stack_local[8];
} mpack_tree_parser_t;
struct mpack_tree_t {
    mpack_tree_error_t error_fn;
    mpack_tree_read_t read_fn;
    mpack_tree_teardown_t teardown;
    void* context;
    mpack_node_data_t nil_node;
    mpack_node_data_t missing_node;
    mpack_error_t error;
    char* buffer;
    size_t buffer_capacity;
    const char* data;
    size_t data_length;
    size_t size;
    size_t node_count;
    size_t max_size;
    size_t max_nodes;
    mpack_tree_parser_t parser;
    mpack_node_data_t* root;
    mpack_node_data_t* pool;
    size_t pool_count;
    mpack_tree_page_t* next;
};
inline mpack_node_t mpack_node(mpack_tree_t* tree, mpack_node_data_t* data) {
    mpack_node_t node;
    node.data = data;
    node.tree = tree;
    return node;
}
inline mpack_node_data_t* mpack_node_child(mpack_node_t node, size_t child) {
    return node.data->value.children + child;
}
inline mpack_node_t mpack_tree_nil_node(mpack_tree_t* tree) {
    return mpack_node(tree, &tree->nil_node);
}
inline mpack_node_t mpack_tree_missing_node(mpack_tree_t* tree) {
    return mpack_node(tree, &tree->missing_node);
}
void mpack_tree_init_data(mpack_tree_t* tree, const char* data, size_t length);
inline void mpack_tree_init(mpack_tree_t* tree, const char* data, size_t length) {
    mpack_tree_init_data(tree, data, length);
}
void mpack_tree_init_stream(mpack_tree_t* tree, mpack_tree_read_t read_fn, void* context,
        size_t max_message_size, size_t max_message_nodes);
void mpack_tree_init_pool(mpack_tree_t* tree, const char* data, size_t length,
        mpack_node_data_t* node_pool, size_t node_pool_count);
void mpack_tree_init_error(mpack_tree_t* tree, mpack_error_t error);
void mpack_tree_init_filename(mpack_tree_t* tree, const char* filename, size_t max_bytes);
inline void mpack_tree_init_file(mpack_tree_t* tree, const char* filename, size_t max_bytes) {
    mpack_tree_init_filename(tree, filename, max_bytes);
}
void mpack_tree_init_stdfile(mpack_tree_t* tree, FILE* stdfile, size_t max_bytes, _Bool close_when_done);
void mpack_tree_set_limits(mpack_tree_t* tree, size_t max_message_size,
        size_t max_message_nodes);
void mpack_tree_parse(mpack_tree_t* tree);
_Bool mpack_tree_try_parse(mpack_tree_t* tree);
mpack_node_t mpack_tree_root(mpack_tree_t* tree);
inline mpack_error_t mpack_tree_error(mpack_tree_t* tree) {
    return tree->error;
}
inline size_t mpack_tree_size(mpack_tree_t* tree) {
    return tree->size;
}
mpack_error_t mpack_tree_destroy(mpack_tree_t* tree);
inline void mpack_tree_set_context(mpack_tree_t* tree, void* context) {
    tree->context = context;
}
inline void* mpack_tree_context(mpack_tree_t* tree) {
    return tree->context;
}
inline void mpack_tree_set_error_handler(mpack_tree_t* tree, mpack_tree_error_t error_fn) {
    tree->error_fn = error_fn;
}
inline void mpack_tree_set_teardown(mpack_tree_t* tree, mpack_tree_teardown_t teardown) {
    tree->teardown = teardown;
}
void mpack_tree_flag_error(mpack_tree_t* tree, mpack_error_t error);
void mpack_node_flag_error(mpack_node_t node, mpack_error_t error);
inline mpack_error_t mpack_node_error(mpack_node_t node) {
    return mpack_tree_error(node.tree);
}
mpack_tag_t mpack_node_tag(mpack_node_t node);
mpack_type_t mpack_node_type(mpack_node_t node);
_Bool mpack_node_is_nil(mpack_node_t node);
_Bool mpack_node_is_missing(mpack_node_t node);
void mpack_node_nil(mpack_node_t node);
void mpack_node_missing(mpack_node_t node);
_Bool mpack_node_bool(mpack_node_t node);
void mpack_node_true(mpack_node_t node);
void mpack_node_false(mpack_node_t node);
uint8_t mpack_node_u8(mpack_node_t node);
int8_t mpack_node_i8(mpack_node_t node);
uint16_t mpack_node_u16(mpack_node_t node);
int16_t mpack_node_i16(mpack_node_t node);
uint32_t mpack_node_u32(mpack_node_t node);
int32_t mpack_node_i32(mpack_node_t node);
uint64_t mpack_node_u64(mpack_node_t node);
int64_t mpack_node_i64(mpack_node_t node);
unsigned int mpack_node_uint(mpack_node_t node);
int mpack_node_int(mpack_node_t node);
float mpack_node_float(mpack_node_t node);
double mpack_node_double(mpack_node_t node);
float mpack_node_float_strict(mpack_node_t node);
double mpack_node_double_strict(mpack_node_t node);
mpack_timestamp_t mpack_node_timestamp(mpack_node_t node);
int64_t mpack_node_timestamp_seconds(mpack_node_t node);
uint32_t mpack_node_timestamp_nanoseconds(mpack_node_t node);
void mpack_node_check_utf8(mpack_node_t node);
void mpack_node_check_utf8_cstr(mpack_node_t node);
int8_t mpack_node_exttype(mpack_node_t node);
size_t mpack_node_bin_size(mpack_node_t node);
uint32_t mpack_node_data_len(mpack_node_t node);
size_t mpack_node_strlen(mpack_node_t node);
const char* mpack_node_str(mpack_node_t node);
const char* mpack_node_data(mpack_node_t node);
const char* mpack_node_bin_data(mpack_node_t node);
size_t mpack_node_copy_data(mpack_node_t node, char* buffer, size_t bufsize);
size_t mpack_node_copy_utf8(mpack_node_t node, char* buffer, size_t bufsize);
void mpack_node_copy_cstr(mpack_node_t node, char* buffer, size_t size);
void mpack_node_copy_utf8_cstr(mpack_node_t node, char* buffer, size_t size);
char* mpack_node_data_alloc(mpack_node_t node, size_t maxsize);
char* mpack_node_cstr_alloc(mpack_node_t node, size_t maxsize);
char* mpack_node_utf8_cstr_alloc(mpack_node_t node, size_t maxsize);
size_t mpack_node_enum(mpack_node_t node, const char* strings[], size_t count);
size_t mpack_node_enum_optional(mpack_node_t node, const char* strings[], size_t count);
size_t mpack_node_array_length(mpack_node_t node);
mpack_node_t mpack_node_array_at(mpack_node_t node, size_t index);
size_t mpack_node_map_count(mpack_node_t node);
mpack_node_t mpack_node_map_key_at(mpack_node_t node, size_t index);
mpack_node_t mpack_node_map_value_at(mpack_node_t node, size_t index);
mpack_node_t mpack_node_map_int(mpack_node_t node, int64_t num);
mpack_node_t mpack_node_map_int_optional(mpack_node_t node, int64_t num);
mpack_node_t mpack_node_map_uint(mpack_node_t node, uint64_t num);
mpack_node_t mpack_node_map_uint_optional(mpack_node_t node, uint64_t num);
mpack_node_t mpack_node_map_str(mpack_node_t node, const char* str, size_t length);
mpack_node_t mpack_node_map_str_optional(mpack_node_t node, const char* str, size_t length);
mpack_node_t mpack_node_map_cstr(mpack_node_t node, const char* cstr);
mpack_node_t mpack_node_map_cstr_optional(mpack_node_t node, const char* cstr);
_Bool mpack_node_map_contains_int(mpack_node_t node, int64_t num);
_Bool mpack_node_map_contains_uint(mpack_node_t node, uint64_t num);
_Bool mpack_node_map_contains_str(mpack_node_t node, const char* str, size_t length);
_Bool mpack_node_map_contains_cstr(mpack_node_t node, const char* cstr);
#pragma GCC diagnostic pop
struct ctrace_opts {
    int _make_windows_happy;
};
struct ctrace {
    uint64_t last_span_id;
    struct cfl_list resource_spans;
    struct cfl_list span_list;
    int log_level;
    void (*log_cb)(void *, int, const char *, int, const char *);
};
struct ctrace *ctr_create(struct ctrace_opts *opts);
void ctr_destroy(struct ctrace *ctx);
void ctr_opts_init(struct ctrace_opts *opts);
void ctr_opts_set(struct ctrace_opts *opts, int value, char *val);
void ctr_opts_exit(struct ctrace_opts *opts);
struct ctrace_id {
    cfl_sds_t buf;
};
struct ctrace_id *ctr_id_create_random(size_t size);
struct ctrace_id *ctr_id_create(void *buf, size_t len);
void ctr_id_destroy(struct ctrace_id *cid);
int ctr_id_set(struct ctrace_id *cid, void *buf, size_t len);
int ctr_id_cmp(struct ctrace_id *cid1, struct ctrace_id *cid2);
size_t ctr_id_get_len(struct ctrace_id *cid);
void *ctr_id_get_buf(struct ctrace_id *cid);
cfl_sds_t ctr_id_to_lower_base16(struct ctrace_id *cid);
struct ctrace_id *ctr_id_from_base16(cfl_sds_t id);

ssize_t ctr_random_get(void *buf, size_t len);
char *ctr_version();

struct ctrace_resource {
    uint32_t dropped_attr_count;
    struct ctrace_attributes *attr;
};
struct ctrace_resource_span {
    struct ctrace_resource *resource;
    struct cfl_list scope_spans;
    cfl_sds_t schema_url;
    struct cfl_list _head;
    struct ctrace *ctx;
};
struct ctrace_resource *ctr_resource_create();
struct ctrace_resource *ctr_resource_create_default();
int ctr_resource_set_attributes(struct ctrace_resource *res, struct ctrace_attributes *attr);
void ctr_resource_set_dropped_attr_count(struct ctrace_resource *res, uint32_t count);
void ctr_resource_destroy(struct ctrace_resource *res);
struct ctrace_resource_span *ctr_resource_span_create(struct ctrace *ctx);
struct ctrace_resource *ctr_resource_span_get_resource(struct ctrace_resource_span *resource_span);
int ctr_resource_span_set_schema_url(struct ctrace_resource_span *resource_span, char *url);
void ctr_resource_span_destroy(struct ctrace_resource_span *resource_span);

struct ctrace_instrumentation_scope {
    cfl_sds_t name;
    cfl_sds_t version;
    uint32_t dropped_attr_count;
    struct ctrace_attributes *attr;
};
struct ctrace_scope_span {
    struct ctrace_instrumentation_scope *instrumentation_scope;
    struct cfl_list spans;
    cfl_sds_t schema_url;
    struct ctrace_resource_span *resource_span;
    struct cfl_list _head;
};
struct ctrace_scope_span *ctr_scope_span_create(struct ctrace_resource_span *resource_span);
void ctr_scope_span_destroy(struct ctrace_scope_span *scope_span);
int ctr_scope_span_set_schema_url(struct ctrace_scope_span *scope_span, char *url);
void ctr_scope_span_set_instrumentation_scope(struct ctrace_scope_span *scope_span, struct ctrace_instrumentation_scope *ins_scope);
struct ctrace_instrumentation_scope *ctr_instrumentation_scope_create(char *name, char *version,
                                                                      uint32_t dropped_attr_count,
                                                                      struct ctrace_attributes *attr);
void ctr_instrumentation_scope_destroy(struct ctrace_instrumentation_scope *ins_scope);
struct ctrace_span_status {
    int code;
    cfl_sds_t message;
};
struct ctrace_span_event {
    uint64_t time_unix_nano;
    cfl_sds_t name;
    struct ctrace_attributes *attr;
    uint32_t dropped_attr_count;
    struct cfl_list _head;
};
struct ctrace_span {
    struct ctrace_id *trace_id;
    struct ctrace_id *span_id;
    struct ctrace_id *parent_span_id;
    cfl_sds_t trace_state;
    uint32_t flags;
    cfl_sds_t name;
    int kind;
    uint64_t start_time_unix_nano;
    uint64_t end_time_unix_nano;
    struct ctrace_attributes *attr;
    uint32_t dropped_attr_count;
    struct cfl_list events;
    uint32_t dropped_events_count;
    struct cfl_list links;
    uint32_t dropped_links_count;
    cfl_sds_t schema_url;
    struct ctrace_span_status status;
    struct cfl_list _head;
    struct cfl_list _head_global;
    struct ctrace_scope_span *scope_span;
    struct ctrace *ctx;
};
struct ctrace_span *ctr_span_create(struct ctrace *ctx, struct ctrace_scope_span *scope_span, cfl_sds_t name,
                                    struct ctrace_span *parent);
void ctr_span_destroy(struct ctrace_span *span);
int ctr_span_set_status(struct ctrace_span *span, int code, char *message);
void ctr_span_set_dropped_events_count(struct ctrace_span *span, uint32_t count);
void ctr_span_set_dropped_links_count(struct ctrace_span *span, uint32_t count);
int ctr_span_set_trace_state(struct ctrace_span *span, char *state, int len);
int ctr_span_set_flags(struct ctrace_span *span, uint32_t flags);
void ctr_span_set_schema_url(struct ctrace_span *span, char *url);
int ctr_span_set_trace_id(struct ctrace_span *span, void *buf, size_t len);
int ctr_span_set_trace_id_with_cid(struct ctrace_span *span, struct ctrace_id *cid);
int ctr_span_set_span_id(struct ctrace_span *span, void *buf, size_t len);
int ctr_span_set_span_id_with_cid(struct ctrace_span *span, struct ctrace_id *cid);
int ctr_span_set_parent_span_id(struct ctrace_span *span, void *buf, size_t len);
int ctr_span_set_parent_span_id_with_cid(struct ctrace_span *span, struct ctrace_id *cid);
int ctr_span_set_attributes(struct ctrace_span *span, struct ctrace_attributes *attr);
int ctr_span_set_attribute_string(struct ctrace_span *span, char *key, char *value);
int ctr_span_set_attribute_bool(struct ctrace_span *span, char *key, int b);
int ctr_span_set_attribute_int64(struct ctrace_span *span, char *key, int64_t value);
int ctr_span_set_attribute_double(struct ctrace_span *span, char *key, double value);
int ctr_span_set_attribute_array(struct ctrace_span *span, char *key,
                                 struct cfl_array *value);
int ctr_span_set_attribute_kvlist(struct ctrace_span *span, char *key,
                                  struct cfl_kvlist *value);
void ctr_span_set_dropped_attributes_count(struct ctrace_span *span, uint32_t count);
void ctr_span_start(struct ctrace *ctx, struct ctrace_span *span);
void ctr_span_start_ts(struct ctrace *ctx, struct ctrace_span *span, uint64_t ts);
void ctr_span_end(struct ctrace *ctx, struct ctrace_span *span);
void ctr_span_end_ts(struct ctrace *ctx, struct ctrace_span *span, uint64_t ts);
int ctr_span_kind_set(struct ctrace_span *span, int kind);
char *ctr_span_kind_string(struct ctrace_span *span);
struct ctrace_span_event *ctr_span_event_add(struct ctrace_span *span, char *name);
struct ctrace_span_event *ctr_span_event_add_ts(struct ctrace_span *span, char *name, uint64_t ts);
int ctr_span_event_set_attributes(struct ctrace_span_event *event, struct ctrace_attributes *attr);
void ctr_span_event_set_dropped_attributes_count(struct ctrace_span_event *event, uint32_t count);
void ctr_span_event_delete(struct ctrace_span_event *event);
int ctr_span_event_set_attribute_string(struct ctrace_span_event *event, char *key, char *value);
int ctr_span_event_set_attribute_bool(struct ctrace_span_event *event, char *key, int b);
int ctr_span_event_set_attribute_int(struct ctrace_span_event *event, char *key, int value);
int ctr_span_event_set_attribute_int64(struct ctrace_span_event *event, char *key,
                                       int64_t value);
int ctr_span_event_set_attribute_double(struct ctrace_span_event *event, char *key, double value);
int ctr_span_event_set_attribute_array(struct ctrace_span_event *event, char *key,
                                       struct cfl_array *value);
int ctr_span_event_set_attribute_kvlist(struct ctrace_span_event *event, char *key,
                                        struct cfl_kvlist *value);


struct ctrace_link {
 struct ctrace_id *trace_id;
    struct ctrace_id *span_id;
 cfl_sds_t trace_state;
    struct ctrace_attributes *attr;
    uint32_t dropped_attr_count;
    uint32_t flags;
    struct cfl_list _head;
};
struct ctrace_link *ctr_link_create(struct ctrace_span *span,
                                    void *trace_id_buf, size_t trace_id_len,
                                    void *span_id_buf, size_t span_id_len);
struct ctrace_link *ctr_link_create_with_cid(struct ctrace_span *span,
                                             struct ctrace_id *trace_id_cid,
                struct ctrace_id *span_id_cid);
int ctr_link_set_trace_state(struct ctrace_link *link, char *trace_state);
int ctr_link_set_attributes(struct ctrace_link *link, struct ctrace_attributes *attr);
void ctr_link_set_dropped_attr_count(struct ctrace_link *link, uint32_t count);
void ctr_link_set_flags(struct ctrace_link *link, uint32_t flags);
void ctr_link_destroy(struct ctrace_link *link);
struct ctrace_attributes {
    struct cfl_kvlist *kv;
};
struct ctrace_attributes *ctr_attributes_create();
void ctr_attributes_destroy(struct ctrace_attributes *attr);
int ctr_attributes_count(struct ctrace_attributes *attr);
int ctr_attributes_set_string(struct ctrace_attributes *attr, char *key, char *value);
int ctr_attributes_set_bool(struct ctrace_attributes *attr, char *key, int b);
int ctr_attributes_set_int64(struct ctrace_attributes *attr, char *key, int64_t value);
int ctr_attributes_set_double(struct ctrace_attributes *attr, char *key, double value);
int ctr_attributes_set_array(struct ctrace_attributes *attr, char *key,
                             struct cfl_array *value);
int ctr_attributes_set_kvlist(struct ctrace_attributes *attr, char *key,
                              struct cfl_kvlist *value);
void ctr_log_print(void *ctx, int level, const char *file, int line,
                     const char *fmt, ...);
int ctr_errno_print(int errnum, const char *file, int line);

cfl_sds_t ctr_encode_text_create(struct ctrace *ctx);
void ctr_encode_text_destroy(cfl_sds_t text);

int ctr_encode_msgpack_create(struct ctrace *ctx, char **out_buf, size_t *out_size);
void ctr_encode_msgpack_destroy(char *buf);

cfl_sds_t ctr_encode_opentelemetry_create(struct ctrace *ctr);
void ctr_encode_opentelemetry_destroy(cfl_sds_t text);
typedef enum {
    CTR_OPENTELEMETRY_TYPE_ATTRIBUTE = 0,
    CTR_OPENTELEMETRY_TYPE_ARRAY = 1,
    CTR_OPENTELEMETRY_TYPE_KVLIST = 2,
} opentelemetry_decode_value_type;
struct opentelemetry_decode_value {
    opentelemetry_decode_value_type type;
    union {
        struct ctrace_attributes *ctr_attr;
        struct cfl_array *cfl_arr;
        struct cfl_kvlist *cfl_kvlist;
    };
};
int ctr_decode_opentelemetry_create(struct ctrace **out_ctr, char *in_buf, size_t in_size,
                                    size_t *offset);
void ctr_decode_opentelemetry_destroy(struct ctrace *ctr);

int flb_input_trace_append(struct flb_input_instance *ins,
                           const char *tag, size_t tag_len,
                           struct ctrace *ctr);
int flb_input_trace_append_skip_processor_stages(
        struct flb_input_instance *ins,
        size_t processor_starting_stage,
        const char *tag, size_t tag_len,
        struct ctrace *ctr);

enum aggregation_temporality {
    CPROF_AGGREGATION_TEMPORALITY_UNSPECIFIED = 0,
    CPROF_AGGREGATION_TEMPORALITY_DELTA = 1,
    CPROF_AGGREGATION_TEMPORALITY_CUMULATIVE = 2
};
struct cprof_value_type {
    int64_t type;
    int64_t unit;
    int aggregation_temporality;
    struct cfl_list _head;
};
struct cprof_sample {
    uint64_t *location_index;
    size_t location_index_count;
    size_t location_index_size;
    uint64_t locations_start_index;
    uint64_t locations_length;
    int64_t *values;
    size_t value_count;
    size_t value_size;
    uint64_t *attributes;
    size_t attributes_count;
    size_t attributes_size;
    uint64_t link;
    uint64_t *timestamps_unix_nano;
    size_t timestamps_count;
    size_t timestamps_size;
    struct cfl_list _head;
};
struct cprof_mapping {
    uint64_t id;
    uint64_t memory_start;
    uint64_t memory_limit;
    uint64_t file_offset;
    int64_t filename;
    uint64_t *attributes;
    size_t attributes_count;
    size_t attributes_size;
    _Bool has_functions;
    _Bool has_filenames;
    _Bool has_line_numbers;
    _Bool has_inline_frames;
    struct cfl_list _head;
};
struct cprof_line {
    uint64_t function_index;
    int64_t line;
    int64_t column;
    struct cfl_list _head;
};
struct cprof_location {
    uint64_t id;
    uint64_t mapping_index;
    uint64_t address;
    struct cfl_list lines;
    _Bool is_folded;
    uint64_t *attributes;
    size_t attributes_count;
    size_t attributes_size;
    struct cfl_list _head;
};
struct cprof_function {
    uint64_t id;
    int64_t name;
    int64_t system_name;
    int64_t filename;
    int64_t start_line;
    struct cfl_list _head;
};
struct cprof_attribute_unit {
    int64_t attribute_key;
    int64_t unit;
    struct cfl_list _head;
};
struct cprof_link {
    uint8_t trace_id[16];
    uint8_t span_id[8];
    struct cfl_list _head;
};
struct cprof_profile {
    uint8_t profile_id[16];
    int64_t start_time_unix_nano;
    int64_t end_time_unix_nano;
    struct cfl_kvlist *attributes;
    uint32_t dropped_attributes_count;
    cfl_sds_t original_payload_format;
    cfl_sds_t original_payload;
    struct cfl_list sample_type;
    struct cfl_list samples;
    struct cfl_list mappings;
    struct cfl_list locations;
    int64_t *location_indices;
    size_t location_indices_count;
    size_t location_indices_size;
    struct cfl_list functions;
    struct cfl_kvlist *attribute_table;
    struct cfl_list attribute_units;
    struct cfl_list link_table;
    cfl_sds_t *string_table;
    size_t string_table_count;
    size_t string_table_size;
    int64_t drop_frames;
    int64_t keep_frames;
    int64_t time_nanos;
    int64_t duration_nanos;
    struct cprof_value_type period_type;
    int64_t period;
    int64_t *comments;
    size_t comments_count;
    size_t comments_size;
    int64_t default_sample_type;
    struct cfl_list _head;
};
struct cprof_resource_profiles {
    struct cprof_resource *resource;
    struct cfl_list scope_profiles;
    cfl_sds_t schema_url;
    struct cfl_list _head;
};
struct cprof_instrumentation_scope {
    cfl_sds_t name;
    cfl_sds_t version;
    struct cfl_kvlist *attributes;
    uint32_t dropped_attributes_count;
};
struct cprof_resource {
    struct cfl_kvlist *attributes;
    uint32_t dropped_attributes_count;
};
struct cprof_scope_profiles {
    struct cprof_instrumentation_scope *scope;
    struct cfl_list profiles;
    cfl_sds_t schema_url;
    struct cfl_list _head;
};
struct cprof {
    struct cfl_list profiles;
    struct cfl_list _head;
};
struct cprof *cprof_create();
void cprof_destroy(struct cprof *cprof);
char *cprof_version();
struct cprof_profile *cprof_profile_create();
int cprof_profile_add_location_index(struct cprof_profile *profile, int64_t index);
void cprof_profile_destroy(struct cprof_profile *instance);
size_t cprof_profile_string_add(struct cprof_profile *profile, char *str, int str_len);
int cprof_profile_add_comment(struct cprof_profile *profile, int64_t comment);
struct cprof_attribute_unit *cprof_attribute_unit_create(struct cprof_profile *profile);
void cprof_attribute_unit_destroy(struct cprof_attribute_unit *instance);
struct cprof_mapping *cprof_mapping_create(struct cprof_profile *profile);
void cprof_mapping_destroy(struct cprof_mapping *instance);
int cprof_mapping_add_attribute(struct cprof_mapping *mapping, uint64_t attribute);
struct cprof_line *cprof_line_create(struct cprof_location *location);
void cprof_line_destroy(struct cprof_line *instance);
struct cprof_location *cprof_location_create(struct cprof_profile *profile);
int cprof_location_add_attribute(struct cprof_location *location, uint64_t attribute);
void cprof_location_destroy(struct cprof_location *instance);
struct cprof_resource *cprof_resource_create(struct cfl_kvlist *attributes);
void cprof_resource_destroy(struct cprof_resource *resource);
int cprof_resource_profiles_add(struct cprof *context,
                                struct cprof_resource_profiles *resource_profiles);
struct cprof_instrumentation_scope *cprof_instrumentation_scope_create(
                                        char *name,
                                        char *version,
                                        struct cfl_kvlist *attributes,
                                        uint32_t dropped_attributes_count);
void cprof_instrumentation_scope_destroy(
            struct cprof_instrumentation_scope *instance);
struct cprof_scope_profiles *cprof_scope_profiles_create(
    struct cprof_resource_profiles *resource_profiles,
    char *schema_url);
void cprof_scope_profiles_destroy(struct cprof_scope_profiles *instance);
struct cprof_resource_profiles *cprof_resource_profiles_create(char *schema_url);
void cprof_resource_profiles_destroy(struct cprof_resource_profiles *instance);
struct cprof_function *cprof_function_create(struct cprof_profile *profile);
void cprof_function_destroy(struct cprof_function *instance);
struct cprof_link *cprof_link_create(struct cprof_profile *profile);
void cprof_link_destroy(struct cprof_link *instance);
struct cprof_sample *cprof_sample_create(struct cprof_profile *profile);
void cprof_sample_destroy(struct cprof_sample *sample);
void cprof_sample_destroy_all(struct cprof_profile *profile);
int cprof_sample_add_timestamp(struct cprof_sample *sample, uint64_t timestamp);
int cprof_sample_add_value(struct cprof_sample *sample, int64_t value);
int cprof_sample_add_location_index(struct cprof_sample *sample, uint64_t location_index);
int cprof_sample_add_attribute(struct cprof_sample *sample, uint64_t attribute);
void cprof_sample_type_destroy(struct cprof_value_type *sample_type);
void cprof_sample_type_destroy_all(struct cprof_profile *profile);
struct cprof_value_type *cprof_sample_type_create(struct cprof_profile *profile,
                                                  int64_t type, int64_t unit, int aggregation_temporality);
struct cprof_value_type *cprof_sample_type_str_create(struct cprof_profile *profile,
                                                      char *type_str, char *unit_str,
                                                      int aggregation_temporality);

int flb_input_profiles_append(struct flb_input_instance *ins,
                              const char *tag, size_t tag_len,
                              struct cprof *profiles_context);
int flb_input_profiles_append_skip_processor_stages(
        struct flb_input_instance *ins,
        size_t processor_starting_stage,
        const char *tag, size_t tag_len,
        struct cprof *profiles_context);
enum cf_file_format {
    FLB_CF_FLUENTBIT,
    FLB_CF_YAML
};
enum section_type {
    FLB_CF_SERVICE = 0,
    FLB_CF_PARSER,
    FLB_CF_MULTILINE_PARSER,
    FLB_CF_STREAM_PROCESSOR,
    FLB_CF_PLUGINS,
    FLB_CF_UPSTREAM_SERVERS,
    FLB_CF_CUSTOM,
    FLB_CF_INPUT,
    FLB_CF_FILTER,
    FLB_CF_OUTPUT,
    FLB_CF_OTHER,
};
struct flb_cf_group {
    flb_sds_t name;
    struct cfl_kvlist *properties;
    struct mk_list _head;
};
struct flb_cf_section {
    int type;
    flb_sds_t name;
    struct cfl_kvlist *properties;
    struct mk_list groups;
    struct mk_list _head;
    struct mk_list _head_section;
};
struct flb_cf {
    int format;
    struct flb_cf_section *service;
    struct mk_list env;
    struct mk_list metas;
    struct mk_list parsers;
    struct mk_list multiline_parsers;
    struct mk_list stream_processors;
    struct mk_list plugins;
    struct mk_list upstream_servers;
    struct mk_list customs;
    struct mk_list inputs;
    struct mk_list filters;
    struct mk_list outputs;
    struct mk_list others;
    struct mk_list sections;
    char *error_str;
    struct mk_list _head;
};
struct flb_cf *flb_cf_create();
struct flb_cf *flb_cf_create_from_file(struct flb_cf *cf, char *file);
flb_sds_t flb_cf_key_translate(struct flb_cf *cf, char *key, int len);
void flb_cf_destroy(struct flb_cf *cf);
int flb_cf_set_origin_format(struct flb_cf *cf, int format);
void flb_cf_dump(struct flb_cf *cf);
struct flb_cf_env_var {
    flb_sds_t name;
    flb_sds_t value;
    flb_sds_t uri;
    int refresh_interval;
    struct mk_list _head;
};
struct flb_cf_env_var *flb_cf_env_var_add(struct flb_cf *cf,
                                          char *name, size_t name_len,
                                          char *value, size_t value_len,
                                          char *uri, size_t uri_len,
                                          int refresh_interval);
struct flb_cf_env_var *flb_cf_env_property_add(struct flb_cf *cf,
                                               char *name, size_t name_len,
                                               char *value, size_t value_len,
                                               char *uri, size_t uri_len,
                                               int refresh_interval);
struct flb_kv *flb_cf_meta_property_add(struct flb_cf *cf, char *meta, int len);
void flb_cf_meta_destroy(struct flb_cf *cf, struct flb_kv *meta);
void flb_cf_meta_destroy_all(struct flb_cf *cf);
struct flb_cf_group *flb_cf_group_create(struct flb_cf *cf, struct flb_cf_section *s,
                                         char *name, int len);
struct flb_cf_group *flb_cf_group_get(struct flb_cf *cf, struct flb_cf_section *s, char *name);
void flb_cf_group_print(struct flb_cf_group *g);
void flb_cf_group_destroy(struct flb_cf_group *g);
struct flb_cf_section *flb_cf_section_create(struct flb_cf *cf, char *name, int len);
struct flb_cf_section *flb_cf_section_get_by_name(struct flb_cf *cf, char *name);
void flb_cf_section_destroy(struct flb_cf *cf, struct flb_cf_section *s);
void flb_cf_section_destroy_all(struct flb_cf *cf);
struct cfl_variant *flb_cf_section_property_add(struct flb_cf *cf,
                                              struct cfl_kvlist *kv_list,
                                              char *k_buf, size_t k_len,
                                              char *v_buf, size_t v_len);
struct cfl_variant *flb_cf_section_property_add_variant(struct flb_cf *cf,
                                                        struct cfl_kvlist *kv_list,
                                                        char *k_buf, size_t k_len,
                                                        struct cfl_variant *variant);
struct cfl_array *flb_cf_section_property_add_list(struct flb_cf *cf,
                                                   struct cfl_kvlist *kv_list,
                                                   char *k_buf, size_t k_len);
struct cfl_variant *flb_cf_section_property_get(struct flb_cf *cf,
                                      struct flb_cf_section *s,
                                      char *key);
char *flb_cf_section_property_get_string(struct flb_cf *cf,
                                         struct flb_cf_section *s,
                                         char *key);
struct flb_cf *flb_cf_fluentbit_create(struct flb_cf *cf,
                                       char *file_path, char *buf, size_t size);
struct flb_cf *flb_cf_yaml_create(struct flb_cf *cf, char *file_path,
                                  char *buf, size_t size);
struct flb_log_event;
struct flb_input_instance;
struct flb_log_event_decoder;
struct flb_log_event_encoder;
struct flb_processor_instance;
struct flb_condition;
struct flb_processor_unit {
    int event_type;
    int unit_type;
    flb_sds_t name;
    size_t stage;
    void *ctx;
    struct flb_condition *condition;
    pthread_mutex_t lock;
    struct mk_list unused_list;
    struct mk_list _head;
    void *parent;
};
struct flb_processor {
    int is_active;
    flb_sds_t name;
    struct mk_list logs;
    struct mk_list metrics;
    struct mk_list traces;
    struct mk_list profiles;
    size_t stage_count;
    void *data;
    int source_plugin_type;
    int notification_channel;
    struct cmt_counter *cmt_invocations;
    struct cmt_counter *cmt_errors;
    struct cmt_counter *cmt_items_in;
    struct cmt_counter *cmt_items_out;
    struct cmt_counter *cmt_items_drop;
    struct cmt_counter *cmt_items_add;
    struct flb_config *config;
};
struct flb_processor_plugin {
    int flags;
    char *name;
    char *description;
    struct flb_config_map *config_map;
    int (*cb_init) (struct flb_processor_instance *,
                    void *,
                    int,
                    struct flb_config *);
    int (*cb_process_logs) (struct flb_processor_instance *,
                            void *,
                            const char *,
                            int);
    int (*cb_process_metrics) (struct flb_processor_instance *,
                               struct cmt *,
                               struct cmt **,
                               const char *,
                               int);
    int (*cb_process_traces) (struct flb_processor_instance *,
                              struct ctrace *,
                              struct ctrace **,
                              const char *,
                              int);
    int (*cb_process_profiles) (struct flb_processor_instance *,
                              struct cprof *,
                              const char *,
                              int);
    int (*cb_exit) (struct flb_processor_instance *, void *);
    int (*cb_notification) (struct flb_processor_instance *, struct flb_config *, void *);
    struct mk_list _head;
};
struct flb_processor_instance {
    int id;
    int log_level;
    int event_type;
    char name[32];
    char *alias;
    void *context;
    void *data;
    struct flb_processor_unit *pu;
    struct flb_processor_plugin *p;
    struct mk_list properties;
    struct mk_list *config_map;
    struct flb_log_event_decoder *log_decoder;
    struct flb_log_event_encoder *log_encoder;
    struct cmt *cmt;
    int notification_channel;
    struct flb_config *config;
};
struct flb_processor *flb_processor_create(struct flb_config *config,
                                           char *name,
                                           void *source_plugin_instance,
                                           int source_plugin_type);
int flb_processor_is_active(struct flb_processor *proc);
int flb_processor_init(struct flb_processor *proc);
void flb_processor_destroy(struct flb_processor *proc);
int flb_processor_run(struct flb_processor *proc,
                      size_t starting_stage,
                      int type,
                      const char *tag, size_t tag_len,
                      void *data, size_t data_size,
                      void **out_buf, size_t *out_size);
struct flb_processor_unit *flb_processor_unit_create(struct flb_processor *proc,
                                                     int event_type,
                                                     char *unit_name);
void flb_processor_unit_destroy(struct flb_processor_unit *pu);
int flb_processor_unit_set_property(struct flb_processor_unit *pu, const char *k, struct cfl_variant *v);
int flb_processor_unit_set_property_str(struct flb_processor_unit *pu, const char *k, const char *v);
int flb_processors_load_from_config_format_group(struct flb_processor *proc, struct flb_cf_group *g);
struct flb_processor_instance *flb_processor_instance_create(struct flb_config *config,
                                                             struct flb_processor_unit *pu,
                                                             int event_type,
                                                             const char *name, void *data);
void flb_processor_instance_destroy(
        struct flb_processor_instance *ins);
int flb_processor_instance_init(
        struct flb_processor_instance *ins,
        void *source_plugin_instance,
        int source_plugin_type,
        struct flb_config *config);
void flb_processor_instance_exit(
        struct flb_processor_instance *ins,
        struct flb_config *config);
void flb_processor_instance_set_context(
        struct flb_processor_instance *ins,
        void *context);
int flb_processor_instance_check_properties(
        struct flb_processor_instance *ins,
        struct flb_config *config);
int flb_processor_instance_set_property(
        struct flb_processor_instance *ins,
        const char *k, struct cfl_variant *v);
const char *flb_processor_instance_get_property(
                const char *key,
                struct flb_processor_instance *ins);
const char *flb_processor_instance_get_name(
                struct flb_processor_instance *ins);
static inline int flb_processor_instance_config_map_set(
                    struct flb_processor_instance *ins,
                    void *context)
{
    return flb_config_map_set(ins->config, &ins->properties, ins->config_map, context);
}
static inline
struct flb_input_instance *flb_processor_get_input_instance(struct flb_processor_unit *pu)
{
        struct flb_processor *processor;
        struct flb_input_instance *ins;
        processor = (struct flb_processor *) pu->parent;
        ins = (struct flb_input_instance *) processor->data;
        return ins;
}
struct mk_list *flb_processor_get_global_config_map(struct flb_config *config);
struct flb_input_instance;
struct flb_sched_timer;
struct flb_http_server_config;
struct flb_test_in_formatter {
    void *rt_ctx;
    int rt_ffd;
    void *format_ctx;
    void (*rt_in_callback) (void *, int, int, void *, size_t, void *);
    void *rt_data;
    int (*callback) (
                     struct flb_config *,
                     struct flb_input_instance *,
                     void *,
                     const void *,
                     size_t,
                     void **,
                     size_t *);
};
struct flb_input_plugin {
    int type;
    void *proxy;
    int flags;
    char *name;
    char *description;
    struct flb_config_map *config_map;
    int (*cb_init) (struct flb_input_instance *, struct flb_config *, void *);
    int (*cb_pre_run) (struct flb_input_instance *, struct flb_config *, void *);
    int (*cb_collect) (struct flb_input_instance *, struct flb_config *, void *);
    int (*cb_notification) (struct flb_input_instance *, struct flb_config *, void *);
    void *(*cb_flush_buf) (void *, size_t *);
    void (*cb_flush_end) (void *);
    void (*cb_pause) (void *, struct flb_config *);
    void (*cb_resume) (void *, struct flb_config *);
    int (*cb_pause_checked) (void *, struct flb_config *);
    int (*cb_resume_checked) (void *, struct flb_config *);
    int (*cb_ingest) (void *in_context, void *, size_t);
    void (*cb_pre_exit) (void *, struct flb_config *);
    int (*cb_exit) (void *, struct flb_config *);
    void (*cb_destroy) (struct flb_input_plugin *);
    struct flb_test_in_formatter test_formatter;
    void *instance;
    struct mk_list _head;
};
struct flb_input_instance {
    struct mk_event event;
    struct flb_processor *processor;
    int flags;
    int id;
    struct flb_chunk_trace_context *chunk_trace_ctxt;
    pthread_mutex_t chunk_trace_lock;
    int log_level;
    int log_suppress_interval;
    int channel[2];
    int runs_in_coroutine;
    char name[32];
    char *alias;
    int test_mode;
    void *context;
    int ch_events[2];
    struct flb_input_plugin *p;
    char *tag;
    int tag_len;
    int tag_default;
    int telemetry_metrics_logs_tag_records;
    int routable;
    int storage_pause_on_chunks_overlimit;
    struct flb_net_host host;
    void *storage;
    int storage_type;
    size_t mem_chunks_size;
    size_t mp_total_buf_size;
    size_t mem_buf_limit;
    int mem_buf_status;
    int storage_buf_status;
    void *data;
    struct mk_list *config_map;
    struct mk_list _head;
    struct cfl_list routes_direct;
    struct cfl_list routes;
    struct mk_list properties;
    struct mk_list collectors;
    struct mk_list chunks;
    struct mk_list chunks_up;
    struct mk_list chunks_down;
    struct mk_list tasks;
    int input_coro_id;
    struct mk_list input_coro_list;
    struct mk_list input_coro_list_destroy;
    struct flb_metrics *metrics;
    struct flb_test_in_formatter test_formatter;
    int is_threaded;
    struct flb_input_thread_instance *thi;
    struct flb_ring_buffer *rb;
    size_t ring_buffer_size;
    uint8_t ring_buffer_window;
    struct mk_list upstreams;
    struct mk_list downstreams;
    struct cmt *cmt;
    struct cmt_counter *cmt_bytes;
    struct cmt_counter *cmt_records;
    struct cmt_counter *cmt_logs_tag_records;
    struct cmt_counter *cmt_logs_tag_records_untracked;
    struct cmt_gauge *cmt_storage_overlimit;
    struct cmt_gauge *cmt_ingestion_paused;
    struct cmt_gauge *cmt_storage_memory_bytes;
    struct cmt_gauge *cmt_storage_chunks;
    struct cmt_gauge *cmt_storage_chunks_up;
    struct cmt_gauge *cmt_storage_chunks_down;
    struct cmt_gauge *cmt_storage_chunks_busy;
    struct cmt_gauge *cmt_storage_chunks_busy_bytes;
    struct cmt_counter *cmt_memrb_dropped_chunks;
    struct cmt_counter *cmt_memrb_dropped_bytes;
    struct cmt_counter *cmt_ring_buffer_writes;
    struct cmt_counter *cmt_ring_buffer_retries;
    struct cmt_counter *cmt_ring_buffer_retry_failures;
    struct cmt_counter *cmt_ingress_queue_busy;
    struct cmt_gauge *cmt_ingress_queue_pending_events;
    struct cmt_gauge *cmt_ingress_queue_pending_bytes;
    struct cmt_gauge *cmt_rate_bytes;
    struct cmt_gauge *cmt_rate_records;
    struct cmt_gauge *cmt_rate_gate_limited;
    struct cmt_gauge *cmt_rate_gate_busy_chunks;
    struct cmt_gauge *cmt_rate_gate_retry_attempts;
    uint64_t rate_window_start;
    uint64_t rate_window_size;
    size_t rate_window_bytes;
    size_t rate_window_records;
    double rate_bytes;
    double rate_records;
    int rate_gate_enabled;
    int rate_gate_status;
    int rate_gate_use_backpressure;
    double rate_gate_resume_ratio;
    size_t rate_gate_max_bytes;
    size_t rate_gate_max_records;
    size_t rate_gate_busy_chunks;
    size_t rate_gate_retry_attempts;
    struct flb_sched_timer *rate_gate_timer;
    struct flb_hash_table *ht_log_chunks;
    struct flb_hash_table *ht_metric_chunks;
    struct flb_hash_table *ht_trace_chunks;
    struct flb_hash_table *ht_profile_chunks;
    pthread_mutex_t metrics_chunk_lock;
    int use_tls;
    int tls_verify;
    int tls_verify_client;
    int tls_verify_hostname;
    int tls_debug;
    char *tls_vhost;
    char *tls_ca_path;
    char *tls_ca_file;
    char *tls_crt_file;
    char *tls_key_file;
    char *tls_key_passwd;
    char *tls_crl_file;
    char *tls_min_version;
    char *tls_max_version;
    char *tls_ciphers;
    struct mk_list *tls_config_map;
    struct flb_tls *tls;
    struct flb_net_setup net_setup;
    struct mk_list *net_config_map;
    struct mk_list net_properties;
    struct mk_list *http_server_config_map;
    struct flb_http_server_config *http_server_config;
    struct mk_list http_server_properties;
    struct mk_list ingress_queue;
    pthread_mutex_t ingress_queue_lock;
    pthread_cond_t ingress_queue_space_available;
    int ingress_queue_channels[2];
    int ingress_queue_enabled;
    int ingress_queue_collector_id;
    int ingress_queue_signal_pending;
    size_t ingress_queue_pending_events;
    size_t ingress_queue_pending_bytes;
    size_t ingress_queue_event_limit;
    size_t ingress_queue_byte_limit;
    struct mk_list *oauth2_jwt_config_map;
    struct mk_list oauth2_jwt_properties;
    int notification_channel;
    struct flb_config *config;
};
struct flb_input_collector {
    struct mk_event event;
    struct mk_event_loop *evl;
    int id;
    int type;
    int running;
    int fd_event;
    int fd_timer;
    time_t seconds;
    long nanoseconds;
    int (*cb_collect) (struct flb_input_instance *,
                       struct flb_config *, void *);
    struct flb_input_instance *instance;
    struct mk_list _head;
};
struct flb_input_coro {
    int id;
    time_t start_time;
    time_t end_time;
    struct flb_input_instance *ins;
    struct flb_coro *coro;
    struct flb_config *config;
    struct mk_list _head;
};
int flb_input_coro_id_get(struct flb_input_instance *ins);
static inline __attribute__((always_inline))
struct flb_input_coro *flb_input_coro_create(struct flb_input_instance *ins,
                                             struct flb_config *config)
{
    struct flb_coro *coro;
    struct flb_input_coro *input_coro;
    input_coro = (struct flb_input_coro *) flb_calloc(1,
                                                      sizeof(struct flb_input_coro));
    if (!input_coro) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_input.h", 607);
        return ((void*)0);
    }
    coro = flb_coro_create(input_coro);
    if (!coro) {
        flb_free(input_coro);
        return ((void*)0);
    }
    input_coro->id = flb_input_coro_id_get(ins);
    input_coro->ins = ins;
    input_coro->start_time = time(((void*)0));
    input_coro->coro = coro;
    input_coro->config = config;
    mk_list_add(&input_coro->_head, &ins->input_coro_list);
    return input_coro;
}
struct flb_libco_in_params {
    struct flb_config *config;
    struct flb_input_collector *coll;
    struct flb_coro *coro;
};
extern pthread_key_t libco_in_param_key;
extern struct flb_libco_in_params libco_in_param;
void flb_input_coro_prepare_destroy(struct flb_input_coro *input_coro);
static inline __attribute__((always_inline)) void input_params_set(struct flb_coro *coro,
                             struct flb_input_collector *coll,
                             struct flb_config *config,
                             void *context)
{
    struct flb_libco_in_params *params;
    params = pthread_getspecific(libco_in_param_key);
    if (params == ((void*)0)) {
        params = flb_calloc(1, sizeof(struct flb_libco_in_params));
        if (params == ((void*)0)) {
            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_input.h", 650);
            return;
        }
        pthread_setspecific(libco_in_param_key, params);
    }
    params->coll = coll;
    params->config = config;
    params->coro = coro;
    co_switch(coro->callee);
}
static inline __attribute__((always_inline)) void input_pre_cb_collect(void)
{
    struct flb_input_collector *coll;
    struct flb_config *config;
    struct flb_coro *coro;
    struct flb_libco_in_params *params;
    params = pthread_getspecific(libco_in_param_key);
    if (params == ((void*)0)) {
        params = flb_calloc(1, sizeof(struct flb_libco_in_params));
        if (params == ((void*)0)) {
            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_input.h", 674);
            return;
        }
        pthread_setspecific(libco_in_param_key, params);
    }
    coll = params->coll;
    config = params->config;
    coro = params->coro;
    co_switch(coro->caller);
    coll->cb_collect(coll->instance, config, coll->instance->context);
}
static inline __attribute__((always_inline)) void flb_input_coro_resume(struct flb_input_coro *input_coro)
{
    flb_coro_resume(input_coro->coro);
}
static void libco_in_param_key_destroy(void *data)
{
    struct flb_libco_inparams *params = (struct flb_libco_inparams*)data;
    flb_free(params);
}
static inline __attribute__((always_inline))
struct flb_input_coro *flb_input_coro_collect(struct flb_input_collector *coll,
                                              struct flb_config *config)
{
    size_t stack_size;
    struct flb_coro *coro;
    struct flb_input_coro *input_coro;
    input_coro = flb_input_coro_create(coll->instance, config);
    if (!input_coro) {
        return ((void*)0);
    }
    pthread_key_create(&libco_in_param_key, libco_in_param_key_destroy);
    coro = input_coro->coro;
    if (!coro) {
        return ((void*)0);
    }
    coro->caller = co_active();
    coro->callee = co_create(config->coro_stack_size,
                             input_pre_cb_collect, &stack_size);
    coro->valgrind_stack_id = (unsigned)__extension__ ({ volatile unsigned long int _zzq_args[6]; volatile unsigned long int _zzq_result; _zzq_args[0] = (unsigned long int)(VG_USERREQ__STACK_REGISTER); _zzq_args[1] = (unsigned long int)(coro->callee); _zzq_args[2] = (unsigned long int)(((char *)coro->callee) + stack_size); _zzq_args[3] = (unsigned long int)(0); _zzq_args[4] = (unsigned long int)(0); _zzq_args[5] = (unsigned long int)(0); __asm__ volatile("rolq $3,  %%rdi ; rolq $13, %%rdi\n\t" "rolq $61, %%rdi ; rolq $51, %%rdi\n\t" "xchgq %%rbx,%%rbx" : "=d" (_zzq_result) : "a" (&_zzq_args[0]), "0" (0) : "cc", "memory" ); _zzq_result; });
    input_params_set(coro, coll, config, coll->instance->context);
    return input_coro;
}
static inline __attribute__((always_inline)) int flb_input_is_threaded(struct flb_input_instance *ins)
{
    return ins->is_threaded;
}
static inline __attribute__((always_inline)) void flb_input_return(struct flb_coro *coro) {
    int n;
    uint64_t val;
    struct flb_input_coro *input_coro;
    struct flb_input_instance *ins;
    input_coro = (struct flb_input_coro *) coro->data;
    ins = input_coro->ins;
    val = ((uint64_t) 3 << 32 | ins->id);
    n = write(ins->ch_events[1], (void *) &val, sizeof(val));
    if (n == -1) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_input.h", 766);
    }
    flb_input_coro_prepare_destroy(input_coro);
}
static inline __attribute__((always_inline)) void flb_input_return_do(int ret) {
    struct flb_coro *coro = flb_coro_get();
    flb_input_return(coro);
    flb_coro_yield(coro, 1);
}
static inline int flb_input_buf_paused(struct flb_input_instance *i)
{
    if (i->mem_buf_status == 0) {
        return 1;
    }
    if (i->storage_buf_status == 0) {
        return 1;
    }
    return 0;
}
static inline int flb_input_paused(struct flb_input_instance *i)
{
    if (flb_input_buf_paused(i) == 1) {
        return 1;
    }
    if (i->rate_gate_status == 0) {
        return 1;
    }
    return 0;
}
static inline int flb_input_config_map_set(struct flb_input_instance *ins,
                                           void *context)
{
    int ret;
    ret = -1;
    if (ins->config_map) {
        ret = flb_config_map_set(ins->config, &ins->properties, ins->config_map, context);
        if (ret == -1) {
            return -1;
        }
    }
    if (ins->net_config_map) {
        ret = flb_config_map_set(ins->config, &ins->net_properties, ins->net_config_map,
                                 &ins->net_setup);
        if (ret == -1) {
            return -1;
        }
    }
    if (ins->http_server_config_map && ins->http_server_config) {
        ret = flb_config_map_set(ins->config,
                                 &ins->http_server_properties,
                                 ins->http_server_config_map,
                                 ins->http_server_config);
        if (ret == -1) {
            return -1;
        }
    }
    return ret;
}
struct mk_list *flb_input_get_global_config_map(struct flb_config *config);
int flb_input_register_all(struct flb_config *config);
struct flb_input_instance *flb_input_new(struct flb_config *config,
                                         const char *input, void *data,
                                         int public_only);
struct flb_input_instance *flb_input_get_instance(struct flb_config *config,
                                                  int ins_id);
int flb_input_set_property(struct flb_input_instance *ins,
                           const char *k, const char *v);
const char *flb_input_get_property(const char *key,
                                   struct flb_input_instance *ins);
void *flb_input_get_cmt_instance(struct flb_input_instance *ins);
int flb_input_check(struct flb_config *config);
void flb_input_set_context(struct flb_input_instance *ins, void *context);
int flb_input_channel_init(struct flb_input_instance *ins);
int flb_input_collector_start(int coll_id, struct flb_input_instance *ins);
int flb_input_collectors_start(struct flb_config *config);
int flb_input_collector_pause(int coll_id, struct flb_input_instance *ins);
int flb_input_collector_resume(int coll_id, struct flb_input_instance *ins);
int flb_input_collector_delete(int coll_id, struct flb_input_instance *ins);
int flb_input_collector_destroy(struct flb_input_collector *coll);
int flb_input_collector_fd(int fd, struct flb_config *config);
struct mk_event *flb_input_collector_get_event(int coll_id,
                                               struct flb_input_instance *ins);
int flb_input_set_collector_time(struct flb_input_instance *ins,
                                 int (*cb_collect) (struct flb_input_instance *,
                                                    struct flb_config *, void *),
                                 time_t seconds,
                                 long nanoseconds,
                                 struct flb_config *config);
int flb_input_set_collector_event(struct flb_input_instance *ins,
                                  int (*cb_collect) (struct flb_input_instance *,
                                                     struct flb_config *, void *),
                                  int fd,
                                  struct flb_config *config);
int flb_input_set_collector_socket(struct flb_input_instance *ins,
                                   int (*cb_new_connection) (struct flb_input_instance *,
                                                             struct flb_config *,
                                                             void*),
                                   int fd,
                                   struct flb_config *config);
int flb_input_collector_running(int coll_id, struct flb_input_instance *ins);
int flb_input_coro_id_get(struct flb_input_instance *ins);
int flb_input_coro_finished(struct flb_config *config, int ins_id);
int flb_input_instance_init(struct flb_input_instance *ins,
                            struct flb_config *config);
void flb_input_instance_exit(struct flb_input_instance *ins,
                             struct flb_config *config);
void flb_input_instance_destroy(struct flb_input_instance *ins);
int flb_input_net_property_check(struct flb_input_instance *ins,
                                 struct flb_config *config);
int flb_input_plugin_property_check(struct flb_input_instance *ins,
                                    struct flb_config *config);
int flb_input_init_all(struct flb_config *config);
void flb_input_pre_run_all(struct flb_config *config);
void flb_input_exit_all(struct flb_config *config);
void *flb_input_flush(struct flb_input_instance *ins, size_t *size);
int flb_input_test_pause_resume(struct flb_input_instance *ins, int sleep_seconds);
int flb_input_pause(struct flb_input_instance *ins);
int flb_input_pause_all(struct flb_config *config);
int flb_input_plugin_pause(struct flb_input_instance *ins);
int flb_input_plugin_resume(struct flb_input_instance *ins);
int flb_input_resume(struct flb_input_instance *ins);
void flb_input_rate_update(struct flb_input_instance *ins,
                           uint64_t timestamp,
                           size_t records,
                           size_t bytes);
int flb_input_rate_gate_protect(struct flb_input_instance *ins);
void flb_input_rate_gate_maybe_resume(struct flb_input_instance *ins);
const char *flb_input_name(struct flb_input_instance *ins);
int flb_input_name_exists(const char *name, struct flb_config *config);
void flb_input_net_default_listener(const char *listen, int port,
                                    struct flb_input_instance *ins);
int flb_input_log_check(struct flb_input_instance *ins, int l);
struct mk_event_loop *flb_input_event_loop_get(struct flb_input_instance *ins);
int flb_input_upstream_set(struct flb_upstream *u, struct flb_input_instance *ins);
int flb_input_downstream_set(struct flb_downstream *stream,
                             struct flb_input_instance *ins);
void flb_input_ingress_destroy(struct flb_input_instance *ins);
int flb_input_ingress_enable(struct flb_input_instance *ins);
int flb_input_ingress_queue_log(struct flb_input_instance *ins,
                                const char *tag, size_t tag_len,
                                const void *buf, size_t buf_size);
int flb_input_ingress_queue_log_take(struct flb_input_instance *ins,
                                     const char *tag, size_t tag_len,
                                     void *buf, size_t buf_size,
                                     size_t allocation_size);
int flb_input_ingress_queue_log_take_records(struct flb_input_instance *ins,
                                             size_t records,
                                             const char *tag, size_t tag_len,
                                             void *buf, size_t buf_size,
                                             size_t allocation_size);
int flb_input_ingress_queue_metrics(struct flb_input_instance *ins,
                                    const char *tag, size_t tag_len,
                                    struct cmt *cmt, size_t payload_size);
int flb_input_ingress_queue_metrics_list(struct flb_input_instance *ins,
                                         const char *tag, size_t tag_len,
                                         struct cfl_list *contexts,
                                         size_t payload_size);
int flb_input_ingress_queue_traces(struct flb_input_instance *ins,
                                   const char *tag, size_t tag_len,
                                   struct ctrace *ctr, size_t payload_size);
int flb_input_ingress_queue_profiles(struct flb_input_instance *ins,
                                     const char *tag, size_t tag_len,
                                     struct cprof *profile, size_t payload_size);
int flb_input_instance_processors_load(struct flb_input_instance *ins, struct flb_cf_group *processors);
struct flb_task_route {
    int status;
    int records;
    size_t bytes;
    void *retry_context;
    void (*retry_context_destroy)(void *);
    int retry_records;
    size_t retry_bytes;
    struct flb_output_instance *out;
    struct mk_list _head;
};
struct flb_task_retry {
    int attempts;
    struct flb_output_instance *o_ins;
    struct flb_task *parent;
    struct mk_list _head;
};
struct flb_task {
    int id;
    uint64_t ref_id;
    uint8_t status;
    int users;
    struct flb_event_chunk *event_chunk;
    void *ic;
    int records;
    struct mk_list routes;
    struct mk_list retries;
    struct mk_list _head;
    struct flb_input_instance *i_ins;
    struct flb_config *config;
    pthread_mutex_t lock;
};
struct flb_task_queue {
    struct mk_list pending;
    struct mk_list in_progress;
};
struct flb_task_enqueued {
    struct flb_task *task;
    struct flb_task_retry *retry;
    struct flb_output_instance *out_instance;
    struct flb_config *config;
    struct mk_list _head;
};
int flb_task_running_count(struct flb_config *config);
int flb_task_running_print(struct flb_config *config);
int flb_task_map_get_task_id(struct flb_config *config);
struct flb_task *task_alloc(struct flb_config *config);
struct flb_task *flb_task_create(uint64_t ref_id,
                                 const char *buf,
                                 size_t size,
                                 struct flb_input_instance *i_ins,
                                 struct flb_input_chunk *ic,
                                 const char *tag_buf, int tag_len,
                                 struct flb_config *config,
                                 int *err);
void flb_task_add_coro(struct flb_task *task, struct flb_coro *coro);
void flb_task_destroy(struct flb_task *task, int del);
struct flb_task_queue* flb_task_queue_create();
void flb_task_queue_destroy(struct flb_task_queue *queue);
struct flb_task_retry *flb_task_retry_create(struct flb_task *task,
                                             struct flb_output_instance *ins);
void flb_task_retry_destroy(struct flb_task_retry *retry);
int flb_task_retry_reschedule(struct flb_task_retry *retry, struct flb_config *config);
int flb_task_from_fs_storage(struct flb_task *task);
int flb_task_retry_count(struct flb_task *task, void *data);
int flb_task_retry_clean(struct flb_task *task, struct flb_output_instance *ins);
struct flb_task *flb_task_chunk_create(uint64_t ref_id,
                                       const char *buf,
                                       size_t size,
                                       struct flb_input_instance *i_ins,
                                       void *ic,
                                       const char *tag_buf, int tag_len,
                                       struct flb_config *config);
static inline void flb_task_users_release(struct flb_task *task)
{
    if (task->users == 0 && mk_list_size(&task->retries) == 0) {
        flb_task_destroy(task, 1);
    }
}
static inline void flb_task_users_inc(struct flb_task *task)
{
    task->users++;
}
static inline void flb_task_users_dec(struct flb_task *task, int release_check)
{
    task->users--;
    if (release_check == 1) {
        flb_task_users_release(task);
    }
}
static inline void flb_task_acquire_lock(struct flb_task *task)
{
    pthread_mutex_lock(&task->lock);
}
static inline void flb_task_release_lock(struct flb_task *task)
{
    pthread_mutex_unlock(&task->lock);
}
static inline __attribute__((always_inline)) int flb_task_get_active_route_count(
                        struct flb_task *task)
{
    struct mk_list *iterator;
    int result;
    struct flb_task_route *route;
    result = 0;
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->status == 1) {
            result++;
        }
    }
    return result;
}
static inline __attribute__((always_inline)) size_t flb_task_get_route_status(
                            struct flb_task *task,
                            struct flb_output_instance *o_ins)
{
    struct mk_list *iterator;
    size_t result;
    struct flb_task_route *route;
    result = 0;
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->out == o_ins) {
            result = route->status;
            break;
        }
    }
    return result;
}
static inline __attribute__((always_inline)) void flb_task_set_route_status(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins,
                        int new_status)
{
    struct mk_list *iterator;
    struct flb_task_route *route;
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->out == o_ins) {
            route->status = new_status;
            break;
        }
    }
}
static inline __attribute__((always_inline)) void flb_task_set_route_data(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins,
                        int records,
                        size_t bytes)
{
    struct mk_list *iterator;
    struct flb_task_route *route;
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->out == o_ins) {
            route->records = records;
            route->bytes = bytes;
            break;
        }
    }
}
static inline __attribute__((always_inline)) int flb_task_get_route_data(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins,
                        int *records,
                        size_t *bytes)
{
    struct mk_list *iterator;
    struct flb_task_route *route;
    if (records == ((void*)0) || bytes == ((void*)0)) {
        return -1;
    }
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->out == o_ins) {
            *records = route->records;
            *bytes = route->bytes;
            return 0;
        }
    }
    return -1;
}
static inline __attribute__((always_inline)) void *flb_task_get_route_retry_context(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins,
                        int *records,
                        size_t *bytes)
{
    struct mk_list *iterator;
    struct flb_task_route *route;
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->out == o_ins) {
            if (records != ((void*)0)) {
                *records = route->retry_records;
            }
            if (bytes != ((void*)0)) {
                *bytes = route->retry_bytes;
            }
            return route->retry_context;
        }
    }
    return ((void*)0);
}
static inline __attribute__((always_inline)) int flb_task_set_route_retry_context(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins,
                        void *context,
                        void (*destroy)(void *),
                        int records,
                        size_t bytes)
{
    struct mk_list *iterator;
    struct flb_task_route *route;
    for( iterator = (&task->routes)->next; iterator != (&task->routes); iterator = iterator->next ) {
        route = ({ const typeof( ((struct flb_task_route *)0)->_head ) *__mptr = (iterator); (struct flb_task_route *)( (char *)__mptr - __builtin_offsetof(struct flb_task_route, _head) );});
        if (route->out == o_ins) {
            if (route->retry_context != ((void*)0) &&
                route->retry_context != context &&
                route->retry_context_destroy != ((void*)0)) {
                route->retry_context_destroy(route->retry_context);
            }
            route->retry_context = context;
            route->retry_context_destroy = destroy;
            route->retry_records = records;
            route->retry_bytes = bytes;
            return 0;
        }
    }
    return -1;
}
static inline __attribute__((always_inline)) int flb_task_clear_route_retry_context(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins)
{
    return flb_task_set_route_retry_context(task, o_ins, ((void*)0), ((void*)0), 0, 0);
}
static inline __attribute__((always_inline)) void flb_task_activate_route(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins)
{
    flb_task_set_route_status(task, o_ins, 1);
}
static inline __attribute__((always_inline)) void flb_task_deactivate_route(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins)
{
    flb_task_set_route_status(task, o_ins, 0);
}
static inline __attribute__((always_inline)) void flb_task_drop_route(
                        struct flb_task *task,
                        struct flb_output_instance *o_ins)
{
    flb_task_set_route_status(task, o_ins, 2);
}
int flb_engine_start(struct flb_config *config);
int flb_engine_failed(struct flb_config *config);
int flb_engine_flush(struct flb_config *config,
                     struct flb_input_plugin *in_force);
int flb_engine_exit(struct flb_config *config);
int flb_engine_exit_status(struct flb_config *config, int status);
int flb_engine_shutdown(struct flb_config *config);
int flb_engine_destroy_tasks(struct mk_list *tasks);
void flb_engine_reschedule_retries(struct flb_config *config);
void flb_engine_stop_ingestion(struct flb_config *config);
int flb_engine_adaptive_flush_target_level(struct flb_config *config,
                                           double pressure);
double flb_engine_adaptive_flush_interval(struct flb_config *config,
                                          int level);
void flb_engine_evl_init();
struct mk_event_loop *flb_engine_evl_get();
void flb_engine_evl_set(struct mk_event_loop *evl);
struct flb_callback_entry {
    flb_sds_t name;
    void (*cb)(char *, void *, void *);
    struct mk_list _head;
};
struct flb_callback {
    flb_sds_t name;
    struct flb_hash_table *ht;
    struct mk_list entries;
    struct flb_config *config;
};
struct flb_callback *flb_callback_create(char *name);
void flb_callback_destroy(struct flb_callback *ctx);
int flb_callback_set(struct flb_callback *ctx, char *name,
                     void (*cb)(char *, void *, void *));
int flb_callback_do(struct flb_callback *ctx, char *name, void *p1, void *p2);
int flb_callback_exists(struct flb_callback *ctx, char *name);
typedef pthread_mutex_t flb_lock_t;
int flb_lock_init(flb_lock_t *lock);
int flb_lock_destroy(flb_lock_t *lock);
int flb_lock_acquire(flb_lock_t *lock,
                     size_t retry_limit,
                     size_t retry_delay);
int flb_lock_release(flb_lock_t *lock,
                     size_t retry_limit,
                     size_t retry_delay);
enum mk_request_methods {
    MK_METHOD_GET = 0,
    MK_METHOD_POST ,
    MK_METHOD_HEAD ,
    MK_METHOD_PUT ,
    MK_METHOD_DELETE ,
    MK_METHOD_OPTIONS ,
    MK_METHOD_SIZEOF ,
    MK_METHOD_UNKNOWN
};
extern pthread_key_t mk_tls_cache_iov_header;
extern pthread_key_t mk_tls_cache_header_cl;
extern pthread_key_t mk_tls_cache_header_lm;
extern pthread_key_t mk_tls_cache_gmtime;
extern pthread_key_t mk_tls_cache_gmtext;
extern pthread_key_t mk_tls_vhost_fdt;
extern pthread_key_t mk_tls_sched_cs;
extern pthread_key_t mk_tls_sched_cs_incomplete;
extern pthread_key_t mk_tls_sched_worker_notif;
extern pthread_key_t mk_tls_sched_worker_node;
extern pthread_key_t mk_tls_server_listen;
extern pthread_key_t mk_tls_server_timeout;
struct rb_tree_node {
    struct rb_tree_node *left;
    struct rb_tree_node *right;
    struct rb_tree_node *parent;
    const void *key;
    int color;
};
typedef int (*rb_cmp_func_t)(const void *lhs, const void *rhs);
typedef int (*rb_cmp_func_ex_t)(void *state, const void *lhs, const void *rhs);
struct rb_tree {
    struct rb_tree_node *root;
    rb_cmp_func_ex_t compare;
    struct rb_tree_node *rightmost;
    void *state;
};
typedef int rb_result_t;
rb_result_t rb_tree_new_ex(struct rb_tree *tree, rb_cmp_func_ex_t compare, void *state);
rb_result_t rb_tree_new(struct rb_tree *tree,
                        rb_cmp_func_t compare);
rb_result_t rb_tree_destroy(struct rb_tree *tree);
rb_result_t rb_tree_empty(struct rb_tree *tree, int *is_empty);
rb_result_t rb_tree_find(struct rb_tree *tree,
                         const void *key,
                         struct rb_tree_node **value);
rb_result_t rb_tree_insert(struct rb_tree *tree,
                           const void *key,
                           struct rb_tree_node *node);
rb_result_t rb_tree_remove(struct rb_tree *tree,
                           struct rb_tree_node *node);
rb_result_t rb_tree_find_or_insert(struct rb_tree *tree,
                                   void *key,
                                   struct rb_tree_node *new_candidate,
                                   struct rb_tree_node **value);
rb_result_t rb_tree_find_or_insert(struct rb_tree *tree,
                                   void *key,
                                   struct rb_tree_node *new_candidate,
                                   struct rb_tree_node **value);
static inline
rb_result_t rb_tree_get_rightmost(struct rb_tree *tree,
                                  struct rb_tree_node **rightmost)
{
    if ( (((void*)0) == tree) || (((void*)0) == rightmost) ) {
        return 0x2;
    }
    *rightmost = tree->rightmost;
    return 0x0;
}
static inline
rb_result_t __rb_tree_find_minimum(struct rb_tree_node *root,
                                   struct rb_tree_node **min)
{
    struct rb_tree_node *x = root;
    while (x->left != ((void*)0)) {
        x = x->left;
    }
    *min = x;
    return 0x0;
}
static inline
rb_result_t __rb_tree_find_maximum(struct rb_tree_node *root,
                                   struct rb_tree_node **max)
{
    struct rb_tree_node *x = root;
    while (x->right != ((void*)0)) {
        x = x->right;
    }
    *max = x;
    return 0x0;
}
static inline
rb_result_t rb_tree_find_successor(struct rb_tree *tree,
                                   struct rb_tree_node *node,
                                   struct rb_tree_node **successor)
{
    rb_result_t ret = 0x0;
    do { if (__builtin_expect(!!(!(tree != ((void*)0))), 0)) { ((void) sizeof (("tree != NULL" && 0) ? 1 : 0), __extension__ ({ if ("tree != NULL" && 0) ; else __assert_fail ("\"tree != NULL\" && 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/monkey/include/monkey/../../deps/rbtree/rbtree.h", 395, __extension__ __PRETTY_FUNCTION__); })); return 0x2; } } while (0);
    do { if (__builtin_expect(!!(!(node != ((void*)0))), 0)) { ((void) sizeof (("node != NULL" && 0) ? 1 : 0), __extension__ ({ if ("node != NULL" && 0) ; else __assert_fail ("\"node != NULL\" && 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/monkey/include/monkey/../../deps/rbtree/rbtree.h", 396, __extension__ __PRETTY_FUNCTION__); })); return 0x2; } } while (0);
    do { if (__builtin_expect(!!(!(successor != ((void*)0))), 0)) { ((void) sizeof (("successor != NULL" && 0) ? 1 : 0), __extension__ ({ if ("successor != NULL" && 0) ; else __assert_fail ("\"successor != NULL\" && 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/monkey/include/monkey/../../deps/rbtree/rbtree.h", 397, __extension__ __PRETTY_FUNCTION__); })); return 0x2; } } while (0);
    struct rb_tree_node *x = node;
    if (x->right != ((void*)0)) {
        __rb_tree_find_minimum(x->right, successor);
        goto done;
    }
    struct rb_tree_node *y = x->parent;
    while (y != ((void*)0) && (x == y->right)) {
        x = y;
        y = y->parent;
    }
    *successor = y;
done:
    return ret;
}
static inline
rb_result_t rb_tree_find_predecessor(struct rb_tree *tree,
                                     struct rb_tree_node *node,
                                     struct rb_tree_node **pred)
{
    rb_result_t ret = 0x0;
    struct rb_tree_node *x = node;
    do { if (__builtin_expect(!!(!(tree != ((void*)0))), 0)) { ((void) sizeof (("tree != NULL" && 0) ? 1 : 0), __extension__ ({ if ("tree != NULL" && 0) ; else __assert_fail ("\"tree != NULL\" && 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/monkey/include/monkey/../../deps/rbtree/rbtree.h", 430, __extension__ __PRETTY_FUNCTION__); })); return 0x2; } } while (0);
    do { if (__builtin_expect(!!(!(node != ((void*)0))), 0)) { ((void) sizeof (("node != NULL" && 0) ? 1 : 0), __extension__ ({ if ("node != NULL" && 0) ; else __assert_fail ("\"node != NULL\" && 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/monkey/include/monkey/../../deps/rbtree/rbtree.h", 431, __extension__ __PRETTY_FUNCTION__); })); return 0x2; } } while (0);
    do { if (__builtin_expect(!!(!(pred != ((void*)0))), 0)) { ((void) sizeof (("pred != NULL" && 0) ? 1 : 0), __extension__ ({ if ("pred != NULL" && 0) ; else __assert_fail ("\"pred != NULL\" && 0", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/lib/monkey/include/monkey/../../deps/rbtree/rbtree.h", 432, __extension__ __PRETTY_FUNCTION__); })); return 0x2; } } while (0);
    if (x->left != ((void*)0)) {
        __rb_tree_find_maximum(x->left, pred);
        goto done;
    }
    struct rb_tree_node *y = x->parent;
    while (y != ((void*)0) && (x == y->left)) {
        x = y;
        y = y->parent;
    }
    *pred = y;
done:
    return ret;
}
struct plugin_api;
struct mk_clock_context;
struct mk_config_listener
{
    char *address;
    char *port;
    uint32_t flags;
    struct mk_list _head;
};
struct mk_server
{
    int server_fd;
    int kernel_version;
    int kernel_features;
    int fd_limit;
    unsigned int server_capacity;
    short int workers;
    short int manual_tcp_cork;
    int8_t fdt;
    int8_t is_daemon;
    int8_t is_seteuid;
    int8_t scheduler_mode;
    char *path_conf_root;
    char *path_conf_pidfile;
    char *conf_mimetype;
    char *conf_main;
    char *conf_sites;
    char *conf_plugin_load;
    char *conf_plugins;
    char *conf_user_pub;
    mk_ptr_t server_software;
    struct mk_list listeners;
    char *one_shot;
    char *port_override;
    char *user;
    char **request_headers_allowed;
    int timeout;
    int standard_port;
    int pid_status;
    int8_t hideversion;
    int8_t resume;
    int8_t symlink;
    int8_t keep_alive;
    int max_keep_alive_request;
    int keep_alive_timeout;
    int thread_counter;
    uid_t egid;
    gid_t euid;
    int max_request_size;
    struct mk_list *index_files;
    int nhosts;
    struct mk_list hosts;
    mode_t open_flags;
    struct mk_list plugins;
    int safe_event_write;
    char *transport_layer;
    int tls_mode;
    char *tls_cert_file;
    char *tls_cert_chain_file;
    char *tls_key_file;
    char *tls_dh_param_file;
    struct mk_list mimetype_list;
    struct rb_tree mimetype_rb_head;
    void *mimetype_default;
    char *mimetype_default_str;
    char server_signature[16];
    char server_signature_header[32];
    int server_signature_header_len;
    int lib_mode;
    int lib_ch_manager[2];
    struct mk_event_loop *lib_evl;
    struct mk_event lib_ch_event;
    int lib_ch_start[2];
    struct mk_event_loop *lib_evl_start;
    struct mk_event lib_ch_start_event;
    void *sched_ctx;
    struct mk_list sched_worker_callbacks;
    struct mk_rconf *config;
    struct mk_plugin_network *network;
    int pth_init;
    pthread_cond_t pth_cond;
    pthread_mutex_t pth_mutex;
    pthread_mutex_t vhost_fdt_mutex;
    int worker_id;
    struct plugin_api *api;
    struct mk_clock_context *clock_context;
    struct mk_list stage10_handler;
    struct mk_list stage20_handler;
    struct mk_list stage30_handler;
    struct mk_list stage40_handler;
    struct mk_list stage50_handler;
};
struct mk_server_config *mk_config_init();
void mk_config_start_configure(struct mk_server *server);
void mk_config_signature(struct mk_server *server);
void mk_config_add_index(char *indexname);
void mk_config_set_init_values(struct mk_server *config);
int mk_config_listen_parse(char *value, struct mk_server *server);
void mk_config_error(const char *path, int line, const char *msg);
struct mk_config_listener *mk_config_listener_add(char *address,
                                                  char *port, int flags,
                                                  struct mk_server *server);
int mk_config_listen_check_busy(struct mk_server *server);
void mk_config_listeners_free(struct mk_server *server);
int mk_config_get_bool(char *value);
void mk_config_read_hosts(char *path);
void mk_config_sanity_check(struct mk_server *server);
void mk_config_free_all(struct mk_server *server);
int mk_socket_set_cork_flag(int fd, int state);
int mk_socket_set_tcp_fastopen(int sockfd);
int mk_socket_set_tcp_nodelay(int sockfd);
int mk_socket_set_tcp_defer_accept(int sockfd);
int mk_socket_set_tcp_reuseport(int sockfd);
int mk_socket_set_nonblocking(int sockfd);
int mk_socket_create(int domain, int type, int protocol);
int mk_socket_connect(char *host, int port, int async);
int mk_socket_open(char *path, int async);
int mk_socket_reset(int socket);
int mk_socket_bind(int socket_fd, const struct sockaddr *addr,
                   socklen_t addrlen, int backlog, struct mk_server *server);
int mk_socket_server(char *port, char *listen_addr,
                     int reuse_port, struct mk_server *server);
int mk_socket_ip_str(int socket_fd, char **buf, int size, unsigned long *len);
int mk_socket_accept(int server_fd);
struct mk_plugin;
struct mk_plugin_network {
    int (*read) (struct mk_plugin *, int, void *, int);
    int (*write) (struct mk_plugin *, int, const void *, size_t);
    int (*writev) (struct mk_plugin *, int, struct mk_iov *);
    int (*close) (struct mk_plugin *, int);
    int (*send_file) (struct mk_plugin *, int, int, off_t *, size_t);
    int (*event_interest) (struct mk_plugin *, int, int);
    int buffer_size;
    struct mk_plugin *plugin;
};
struct mk_server_listen
{
    struct mk_event event;
    int server_fd;
    struct mk_plugin_network *network;
    struct mk_sched_handler *protocol;
    struct mk_config_listener *listen;
    struct mk_list _head;
};
struct mk_server_timeout {
    struct mk_event event;
};
extern pthread_key_t mk_server_fifo_key;
struct mk_sched_worker;
int mk_socket_set_cork_flag(int fd, int state);
static inline int mk_server_cork_flag(int fd, int state)
{
    return mk_socket_set_cork_flag(fd, state);
}
struct mk_server *mk_server_create();
int mk_server_listen_check(struct mk_server_listen *listen, int server_fd);
void mk_server_listen_free();
struct mk_list *mk_server_listen_init(struct mk_server *server);
unsigned int mk_server_capacity(struct mk_server *server);
void mk_server_launch_workers(struct mk_server *server);
void mk_server_worker_loop(struct mk_server *server);
void mk_server_loop_balancer(struct mk_server *server);
void mk_server_worker_loop(struct mk_server *server);
void mk_server_loop(struct mk_server *server);
struct mk_channel {
    int type;
    int fd;
    int status;
    struct mk_event *event;
    struct mk_plugin_network *io;
    struct mk_list streams;
    void *thread;
};
struct mk_stream_input {
    int type;
    int fd;
    int dynamic;
    size_t bytes_total;
    off_t bytes_offset;
    void *buffer;
    void *context;
    void (*cb_consumed)(struct mk_stream_input *, long);
    void (*cb_finished)(struct mk_stream_input *);
    struct mk_stream *stream;
    struct mk_list _head;
};
struct mk_stream {
    int preserve;
    int encoding;
    int dynamic;
    size_t bytes_total;
    off_t bytes_offset;
    struct mk_channel *channel;
    void *context;
    void (*cb_finished) (struct mk_stream *);
    void (*cb_bytes_consumed) (struct mk_stream *, long);
    void (*cb_exception) (struct mk_stream *, int);
    struct mk_list inputs;
    struct mk_list _head;
};
int mk_stream_in_release(struct mk_stream_input *in);
static inline int mk_channel_is_empty(struct mk_channel *channel)
{
    return mk_list_is_empty(&channel->streams);
}
static inline void mk_channel_append_stream(struct mk_channel *channel,
                                            struct mk_stream *stream)
{
    mk_list_add(&stream->_head, &channel->streams);
}
static inline void mk_stream_append(struct mk_stream_input *in,
                                    struct mk_stream *stream)
{
    mk_list_add(&in->_head, &stream->inputs);
}
static inline int mk_stream_input(struct mk_stream *stream,
                                  struct mk_stream_input *in,
                                  int type,
                                  int fd,
                                  void *buffer, size_t size,
                                  off_t offset,
                                  void (*cb_consumed) (struct mk_stream_input *, long),
                                  void (*cb_finished)(struct mk_stream_input *))
{
    struct mk_iov *iov;
    if (!in) {
        in = mk_mem_alloc(sizeof(struct mk_stream_input));
        if (!in) {
            return -1;
        }
        in->dynamic = !0;
    }
    else {
        in->dynamic = 0;
    }
    in->fd = fd;
    in->type = type;
    in->bytes_offset = offset;
    in->buffer = buffer;
    in->cb_consumed = cb_consumed;
    in->cb_finished = cb_finished;
    in->stream = stream;
    if (type == 1) {
        iov = buffer;
        in->bytes_total = iov->total_len;
    }
    else {
        in->bytes_total = size;
    }
    mk_list_add(&in->_head, &stream->inputs);
    return 0;
}
static inline int mk_stream_in_file(struct mk_stream *stream,
                                    struct mk_stream_input *in, int fd,
                                    size_t total_bytes,
                                    off_t offset,
                                    void (*cb_consumed)(struct mk_stream_input *, long),
                                    void (*cb_finished)(struct mk_stream_input *))
{
    return mk_stream_input(stream,
                           in,
                           2,
                           fd,
                           ((void*)0), total_bytes, offset,
                           cb_consumed, cb_finished);
}
static inline int mk_stream_in_iov(struct mk_stream *stream,
                                   struct mk_stream_input *in,
                                   struct mk_iov *iov,
                                   void (*cb_consumed)(struct mk_stream_input *, long),
                                   void (*cb_finished)(struct mk_stream_input *))
{
    return mk_stream_input(stream,
                           in,
                           1,
                           0,
                           iov, 0, 0,
                           cb_consumed, cb_finished);
}
static inline int mk_stream_in_raw(struct mk_stream *stream,
                                   struct mk_stream_input *in,
                                   char *buf, size_t length,
                                   void (*cb_consumed)(struct mk_stream_input *, long),
                                   void (*cb_finished)(struct mk_stream_input *))
{
    return mk_stream_input(stream,
                           in,
                           0,
                           -1,
                           buf, length,
                           0,
                           cb_consumed, cb_finished);
}
static inline void mk_stream_release(struct mk_stream *stream)
{
    struct mk_list *tmp;
    struct mk_list *head;
    struct mk_stream_input *in;
    for (head = (&stream->inputs)->next, tmp = head->next; head != (&stream->inputs); head = tmp, tmp = head->next) {
        in = ({ const typeof( ((struct mk_stream_input *)0)->_head ) *__mptr = (head); (struct mk_stream_input *)( (char *)__mptr - __builtin_offsetof(struct mk_stream_input, _head) );});
        mk_stream_in_release(in);
    }
    if (stream->cb_finished) {
        stream->cb_finished(stream);
    }
    stream->channel = ((void*)0);
    mk_list_del(&stream->_head);
    if (stream->dynamic == !0) {
        mk_mem_free(stream);
    }
}
static inline
struct mk_stream *mk_stream_set(struct mk_stream *stream,
                                struct mk_channel *channel,
                                void *data,
                                void (*cb_finished) (struct mk_stream *),
                                void (*cb_bytes_consumed) (struct mk_stream *, long),
                                void (*cb_exception) (struct mk_stream *, int))
{
    if (!stream) {
        stream = mk_mem_alloc(sizeof(struct mk_stream));
        if (!stream) {
            return ((void*)0);
        }
        stream->dynamic = !0;
    }
    else {
        stream->dynamic = 0;
    }
    stream->channel = channel;
    stream->bytes_offset = 0;
    stream->context = data;
    stream->preserve = 0;
    stream->cb_finished = cb_finished;
    stream->cb_bytes_consumed = cb_bytes_consumed;
    stream->cb_exception = cb_exception;
    mk_list_init(&stream->inputs);
    mk_list_add(&stream->_head, &channel->streams);
    return stream;
}
static inline void mk_stream_input_unlink(struct mk_stream_input *in)
{
    mk_list_del(&in->_head);
}
static inline void mk_stream_input_consume(struct mk_stream_input *in, long bytes)
{
    in->bytes_total -= bytes;
}
struct mk_stream *mk_stream_new(int type, struct mk_channel *channel,
                                void *buffer, size_t size, void *data,
                                void (*cb_finished) (struct mk_stream *),
                                void (*cb_bytes_consumed) (struct mk_stream *, long),
                                void (*cb_exception) (struct mk_stream *, int));
int mk_channel_stream_write(struct mk_stream *stream, size_t *count);
struct mk_channel *mk_channel_new(int type, int fd);
int mk_channel_release(struct mk_channel *channel);
int mk_channel_flush(struct mk_channel *channel);
int mk_channel_write(struct mk_channel *channel, size_t *count);
int mk_channel_clean(struct mk_channel *channel);
struct mk_net_connection {
    struct mk_event event;
    int fd;
    char *host;
    int port;
    void *thread;
};
int mk_net_init();
struct mk_plugin_network *mk_net_transport_default();
int mk_net_transport_event_interest(struct mk_plugin_network *transport,
                                    int fd, int fallback);
struct mk_net_connection *mk_net_conn_create(char *addr, int port);
int mk_net_conn_write(struct mk_channel *channel,
                      void *data, size_t len);
struct mk_sched_worker
{
    struct mk_event_loop *loop;
    unsigned long long accepted_connections;
    unsigned long long closed_connections;
    unsigned long long over_capacity;
    struct mk_list timeout_queue;
    short int idx;
    unsigned char initialized;
    pthread_t tid;
    pid_t pid;
    unsigned int mem_pagesize;
    struct mk_http_session *request_handler;
    struct mk_list event_free_queue;
    int signal_channel_r;
    int signal_channel_w;
    struct mk_list *listeners;
    struct mk_list requests_done;
    struct mk_list threads;
    struct mk_list threads_purge;
};
struct mk_sched_conn
{
    struct mk_event event;
    int status;
    uint32_t properties;
    char is_timeout_on;
    time_t arrive_time;
    struct mk_sched_handler *protocol;
    struct mk_server_listen *server_listen;
    struct mk_plugin_network *net;
    struct mk_channel channel;
    struct mk_list timeout_head;
    void *data;
};
struct mk_sched_handler
{
    const char *name;
    int (*cb_read) (struct mk_sched_conn *, struct mk_sched_worker *,
                     struct mk_server *);
    int (*cb_close) (struct mk_sched_conn *, struct mk_sched_worker *, int,
                     struct mk_server *);
    int (*cb_done) (struct mk_sched_conn *, struct mk_sched_worker *,
                     struct mk_server *);
    int (*cb_upgrade) (void *, void *, struct mk_server *);
    int sched_extra_size;
    char capabilities;
};
struct mk_sched_notif {
    struct mk_event event;
};
struct mk_sched_thread_conf {
    struct mk_server *server;
};
struct mk_sched_worker_cb {
    void (*cb_func) (void *);
    void *data;
    struct mk_list _head;
};
struct mk_sched_ctx {
    struct mk_sched_worker *workers;
};
struct mk_sched_worker *mk_sched_next_target(struct mk_server *server);
int mk_sched_init(struct mk_server *server);
int mk_sched_exit(struct mk_server *server);
int mk_sched_launch_thread(struct mk_server *server, pthread_t *tout);
void *mk_sched_launch_epoll_loop(void *thread_conf);
struct mk_sched_worker *mk_sched_get_handler_owner(void);
static inline struct rb_root *mk_sched_get_request_list()
{
    return pthread_getspecific(mk_tls_sched_cs);
}
static inline struct mk_sched_worker *mk_sched_get_thread_conf()
{
    return pthread_getspecific(mk_tls_sched_worker_node);
}
static inline struct mk_event_loop *mk_sched_loop()
{
    struct mk_sched_worker *w;
    w = pthread_getspecific(mk_tls_sched_worker_node);
    return w->loop;
}
void mk_sched_update_thread_status(struct mk_sched_worker *sched,
                                   int active, int closed);
int mk_sched_drop_connection(struct mk_sched_conn *conn,
                             struct mk_sched_worker *sched,
                             struct mk_server *server);
int mk_sched_check_timeouts(struct mk_sched_worker *sched,
                            struct mk_server *server);
struct mk_sched_conn *mk_sched_add_connection(int remote_fd,
                                              struct mk_server_listen *listener,
                                              struct mk_sched_worker *sched,
                                              struct mk_server *server);
int mk_sched_remove_client(struct mk_sched_conn *conn,
                           struct mk_sched_worker *sched,
                           struct mk_server *server);
struct mk_sched_conn *mk_sched_get_connection(struct mk_sched_worker
                                                     *sched, int remote_fd);
int mk_sched_update_conn_status(struct mk_sched_worker *sched, int remote_fd,
                                int status);
int mk_sched_sync_counters();
void mk_sched_worker_free(struct mk_server *server);
struct mk_sched_handler *mk_sched_handler_cap(char cap);
int mk_sched_event_read(struct mk_sched_conn *conn,
                        struct mk_sched_worker *sched,
                        struct mk_server *server);
int mk_sched_event_write(struct mk_sched_conn *conn,
                         struct mk_sched_worker *sched,
                         struct mk_server *server);
int mk_sched_event_close(struct mk_sched_conn *conn,
                         struct mk_sched_worker *sched,
                         int type, struct mk_server *server);
void mk_sched_event_free(struct mk_event *event);
static inline void mk_sched_event_free_all(struct mk_sched_worker *sched)
{
    struct mk_list *tmp;
    struct mk_list *head;
    struct mk_event *event;
    for (head = (&sched->event_free_queue)->next, tmp = head->next; head != (&sched->event_free_queue); head = tmp, tmp = head->next) {
        event = ({ const typeof( ((struct mk_event *)0)->_head ) *__mptr = (head); (struct mk_event *)( (char *)__mptr - __builtin_offsetof(struct mk_event, _head) );});
        mk_list_del(&event->_head);
        mk_mem_free(event);
    }
}
static inline void mk_sched_conn_timeout_add(struct mk_sched_conn *conn,
                                             struct mk_sched_worker *sched)
{
    if (conn->is_timeout_on == 0) {
        mk_list_add(&conn->timeout_head, &sched->timeout_queue);
        conn->is_timeout_on = !0;
    }
}
static inline void mk_sched_conn_timeout_del(struct mk_sched_conn *conn)
{
    if (conn->is_timeout_on == !0) {
        mk_list_del(&conn->timeout_head);
        conn->is_timeout_on = 0;
    }
}
int mk_sched_worker_cb_add(struct mk_server *server,
                           void (*cb_func) (void *),
                           void *data);
void mk_sched_worker_cb_free(struct mk_server *server);
int mk_sched_send_signal(struct mk_sched_worker *worker, uint64_t val);
int mk_sched_broadcast_signal(struct mk_server *server, uint64_t val);
int mk_sched_workers_join(struct mk_server *server);
int mk_sched_threads_purge(struct mk_sched_worker *sched);
int mk_sched_threads_destroy_all(struct mk_sched_worker *sched);
int mk_sched_threads_destroy_conn(struct mk_sched_worker *sched,
                                  struct mk_sched_conn *conn);

enum
{
  _ISupper = ((0) < 8 ? ((1 << (0)) << 8) : ((1 << (0)) >> 8)),
  _ISlower = ((1) < 8 ? ((1 << (1)) << 8) : ((1 << (1)) >> 8)),
  _ISalpha = ((2) < 8 ? ((1 << (2)) << 8) : ((1 << (2)) >> 8)),
  _ISdigit = ((3) < 8 ? ((1 << (3)) << 8) : ((1 << (3)) >> 8)),
  _ISxdigit = ((4) < 8 ? ((1 << (4)) << 8) : ((1 << (4)) >> 8)),
  _ISspace = ((5) < 8 ? ((1 << (5)) << 8) : ((1 << (5)) >> 8)),
  _ISprint = ((6) < 8 ? ((1 << (6)) << 8) : ((1 << (6)) >> 8)),
  _ISgraph = ((7) < 8 ? ((1 << (7)) << 8) : ((1 << (7)) >> 8)),
  _ISblank = ((8) < 8 ? ((1 << (8)) << 8) : ((1 << (8)) >> 8)),
  _IScntrl = ((9) < 8 ? ((1 << (9)) << 8) : ((1 << (9)) >> 8)),
  _ISpunct = ((10) < 8 ? ((1 << (10)) << 8) : ((1 << (10)) >> 8)),
  _ISalnum = ((11) < 8 ? ((1 << (11)) << 8) : ((1 << (11)) >> 8))
};
extern const unsigned short int **__ctype_b_loc (void)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern const __int32_t **__ctype_tolower_loc (void)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern const __int32_t **__ctype_toupper_loc (void)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int isalnum (int) __attribute__ ((__nothrow__ ));
extern int isalpha (int) __attribute__ ((__nothrow__ ));
extern int iscntrl (int) __attribute__ ((__nothrow__ ));
extern int isdigit (int) __attribute__ ((__nothrow__ ));
extern int islower (int) __attribute__ ((__nothrow__ ));
extern int isgraph (int) __attribute__ ((__nothrow__ ));
extern int isprint (int) __attribute__ ((__nothrow__ ));
extern int ispunct (int) __attribute__ ((__nothrow__ ));
extern int isspace (int) __attribute__ ((__nothrow__ ));
extern int isupper (int) __attribute__ ((__nothrow__ ));
extern int isxdigit (int) __attribute__ ((__nothrow__ ));
extern int tolower (int __c) __attribute__ ((__nothrow__ ));
extern int toupper (int __c) __attribute__ ((__nothrow__ ));
extern int isblank (int) __attribute__ ((__nothrow__ ));
extern int isascii (int __c) __attribute__ ((__nothrow__ ));
extern int toascii (int __c) __attribute__ ((__nothrow__ ));
extern int _toupper (int) __attribute__ ((__nothrow__ ));
extern int _tolower (int) __attribute__ ((__nothrow__ ));
extern int isalnum_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isalpha_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int iscntrl_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isdigit_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int islower_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isgraph_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isprint_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int ispunct_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isspace_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isupper_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isxdigit_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int isblank_l (int, locale_t) __attribute__ ((__nothrow__ ));
extern int __tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
extern int tolower_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
extern int __toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
extern int toupper_l (int __c, locale_t __l) __attribute__ ((__nothrow__ ));
struct response_headers
{
    int status;
    int connection;
    mk_ptr_t custom_status;
    long content_length;
    long real_length;
    int cgi;
    int pconnections_left;
    int breakline;
    int transfer_encoding;
    int upgrade;
    int ranges[2];
    time_t last_modified;
    mk_ptr_t allow_methods;
    mk_ptr_t content_type;
    mk_ptr_t content_encoding;
    char *location;
    int etag_len;
    char etag_buf[32];
    struct mk_iov *_extra_rows;
    int sent;
    struct mk_iov headers_iov;
    struct iovec __iov_io[32];
    void *__iov_buf[32];
};
struct mk_http_request
{
    int status;
    int protocol;
    int user_home;
    long port;
    uint64_t stream_size;
    struct mk_stream stream;
    struct mk_stream_input in_headers;
    struct mk_stream_input in_headers_extra;
    struct mk_stream_input in_file;
    struct mk_stream_input page_stream;
    int headers_len;
    int method;
    mk_ptr_t method_p;
    mk_ptr_t uri;
    mk_ptr_t uri_processed;
    mk_ptr_t protocol_p;
    mk_ptr_t body;
    int content_length;
    mk_ptr_t _content_length;
    mk_ptr_t content_type;
    mk_ptr_t connection;
    mk_ptr_t host;
    mk_ptr_t host_port;
    mk_ptr_t if_modified_since;
    mk_ptr_t last_modified_since;
    mk_ptr_t range;
    mk_ptr_t data;
    mk_ptr_t real_path;
    char real_path_static[128];
    mk_ptr_t query_string;
    int stage30_blocked;
    void *stage30_handler;
    int file_fd;
    struct file_info file_info;
    int vhost_fdt_id;
    unsigned int vhost_fdt_hash;
    int vhost_fdt_enabled;
    struct mk_vhost *host_conf;
    struct mk_vhost_alias *host_alias;
    void *handler_data;
    struct mk_http_session *session;
    void *thread;
    struct mk_list _head;
    struct response_headers headers;
};
enum {
    REQ_LEVEL_FIRST = 1,
    REQ_LEVEL_CONTINUE ,
    REQ_LEVEL_HEADERS ,
    REQ_LEVEL_END ,
    REQ_LEVEL_BODY
};
enum {
    MK_ST_REQ_METHOD = 1,
    MK_ST_REQ_URI ,
    MK_ST_REQ_QUERY_STRING ,
    MK_ST_REQ_PROT_VERSION ,
    MK_ST_FIRST_CONTINUE ,
    MK_ST_FIRST_FINALIZING ,
    MK_ST_FIRST_COMPLETE ,
    MK_ST_HEADER_KEY ,
    MK_ST_HEADER_SEP ,
    MK_ST_HEADER_VAL_STARTS ,
    MK_ST_HEADER_VALUE ,
    MK_ST_HEADER_END ,
    MK_ST_BLOCK_END
};
enum mk_request_headers {
    MK_HEADER_ACCEPT = 0,
    MK_HEADER_ACCEPT_CHARSET ,
    MK_HEADER_ACCEPT_ENCODING ,
    MK_HEADER_ACCEPT_LANGUAGE ,
    MK_HEADER_AUTHORIZATION ,
    MK_HEADER_CACHE_CONTROL ,
    MK_HEADER_COOKIE ,
    MK_HEADER_CONNECTION ,
    MK_HEADER_CONTENT_LENGTH ,
    MK_HEADER_CONTENT_RANGE ,
    MK_HEADER_CONTENT_TYPE ,
    MK_HEADER_HOST ,
    MK_HEADER_HTTP2_SETTINGS ,
    MK_HEADER_IF_MODIFIED_SINCE ,
    MK_HEADER_LAST_MODIFIED ,
    MK_HEADER_LAST_MODIFIED_SINCE ,
    MK_HEADER_RANGE ,
    MK_HEADER_REFERER ,
    MK_HEADER_TRANSFER_ENCODING ,
    MK_HEADER_UPGRADE ,
    MK_HEADER_USER_AGENT ,
    MK_HEADER_SIZEOF ,
    MK_HEADER_OTHER
};
struct mk_http_header {
    int type;
    mk_ptr_t key;
    mk_ptr_t val;
    struct mk_list _head;
};
struct mk_http_parser {
    int i;
    int level;
    int status;
    int next;
    int length;
    int method;
    int start;
    int end;
    int chars;
    int header_host_port;
    long int body_received;
    long int header_content_length;
    int header_connection;
    int header_upgrade;
    int header_transfer_encoding;
    int header_key;
    int header_sep;
    int header_val;
    int header_min;
    int header_max;
    int headers_extra_count;
    struct mk_http_header headers[MK_HEADER_SIZEOF];
    int header_count;
    struct mk_list header_list;
    struct mk_http_header headers_extra[50];
    size_t chunk_total_size_received;
    char *chunk_expected_start;
    size_t chunk_expected_size;
    char *chunk_processed_start;
    char *chunk_processed_end;
};
static inline void mk_http_parser_init(struct mk_http_parser *p)
{
    memset(p, '\0', sizeof(struct mk_http_parser));
    p->level = REQ_LEVEL_FIRST;
    p->status = MK_ST_REQ_METHOD;
    p->chars = -1;
    p->method = -1;
    p->header_key = -1;
    p->header_sep = -1;
    p->header_val = -1;
    p->header_min = -1;
    p->header_max = -1;
    p->header_content_length = -1;
    p->header_count = 0;
    mk_list_init(&p->header_list);
}
int mk_http_parser(struct mk_http_request *req, struct mk_http_parser *p,
                   char *buffer, int buf_len, struct mk_server *server);
size_t mk_http_parser_content_length(struct mk_http_parser *p);
int mk_http_parser_is_content_chunked(struct mk_http_parser *p);
int mk_http_parser_chunked_decode(struct mk_http_parser *p,
                                  char *buf_request, size_t buf_request_len,
                                  char **out_buf, size_t *out_buf_size);
int mk_http_parser_chunked_decode_buf(struct mk_http_parser *p,
                                      char *buf_request, size_t buf_request_len,
                                      char *out_buf, size_t out_buf_size, size_t *out_buf_len);
static inline int mk_http_parser_more(struct mk_http_parser *p, int len)
{
    if (len <= 0 || p->i < 0) {
        return 0;
    }
    if ((p->i + 1) < len) {
        return !0;
    }
    return 0;
}
static inline size_t mk_http_parser_request_size(struct mk_http_parser *p, char *buf_request, size_t buf_request_len)
{
    size_t bytes;
    if (mk_http_parser_is_content_chunked(p)) {
        if (p->chunk_processed_start < buf_request) {
            return -1;
        }
        bytes = p->chunk_processed_start - buf_request + 5;
        if (bytes > buf_request_len) {
            return -1;
        }
        return bytes;
    }
    else if (p->header_content_length > 0) {
        return p->i;
    }
    return -1;
}
extern const mk_ptr_t mk_http_method_get_p;
extern const mk_ptr_t mk_http_method_post_p;
extern const mk_ptr_t mk_http_method_head_p;
extern const mk_ptr_t mk_http_method_put_p;
extern const mk_ptr_t mk_http_method_delete_p;
extern const mk_ptr_t mk_http_method_options_p;
extern const mk_ptr_t mk_http_method_null_p;
extern const mk_ptr_t mk_http_protocol_09_p;
extern const mk_ptr_t mk_http_protocol_10_p;
extern const mk_ptr_t mk_http_protocol_11_p;
extern const mk_ptr_t mk_http_protocol_null_p;
struct mk_http_session
{
    int _sched_init;
    int socket;
    int pipelined;
    int counter_connections;
    int status;
    int close_now;
    struct mk_channel *channel;
    struct mk_sched_conn *conn;
    unsigned int body_size;
    unsigned int body_length;
    struct mk_list request_list;
    time_t init_time;
    char *body;
    char body_fixed[(int) 4096 + 1];
    struct mk_http_request sr_fixed;
    struct mk_http_parser parser;
    struct mk_server *server;
};
static inline int mk_http_status_completed(struct mk_http_session *cs,
                                           struct mk_sched_conn *conn)
{
    (void) conn;
    if (cs->status == 0) {
        do {} while (0);
        return -1;
    }
    cs->status = 0;
    return 0;
}
int mk_http_error(int http_status, struct mk_http_session *cs,
                  struct mk_http_request *sr,
                  struct mk_server *server);
int mk_http_method_check(mk_ptr_t method);
mk_ptr_t mk_http_method_check_str(int method);
int mk_http_method_get(char *body);
int mk_http_protocol_check(char *protocol, int len);
mk_ptr_t mk_http_protocol_check_str(int protocol);
int mk_http_init(struct mk_http_session *cs, struct mk_http_request *sr,
                 struct mk_server *server);
int mk_http_keepalive_check(struct mk_http_session *cs,
                            struct mk_http_request *sr,
                            struct mk_server *server);
int mk_http_pending_request(struct mk_http_session *cs);
int mk_http_send_file(struct mk_http_session *cs, struct mk_http_request *sr);
int mk_http_session_init(struct mk_http_session *cs,
                         struct mk_sched_conn *conn,
                         struct mk_server *server);
void mk_http_session_remove(struct mk_http_session *cs,
                            struct mk_server *server);
int mk_http_handler_read(struct mk_sched_conn *conn, struct mk_http_session *cs,
                         struct mk_server *server);
int mk_http_handler_write(int socket, struct mk_http_session *cs);
void mk_http_request_free(struct mk_http_request *sr, struct mk_server *server);
void mk_http_request_free_list(struct mk_http_session *cs,
                               struct mk_server *server);
void mk_http_request_init(struct mk_http_session *session,
                          struct mk_http_request *request,
                          struct mk_server *server);
struct mk_http_header *mk_http_header_get(int name, struct mk_http_request *req,
                                          const char *key, unsigned int len);
int mk_http_request_end(struct mk_http_session *cs, struct mk_server *server);
struct flb_http_stream;
struct flb_http_server_session;
struct flb_http_request {
    int protocol_version;
    cfl_sds_t authority;
    int method;
    cfl_sds_t path;
    cfl_sds_t host;
    uint16_t port;
    cfl_sds_t query_string;
    struct flb_hash_table *headers;
    struct flb_hash_table *trailer_headers;
    cfl_sds_t user_agent;
    size_t content_length;
    char *content_type;
    cfl_sds_t body;
    size_t body_read_offset;
    struct flb_http_stream *stream;
    int releasable;
    struct cfl_list _head;
};
struct flb_http_response {
    int protocol_version;
    int status;
    cfl_sds_t message;
    struct flb_hash_table *headers;
    struct flb_hash_table *trailer_headers;
    size_t content_length;
    char *content_type;
    cfl_sds_t body;
    size_t body_read_offset;
    struct flb_http_stream *stream;
    int releasable;
    struct cfl_list _head;
};
struct flb_http_stream {
    int32_t id;
    int role;
    int status;
    struct flb_http_request request;
    struct flb_http_response response;
    void *parent;
    void *user_data;
    int releasable;
    struct cfl_list _head;
};
struct flb_aws_provider;
struct flb_connection;
int flb_http_request_init(struct flb_http_request *request);
struct flb_http_request *flb_http_request_create();
void flb_http_request_destroy(struct flb_http_request *request);
int flb_http_request_commit(struct flb_http_request *request);
char *flb_http_request_get_header(struct flb_http_request *request,
                                  char *name);
const char *flb_http_request_get_remote_address(struct flb_http_request *request);
int flb_http_request_set_header(struct flb_http_request *request,
                                char *name, size_t name_length,
                                char *value, size_t value_length);
int flb_http_request_unset_header(struct flb_http_request *request,
                                  char *name);
int flb_http_request_set_method(struct flb_http_request *request,
                                int method);
int flb_http_request_set_host(struct flb_http_request *request,
                              char *host);
int flb_http_request_set_port(struct flb_http_request *request,
                              uint16_t port);
int flb_http_request_set_url(struct flb_http_request *request,
                             char *url);
int flb_http_request_set_uri(struct flb_http_request *request,
                             char *uri);
int flb_http_request_set_query_string(struct flb_http_request *request,
                                      char *query_string);
int flb_http_request_set_content_type(struct flb_http_request *request,
                                      char *content_type);
int flb_http_request_set_user_agent(struct flb_http_request *request,
                                    char *user_agent);
int flb_http_request_set_content_length(struct flb_http_request *request,
                                        size_t content_length);
int flb_http_request_set_content_encoding(struct flb_http_request *request,
                                          char *encoding);
int flb_http_request_set_body(struct flb_http_request *request,
                              unsigned char *body, size_t body_length,
                              char *compression_algorithm);
int flb_http_request_normalize(struct flb_http_request *request);
int flb_http_request_set_authorization(struct flb_http_request *request,
                                       int type, ...);
int flb_http_request_compress_body(
    struct flb_http_request *request,
    char *content_encoding_header_value);
int flb_http_request_uncompress_body(
    struct flb_http_request *request);
int flb_http_request_perform_signv4_signature(
        struct flb_http_request *request,
        const char *aws_region,
        const char *aws_service,
        struct flb_aws_provider *aws_provider);
int flb_http_response_init(struct flb_http_response *response);
struct flb_http_response *flb_http_response_create();
void flb_http_response_destroy(struct flb_http_response *response);
struct flb_http_response *flb_http_response_begin(
                                struct flb_http_server_session *session,
                                void *stream);
int flb_http_response_commit(struct flb_http_response *response);
char *flb_http_response_get_header(struct flb_http_response *response,
                                  char *name);
int flb_http_response_set_header(struct flb_http_response *response,
                             char *name, size_t name_length,
                             char *value, size_t value_length);
int flb_http_response_unset_header(struct flb_http_response *response,
                                  char *name);
int flb_http_response_set_trailer_header(struct flb_http_response *response,
                                         char *name, size_t name_length,
                                         char *value, size_t value_length);
int flb_http_response_set_status(struct flb_http_response *response,
                             int status);
int flb_http_response_set_message(struct flb_http_response *response,
                              char *message);
int flb_http_response_set_body(struct flb_http_response *response,
                           unsigned char *body, size_t body_length);
int flb_http_response_append_to_body(struct flb_http_response *response,
                                     unsigned char *body, size_t body_length);
int flb_http_response_compress_body(
    struct flb_http_response *response,
    char *content_encoding_header_value);
int flb_http_response_uncompress_body(
    struct flb_http_response *response);
int flb_http_stream_init(struct flb_http_stream *stream,
                     void *parent,
                     int32_t stream_id,
                     int role,
                     void *user_data);
struct flb_http_stream *flb_http_stream_create(void *parent,
                                           int32_t stream_id,
                                           int role,
                                           void *user_data);
void flb_http_stream_destroy(struct flb_http_stream *stream);
const char *flb_http_get_method_string_from_id(int method);
char *flb_http_server_convert_string_to_lowercase(char *input_buffer,
                                                  size_t length);
int flb_http_server_strncasecmp(const uint8_t *first_buffer,
                                size_t first_length,
                                const char *second_buffer,
                                size_t second_length);
struct flb_http_client;
struct flb_http_client_session;
struct flb_http1_client_session {
    struct flb_http_client *inner_session;
    int initialized;
    struct flb_http_client_session *parent;
};
int flb_http1_client_session_init(struct flb_http1_client_session *session);
void flb_http1_client_session_destroy(struct flb_http1_client_session *session);
int flb_http1_client_session_ingest(struct flb_http1_client_session *session,
                                    unsigned char *buffer,
                                    size_t length);
int flb_http1_request_begin(struct flb_http_request *request);
int flb_http1_request_commit(struct flb_http_request *request);

typedef ptrdiff_t nghttp2_ssize;
struct nghttp2_session;
typedef struct nghttp2_session nghttp2_session;
typedef struct {
  int age;
  int version_num;
  const char *version_str;
  const char *proto_str;
} nghttp2_info;
typedef enum {
  NGHTTP2_ERR_INVALID_ARGUMENT = -501,
  NGHTTP2_ERR_BUFFER_ERROR = -502,
  NGHTTP2_ERR_UNSUPPORTED_VERSION = -503,
  NGHTTP2_ERR_WOULDBLOCK = -504,
  NGHTTP2_ERR_PROTO = -505,
  NGHTTP2_ERR_INVALID_FRAME = -506,
  NGHTTP2_ERR_EOF = -507,
  NGHTTP2_ERR_DEFERRED = -508,
  NGHTTP2_ERR_STREAM_ID_NOT_AVAILABLE = -509,
  NGHTTP2_ERR_STREAM_CLOSED = -510,
  NGHTTP2_ERR_STREAM_CLOSING = -511,
  NGHTTP2_ERR_STREAM_SHUT_WR = -512,
  NGHTTP2_ERR_INVALID_STREAM_ID = -513,
  NGHTTP2_ERR_INVALID_STREAM_STATE = -514,
  NGHTTP2_ERR_DEFERRED_DATA_EXIST = -515,
  NGHTTP2_ERR_START_STREAM_NOT_ALLOWED = -516,
  NGHTTP2_ERR_GOAWAY_ALREADY_SENT = -517,
  NGHTTP2_ERR_INVALID_HEADER_BLOCK = -518,
  NGHTTP2_ERR_INVALID_STATE = -519,
  NGHTTP2_ERR_TEMPORAL_CALLBACK_FAILURE = -521,
  NGHTTP2_ERR_FRAME_SIZE_ERROR = -522,
  NGHTTP2_ERR_HEADER_COMP = -523,
  NGHTTP2_ERR_FLOW_CONTROL = -524,
  NGHTTP2_ERR_INSUFF_BUFSIZE = -525,
  NGHTTP2_ERR_PAUSE = -526,
  NGHTTP2_ERR_TOO_MANY_INFLIGHT_SETTINGS = -527,
  NGHTTP2_ERR_PUSH_DISABLED = -528,
  NGHTTP2_ERR_DATA_EXIST = -529,
  NGHTTP2_ERR_SESSION_CLOSING = -530,
  NGHTTP2_ERR_HTTP_HEADER = -531,
  NGHTTP2_ERR_HTTP_MESSAGING = -532,
  NGHTTP2_ERR_REFUSED_STREAM = -533,
  NGHTTP2_ERR_INTERNAL = -534,
  NGHTTP2_ERR_CANCEL = -535,
  NGHTTP2_ERR_SETTINGS_EXPECTED = -536,
  NGHTTP2_ERR_TOO_MANY_SETTINGS = -537,
  NGHTTP2_ERR_FATAL = -900,
  NGHTTP2_ERR_NOMEM = -901,
  NGHTTP2_ERR_CALLBACK_FAILURE = -902,
  NGHTTP2_ERR_BAD_CLIENT_MAGIC = -903,
  NGHTTP2_ERR_FLOODED = -904,
  NGHTTP2_ERR_TOO_MANY_CONTINUATIONS = -905,
} nghttp2_error;
typedef struct {
  uint8_t *base;
  size_t len;
} nghttp2_vec;
struct nghttp2_rcbuf;
typedef struct nghttp2_rcbuf nghttp2_rcbuf;
               void nghttp2_rcbuf_incref(nghttp2_rcbuf *rcbuf);
               void nghttp2_rcbuf_decref(nghttp2_rcbuf *rcbuf);
               nghttp2_vec nghttp2_rcbuf_get_buf(nghttp2_rcbuf *rcbuf);
               int nghttp2_rcbuf_is_static(const nghttp2_rcbuf *rcbuf);
typedef enum {
  NGHTTP2_NV_FLAG_NONE = 0,
  NGHTTP2_NV_FLAG_NO_INDEX = 0x01,
  NGHTTP2_NV_FLAG_NO_COPY_NAME = 0x02,
  NGHTTP2_NV_FLAG_NO_COPY_VALUE = 0x04
} nghttp2_nv_flag;
typedef struct {
  uint8_t *name;
  uint8_t *value;
  size_t namelen;
  size_t valuelen;
  uint8_t flags;
} nghttp2_nv;
typedef enum {
  NGHTTP2_DATA = 0,
  NGHTTP2_HEADERS = 0x01,
  NGHTTP2_PRIORITY = 0x02,
  NGHTTP2_RST_STREAM = 0x03,
  NGHTTP2_SETTINGS = 0x04,
  NGHTTP2_PUSH_PROMISE = 0x05,
  NGHTTP2_PING = 0x06,
  NGHTTP2_GOAWAY = 0x07,
  NGHTTP2_WINDOW_UPDATE = 0x08,
  NGHTTP2_CONTINUATION = 0x09,
  NGHTTP2_ALTSVC = 0x0a,
  NGHTTP2_ORIGIN = 0x0c,
  NGHTTP2_PRIORITY_UPDATE = 0x10
} nghttp2_frame_type;
typedef enum {
  NGHTTP2_FLAG_NONE = 0,
  NGHTTP2_FLAG_END_STREAM = 0x01,
  NGHTTP2_FLAG_END_HEADERS = 0x04,
  NGHTTP2_FLAG_ACK = 0x01,
  NGHTTP2_FLAG_PADDED = 0x08,
  NGHTTP2_FLAG_PRIORITY = 0x20
} nghttp2_flag;
typedef enum {
  NGHTTP2_SETTINGS_HEADER_TABLE_SIZE = 0x01,
  NGHTTP2_SETTINGS_ENABLE_PUSH = 0x02,
  NGHTTP2_SETTINGS_MAX_CONCURRENT_STREAMS = 0x03,
  NGHTTP2_SETTINGS_INITIAL_WINDOW_SIZE = 0x04,
  NGHTTP2_SETTINGS_MAX_FRAME_SIZE = 0x05,
  NGHTTP2_SETTINGS_MAX_HEADER_LIST_SIZE = 0x06,
  NGHTTP2_SETTINGS_ENABLE_CONNECT_PROTOCOL = 0x08,
  NGHTTP2_SETTINGS_NO_RFC7540_PRIORITIES = 0x09
} nghttp2_settings_id;
typedef enum {
  NGHTTP2_NO_ERROR = 0x00,
  NGHTTP2_PROTOCOL_ERROR = 0x01,
  NGHTTP2_INTERNAL_ERROR = 0x02,
  NGHTTP2_FLOW_CONTROL_ERROR = 0x03,
  NGHTTP2_SETTINGS_TIMEOUT = 0x04,
  NGHTTP2_STREAM_CLOSED = 0x05,
  NGHTTP2_FRAME_SIZE_ERROR = 0x06,
  NGHTTP2_REFUSED_STREAM = 0x07,
  NGHTTP2_CANCEL = 0x08,
  NGHTTP2_COMPRESSION_ERROR = 0x09,
  NGHTTP2_CONNECT_ERROR = 0x0a,
  NGHTTP2_ENHANCE_YOUR_CALM = 0x0b,
  NGHTTP2_INADEQUATE_SECURITY = 0x0c,
  NGHTTP2_HTTP_1_1_REQUIRED = 0x0d
} nghttp2_error_code;
typedef struct {
  size_t length;
  int32_t stream_id;
  uint8_t type;
  uint8_t flags;
  uint8_t reserved;
} nghttp2_frame_hd;
typedef union {
  int fd;
  void *ptr;
} nghttp2_data_source;
typedef enum {
  NGHTTP2_DATA_FLAG_NONE = 0,
  NGHTTP2_DATA_FLAG_EOF = 0x01,
  NGHTTP2_DATA_FLAG_NO_END_STREAM = 0x02,
  NGHTTP2_DATA_FLAG_NO_COPY = 0x04
} nghttp2_data_flag;
typedef ssize_t (*nghttp2_data_source_read_callback)(
  nghttp2_session *session, int32_t stream_id, uint8_t *buf, size_t length,
  uint32_t *data_flags, nghttp2_data_source *source, void *user_data);
typedef nghttp2_ssize (*nghttp2_data_source_read_callback2)(
  nghttp2_session *session, int32_t stream_id, uint8_t *buf, size_t length,
  uint32_t *data_flags, nghttp2_data_source *source, void *user_data);
typedef struct {
  nghttp2_data_source source;
  nghttp2_data_source_read_callback read_callback;
} nghttp2_data_provider;
typedef struct {
  nghttp2_data_source source;
  nghttp2_data_source_read_callback2 read_callback;
} nghttp2_data_provider2;
typedef struct {
  nghttp2_frame_hd hd;
  size_t padlen;
} nghttp2_data;
typedef enum {
  NGHTTP2_HCAT_REQUEST = 0,
  NGHTTP2_HCAT_RESPONSE = 1,
  NGHTTP2_HCAT_PUSH_RESPONSE = 2,
  NGHTTP2_HCAT_HEADERS = 3
} nghttp2_headers_category;
typedef struct {
  int32_t stream_id;
  int32_t weight;
  uint8_t exclusive;
} nghttp2_priority_spec;
typedef struct {
  nghttp2_frame_hd hd;
  size_t padlen;
  nghttp2_priority_spec pri_spec;
  nghttp2_nv *nva;
  size_t nvlen;
  nghttp2_headers_category cat;
} nghttp2_headers;
typedef struct {
  nghttp2_frame_hd hd;
  nghttp2_priority_spec pri_spec;
} nghttp2_priority;
typedef struct {
  nghttp2_frame_hd hd;
  uint32_t error_code;
} nghttp2_rst_stream;
typedef struct {
  int32_t settings_id;
  uint32_t value;
} nghttp2_settings_entry;
typedef struct {
  nghttp2_frame_hd hd;
  size_t niv;
  nghttp2_settings_entry *iv;
} nghttp2_settings;
typedef struct {
  nghttp2_frame_hd hd;
  size_t padlen;
  nghttp2_nv *nva;
  size_t nvlen;
  int32_t promised_stream_id;
  uint8_t reserved;
} nghttp2_push_promise;
typedef struct {
  nghttp2_frame_hd hd;
  uint8_t opaque_data[8];
} nghttp2_ping;
typedef struct {
  nghttp2_frame_hd hd;
  int32_t last_stream_id;
  uint32_t error_code;
  uint8_t *opaque_data;
  size_t opaque_data_len;
  uint8_t reserved;
} nghttp2_goaway;
typedef struct {
  nghttp2_frame_hd hd;
  int32_t window_size_increment;
  uint8_t reserved;
} nghttp2_window_update;
typedef struct {
  nghttp2_frame_hd hd;
  void *payload;
} nghttp2_extension;
typedef union {
  nghttp2_frame_hd hd;
  nghttp2_data data;
  nghttp2_headers headers;
  nghttp2_priority priority;
  nghttp2_rst_stream rst_stream;
  nghttp2_settings settings;
  nghttp2_push_promise push_promise;
  nghttp2_ping ping;
  nghttp2_goaway goaway;
  nghttp2_window_update window_update;
  nghttp2_extension ext;
} nghttp2_frame;
typedef ssize_t (*nghttp2_send_callback)(nghttp2_session *session,
                                         const uint8_t *data, size_t length,
                                         int flags, void *user_data);
typedef nghttp2_ssize (*nghttp2_send_callback2)(nghttp2_session *session,
                                                const uint8_t *data,
                                                size_t length, int flags,
                                                void *user_data);
typedef int (*nghttp2_send_data_callback)(nghttp2_session *session,
                                          nghttp2_frame *frame,
                                          const uint8_t *framehd, size_t length,
                                          nghttp2_data_source *source,
                                          void *user_data);
typedef ssize_t (*nghttp2_recv_callback)(nghttp2_session *session, uint8_t *buf,
                                         size_t length, int flags,
                                         void *user_data);
typedef nghttp2_ssize (*nghttp2_recv_callback2)(nghttp2_session *session,
                                                uint8_t *buf, size_t length,
                                                int flags, void *user_data);
typedef int (*nghttp2_on_frame_recv_callback)(nghttp2_session *session,
                                              const nghttp2_frame *frame,
                                              void *user_data);
typedef int (*nghttp2_on_invalid_frame_recv_callback)(
  nghttp2_session *session, const nghttp2_frame *frame, int lib_error_code,
  void *user_data);
typedef int (*nghttp2_on_data_chunk_recv_callback)(nghttp2_session *session,
                                                   uint8_t flags,
                                                   int32_t stream_id,
                                                   const uint8_t *data,
                                                   size_t len, void *user_data);
typedef int (*nghttp2_before_frame_send_callback)(nghttp2_session *session,
                                                  const nghttp2_frame *frame,
                                                  void *user_data);
typedef int (*nghttp2_on_frame_send_callback)(nghttp2_session *session,
                                              const nghttp2_frame *frame,
                                              void *user_data);
typedef int (*nghttp2_on_frame_not_send_callback)(nghttp2_session *session,
                                                  const nghttp2_frame *frame,
                                                  int lib_error_code,
                                                  void *user_data);
typedef int (*nghttp2_on_stream_close_callback)(nghttp2_session *session,
                                                int32_t stream_id,
                                                uint32_t error_code,
                                                void *user_data);
typedef int (*nghttp2_on_begin_headers_callback)(nghttp2_session *session,
                                                 const nghttp2_frame *frame,
                                                 void *user_data);
typedef int (*nghttp2_on_header_callback)(nghttp2_session *session,
                                          const nghttp2_frame *frame,
                                          const uint8_t *name, size_t namelen,
                                          const uint8_t *value, size_t valuelen,
                                          uint8_t flags, void *user_data);
typedef int (*nghttp2_on_header_callback2)(nghttp2_session *session,
                                           const nghttp2_frame *frame,
                                           nghttp2_rcbuf *name,
                                           nghttp2_rcbuf *value, uint8_t flags,
                                           void *user_data);
typedef int (*nghttp2_on_invalid_header_callback)(
  nghttp2_session *session, const nghttp2_frame *frame, const uint8_t *name,
  size_t namelen, const uint8_t *value, size_t valuelen, uint8_t flags,
  void *user_data);
typedef int (*nghttp2_on_invalid_header_callback2)(
  nghttp2_session *session, const nghttp2_frame *frame, nghttp2_rcbuf *name,
  nghttp2_rcbuf *value, uint8_t flags, void *user_data);
typedef ssize_t (*nghttp2_select_padding_callback)(nghttp2_session *session,
                                                   const nghttp2_frame *frame,
                                                   size_t max_payloadlen,
                                                   void *user_data);
typedef nghttp2_ssize (*nghttp2_select_padding_callback2)(
  nghttp2_session *session, const nghttp2_frame *frame, size_t max_payloadlen,
  void *user_data);
typedef ssize_t (*nghttp2_data_source_read_length_callback)(
  nghttp2_session *session, uint8_t frame_type, int32_t stream_id,
  int32_t session_remote_window_size, int32_t stream_remote_window_size,
  uint32_t remote_max_frame_size, void *user_data);
typedef nghttp2_ssize (*nghttp2_data_source_read_length_callback2)(
  nghttp2_session *session, uint8_t frame_type, int32_t stream_id,
  int32_t session_remote_window_size, int32_t stream_remote_window_size,
  uint32_t remote_max_frame_size, void *user_data);
typedef int (*nghttp2_on_begin_frame_callback)(nghttp2_session *session,
                                               const nghttp2_frame_hd *hd,
                                               void *user_data);
typedef int (*nghttp2_on_extension_chunk_recv_callback)(
  nghttp2_session *session, const nghttp2_frame_hd *hd, const uint8_t *data,
  size_t len, void *user_data);
typedef int (*nghttp2_unpack_extension_callback)(nghttp2_session *session,
                                                 void **payload,
                                                 const nghttp2_frame_hd *hd,
                                                 void *user_data);
typedef ssize_t (*nghttp2_pack_extension_callback)(nghttp2_session *session,
                                                   uint8_t *buf, size_t len,
                                                   const nghttp2_frame *frame,
                                                   void *user_data);
typedef nghttp2_ssize (*nghttp2_pack_extension_callback2)(
  nghttp2_session *session, uint8_t *buf, size_t len,
  const nghttp2_frame *frame, void *user_data);
typedef int (*nghttp2_error_callback)(nghttp2_session *session, const char *msg,
                                      size_t len, void *user_data);
typedef int (*nghttp2_error_callback2)(nghttp2_session *session,
                                       int lib_error_code, const char *msg,
                                       size_t len, void *user_data);
struct nghttp2_session_callbacks;
typedef struct nghttp2_session_callbacks nghttp2_session_callbacks;
               int
nghttp2_session_callbacks_new(nghttp2_session_callbacks **callbacks_ptr);
               void
nghttp2_session_callbacks_del(nghttp2_session_callbacks *callbacks);
               void nghttp2_session_callbacks_set_send_callback(
  nghttp2_session_callbacks *cbs, nghttp2_send_callback send_callback);
               void nghttp2_session_callbacks_set_send_callback2(
  nghttp2_session_callbacks *cbs, nghttp2_send_callback2 send_callback);
               void nghttp2_session_callbacks_set_recv_callback(
  nghttp2_session_callbacks *cbs, nghttp2_recv_callback recv_callback);
               void nghttp2_session_callbacks_set_recv_callback2(
  nghttp2_session_callbacks *cbs, nghttp2_recv_callback2 recv_callback);
               void nghttp2_session_callbacks_set_on_frame_recv_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_frame_recv_callback on_frame_recv_callback);
               void
nghttp2_session_callbacks_set_on_invalid_frame_recv_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_invalid_frame_recv_callback on_invalid_frame_recv_callback);
               void nghttp2_session_callbacks_set_on_data_chunk_recv_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_data_chunk_recv_callback on_data_chunk_recv_callback);
               void nghttp2_session_callbacks_set_before_frame_send_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_before_frame_send_callback before_frame_send_callback);
               void nghttp2_session_callbacks_set_on_frame_send_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_frame_send_callback on_frame_send_callback);
               void nghttp2_session_callbacks_set_on_frame_not_send_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_frame_not_send_callback on_frame_not_send_callback);
               void nghttp2_session_callbacks_set_on_stream_close_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_stream_close_callback on_stream_close_callback);
               void nghttp2_session_callbacks_set_on_begin_headers_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_begin_headers_callback on_begin_headers_callback);
               void nghttp2_session_callbacks_set_on_header_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_header_callback on_header_callback);
               void nghttp2_session_callbacks_set_on_header_callback2(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_header_callback2 on_header_callback2);
               void nghttp2_session_callbacks_set_on_invalid_header_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_invalid_header_callback on_invalid_header_callback);
               void nghttp2_session_callbacks_set_on_invalid_header_callback2(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_invalid_header_callback2 on_invalid_header_callback2);
               void nghttp2_session_callbacks_set_select_padding_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_select_padding_callback select_padding_callback);
               void nghttp2_session_callbacks_set_select_padding_callback2(
  nghttp2_session_callbacks *cbs,
  nghttp2_select_padding_callback2 select_padding_callback);
               void
nghttp2_session_callbacks_set_data_source_read_length_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_data_source_read_length_callback data_source_read_length_callback);
               void
nghttp2_session_callbacks_set_data_source_read_length_callback2(
  nghttp2_session_callbacks *cbs,
  nghttp2_data_source_read_length_callback2 data_source_read_length_callback);
               void nghttp2_session_callbacks_set_on_begin_frame_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_begin_frame_callback on_begin_frame_callback);
               void nghttp2_session_callbacks_set_send_data_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_send_data_callback send_data_callback);
               void nghttp2_session_callbacks_set_pack_extension_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_pack_extension_callback pack_extension_callback);
               void nghttp2_session_callbacks_set_pack_extension_callback2(
  nghttp2_session_callbacks *cbs,
  nghttp2_pack_extension_callback2 pack_extension_callback);
               void nghttp2_session_callbacks_set_unpack_extension_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_unpack_extension_callback unpack_extension_callback);
               void
nghttp2_session_callbacks_set_on_extension_chunk_recv_callback(
  nghttp2_session_callbacks *cbs,
  nghttp2_on_extension_chunk_recv_callback on_extension_chunk_recv_callback);
               void nghttp2_session_callbacks_set_error_callback(
  nghttp2_session_callbacks *cbs, nghttp2_error_callback error_callback);
               void nghttp2_session_callbacks_set_error_callback2(
  nghttp2_session_callbacks *cbs, nghttp2_error_callback2 error_callback2);
typedef void *(*nghttp2_malloc)(size_t size, void *mem_user_data);
typedef void (*nghttp2_free)(void *ptr, void *mem_user_data);
typedef void *(*nghttp2_calloc)(size_t nmemb, size_t size, void *mem_user_data);
typedef void *(*nghttp2_realloc)(void *ptr, size_t size, void *mem_user_data);
typedef struct {
  void *mem_user_data;
  nghttp2_malloc malloc;
  nghttp2_free free;
  nghttp2_calloc calloc;
  nghttp2_realloc realloc;
} nghttp2_mem;
struct nghttp2_option;
typedef struct nghttp2_option nghttp2_option;
               int nghttp2_option_new(nghttp2_option **option_ptr);
               void nghttp2_option_del(nghttp2_option *option);
               void
nghttp2_option_set_no_auto_window_update(nghttp2_option *option, int val);
               void
nghttp2_option_set_peer_max_concurrent_streams(nghttp2_option *option,
                                               uint32_t val);
               void
nghttp2_option_set_no_recv_client_magic(nghttp2_option *option, int val);
               void nghttp2_option_set_no_http_messaging(nghttp2_option *option,
                                                         int val);
               void
nghttp2_option_set_max_reserved_remote_streams(nghttp2_option *option,
                                               uint32_t val);
               void
nghttp2_option_set_user_recv_extension_type(nghttp2_option *option,
                                            uint8_t type);
               void
nghttp2_option_set_builtin_recv_extension_type(nghttp2_option *option,
                                               uint8_t type);
               void nghttp2_option_set_no_auto_ping_ack(nghttp2_option *option,
                                                        int val);
               void
nghttp2_option_set_max_send_header_block_length(nghttp2_option *option,
                                                size_t val);
               void
nghttp2_option_set_max_deflate_dynamic_table_size(nghttp2_option *option,
                                                  size_t val);
               void nghttp2_option_set_no_closed_streams(nghttp2_option *option,
                                                         int val);
               void nghttp2_option_set_max_outbound_ack(nghttp2_option *option,
                                                        size_t val);
               void nghttp2_option_set_max_settings(nghttp2_option *option,
                                                    size_t val);
               void
nghttp2_option_set_server_fallback_rfc7540_priorities(nghttp2_option *option,
                                                      int val);
               void
nghttp2_option_set_no_rfc9113_leading_and_trailing_ws_validation(
  nghttp2_option *option, int val);
               void
nghttp2_option_set_stream_reset_rate_limit(nghttp2_option *option,
                                           uint64_t burst, uint64_t rate);
               void nghttp2_option_set_max_continuations(nghttp2_option *option,
                                                         size_t val);
               int
nghttp2_session_client_new(nghttp2_session **session_ptr,
                           const nghttp2_session_callbacks *callbacks,
                           void *user_data);
               int
nghttp2_session_server_new(nghttp2_session **session_ptr,
                           const nghttp2_session_callbacks *callbacks,
                           void *user_data);
               int
nghttp2_session_client_new2(nghttp2_session **session_ptr,
                            const nghttp2_session_callbacks *callbacks,
                            void *user_data, const nghttp2_option *option);
               int
nghttp2_session_server_new2(nghttp2_session **session_ptr,
                            const nghttp2_session_callbacks *callbacks,
                            void *user_data, const nghttp2_option *option);
               int nghttp2_session_client_new3(
  nghttp2_session **session_ptr, const nghttp2_session_callbacks *callbacks,
  void *user_data, const nghttp2_option *option, nghttp2_mem *mem);
               int nghttp2_session_server_new3(
  nghttp2_session **session_ptr, const nghttp2_session_callbacks *callbacks,
  void *user_data, const nghttp2_option *option, nghttp2_mem *mem);
               void nghttp2_session_del(nghttp2_session *session);
               int nghttp2_session_send(nghttp2_session *session);
               ssize_t nghttp2_session_mem_send(nghttp2_session *session,
                                                const uint8_t **data_ptr);
               nghttp2_ssize
nghttp2_session_mem_send2(nghttp2_session *session, const uint8_t **data_ptr);
               int nghttp2_session_recv(nghttp2_session *session);
               ssize_t nghttp2_session_mem_recv(nghttp2_session *session,
                                                const uint8_t *in,
                                                size_t inlen);
               nghttp2_ssize nghttp2_session_mem_recv2(nghttp2_session *session,
                                                       const uint8_t *in,
                                                       size_t inlen);
               int nghttp2_session_resume_data(nghttp2_session *session,
                                               int32_t stream_id);
               int nghttp2_session_want_read(nghttp2_session *session);
               int nghttp2_session_want_write(nghttp2_session *session);
               void *
nghttp2_session_get_stream_user_data(nghttp2_session *session,
                                     int32_t stream_id);
               int
nghttp2_session_set_stream_user_data(nghttp2_session *session,
                                     int32_t stream_id, void *stream_user_data);
               void nghttp2_session_set_user_data(nghttp2_session *session,
                                                  void *user_data);
               size_t
nghttp2_session_get_outbound_queue_size(nghttp2_session *session);
               int32_t nghttp2_session_get_stream_effective_recv_data_length(
  nghttp2_session *session, int32_t stream_id);
               int32_t nghttp2_session_get_stream_effective_local_window_size(
  nghttp2_session *session, int32_t stream_id);
               int32_t nghttp2_session_get_stream_local_window_size(
  nghttp2_session *session, int32_t stream_id);
               int32_t
nghttp2_session_get_effective_recv_data_length(nghttp2_session *session);
               int32_t
nghttp2_session_get_effective_local_window_size(nghttp2_session *session);
               int32_t
nghttp2_session_get_local_window_size(nghttp2_session *session);
               int32_t nghttp2_session_get_stream_remote_window_size(
  nghttp2_session *session, int32_t stream_id);
               int32_t
nghttp2_session_get_remote_window_size(nghttp2_session *session);
               int
nghttp2_session_get_stream_local_close(nghttp2_session *session,
                                       int32_t stream_id);
               int
nghttp2_session_get_stream_remote_close(nghttp2_session *session,
                                        int32_t stream_id);
               size_t
nghttp2_session_get_hd_inflate_dynamic_table_size(nghttp2_session *session);
               size_t
nghttp2_session_get_hd_deflate_dynamic_table_size(nghttp2_session *session);
               int nghttp2_session_terminate_session(nghttp2_session *session,
                                                     uint32_t error_code);
               int nghttp2_session_terminate_session2(nghttp2_session *session,
                                                      int32_t last_stream_id,
                                                      uint32_t error_code);
               int nghttp2_submit_shutdown_notice(nghttp2_session *session);
               uint32_t nghttp2_session_get_remote_settings(
  nghttp2_session *session, nghttp2_settings_id id);
               uint32_t nghttp2_session_get_local_settings(
  nghttp2_session *session, nghttp2_settings_id id);
               int nghttp2_session_set_next_stream_id(nghttp2_session *session,
                                                      int32_t next_stream_id);
               uint32_t
nghttp2_session_get_next_stream_id(nghttp2_session *session);
               int nghttp2_session_consume(nghttp2_session *session,
                                           int32_t stream_id, size_t size);
               int nghttp2_session_consume_connection(nghttp2_session *session,
                                                      size_t size);
               int nghttp2_session_consume_stream(nghttp2_session *session,
                                                  int32_t stream_id,
                                                  size_t size);
               int
nghttp2_session_change_stream_priority(nghttp2_session *session,
                                       int32_t stream_id,
                                       const nghttp2_priority_spec *pri_spec);
               int
nghttp2_session_create_idle_stream(nghttp2_session *session, int32_t stream_id,
                                   const nghttp2_priority_spec *pri_spec);
               int nghttp2_session_upgrade(nghttp2_session *session,
                                           const uint8_t *settings_payload,
                                           size_t settings_payloadlen,
                                           void *stream_user_data);
               int nghttp2_session_upgrade2(nghttp2_session *session,
                                            const uint8_t *settings_payload,
                                            size_t settings_payloadlen,
                                            int head_request,
                                            void *stream_user_data);
               ssize_t nghttp2_pack_settings_payload(
  uint8_t *buf, size_t buflen, const nghttp2_settings_entry *iv, size_t niv);
               nghttp2_ssize nghttp2_pack_settings_payload2(
  uint8_t *buf, size_t buflen, const nghttp2_settings_entry *iv, size_t niv);
               const char *nghttp2_strerror(int lib_error_code);
               const char *nghttp2_http2_strerror(uint32_t error_code);
               void nghttp2_priority_spec_init(nghttp2_priority_spec *pri_spec,
                                               int32_t stream_id,
                                               int32_t weight, int exclusive);
               void
nghttp2_priority_spec_default_init(nghttp2_priority_spec *pri_spec);
               int
nghttp2_priority_spec_check_default(const nghttp2_priority_spec *pri_spec);
               int32_t nghttp2_submit_request(
  nghttp2_session *session, const nghttp2_priority_spec *pri_spec,
  const nghttp2_nv *nva, size_t nvlen, const nghttp2_data_provider *data_prd,
  void *stream_user_data);
               int32_t nghttp2_submit_request2(
  nghttp2_session *session, const nghttp2_priority_spec *pri_spec,
  const nghttp2_nv *nva, size_t nvlen, const nghttp2_data_provider2 *data_prd,
  void *stream_user_data);
               int
nghttp2_submit_response(nghttp2_session *session, int32_t stream_id,
                        const nghttp2_nv *nva, size_t nvlen,
                        const nghttp2_data_provider *data_prd);
               int
nghttp2_submit_response2(nghttp2_session *session, int32_t stream_id,
                         const nghttp2_nv *nva, size_t nvlen,
                         const nghttp2_data_provider2 *data_prd);
               int nghttp2_submit_trailer(nghttp2_session *session,
                                          int32_t stream_id,
                                          const nghttp2_nv *nva, size_t nvlen);
               int32_t nghttp2_submit_headers(
  nghttp2_session *session, uint8_t flags, int32_t stream_id,
  const nghttp2_priority_spec *pri_spec, const nghttp2_nv *nva, size_t nvlen,
  void *stream_user_data);
               int nghttp2_submit_data(nghttp2_session *session, uint8_t flags,
                                       int32_t stream_id,
                                       const nghttp2_data_provider *data_prd);
               int nghttp2_submit_data2(nghttp2_session *session, uint8_t flags,
                                        int32_t stream_id,
                                        const nghttp2_data_provider2 *data_prd);
               int
nghttp2_submit_priority(nghttp2_session *session, uint8_t flags,
                        int32_t stream_id,
                        const nghttp2_priority_spec *pri_spec);
typedef struct nghttp2_extpri {
  uint32_t urgency;
  int inc;
} nghttp2_extpri;
               int nghttp2_submit_rst_stream(nghttp2_session *session,
                                             uint8_t flags, int32_t stream_id,
                                             uint32_t error_code);
               int nghttp2_submit_settings(nghttp2_session *session,
                                           uint8_t flags,
                                           const nghttp2_settings_entry *iv,
                                           size_t niv);
               int32_t nghttp2_submit_push_promise(
  nghttp2_session *session, uint8_t flags, int32_t stream_id,
  const nghttp2_nv *nva, size_t nvlen, void *promised_stream_user_data);
               int nghttp2_submit_ping(nghttp2_session *session, uint8_t flags,
                                       const uint8_t *opaque_data);
               int nghttp2_submit_goaway(nghttp2_session *session,
                                         uint8_t flags, int32_t last_stream_id,
                                         uint32_t error_code,
                                         const uint8_t *opaque_data,
                                         size_t opaque_data_len);
               int32_t
nghttp2_session_get_last_proc_stream_id(nghttp2_session *session);
               int
nghttp2_session_check_request_allowed(nghttp2_session *session);
               int
nghttp2_session_check_server_session(nghttp2_session *session);
               int nghttp2_submit_window_update(nghttp2_session *session,
                                                uint8_t flags,
                                                int32_t stream_id,
                                                int32_t window_size_increment);
               int
nghttp2_session_set_local_window_size(nghttp2_session *session, uint8_t flags,
                                      int32_t stream_id, int32_t window_size);
               int nghttp2_submit_extension(nghttp2_session *session,
                                            uint8_t type, uint8_t flags,
                                            int32_t stream_id, void *payload);
typedef struct {
  uint8_t *origin;
  size_t origin_len;
  uint8_t *field_value;
  size_t field_value_len;
} nghttp2_ext_altsvc;
               int nghttp2_submit_altsvc(nghttp2_session *session,
                                         uint8_t flags, int32_t stream_id,
                                         const uint8_t *origin,
                                         size_t origin_len,
                                         const uint8_t *field_value,
                                         size_t field_value_len);
typedef struct {
  uint8_t *origin;
  size_t origin_len;
} nghttp2_origin_entry;
typedef struct {
  size_t nov;
  nghttp2_origin_entry *ov;
} nghttp2_ext_origin;
               int nghttp2_submit_origin(nghttp2_session *session,
                                         uint8_t flags,
                                         const nghttp2_origin_entry *ov,
                                         size_t nov);
typedef struct {
  int32_t stream_id;
  uint8_t *field_value;
  size_t field_value_len;
} nghttp2_ext_priority_update;
               int nghttp2_submit_priority_update(nghttp2_session *session,
                                                  uint8_t flags,
                                                  int32_t stream_id,
                                                  const uint8_t *field_value,
                                                  size_t field_value_len);
               int nghttp2_session_change_extpri_stream_priority(
  nghttp2_session *session, int32_t stream_id, const nghttp2_extpri *extpri,
  int ignore_client_signal);
               int nghttp2_session_get_extpri_stream_priority(
  nghttp2_session *session, nghttp2_extpri *extpri, int32_t stream_id);
               int nghttp2_extpri_parse_priority(nghttp2_extpri *extpri,
                                                 const uint8_t *value,
                                                 size_t len);
               int nghttp2_nv_compare_name(const nghttp2_nv *lhs,
                                           const nghttp2_nv *rhs);
               int nghttp2_select_next_protocol(unsigned char **out,
                                                unsigned char *outlen,
                                                const unsigned char *in,
                                                unsigned int inlen);
               int nghttp2_select_alpn(const unsigned char **out,
                                       unsigned char *outlen,
                                       const unsigned char *in,
                                       unsigned int inlen);
               nghttp2_info *nghttp2_version(int least_version);
               int nghttp2_is_fatal(int lib_error_code);
               int nghttp2_check_header_name(const uint8_t *name, size_t len);
               int nghttp2_check_header_value(const uint8_t *value, size_t len);
               int nghttp2_check_header_value_rfc9113(const uint8_t *value,
                                                      size_t len);
               int nghttp2_check_method(const uint8_t *value, size_t len);
               int nghttp2_check_path(const uint8_t *value, size_t len);
               int nghttp2_check_authority(const uint8_t *value, size_t len);
struct nghttp2_hd_deflater;
typedef struct nghttp2_hd_deflater nghttp2_hd_deflater;
               int
nghttp2_hd_deflate_new(nghttp2_hd_deflater **deflater_ptr,
                       size_t max_deflate_dynamic_table_size);
               int
nghttp2_hd_deflate_new2(nghttp2_hd_deflater **deflater_ptr,
                        size_t max_deflate_dynamic_table_size,
                        nghttp2_mem *mem);
               void nghttp2_hd_deflate_del(nghttp2_hd_deflater *deflater);
               int
nghttp2_hd_deflate_change_table_size(nghttp2_hd_deflater *deflater,
                                     size_t settings_max_dynamic_table_size);
               ssize_t nghttp2_hd_deflate_hd(nghttp2_hd_deflater *deflater,
                                             uint8_t *buf, size_t buflen,
                                             const nghttp2_nv *nva,
                                             size_t nvlen);
               nghttp2_ssize
nghttp2_hd_deflate_hd2(nghttp2_hd_deflater *deflater, uint8_t *buf,
                       size_t buflen, const nghttp2_nv *nva, size_t nvlen);
               ssize_t nghttp2_hd_deflate_hd_vec(nghttp2_hd_deflater *deflater,
                                                 const nghttp2_vec *vec,
                                                 size_t veclen,
                                                 const nghttp2_nv *nva,
                                                 size_t nvlen);
               nghttp2_ssize nghttp2_hd_deflate_hd_vec2(
  nghttp2_hd_deflater *deflater, const nghttp2_vec *vec, size_t veclen,
  const nghttp2_nv *nva, size_t nvlen);
               size_t nghttp2_hd_deflate_bound(nghttp2_hd_deflater *deflater,
                                               const nghttp2_nv *nva,
                                               size_t nvlen);
size_t nghttp2_hd_deflate_get_num_table_entries(nghttp2_hd_deflater *deflater);
const nghttp2_nv *
nghttp2_hd_deflate_get_table_entry(nghttp2_hd_deflater *deflater, size_t idx);
size_t nghttp2_hd_deflate_get_dynamic_table_size(nghttp2_hd_deflater *deflater);
size_t
nghttp2_hd_deflate_get_max_dynamic_table_size(nghttp2_hd_deflater *deflater);
struct nghttp2_hd_inflater;
typedef struct nghttp2_hd_inflater nghttp2_hd_inflater;
               int nghttp2_hd_inflate_new(nghttp2_hd_inflater **inflater_ptr);
               int nghttp2_hd_inflate_new2(nghttp2_hd_inflater **inflater_ptr,
                                           nghttp2_mem *mem);
               void nghttp2_hd_inflate_del(nghttp2_hd_inflater *inflater);
               int
nghttp2_hd_inflate_change_table_size(nghttp2_hd_inflater *inflater,
                                     size_t settings_max_dynamic_table_size);
typedef enum {
  NGHTTP2_HD_INFLATE_NONE = 0,
  NGHTTP2_HD_INFLATE_FINAL = 0x01,
  NGHTTP2_HD_INFLATE_EMIT = 0x02
} nghttp2_hd_inflate_flag;
               ssize_t nghttp2_hd_inflate_hd(nghttp2_hd_inflater *inflater,
                                             nghttp2_nv *nv_out,
                                             int *inflate_flags, uint8_t *in,
                                             size_t inlen, int in_final);
               ssize_t nghttp2_hd_inflate_hd2(nghttp2_hd_inflater *inflater,
                                              nghttp2_nv *nv_out,
                                              int *inflate_flags,
                                              const uint8_t *in, size_t inlen,
                                              int in_final);
               nghttp2_ssize nghttp2_hd_inflate_hd3(
  nghttp2_hd_inflater *inflater, nghttp2_nv *nv_out, int *inflate_flags,
  const uint8_t *in, size_t inlen, int in_final);
               int
nghttp2_hd_inflate_end_headers(nghttp2_hd_inflater *inflater);
size_t nghttp2_hd_inflate_get_num_table_entries(nghttp2_hd_inflater *inflater);
const nghttp2_nv *
nghttp2_hd_inflate_get_table_entry(nghttp2_hd_inflater *inflater, size_t idx);
size_t nghttp2_hd_inflate_get_dynamic_table_size(nghttp2_hd_inflater *inflater);
size_t
nghttp2_hd_inflate_get_max_dynamic_table_size(nghttp2_hd_inflater *inflater);
struct nghttp2_stream;
typedef struct nghttp2_stream nghttp2_stream;
               nghttp2_stream *
nghttp2_session_find_stream(nghttp2_session *session, int32_t stream_id);
typedef enum {
  NGHTTP2_STREAM_STATE_IDLE = 1,
  NGHTTP2_STREAM_STATE_OPEN,
  NGHTTP2_STREAM_STATE_RESERVED_LOCAL,
  NGHTTP2_STREAM_STATE_RESERVED_REMOTE,
  NGHTTP2_STREAM_STATE_HALF_CLOSED_LOCAL,
  NGHTTP2_STREAM_STATE_HALF_CLOSED_REMOTE,
  NGHTTP2_STREAM_STATE_CLOSED
} nghttp2_stream_proto_state;
               nghttp2_stream_proto_state
nghttp2_stream_get_state(nghttp2_stream *stream);
               nghttp2_stream *
nghttp2_session_get_root_stream(nghttp2_session *session);
               nghttp2_stream *
nghttp2_stream_get_parent(nghttp2_stream *stream);
               int32_t nghttp2_stream_get_stream_id(nghttp2_stream *stream);
               nghttp2_stream *
nghttp2_stream_get_next_sibling(nghttp2_stream *stream);
               nghttp2_stream *
nghttp2_stream_get_previous_sibling(nghttp2_stream *stream);
               nghttp2_stream *
nghttp2_stream_get_first_child(nghttp2_stream *stream);
               int32_t nghttp2_stream_get_weight(nghttp2_stream *stream);
               int32_t
nghttp2_stream_get_sum_dependency_weight(nghttp2_stream *stream);
typedef void (*nghttp2_debug_vprintf_callback)(const char *format,
                                               va_list args);
               void nghttp2_set_debug_vprintf_callback(
  nghttp2_debug_vprintf_callback debug_vprintf_callback);
struct flb_http_client_session;
struct flb_http2_client_session {
    nghttp2_session *inner_session;
    int initialized;
    struct flb_http_client_session *parent;
};
int flb_http2_client_session_init(struct flb_http2_client_session *session);
void flb_http2_client_session_destroy(struct flb_http2_client_session *session);
int flb_http2_client_session_ingest(struct flb_http2_client_session *session,
                                    unsigned char *buffer,
                                    size_t length);
int flb_http2_request_begin(struct flb_http_request *request);
int flb_http2_request_commit(struct flb_http_request *request);
typedef size_t flb_http_client_size_t;
typedef int64_t flb_http_client_int64_t;
typedef uint64_t flb_http_client_uint64_t;
struct flb_http_client_response {
    int status;
    int content_length;
    int chunked_encoding;
    int connection_close;
    int chunked_trailer_pending;
    char *chunk_processed_end;
    char *headers_end;
    char *trailer_buf;
    size_t trailer_size;
    char *payload;
    size_t payload_size;
    char *data;
    size_t data_len;
    size_t data_size;
    size_t data_size_max;
};
struct flb_http_proxy {
    int type;
    int port;
    const char *host;
};
struct flb_http_debug {
    int debug_request_headers;
    void (*cb_debug_request_headers);
    int debug_request_payload;
    int (*cb_debug_request_payload);
};
struct flb_http_client;
struct flb_test_http_response {
    void *rt_ctx;
    int rt_status;
    void *response_ctx;
    void (*rt_resp_callback) (void *, int, void *, size_t, void *);
    void *rt_data;
    int (*callback) (
                     struct flb_http_client *,
                     const void *,
                     size_t,
                     void **,
                     size_t *);
};
struct flb_http_client {
    struct flb_connection *u_conn;
    struct flb_net_setup request_net_setup;
    struct flb_net_setup *original_net_setup;
    int method;
    int flags;
    int header_len;
    int base_header_len;
    int header_size;
    char *header_buf;
    int allow_dup_headers;
    const char *uri;
    const char *query_string;
    const char *host;
    int port;
    int body_len;
    const char *body_buf;
    struct mk_list headers;
    struct flb_http_proxy proxy;
    struct flb_http_client_response resp;
    time_t ts_start;
    time_t last_read_ts;
    int response_timeout;
    int read_idle_timeout;
    int test_mode;
    struct flb_test_http_response test_response;
    void *cb_ctx;
};
struct flb_oauth2;
struct flb_http_client_ng {
    struct cfl_list sessions;
    uint16_t port;
    uint64_t flags;
    int protocol_version;
    cfl_sds_t temporary_buffer;
    int releasable;
    void *user_data;
    struct flb_upstream *upstream;
    struct flb_upstream_ha *upstream_ha;
    flb_lock_t lock;
};
struct flb_http_client_session {
    struct flb_http1_client_session http1;
    struct flb_http2_client_session http2;
    struct cfl_list streams;
    int protocol_version;
    cfl_sds_t incoming_data;
    cfl_sds_t outgoing_data;
    int releasable;
    struct cfl_list response_queue;
    int stream_sequence_number;
    struct flb_upstream_node *upstream_node;
    struct flb_connection *connection;
    struct flb_http_client_ng *parent;
    struct cfl_list _head;
};
struct flb_aws_provider;
int flb_http_client_ng_init(struct flb_http_client_ng *client,
                            struct flb_upstream_ha *upstream_ha,
                            struct flb_upstream *upstream,
                            int protocol_version,
                            uint64_t flags);
struct flb_http_client_ng *flb_http_client_ng_create(
                                struct flb_upstream_ha *upstream_ha,
                                struct flb_upstream *upstream,
                                int protocol_version,
                                uint64_t flags);
void flb_http_client_ng_destroy(struct flb_http_client_ng *client);
int flb_http_client_session_init(struct flb_http_client_session *session,
                                 struct flb_http_client_ng *client,
                                 int protocol_version,
                                 struct flb_connection *connection);
struct flb_http_client_session *flb_http_client_session_create(
                                    struct flb_http_client_ng *client,
                                    int protocol_version,
                                    struct flb_connection *connection);
struct flb_http_client_session *flb_http_client_session_begin(
                                    struct flb_http_client_ng *client);
void flb_http_client_session_destroy(struct flb_http_client_session *session);
struct flb_http_request *flb_http_client_request_begin(
                            struct flb_http_client_session *session);
struct flb_http_response *flb_http_client_request_execute(
                            struct flb_http_request *request);
struct flb_http_response *flb_http_client_request_execute_step(
                            struct flb_http_request *request);
void flb_http_client_request_destroy(struct flb_http_request *request,
                                     int destroy_session);
int flb_http_client_session_ingest(struct flb_http_client_session *session,
                                   unsigned char *buffer,
                                   size_t length);
void flb_http_client_debug(struct flb_http_client *c,
                           struct flb_callback *cb_ctx);
struct flb_http_client *flb_http_client(struct flb_connection *u_conn,
                                        int method, const char *uri,
                                        const char *body, size_t body_len,
                                        const char *host, int port,
                                        const char *proxy, int flags);
struct flb_http_client *flb_http_dummy_client(struct flb_connection *u_conn,
                                              int method, const char *uri,
                                              const char *body, size_t body_len,
                                              const char *host, int port,
                                              const char *proxy, int flags);
int flb_http_add_header(struct flb_http_client *c,
                        const char *key, size_t key_len,
                        const char *val, size_t val_len);
flb_sds_t flb_http_get_header(struct flb_http_client *c,
                              const char *key, size_t key_len);
flb_sds_t flb_http_get_response_header(struct flb_http_client *c,
                                       const char *key, size_t key_len);
int flb_http_client_process_response_buffer(struct flb_http_client *c);
int flb_http_basic_auth(struct flb_http_client *c,
                        const char *user, const char *passwd);
int flb_http_proxy_auth(struct flb_http_client *c,
                        const char *user, const char *passwd);
int flb_http_bearer_auth(struct flb_http_client *c,
                        const char *token);
int flb_http_remove_header(struct flb_http_client *c,
                          const char *key, size_t key_len);
int flb_http_set_keepalive(struct flb_http_client *c);
int flb_http_set_content_encoding_gzip(struct flb_http_client *c);
int flb_http_set_content_encoding_zstd(struct flb_http_client *c);
int flb_http_set_content_encoding_snappy(struct flb_http_client *c);
int flb_http_set_read_idle_timeout(struct flb_http_client *c, int timeout);
int flb_http_set_response_timeout(struct flb_http_client *c, int timeout);
int flb_http_set_callback_context(struct flb_http_client *c,
                                  struct flb_callback *cb_ctx);
int flb_http_set_response_test(struct flb_http_client *c, char *test_name,
                               const void *data, size_t len,
                               int status,
                               void (*resp_callback) (void *, int, void *, size_t, void *),
                               void *resp_callback_data);
int flb_http_push_response(struct flb_http_client *c, const void *data, size_t len);
int flb_http_get_response_data(struct flb_http_client *c, size_t bytes_consumed);
int flb_http_do_request(struct flb_http_client *c, size_t *bytes);
int flb_http_do(struct flb_http_client *c, size_t *bytes);
int flb_http_do_with_oauth2(struct flb_http_client *c, size_t *bytes,
                            struct flb_oauth2 *oauth2);
int flb_http_client_proxy_connect(struct flb_connection *u_conn);
void flb_http_client_detach_connection(struct flb_http_client *c);
void flb_http_client_destroy(struct flb_http_client *c);
int flb_http_buffer_size(struct flb_http_client *c, size_t size);
size_t flb_http_buffer_available(struct flb_http_client *c);
int flb_http_buffer_increase(struct flb_http_client *c, size_t size,
                             size_t *out_size);
int flb_http_strip_port_from_host(struct flb_http_client *c);
int flb_http_allow_duplicated_headers(struct flb_http_client *c, int allow);
int flb_http_client_debug_property_is_valid(char *key, char *val);
int flb_http_request_set_parameters_internal(
    struct flb_http_request *request,
    va_list arguments);
int flb_http_request_set_parameters_unsafe(
    struct flb_http_request *request,
    ...);
struct flb_http_request *flb_http_client_request_builder_unsafe(
    struct flb_http_client_ng *client,
    ...);

struct flb_out_thread_upstream {
    struct flb_upstream *u;
    struct flb_upstream_queue queue;
    struct mk_list _head;
};
struct flb_out_thread_instance {
    struct mk_event event;
    struct mk_event_loop *evl;
    struct flb_bucket_queue *evl_bktq;
    int ch_parent_events[2];
    int ch_thread_events[2];
    int notification_channels_initialized;
    int notification_channels[2];
    struct mk_event notification_event;
    struct flb_output_instance *ins;
    struct flb_config *config;
    struct flb_tp_thread *th;
    struct mk_list _head;
    int flush_id;
    struct mk_list flush_list;
    struct mk_list flush_list_destroy;
     pthread_mutex_t flush_mutex;
    struct mk_list upstreams;
};
int flb_output_thread_pool_create(struct flb_config *config,
                                  struct flb_output_instance *ins);
int flb_output_thread_pool_coros_size(struct flb_output_instance *ins);
void flb_output_thread_pool_destroy(struct flb_output_instance *ins);
int flb_output_thread_pool_start(struct flb_output_instance *ins);
int flb_output_thread_pool_flush(struct flb_task *task,
                                 struct flb_output_instance *out_ins,
                                 struct flb_config *config);
void flb_output_thread_instance_init();
struct flb_out_thread_instance *flb_output_thread_instance_get();
void flb_output_thread_instance_set(struct flb_out_thread_instance *th_ins);

struct flb_upstream_node {
    flb_sds_t name;
    flb_sds_t host;
    flb_sds_t port;
    int tls_enabled;
    int tls_verify;
    int tls_verify_hostname;
    int tls_debug;
    char *tls_ca_path;
    char *tls_ca_file;
    char *tls_crt_file;
    char *tls_key_file;
    char *tls_key_passwd;
    struct flb_tls *tls;
    struct flb_hash_table *ht;
    struct flb_upstream *u;
    void *data;
    struct mk_list _head;
};
struct flb_upstream_node *flb_upstream_node_create(flb_sds_t name, flb_sds_t host,
                                                   flb_sds_t port,
                                                   int tls, int tls_verify,
                                                   int tls_verify_hostname,
                                                   int tls_debug,
                                                   const char *tls_vhost,
                                                   const char *tls_ca_path,
                                                   const char *tls_ca_file,
                                                   const char *tls_crt_file,
                                                   const char *tls_key_file,
                                                   const char *tls_key_passwd,
                                                   struct flb_hash_table *ht,
                                                   struct flb_config *config);
const char *flb_upstream_node_get_property(const char *prop,
                                           struct flb_upstream_node *node);
static inline void flb_upstream_node_set_data(void *data,
                                              struct flb_upstream_node *node)
{
    node->data = data;
}
static inline void *flb_upstream_node_get_data(struct flb_upstream_node *node)
{
    return node->data;
}
void flb_upstream_node_destroy(struct flb_upstream_node *node);
struct flb_upstream_ha {
    flb_sds_t name;
    void *last_used_node;
    struct mk_list nodes;
};
struct flb_upstream_ha *flb_upstream_ha_create(const char *name);
void flb_upstream_ha_destroy(struct flb_upstream_ha *ctx);
void flb_upstream_ha_node_add(struct flb_upstream_ha *ctx,
                              struct flb_upstream_node *node);
struct flb_upstream_node *flb_upstream_ha_node_get(struct flb_upstream_ha *ctx);
struct flb_upstream_ha *flb_upstream_ha_from_file(const char *file,
                                                  struct flb_config *config);
struct flb_event_chunk {
    int type;
    flb_sds_t tag;
    void *data;
    size_t size;
    size_t total_events;
    struct flb_chunk_trace *trace;
};
struct flb_event_chunk *flb_event_chunk_create(int type,
                                               int total_events,
                                               char *tag_buf, int tag_len,
                                               char *buf_data, size_t buf_size);
int flb_event_chunk_update(struct flb_event_chunk *evc,
                           char *buf_data, size_t buf_size);
void flb_event_chunk_destroy(struct flb_event_chunk *evc);
struct cmt_histogram_buckets {
    size_t count;
    double *upper_bounds;
};
struct cmt_histogram {
    struct cmt_histogram_buckets *buckets;
    struct cmt_opts opts;
    struct cmt_map *map;
    struct cfl_list _head;
    struct cmt *cmt;
    int aggregation_type;
};
struct cmt_histogram_buckets *cmt_histogram_buckets_create_size(double *bkts, size_t count);
struct cmt_histogram_buckets *cmt_histogram_buckets_create(size_t count, ...);
void cmt_histogram_buckets_destroy(struct cmt_histogram_buckets *buckets);
struct cmt_histogram_buckets *cmt_histogram_buckets_default_create();
struct cmt_histogram_buckets *cmt_histogram_buckets_linear_create(double start,
                                                                  double width,
                                                                  size_t count);
struct cmt_histogram_buckets *cmt_histogram_buckets_exponential_create(double start,
                                                                       double factor,
                                                                       size_t count);
struct cmt_histogram *cmt_histogram_create(struct cmt *cmt,
                                           char *ns, char *subsystem,
                                           char *name, char *help,
                                           struct cmt_histogram_buckets *buckets,
                                           int label_count, char **label_keys);
int cmt_histogram_observe(struct cmt_histogram *histogram, uint64_t timestamp,
                          double val, int labels_count, char **label_vals);
int cmt_histogram_set_default(struct cmt_histogram *histogram,
                              uint64_t timestamp,
                              uint64_t *bucket_defaults,
                              double sum,
                              uint64_t count,
                              int labels_count, char **label_vals);
int cmt_histogram_destroy(struct cmt_histogram *h);
struct ctr_msgpack_decode_context {
    struct ctrace_resource_span *resource_span;
    struct ctrace_scope_span *scope_span;
    struct ctrace_resource *resource;
    struct ctrace *trace;
    struct ctrace_span_event *event;
    struct ctrace_span *span;
    struct ctrace_link *link;
};
int ctr_decode_msgpack_create(struct ctrace **out_context, char *in_buf, size_t in_size, size_t *offset);
void ctr_decode_msgpack_destroy(struct ctrace *context);
struct crof_msgpack_decode_context {
    struct cprof *inner_context;
    mpack_reader_t reader;
};
int cprof_decode_msgpack_create(struct cprof **result_context,
                                unsigned char *in_buf,
                                size_t in_size,
                                size_t *offset);
void cprof_decode_msgpack_destroy(struct cprof *context);
struct cprof_msgpack_encoding_context {
    mpack_writer_t writer;
    char *output_buffer;
    size_t output_size;
};
int cprof_encode_msgpack_create(cfl_sds_t *result_buffer,
                                struct cprof *profile);
void cprof_encode_msgpack_destroy(cfl_sds_t instance);
int flb_chunk_trace_output(struct flb_chunk_trace *trace, struct flb_output_instance *output, int ret);
struct flb_output_flush;
struct flb_http_server_config;
struct flb_test_out_formatter {
    void *rt_ctx;
    int rt_ffd;
    void (*rt_out_callback) (void *, int, int, void *, size_t, void *);
    void *rt_data;
    void *flush_ctx;
    void *(*flush_ctx_callback) (
                                 struct flb_config *,
                                 struct flb_input_instance *,
                                 void *plugin_context,
                                 void *flush_ctx);
    int (*callback) (
                     struct flb_config *,
                     struct flb_input_instance *,
                     void *,
                     void *,
                     int,
                     const char *,
                     int,
                     const void *,
                     size_t,
                     void **,
                     size_t *);
};
struct flb_test_out_response {
    void *rt_ctx;
    int rt_ffd;
    void (*rt_out_response) (void *, int, int, void *, size_t, void *);
    void *rt_data;
    void *flush_ctx;
    int (*callback) (
                     struct flb_config *,
                     void *,
                     int status,
                     const void *,
                     size_t,
                     void **,
                     size_t *);
};
struct flb_output_plugin {
    int event_type;
    int type;
    void *proxy;
    int flags;
    char *name;
    char *description;
    struct flb_config_map *config_map;
    struct flb_net_host host;
    int (*cb_init) (struct flb_output_instance *, struct flb_config *, void *);
    int (*cb_pre_run) (void *, struct flb_config *);
    void (*cb_flush) (struct flb_event_chunk *,
                      struct flb_output_flush *,
                      struct flb_input_instance *,
                      void *,
                      struct flb_config *);
    int (*cb_exit) (void *, struct flb_config *);
    void (*cb_destroy) (struct flb_output_plugin *);
    int workers;
    int (*cb_worker_init) (void *, struct flb_config *);
    int (*cb_worker_exit) (void *, struct flb_config *);
    int (*cb_notification) (struct flb_output_instance *, struct flb_config *, void *);
    struct flb_test_out_formatter test_formatter;
    struct flb_test_out_response test_response;
    struct mk_list _head;
};
struct flb_output_instance {
    struct mk_event event;
    struct flb_processor *processor;
    int event_type;
    int id;
    int log_level;
    int log_suppress_interval;
    char name[32];
    char *alias;
    int flags;
    int test_mode;
    int ch_events[2];
    struct flb_output_plugin *p;
    void *context;
    int retry_limit;
    int retry_limit_is_set;
    int use_tls;
    char *match;
    struct flb_regex *match_regex;
    int tls_verify;
    int tls_verify_hostname;
    int tls_debug;
    char *tls_vhost;
    char *tls_ca_path;
    char *tls_ca_file;
    char *tls_crt_file;
    char *tls_key_file;
    char *tls_key_passwd;
    char *tls_crl_file;
    char *tls_min_version;
    char *tls_max_version;
    char *tls_ciphers;
    int tls_proxy_verify;
    int tls_proxy_verify_hostname;
    char *tls_proxy_ca_path;
    char *tls_proxy_ca_file;
    struct flb_net_host host;
    void *data;
    void *out_context;
    struct flb_tls *tls;
    struct mk_list properties;
    struct mk_list *config_map;
    struct flb_net_setup net_setup;
    struct mk_list *net_config_map;
    struct mk_list net_properties;
    struct mk_list *http_server_config_map;
    struct flb_http_server_config *http_server_config;
    struct mk_list http_server_properties;
    struct mk_list *oauth2_config_map;
    struct mk_list oauth2_properties;
    struct mk_list *tls_config_map;
    struct mk_list _head;
    struct cmt *cmt;
    struct cmt_counter *cmt_proc_records;
    struct cmt_counter *cmt_proc_bytes;
    struct cmt_counter *cmt_errors;
    struct cmt_counter *cmt_retries;
    struct cmt_counter *cmt_retries_failed;
    struct cmt_counter *cmt_dropped_records;
    struct cmt_counter *cmt_retried_records;
    struct cmt_gauge *cmt_upstream_total_connections;
    struct cmt_gauge *cmt_upstream_busy_connections;
    struct cmt_gauge *cmt_chunk_available_capacity_percent;
    struct cmt_histogram *cmt_latency;
    struct cmt_histogram *cmt_backpressure_wait;
    struct flb_metrics *metrics;
    struct flb_callback *callback;
    struct flb_test_out_formatter test_formatter;
    struct flb_test_out_response test_response;
    size_t fs_chunks_size;
    size_t fs_backlog_chunks_size;
    size_t total_limit_size;
    struct flb_task_queue *singleplex_queue;
    int tp_workers;
    struct flb_tp *tp;
    int is_threaded;
    struct mk_list upstreams;
    int flush_id;
    struct mk_list flush_list;
    struct mk_list flush_list_destroy;
    int notification_channel;
    struct flb_config *config;
};
struct flb_output_flush {
    int id;
    const void *buffer;
    struct flb_task *task;
    struct flb_config *config;
    struct flb_output_instance *o_ins;
    struct flb_coro *coro;
    struct flb_event_chunk *processed_event_chunk;
    int successful_route_data_set;
    int successful_records;
    size_t successful_bytes;
    struct mk_list _head;
};
static inline __attribute__((always_inline)) int flb_output_set_successful_route_data(
                        struct flb_output_flush *out_flush,
                        int records,
                        size_t bytes)
{
    if (out_flush == ((void*)0) || records < 0) {
        return -1;
    }
    out_flush->successful_records = records;
    out_flush->successful_bytes = bytes;
    out_flush->successful_route_data_set = 1;
    return 0;
}
static inline __attribute__((always_inline)) void *flb_output_get_retry_context(
                        struct flb_output_flush *out_flush,
                        int *records,
                        size_t *bytes)
{
    void *context;
    flb_task_acquire_lock(out_flush->task);
    context = flb_task_get_route_retry_context(out_flush->task,
                                               out_flush->o_ins,
                                               records, bytes);
    flb_task_release_lock(out_flush->task);
    return context;
}
static inline __attribute__((always_inline)) int flb_output_set_retry_context(
                        struct flb_output_flush *out_flush,
                        void *context,
                        void (*destroy)(void *),
                        int records,
                        size_t bytes)
{
    int result;
    flb_task_acquire_lock(out_flush->task);
    result = flb_task_set_route_retry_context(out_flush->task,
                                              out_flush->o_ins,
                                              context, destroy,
                                              records, bytes);
    flb_task_release_lock(out_flush->task);
    return result;
}
static inline __attribute__((always_inline)) int flb_output_clear_retry_context(
                        struct flb_output_flush *out_flush)
{
    return flb_output_set_retry_context(out_flush, ((void*)0), ((void*)0), 0, 0);
}
static inline __attribute__((always_inline)) int flb_output_is_threaded(struct flb_output_instance *ins)
{
    return ins->is_threaded;
}
static inline __attribute__((always_inline)) void flb_output_flush_destroy(struct flb_output_flush *out_flush)
{
    if (flb_log_check(4)) flb_log_print(4, ((void*)0), 0, "[out flush] cb_destroy coro_id=%i", out_flush->id);
    mk_list_del(&out_flush->_head);
    flb_coro_destroy(out_flush->coro);
    flb_free(out_flush);
}
struct flb_out_flush_params {
    struct flb_event_chunk *event_chunk;
    struct flb_output_flush *out_flush;
    struct flb_input_instance *i_ins;
    struct flb_output_plugin *out_plugin;
    void *out_context;
    struct flb_config *config;
    struct flb_coro *coro;
};
extern __thread struct flb_out_flush_params *out_flush_params;;
static inline void flb_output_return_do(int x);
static inline __attribute__((always_inline)) void output_params_set(struct flb_output_flush *out_flush,
                                         struct flb_coro *coro,
                                         struct flb_task *task,
                                         struct flb_output_plugin *out_plugin,
                                         void *out_context,
                                         struct flb_config *config)
{
    int s = sizeof(struct flb_out_flush_params);
    struct flb_out_flush_params *params;
    params = (struct flb_out_flush_params *) out_flush_params;
    if (!params) {
        params = (struct flb_out_flush_params *) flb_malloc(s);
        if (!params) {
            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 723);
            return;
        }
    }
    if (out_flush->processed_event_chunk) {
        params->event_chunk = out_flush->processed_event_chunk;
    }
    else {
        params->event_chunk = task->event_chunk;
    }
    params->out_flush = out_flush;
    params->i_ins = task->i_ins;
    params->out_context = out_context;
    params->config = config;
    params->out_plugin = out_plugin;
    params->coro = coro;
    out_flush_params=params;
    co_switch(coro->callee);
}
static inline __attribute__((always_inline)) void output_pre_cb_flush(void)
{
    int route_status;
    struct flb_coro *coro;
    struct flb_output_plugin *out_p;
    struct flb_out_flush_params *params;
    struct flb_out_flush_params persisted_params;
    params = (struct flb_out_flush_params *) out_flush_params;
    if (!params) {
        if (flb_log_check(1)) flb_log_print(1, ((void*)0), 0, "[output] no co-routines params defined, unexpected");
        return;
    }
    coro = params->coro;
    persisted_params = *params;
    co_switch(coro->caller);
    if (persisted_params.event_chunk &&
        persisted_params.event_chunk->type == 0 &&
        persisted_params.event_chunk->total_events == 0) {
        if (flb_log_check(4)) flb_log_print(4, ((void*)0), 0, "[output] skipping flush for event chunk with zero records.");
        flb_output_return_do(1); return;
    }
    else if (persisted_params.event_chunk &&
             persisted_params.event_chunk->type == 1 &&
             persisted_params.event_chunk->size == 0) {
        if (flb_log_check(4)) flb_log_print(4, ((void*)0), 0, "[output] skipping flush for event chunk with no data after processing.");
        flb_output_return_do(1); return;
    }
    out_p = persisted_params.out_plugin;
    flb_task_acquire_lock(persisted_params.out_flush->task);
    route_status = flb_task_get_route_status(
                    persisted_params.out_flush->task,
                    persisted_params.out_flush->o_ins);
    if (route_status == 2) {
        flb_task_release_lock(persisted_params.out_flush->task);
        flb_output_return_do(0); return;
    }
    flb_task_activate_route(persisted_params.out_flush->task,
                            persisted_params.out_flush->o_ins);
    flb_task_release_lock(persisted_params.out_flush->task);
    out_p->cb_flush(persisted_params.event_chunk,
                    persisted_params.out_flush,
                    persisted_params.i_ins,
                    persisted_params.out_context,
                    persisted_params.config);
}
void flb_output_flush_prepare_destroy(struct flb_output_flush *out_flush);
int flb_output_flush_id_get(struct flb_output_instance *ins);
static inline __attribute__((always_inline))
struct flb_output_flush *flb_output_flush_create(struct flb_task *task,
                                                 struct flb_input_instance *i_ins,
                                                 struct flb_output_instance *o_ins,
                                                 struct flb_config *config)
{
    int ret;
    size_t records;
    void *p_buf = ((void*)0);
    size_t p_size;
    size_t stack_size;
    struct flb_coro *coro;
    struct flb_output_flush *out_flush;
    struct flb_out_thread_instance *th_ins;
    struct flb_event_chunk *evc;
    struct flb_event_chunk *tmp;
    char *resized_serialization_buffer;
    size_t serialization_buffer_offset;
    cfl_sds_t serialized_profiles_context_buffer;
    char *serialized_context_buffer;
    size_t serialized_context_size;
    struct cmt *metrics_context;
    struct ctrace *trace_context;
    struct cprof *profile_context;
    size_t chunk_offset;
    struct cmt *encode_context = ((void*)0);
    struct cmt *cmt_out_context = ((void*)0);
    out_flush = (struct flb_output_flush *) flb_calloc(1, sizeof(struct flb_output_flush));
    if (!out_flush) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 849);
        return ((void*)0);
    }
    coro = flb_coro_create(out_flush);
    if (!coro) {
        flb_free(out_flush);
        return ((void*)0);
    }
    out_flush->id = flb_output_flush_id_get(o_ins);
    out_flush->o_ins = o_ins;
    out_flush->task = task;
    out_flush->buffer = task->event_chunk->data;
    out_flush->config = config;
    out_flush->coro = coro;
    out_flush->processed_event_chunk = ((void*)0);
    evc = task->event_chunk;
    if (flb_processor_is_active(o_ins->processor)) {
        if (evc->type == 0) {
            char *normalized_buf;
            size_t normalized_size;
            ret = flb_processor_run(o_ins->processor,
                                    0,
                                    1,
                                    evc->tag, flb_sds_len(evc->tag),
                                    evc->data, evc->size,
                                    &p_buf, &p_size);
            if (ret == -1) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                return ((void*)0);
            }
            normalized_buf = ((void*)0);
            normalized_size = 0;
            ret = flb_mp_normalize_log_buffer_groups_msgpack(p_buf, p_size,
                                                             &normalized_buf,
                                                             &normalized_size);
            if (ret == 0) {
                if (p_buf != evc->data) {
                    flb_free(p_buf);
                }
                p_buf = normalized_buf;
                p_size = normalized_size;
            }
            records = flb_mp_count_log_records(p_buf, p_size);
            tmp = flb_event_chunk_create(evc->type, records, evc->tag, flb_sds_len(evc->tag), p_buf, p_size);
            if (!tmp) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                flb_free(p_buf);
                return ((void*)0);
            }
            out_flush->processed_event_chunk = tmp;
        }
        else if (evc->type == 1) {
            p_buf = flb_calloc(evc->size * 2, sizeof(char));
            if (p_buf == ((void*)0)) {
                flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 923);
                flb_coro_destroy(coro);
                flb_free(out_flush);
                return ((void*)0);
            }
            p_size = evc->size;
            chunk_offset = 0;
            serialization_buffer_offset = 0;
            while ((ret = cmt_decode_msgpack_create(
                            &metrics_context,
                            (char *) evc->data,
                            evc->size,
                            &chunk_offset)) == 0) {
                cmt_out_context = ((void*)0);
                ret = flb_processor_run(o_ins->processor,
                                        0,
                                        2,
                                        evc->tag,
                                        flb_sds_len(evc->tag),
                                        (char *) metrics_context,
                                        0,
                                        (void **)&cmt_out_context,
                                        ((void*)0));
                if (ret == 0) {
                    if (cmt_out_context) {
                        encode_context = cmt_out_context;
                    }
                    else {
                        encode_context = metrics_context;
                    }
                    if (flb_metrics_is_empty(encode_context)) {
                        if (encode_context != metrics_context) {
                            cmt_destroy(encode_context);
                        }
                        cmt_destroy(metrics_context);
                        continue;
                    }
                    if (cmt_out_context != ((void*)0)) {
                        ret = cmt_encode_msgpack_create(cmt_out_context,
                                                        &serialized_context_buffer,
                                                        &serialized_context_size);
                        if (cmt_out_context != metrics_context) {
                            cmt_destroy(cmt_out_context);
                        }
                    }
                    else {
                        ret = cmt_encode_msgpack_create(metrics_context,
                                                        &serialized_context_buffer,
                                                        &serialized_context_size);
                    }
                    cmt_destroy(metrics_context);
                    if (ret != 0) {
                        flb_coro_destroy(coro);
                        flb_free(out_flush);
                        flb_free(p_buf);
                        return ((void*)0);
                    }
                    if ((serialization_buffer_offset + serialized_context_size) > p_size) {
                        resized_serialization_buffer = flb_realloc(p_buf, p_size + serialized_context_size);
                        if (resized_serialization_buffer == ((void*)0)) {
                            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 995);
                            cmt_encode_msgpack_destroy(serialized_context_buffer);
                            flb_coro_destroy(coro);
                            flb_free(out_flush);
                            flb_free(p_buf);
                            return ((void*)0);
                        }
                        p_size += serialized_context_size;
                        p_buf = resized_serialization_buffer;
                    }
                    memcpy(&(((char *) p_buf)[serialization_buffer_offset]),
                           serialized_context_buffer,
                           serialized_context_size);
                    serialization_buffer_offset += serialized_context_size;
                    cmt_encode_msgpack_destroy(serialized_context_buffer);
                }
                else {
                    cmt_destroy(metrics_context);
                    if (cmt_out_context != ((void*)0) && cmt_out_context != metrics_context) {
                        cmt_destroy(cmt_out_context);
                    }
                    flb_coro_destroy(coro);
                    flb_free(out_flush);
                    flb_free(p_buf);
                    return ((void*)0);
                }
            }
            if (serialization_buffer_offset == 0) {
                if (flb_log_check(4)) flb_log_print(4, ((void*)0), 0, "[output] skipping flush for metrics event chunk with zero metrics after processing.");
                flb_free(p_buf);
                p_buf = ((void*)0);
                out_flush->processed_event_chunk = flb_event_chunk_create(
                                                    evc->type,
                                                    0,
                                                    evc->tag,
                                                    flb_sds_len(evc->tag),
                                                    ((void*)0),
                                                    0);
            }
            else {
                p_size = serialization_buffer_offset;
                out_flush->processed_event_chunk = flb_event_chunk_create(
                                                    evc->type,
                                                    0,
                                                    evc->tag,
                                                    flb_sds_len(evc->tag),
                                                    p_buf,
                                                    p_size);
            }
            if (out_flush->processed_event_chunk == ((void*)0)) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                if (p_buf != ((void*)0)) {
                    flb_free(p_buf);
                }
                return ((void*)0);
            }
        }
        else if (evc->type == 2) {
            p_buf = flb_calloc(evc->size * 2, sizeof(char));
            if (p_buf == ((void*)0)) {
                flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 1065);
                flb_coro_destroy(coro);
                flb_free(out_flush);
                return ((void*)0);
            }
            p_size = evc->size;
            chunk_offset = 0;
            serialization_buffer_offset = 0;
            while ((ret = ctr_decode_msgpack_create(
                            &trace_context,
                            (char *) evc->data,
                            evc->size,
                            &chunk_offset)) == (0)) {
                ret = flb_processor_run(o_ins->processor,
                                        0,
                                        4,
                                        evc->tag,
                                        flb_sds_len(evc->tag),
                                        (char *) trace_context,
                                        0,
                                        ((void*)0),
                                        ((void*)0));
                if (ret == 0) {
                    ret = ctr_encode_msgpack_create(trace_context,
                                                    &serialized_context_buffer,
                                                    &serialized_context_size);
                    ctr_destroy(trace_context);
                    if (ret != 0) {
                        flb_coro_destroy(coro);
                        flb_free(out_flush);
                        flb_free(p_buf);
                        return ((void*)0);
                    }
                    if ((serialization_buffer_offset +
                         serialized_context_size) > p_size) {
                        resized_serialization_buffer = flb_realloc(p_buf, p_size + serialized_context_size);
                        if (resized_serialization_buffer == ((void*)0)) {
                            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 1114);
                            ctr_encode_msgpack_destroy(serialized_context_buffer);
                            flb_coro_destroy(coro);
                            flb_free(out_flush);
                            flb_free(p_buf);
                            return ((void*)0);
                        }
                        p_size += serialized_context_size;
                        p_buf = resized_serialization_buffer;
                    }
                    memcpy(&(((char *) p_buf)[serialization_buffer_offset]),
                           serialized_context_buffer,
                           serialized_context_size);
                    serialization_buffer_offset += serialized_context_size;
                    ctr_encode_msgpack_destroy(serialized_context_buffer);
                }
            }
            if (serialization_buffer_offset == 0) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                flb_free(p_buf);
                return ((void*)0);
            }
            out_flush->processed_event_chunk = flb_event_chunk_create(
                                                evc->type,
                                                0,
                                                evc->tag,
                                                flb_sds_len(evc->tag),
                                                p_buf,
                                                p_size);
            if (out_flush->processed_event_chunk == ((void*)0)) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                flb_free(p_buf);
                return ((void*)0);
            }
        }
        else if (evc->type == 4) {
            p_buf = flb_calloc(evc->size * 2, sizeof(char));
            if (p_buf == ((void*)0)) {
                flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 1166);
                flb_coro_destroy(coro);
                flb_free(out_flush);
                return ((void*)0);
            }
            p_size = evc->size;
            chunk_offset = 0;
            serialization_buffer_offset = 0;
            while ((ret = cprof_decode_msgpack_create(
                            &profile_context,
                            (unsigned char *) evc->data,
                            evc->size,
                            &chunk_offset)) == 0) {
                ret = flb_processor_run(o_ins->processor,
                                        0,
                                        8,
                                        evc->tag,
                                        flb_sds_len(evc->tag),
                                        (char *) profile_context,
                                        0,
                                        ((void*)0),
                                        ((void*)0));
                if (ret == 0) {
                    ret = cprof_encode_msgpack_create(&serialized_profiles_context_buffer,
                                                      profile_context);
                    cprof_destroy(profile_context);
                    if (ret != 0) {
                        flb_coro_destroy(coro);
                        flb_free(out_flush);
                        flb_free(p_buf);
                        return ((void*)0);
                    }
                    if ((serialization_buffer_offset +
                         cfl_sds_len(serialized_profiles_context_buffer)) > p_size) {
                        resized_serialization_buffer = flb_realloc(p_buf, p_size + cfl_sds_len(serialized_profiles_context_buffer));
                        if (resized_serialization_buffer == ((void*)0)) {
                            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 1214);
                            cprof_encode_msgpack_destroy(serialized_profiles_context_buffer);
                            flb_coro_destroy(coro);
                            flb_free(out_flush);
                            flb_free(p_buf);
                            return ((void*)0);
                        }
                        p_size += cfl_sds_len(serialized_profiles_context_buffer);
                        p_buf = resized_serialization_buffer;
                    }
                    memcpy(&(((char *) p_buf)[serialization_buffer_offset]),
                           serialized_profiles_context_buffer,
                           cfl_sds_len(serialized_profiles_context_buffer));
                    serialization_buffer_offset += cfl_sds_len(serialized_profiles_context_buffer);
                    cprof_encode_msgpack_destroy(serialized_profiles_context_buffer);
                }
            }
            if (serialization_buffer_offset == 0) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                flb_free(p_buf);
                return ((void*)0);
            }
            out_flush->processed_event_chunk = flb_event_chunk_create(
                                                evc->type,
                                                0,
                                                evc->tag,
                                                flb_sds_len(evc->tag),
                                                p_buf,
                                                p_size);
            if (out_flush->processed_event_chunk == ((void*)0)) {
                flb_coro_destroy(coro);
                flb_free(out_flush);
                flb_free(p_buf);
                return ((void*)0);
            }
        }
    }
    coro->caller = co_active();
    coro->callee = co_create(config->coro_stack_size,
                             output_pre_cb_flush, &stack_size);
    if (coro->callee == ((void*)0)) {
        flb_coro_destroy(coro);
        if (out_flush->processed_event_chunk) {
            flb_free(out_flush->processed_event_chunk->data);
            flb_event_chunk_destroy(out_flush->processed_event_chunk);
        }
        flb_free(out_flush);
        return ((void*)0);
    }
    coro->valgrind_stack_id = (unsigned)__extension__ ({ volatile unsigned long int _zzq_args[6]; volatile unsigned long int _zzq_result; _zzq_args[0] = (unsigned long int)(VG_USERREQ__STACK_REGISTER); _zzq_args[1] = (unsigned long int)(coro->callee); _zzq_args[2] = (unsigned long int)(((char *) coro->callee) + stack_size); _zzq_args[3] = (unsigned long int)(0); _zzq_args[4] = (unsigned long int)(0); _zzq_args[5] = (unsigned long int)(0); __asm__ volatile("rolq $3,  %%rdi ; rolq $13, %%rdi\n\t" "rolq $61, %%rdi ; rolq $51, %%rdi\n\t" "xchgq %%rbx,%%rbx" : "=d" (_zzq_result) : "a" (&_zzq_args[0]), "0" (0) : "cc", "memory" ); _zzq_result; });
    if (o_ins->is_threaded == 1) {
        th_ins = flb_output_thread_instance_get();
        pthread_mutex_lock(&th_ins->flush_mutex);
        mk_list_add(&out_flush->_head, &th_ins->flush_list);
        pthread_mutex_unlock(&th_ins->flush_mutex);
    }
    else {
        mk_list_add(&out_flush->_head, &o_ins->flush_list);
    }
    output_params_set(out_flush, coro, task, o_ins->p, o_ins->context, config);
    return out_flush;
}
static inline void flb_output_return(int ret, struct flb_coro *co) {
    int n;
    int records;
    int pipe_fd;
    uint32_t set;
    uint64_t val;
    size_t bytes;
    struct flb_task *task;
    struct flb_event_chunk *counted_event_chunk;
    struct flb_output_flush *out_flush;
    struct flb_output_instance *o_ins;
    struct flb_out_thread_instance *th_ins = ((void*)0);
    out_flush = (struct flb_output_flush *) co->data;
    o_ins = out_flush->o_ins;
    task = out_flush->task;
    if (out_flush->processed_event_chunk) {
        counted_event_chunk = out_flush->processed_event_chunk;
    }
    else {
        counted_event_chunk = task->event_chunk;
    }
    records = task->event_chunk->total_events;
    if (counted_event_chunk->type == 0) {
        records = counted_event_chunk->total_events;
    }
    bytes = counted_event_chunk->size;
    flb_task_acquire_lock(task);
    if (ret == 1 && out_flush->successful_route_data_set == 1) {
        records = out_flush->successful_records;
        bytes = out_flush->successful_bytes;
    }
    else if (ret != 1 &&
        flb_task_get_route_retry_context(task, o_ins,
                                         &records, &bytes) == ((void*)0)) {
        records = counted_event_chunk->total_events;
        bytes = counted_event_chunk->size;
    }
    flb_task_set_route_data(task, o_ins, records, bytes);
    flb_task_deactivate_route(task, o_ins);
    flb_task_release_lock(task);
    if (task->event_chunk) {
        if (task->event_chunk->trace) {
             flb_chunk_trace_output(task->event_chunk->trace, o_ins, ret);
        }
    }
    if (out_flush->processed_event_chunk) {
        if (task->event_chunk->data != out_flush->processed_event_chunk->data) {
            flb_free(out_flush->processed_event_chunk->data);
        }
        flb_event_chunk_destroy(out_flush->processed_event_chunk);
        out_flush->processed_event_chunk = ((void*)0);
    }
    set = (uint32_t) ((ret << 28) | (task->id << 14) | o_ins->id);
    val = ((uint64_t) 2 << 32 | set);
    if (flb_output_is_threaded(o_ins) == 1) {
        th_ins = flb_output_thread_instance_get();
        pipe_fd = th_ins->ch_thread_events[1];
    }
    else {
        pipe_fd = out_flush->o_ins->ch_events[1];
    }
    n = write(pipe_fd, (void *) &val, sizeof(val));
    if (n == -1) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_output.h", 1401);
    }
    flb_output_flush_prepare_destroy(out_flush);
}
static inline int flb_output_coros_size(struct flb_output_instance *ins)
{
    int size = 0;
    if (flb_output_is_threaded(ins) == 1) {
        size = flb_output_thread_pool_coros_size(ins);
    }
    else {
        size = mk_list_size(&ins->flush_list);
    }
    return size;
}
static inline void flb_output_return_do(int x)
{
    struct flb_coro *coro;
    coro = flb_coro_get();
    flb_output_return(x, coro);
    flb_coro_yield(coro, 1);
}
static inline int flb_output_config_map_set(struct flb_output_instance *ins,
                                            void *context)
{
    int ret;
    if (ins->config_map) {
        ret = flb_config_map_set(ins->config, &ins->properties, ins->config_map, context);
        if (ret == -1) {
            return -1;
        }
    }
    if (ins->net_config_map) {
        ret = flb_config_map_set(ins->config, &ins->net_properties, ins->net_config_map,
                                 &ins->net_setup);
        if (ret == -1) {
            return -1;
        }
    }
    if (ins->http_server_config_map && ins->http_server_config) {
        ret = flb_config_map_set(ins->config,
                                 &ins->http_server_properties,
                                 ins->http_server_config_map,
                                 ins->http_server_config);
        if (ret == -1) {
            return -1;
        }
    }
    return 0;
}
int flb_output_help(struct flb_output_instance *ins, void **out_buf, size_t *out_size);
struct flb_output_instance *flb_output_get_instance(struct flb_config *config,
                                                    int out_id);
int flb_output_flush_finished(struct flb_config *config, int out_id);
int flb_output_task_singleplex_enqueue(struct flb_task_queue *queue,
                                       struct flb_task_retry *retry,
                                       struct flb_task *task,
                                       struct flb_output_instance *out_ins,
                                       struct flb_config *config);
int flb_output_task_singleplex_flush_next(struct flb_task_queue *queue);
struct flb_output_instance *flb_output_new(struct flb_config *config,
                                           const char *output, void *data,
                                           int public_only);
const char *flb_output_name(struct flb_output_instance *in);
int flb_output_set_property(struct flb_output_instance *out,
                            const char *k, const char *v);
const char *flb_output_get_property(const char *key, struct flb_output_instance *ins);
void *flb_output_get_cmt_instance(struct flb_output_instance *ins);
void flb_output_net_default(const char *host, int port,
                            struct flb_output_instance *ins);
int flb_output_enable_multi_threading(struct flb_output_instance *ins,
                                      struct flb_config *config);
const char *flb_output_name(struct flb_output_instance *ins);
void flb_output_pre_run(struct flb_config *config);
void flb_output_exit(struct flb_config *config);
void flb_output_set_context(struct flb_output_instance *ins, void *context);
int flb_output_instance_destroy(struct flb_output_instance *ins);
int flb_output_net_property_check(struct flb_output_instance *ins,
                                  struct flb_config *config);
int flb_output_oauth2_property_check(struct flb_output_instance *ins,
                                      struct flb_config *config);
int flb_output_plugin_property_check(struct flb_output_instance *ins,
                                     struct flb_config *config);
int flb_output_proxy_tls_ca_check(struct flb_output_instance *ins);
int flb_output_init_all(struct flb_config *config);
int flb_output_check(struct flb_config *config);
int flb_output_log_check(struct flb_output_instance *ins, int l);
int flb_output_upstream_set(struct flb_upstream *u, struct flb_output_instance *ins);
int flb_output_upstream_ha_set(void *ha, struct flb_output_instance *ins);
void flb_output_prepare();
int flb_output_set_http_debug_callbacks(struct flb_output_instance *ins);
int flb_output_task_flush(struct flb_task *task,
                          struct flb_output_instance *out_ins,
                          struct flb_config *config);
int flb_output_task_flush_error(struct flb_task *task,
                                struct flb_output_instance *out_ins);
struct mk_list *flb_output_get_global_config_map(struct flb_config *config);
struct flb_sched;
struct flb_sched_timer {
    struct mk_event event;
    int active;
    int type;
    int coro;
    void *data;
    struct flb_sched *sched;
    int timer_fd;
    void (*cb)(struct flb_config *, void *);
    void (*cb_coroutine_wrapper)(struct flb_config *, void *);
    struct flb_config *config;
    struct mk_list _head;
};
struct flb_sched_request {
    int fd;
    time_t created;
    time_t timeout;
    void *data;
    struct flb_sched_timer *timer;
    struct mk_list _head;
};
struct flb_sched {
    struct mk_event event;
    struct mk_list requests;
    struct mk_list requests_wait;
    struct mk_list timers;
    struct mk_list timers_drop;
    struct cfl_list timer_coro_list;
    struct cfl_list timer_coro_list_drop;
    int frame_fd;
    struct mk_event_loop *evl;
    struct flb_config *config;
    int ch_events[2];
};
struct flb_sched_timer_coro;
int flb_sched_request_create(struct flb_config *config,
                             void *data, int tries);
int flb_sched_request_destroy(struct flb_sched_request *req);
int flb_sched_event_handler(struct flb_config *config, struct mk_event *event);
struct flb_sched *flb_sched_create(struct flb_config *config,
                                   struct mk_event_loop *evl);
int flb_sched_destroy(struct flb_sched *sched);
struct flb_sched_timer *flb_sched_timer_create(struct flb_sched *sched);
int flb_sched_timer_destroy(struct flb_sched_timer *timer);
int flb_sched_request_invalidate(struct flb_config *config, void *data);
int flb_sched_timer_cb_create(struct flb_sched *sched, int type, int ms,
                              void (*cb)(struct flb_config *, void *),
                              void *data, struct flb_sched_timer **out_timer);
int flb_sched_timer_coro_cb_create(struct flb_sched *sched, int type, int64_t ms,
                                   void (*cb)(struct flb_config *, void *),
                                   void *data, struct flb_sched_timer **out_timer);
void flb_sched_timer_coro_destroy(struct flb_sched_timer_coro *instance);
struct flb_sched_timer_coro *flb_sched_timer_coro_create(struct flb_sched_timer *timer,
                                                         struct flb_config *config,
                                                         void *data);
int flb_sched_timer_coro_cleanup(struct flb_sched *sched);
int flb_sched_timer_cb_disable(struct flb_sched_timer *timer);
int flb_sched_timer_cb_destroy(struct flb_sched_timer *timer);
void flb_sched_timer_invalidate(struct flb_sched_timer *timer);
int flb_sched_timer_cleanup(struct flb_sched *sched);
int flb_sched_retry_now(struct flb_config *config,
                        struct flb_task_retry *retry);
void flb_sched_ctx_init();
struct flb_sched *flb_sched_ctx_get();
void flb_sched_ctx_set(struct flb_sched *sched);
struct flb_sched_timer_coro {
    uint32_t id;
    struct flb_sched_timer *timer;
    struct flb_config *config;
    struct flb_coro *coro;
    void *data;
    struct cfl_list _head;
};
struct flb_sched_timer_coro_cb_params {
    struct flb_sched_timer_coro *stc;
    struct flb_config *config;
    void *data;
    uint32_t magic;
    struct flb_coro *coro;
};
extern __thread struct flb_sched_timer_coro_cb_params *sched_timer_coro_cb_params;;
struct flb_timer_cb_coro_params {
    struct flb_config *config;
    void *data;
};
static inline __attribute__((always_inline)) void flb_sched_timer_cb_coro_return()
{
    int n;
    uint64_t val;
    struct flb_coro *coro;
    struct flb_sched *sched;
    struct flb_sched_timer_coro *stc;
    coro = flb_coro_get();
    sched = flb_sched_ctx_get();
    if (!sched) {
        if (flb_log_check(1)) flb_log_print(1, ((void*)0), 0, "[sched] invalid scheduler context");
        return;
    }
    stc = (struct flb_sched_timer_coro *) coro->data;
    if (!stc) {
        if (flb_log_check(1)) flb_log_print(1, ((void*)0), 0, "[sched] invalid timer coro context");
        return;
    }
    val = ((uint64_t) 1 << 32 | stc->id);
    n = write(sched->ch_events[1], &val, sizeof(val));
    if (n == -1) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_scheduler.h", 244);
    }
    flb_coro_yield(coro, 1);
}
static inline __attribute__((always_inline)) void sched_timer_cb_params_set(struct flb_sched_timer_coro *stc,
                                                 struct flb_coro *coro, struct flb_config *config, void *data)
{
    struct flb_sched_timer_coro_cb_params *params;
    params = (struct flb_sched_timer_coro_cb_params *) sched_timer_coro_cb_params;
    if (!params) {
        params = flb_calloc(1, sizeof(struct flb_sched_timer_coro_cb_params));
        if (!params) {
            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_scheduler.h", 260);
            return;
        }
    }
    params->stc = stc;
    params->config = config;
    params->data = data;
    params->coro = coro;
    params->magic = 0x53544350u;
    sched_timer_coro_cb_params=params;
    co_switch(coro->callee);
}
static inline __attribute__((always_inline)) void sched_timer_coro_cb_run(void)
{
    struct flb_coro *coro;
    struct flb_sched_timer *timer;
    struct flb_sched_timer_coro_cb_params *params;
    params = (struct flb_sched_timer_coro_cb_params *) sched_timer_coro_cb_params;
    if (!params) {
        return;
    }
    coro = params->coro;
    co_switch(coro->caller);
    timer = params->stc->timer;
    timer->cb(params->config, params->data);
}

static void flb_time_thread_wakeup(struct flb_config *config, void *data)
{
    (void) config;
    struct flb_coro *th;
    th = (struct flb_coro *) data;
    flb_coro_resume(th);
}
static inline __attribute__((always_inline)) void flb_time_sleep(int ms)
{
    int ret;
    struct flb_coro *coro;
    struct flb_sched *sched;
    coro = flb_coro_get();
    if (!coro) {
        if (flb_log_check(1)) flb_log_print(1, ((void*)0), 0, "[thread] invalid context for thread_sleep()");
        return;
    }
    sched = flb_sched_ctx_get();
    ((void) sizeof ((sched != ((void*)0)) ? 1 : 0), __extension__ ({ if (sched != ((void*)0)) ; else __assert_fail ("sched != NULL", "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/include/fluent-bit/flb_time_utils.h", 60, __extension__ __PRETTY_FUNCTION__); }));
    ret = flb_sched_timer_cb_create(sched, 3,
                                    ms, flb_time_thread_wakeup, coro, ((void*)0));
    if (ret == -1) {
        return;
    }
    flb_coro_yield(coro, 0);
}

struct flb_time {
    struct timespec tm;
};
struct flb_tm {
    struct tm tm;
};
struct flb_time_fmt {
    char *fmt;
    char *frac_secs;
};
enum flb_time_eventtime_fmt {
    FLB_TIME_ETFMT_INT = 1,
    FLB_TIME_ETFMT_V0,
    FLB_TIME_ETFMT_V1_EXT,
    FLB_TIME_ETFMT_V1_FIXEXT,
    FLB_TIME_ETFMT_OTHER,
};
static inline void flb_time_zero(struct flb_time *tm)
{
    tm->tm.tv_sec = 0;
    tm->tm.tv_nsec = 0;
}
static inline void flb_time_set(struct flb_time *tm, time_t sec, long nsec)
{
    tm->tm.tv_sec = sec;
    tm->tm.tv_nsec = nsec;
}
static inline void flb_time_copy(struct flb_time *dst, struct flb_time *src)
{
    dst->tm.tv_sec = src->tm.tv_sec;
    dst->tm.tv_nsec = src->tm.tv_nsec;
}
static inline int flb_time_is_valid_eventtime(struct flb_time *tm)
{
    if (tm == ((void*)0) || tm->tm.tv_sec < 0 ||
        (uint64_t) tm->tm.tv_sec > (4294967295U) ||
        tm->tm.tv_nsec < 0 || tm->tm.tv_nsec >= 1000000000L) {
        return 0;
    }
    return 1;
}
static inline int flb_time_from_uint64(struct flb_time *dst, uint64_t value)
{
    uint64_t seconds;
    uint64_t maximum_seconds;
    unsigned int bit_count;
    if (dst == ((void*)0)) {
        return -1;
    }
    seconds = value / 1000000000L;
    bit_count = sizeof(time_t) * 8;
    if ((time_t) -1 < 0) {
        bit_count--;
    }
    if (bit_count >= sizeof(uint64_t) * 8) {
        maximum_seconds = (18446744073709551615UL);
    }
    else {
        maximum_seconds = (18446744073709551615UL) >>
                          (sizeof(uint64_t) * 8 - bit_count);
    }
    if (seconds > maximum_seconds) {
        return -1;
    }
    dst->tm.tv_sec = (time_t) seconds;
    dst->tm.tv_nsec = (long) (value - ((uint64_t) dst->tm.tv_sec * 1000000000L));
    return 0;
}
static inline void flb_time_from_double(struct flb_time *dst, double d)
{
    dst->tm.tv_sec = (time_t) d;
    dst->tm.tv_nsec = (long) ((d - dst->tm.tv_sec) * 1000000000L);
}
static inline int flb_time_equal(struct flb_time *t0, struct flb_time *t1) {
    return t0->tm.tv_sec == t1->tm.tv_sec && t0->tm.tv_nsec == t1->tm.tv_nsec;
}
int flb_time_get(struct flb_time *tm);
int flb_time_msleep(uint32_t ms);
double flb_time_to_double(struct flb_time *tm);
uint64_t flb_time_to_nanosec(struct flb_time *tm);
uint64_t flb_time_to_millisec(struct flb_time *tm);
int flb_time_add(struct flb_time *base, struct flb_time *duration,
                 struct flb_time *result);
int flb_time_diff(struct flb_time *time1,
                  struct flb_time *time0, struct flb_time *result);
int flb_time_append_to_mpack(mpack_writer_t *writer, struct flb_time *tm, int fmt);
int flb_time_append_to_msgpack(struct flb_time *tm, msgpack_packer *pk, int fmt);
int flb_time_msgpack_to_time(struct flb_time *time, msgpack_object *obj);
int flb_time_fmt_create(struct flb_time_fmt *tf, const char *format);
void flb_time_fmt_destroy(struct flb_time_fmt *tf);
int flb_time_from_str(struct flb_time *tm, const char *str, size_t len,
                      struct flb_time_fmt *tf);
int flb_time_from_msgpack_object(struct flb_time *tm, msgpack_object *obj,
                                 struct flb_time_fmt *tf);
int flb_time_pop_from_mpack(struct flb_time *time, mpack_reader_t *reader);
int flb_time_pop_from_msgpack(struct flb_time *time, msgpack_unpacked *upk,
                              msgpack_object **map);
const char *flb_time_windows_zone_to_iana(const char *windows_zone);
const char *flb_time_iana_zone_to_windows(const char *iana_zone);
int flb_time_windows_zone_to_utc_offset(const char *windows_zone, long *offset);
int flb_time_iana_zone_to_utc_offset(const char *iana_zone, long *offset);
long flb_time_tz_offset_to_second();
struct flb_parser_types {
    char *key;
    int key_len;
    int type;
};
struct flb_parser {
    int type;
    char *name;
    char *p_regex;
    int skip_empty;
    char *time_fmt;
    char *time_fmt_full;
    char *time_key;
    int time_offset;
    int time_system_timezone;
    char *time_zone;
    void *time_zone_data;
    int time_keep;
    int time_strict;
    int logfmt_no_bare_keys;
    char *time_frac_secs;
    struct flb_parser_types *types;
    int types_len;
    struct mk_list *decoders;
    int time_with_year;
    char *time_fmt_year;
    int time_with_tz;
    struct flb_regex *regex;
    struct mk_list _head;
};
enum {
    FLB_PARSER_TYPE_INT = 1,
    FLB_PARSER_TYPE_FLOAT,
    FLB_PARSER_TYPE_BOOL,
    FLB_PARSER_TYPE_STRING,
    FLB_PARSER_TYPE_HEX,
};
static inline time_t flb_parser_tm2time(const struct flb_tm *src,
                                        int use_system_timezone)
{
    struct tm tmp;
    time_t res;
    tmp = src->tm;
    if (use_system_timezone) {
        tmp.tm_isdst = -1;
        res = mktime(&tmp);
    } else {
        res = timegm(&tmp) - (src)->tm.tm_gmtoff;
    }
    return res;
}
time_t flb_parser_tm2time_parser(const struct flb_tm *src,
                                 struct flb_parser *parser);
struct flb_parser *flb_parser_create(const char *name, const char *format,
                                     const char *p_regex,
                                     int skip_empty,
                                     const char *time_fmt, const char *time_key,
                                     const char *time_offset,
                                     int time_keep,
                                     int time_strict,
                                     int time_system_timezone,
                                     int logfmt_no_bare_keys,
                                     struct flb_parser_types *types,
                                     int types_len,
                                     struct mk_list *decoders,
                                     struct flb_config *config);
struct flb_parser *flb_parser_create_with_time_zone(const char *name,
                                     const char *format,
                                     const char *p_regex,
                                     int skip_empty,
                                     const char *time_fmt,
                                     const char *time_key,
                                     const char *time_offset,
                                     int time_keep,
                                     int time_strict,
                                     int time_system_timezone,
                                     const char *time_zone,
                                     int logfmt_no_bare_keys,
                                     struct flb_parser_types *types,
                                     int types_len,
                                     struct mk_list *decoders,
                                     struct flb_config *config);
int flb_parser_conf_file_stat(const char *file, struct flb_config *config);
int flb_parser_conf_file(const char *file, struct flb_config *config);
int flb_parser_load_parser_definitions(const char *cfg, struct flb_cf *cf,
                                       struct flb_config *config);
int flb_parser_load_multiline_parser_definitions(const char *cfg, struct flb_cf *cf,
                                                 struct flb_config *config);
void flb_parser_destroy(struct flb_parser *parser);
struct flb_parser *flb_parser_get(const char *name, struct flb_config *config);
int flb_parser_do(struct flb_parser *parser, const char *buf, size_t length,
                  void **out_buf, size_t *out_size, struct flb_time *out_time);
void flb_parser_exit(struct flb_config *config);
int flb_parser_tzone_offset(const char *str, int len, int *tmdiff);
int flb_parser_time_lookup(const char *time, size_t tsize, time_t now,
                           struct flb_parser *parser,
                           struct flb_tm *tm, double *ns);
int flb_parser_typecast(const char *key, int key_len,
                        const char *val, int val_len,
                        msgpack_packer *pck,
                        struct flb_parser_types *types,
                        int types_len);
typedef __m128i flb_vector8;
typedef __m128i flb_vector32;
static inline _Bool flb_vector8_has(const flb_vector8 v, const uint8_t c);
static inline _Bool flb_vector8_has_zero(const flb_vector8 v);
static inline _Bool flb_vector8_has_le(const flb_vector8 v, const uint8_t c);
static inline _Bool flb_vector8_is_highbit_set(const flb_vector8 v);
static inline void flb_vector8_load(flb_vector8 *v, const uint8_t *s)
{
 *v = _mm_loadu_si128((const __m128i *) s);
}
static inline _Bool flb_vector8_has_zero(const flb_vector8 v)
{
 return flb_vector8_has(v, 0);
}
static inline flb_vector8 flb_vector8_ssub(const flb_vector8 v1, const flb_vector8 v2)
{
 return _mm_subs_epu8(v1, v2);
}
static inline flb_vector8 flb_vector8_eq(const flb_vector8 v1, const flb_vector8 v2)
{
    return _mm_cmpeq_epi8(v1, v2);
}
static inline flb_vector32 flb_vector32_eq(const flb_vector32 v1, const flb_vector32 v2)
{
 return _mm_cmpeq_epi32(v1, v2);
}
static inline flb_vector8 flb_vector8_broadcast(const uint8_t c)
{
 return _mm_set1_epi8(c);
}
static inline _Bool flb_vector8_is_highbit_set(const flb_vector8 v)
{
 return _mm_movemask_epi8(v) != 0;
}
static inline _Bool flb_vector8_has(const flb_vector8 v, const uint8_t c)
{
 _Bool result = 0;
 result = flb_vector8_is_highbit_set(flb_vector8_eq(v, flb_vector8_broadcast(c)));
 return result;
}
static inline _Bool flb_vector8_has_le(const flb_vector8 v, const uint8_t c)
{
 _Bool result = 0;
 result = flb_vector8_has_zero(flb_vector8_ssub(v, flb_vector8_broadcast(c)));
 return result;
}
static inline char *flb_simd_info()
{
   return "SSE2";
}

int in_tail_collect_event(void *file, struct flb_config *config);

 extern const char sqlite3_version[];
           const char *sqlite3_libversion(void);
           const char *sqlite3_sourceid(void);
           int sqlite3_libversion_number(void);
           int sqlite3_compileoption_used(const char *zOptName);
           const char *sqlite3_compileoption_get(int N);
           int sqlite3_threadsafe(void);
typedef struct sqlite3 sqlite3;
  typedef long long int sqlite_int64;
  typedef unsigned long long int sqlite_uint64;
typedef sqlite_int64 sqlite3_int64;
typedef sqlite_uint64 sqlite3_uint64;
           int sqlite3_close(sqlite3*);
           int sqlite3_close_v2(sqlite3*);
typedef int (*sqlite3_callback)(void*,int,char**, char**);
           int sqlite3_exec(
  sqlite3*,
  const char *sql,
  int (*callback)(void*,int,char**,char**),
  void *,
  char **errmsg
);
typedef struct sqlite3_file sqlite3_file;
struct sqlite3_file {
  const struct sqlite3_io_methods *pMethods;
};
typedef struct sqlite3_io_methods sqlite3_io_methods;
struct sqlite3_io_methods {
  int iVersion;
  int (*xClose)(sqlite3_file*);
  int (*xRead)(sqlite3_file*, void*, int iAmt, sqlite3_int64 iOfst);
  int (*xWrite)(sqlite3_file*, const void*, int iAmt, sqlite3_int64 iOfst);
  int (*xTruncate)(sqlite3_file*, sqlite3_int64 size);
  int (*xSync)(sqlite3_file*, int flags);
  int (*xFileSize)(sqlite3_file*, sqlite3_int64 *pSize);
  int (*xLock)(sqlite3_file*, int);
  int (*xUnlock)(sqlite3_file*, int);
  int (*xCheckReservedLock)(sqlite3_file*, int *pResOut);
  int (*xFileControl)(sqlite3_file*, int op, void *pArg);
  int (*xSectorSize)(sqlite3_file*);
  int (*xDeviceCharacteristics)(sqlite3_file*);
  int (*xShmMap)(sqlite3_file*, int iPg, int pgsz, int, void volatile**);
  int (*xShmLock)(sqlite3_file*, int offset, int n, int flags);
  void (*xShmBarrier)(sqlite3_file*);
  int (*xShmUnmap)(sqlite3_file*, int deleteFlag);
  int (*xFetch)(sqlite3_file*, sqlite3_int64 iOfst, int iAmt, void **pp);
  int (*xUnfetch)(sqlite3_file*, sqlite3_int64 iOfst, void *p);
};
typedef struct sqlite3_mutex sqlite3_mutex;
typedef struct sqlite3_api_routines sqlite3_api_routines;
typedef const char *sqlite3_filename;
typedef struct sqlite3_vfs sqlite3_vfs;
typedef void (*sqlite3_syscall_ptr)(void);
struct sqlite3_vfs {
  int iVersion;
  int szOsFile;
  int mxPathname;
  sqlite3_vfs *pNext;
  const char *zName;
  void *pAppData;
  int (*xOpen)(sqlite3_vfs*, sqlite3_filename zName, sqlite3_file*,
               int flags, int *pOutFlags);
  int (*xDelete)(sqlite3_vfs*, const char *zName, int syncDir);
  int (*xAccess)(sqlite3_vfs*, const char *zName, int flags, int *pResOut);
  int (*xFullPathname)(sqlite3_vfs*, const char *zName, int nOut, char *zOut);
  void *(*xDlOpen)(sqlite3_vfs*, const char *zFilename);
  void (*xDlError)(sqlite3_vfs*, int nByte, char *zErrMsg);
  void (*(*xDlSym)(sqlite3_vfs*,void*, const char *zSymbol))(void);
  void (*xDlClose)(sqlite3_vfs*, void*);
  int (*xRandomness)(sqlite3_vfs*, int nByte, char *zOut);
  int (*xSleep)(sqlite3_vfs*, int microseconds);
  int (*xCurrentTime)(sqlite3_vfs*, double*);
  int (*xGetLastError)(sqlite3_vfs*, int, char *);
  int (*xCurrentTimeInt64)(sqlite3_vfs*, sqlite3_int64*);
  int (*xSetSystemCall)(sqlite3_vfs*, const char *zName, sqlite3_syscall_ptr);
  sqlite3_syscall_ptr (*xGetSystemCall)(sqlite3_vfs*, const char *zName);
  const char *(*xNextSystemCall)(sqlite3_vfs*, const char *zName);
};
           int sqlite3_initialize(void);
           int sqlite3_shutdown(void);
           int sqlite3_os_init(void);
           int sqlite3_os_end(void);
           int sqlite3_config(int, ...);
           int sqlite3_db_config(sqlite3*, int op, ...);
typedef struct sqlite3_mem_methods sqlite3_mem_methods;
struct sqlite3_mem_methods {
  void *(*xMalloc)(int);
  void (*xFree)(void*);
  void *(*xRealloc)(void*,int);
  int (*xSize)(void*);
  int (*xRoundup)(int);
  int (*xInit)(void*);
  void (*xShutdown)(void*);
  void *pAppData;
};
           int sqlite3_extended_result_codes(sqlite3*, int onoff);
           sqlite3_int64 sqlite3_last_insert_rowid(sqlite3*);
           void sqlite3_set_last_insert_rowid(sqlite3*,sqlite3_int64);
           int sqlite3_changes(sqlite3*);
           sqlite3_int64 sqlite3_changes64(sqlite3*);
           int sqlite3_total_changes(sqlite3*);
           sqlite3_int64 sqlite3_total_changes64(sqlite3*);
           void sqlite3_interrupt(sqlite3*);
           int sqlite3_is_interrupted(sqlite3*);
           int sqlite3_complete(const char *sql);
           int sqlite3_complete16(const void *sql);
           int sqlite3_busy_handler(sqlite3*,int(*)(void*,int),void*);
           int sqlite3_busy_timeout(sqlite3*, int ms);
           int sqlite3_setlk_timeout(sqlite3*, int ms, int flags);
           int sqlite3_get_table(
  sqlite3 *db,
  const char *zSql,
  char ***pazResult,
  int *pnRow,
  int *pnColumn,
  char **pzErrmsg
);
           void sqlite3_free_table(char **result);
           char *sqlite3_mprintf(const char*,...);
           char *sqlite3_vmprintf(const char*, va_list);
           char *sqlite3_snprintf(int,char*,const char*, ...);
           char *sqlite3_vsnprintf(int,char*,const char*, va_list);
           void *sqlite3_malloc(int);
           void *sqlite3_malloc64(sqlite3_uint64);
           void *sqlite3_realloc(void*, int);
           void *sqlite3_realloc64(void*, sqlite3_uint64);
           void sqlite3_free(void*);
           sqlite3_uint64 sqlite3_msize(void*);
           sqlite3_int64 sqlite3_memory_used(void);
           sqlite3_int64 sqlite3_memory_highwater(int resetFlag);
           void sqlite3_randomness(int N, void *P);
           int sqlite3_set_authorizer(
  sqlite3*,
  int (*xAuth)(void*,int,const char*,const char*,const char*,const char*),
  void *pUserData
);
                             void *sqlite3_trace(sqlite3*,
   void(*xTrace)(void*,const char*), void*);
                             void *sqlite3_profile(sqlite3*,
   void(*xProfile)(void*,const char*,sqlite3_uint64), void*);
           int sqlite3_trace_v2(
  sqlite3*,
  unsigned uMask,
  int(*xCallback)(unsigned,void*,void*,void*),
  void *pCtx
);
           void sqlite3_progress_handler(sqlite3*, int, int(*)(void*), void*);
           int sqlite3_open(
  const char *filename,
  sqlite3 **ppDb
);
           int sqlite3_open16(
  const void *filename,
  sqlite3 **ppDb
);
           int sqlite3_open_v2(
  const char *filename,
  sqlite3 **ppDb,
  int flags,
  const char *zVfs
);
           const char *sqlite3_uri_parameter(sqlite3_filename z, const char *zParam);
           int sqlite3_uri_boolean(sqlite3_filename z, const char *zParam, int bDefault);
           sqlite3_int64 sqlite3_uri_int64(sqlite3_filename, const char*, sqlite3_int64);
           const char *sqlite3_uri_key(sqlite3_filename z, int N);
           const char *sqlite3_filename_database(sqlite3_filename);
           const char *sqlite3_filename_journal(sqlite3_filename);
           const char *sqlite3_filename_wal(sqlite3_filename);
           sqlite3_file *sqlite3_database_file_object(const char*);
           sqlite3_filename sqlite3_create_filename(
  const char *zDatabase,
  const char *zJournal,
  const char *zWal,
  int nParam,
  const char **azParam
);
           void sqlite3_free_filename(sqlite3_filename);
           int sqlite3_errcode(sqlite3 *db);
           int sqlite3_extended_errcode(sqlite3 *db);
           const char *sqlite3_errmsg(sqlite3*);
           const void *sqlite3_errmsg16(sqlite3*);
           const char *sqlite3_errstr(int);
           int sqlite3_error_offset(sqlite3 *db);
           int sqlite3_set_errmsg(sqlite3 *db, int errcode, const char *zErrMsg);
typedef struct sqlite3_stmt sqlite3_stmt;
           int sqlite3_limit(sqlite3*, int id, int newVal);
           int sqlite3_prepare(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);
           int sqlite3_prepare_v2(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);
           int sqlite3_prepare_v3(
  sqlite3 *db,
  const char *zSql,
  int nByte,
  unsigned int prepFlags,
  sqlite3_stmt **ppStmt,
  const char **pzTail
);
           int sqlite3_prepare16(
  sqlite3 *db,
  const void *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const void **pzTail
);
           int sqlite3_prepare16_v2(
  sqlite3 *db,
  const void *zSql,
  int nByte,
  sqlite3_stmt **ppStmt,
  const void **pzTail
);
           int sqlite3_prepare16_v3(
  sqlite3 *db,
  const void *zSql,
  int nByte,
  unsigned int prepFlags,
  sqlite3_stmt **ppStmt,
  const void **pzTail
);
           const char *sqlite3_sql(sqlite3_stmt *pStmt);
           char *sqlite3_expanded_sql(sqlite3_stmt *pStmt);
           int sqlite3_stmt_readonly(sqlite3_stmt *pStmt);
           int sqlite3_stmt_isexplain(sqlite3_stmt *pStmt);
           int sqlite3_stmt_explain(sqlite3_stmt *pStmt, int eMode);
           int sqlite3_stmt_busy(sqlite3_stmt*);
typedef struct sqlite3_value sqlite3_value;
typedef struct sqlite3_context sqlite3_context;
           int sqlite3_bind_blob(sqlite3_stmt*, int, const void*, int n, void(*)(void*));
           int sqlite3_bind_blob64(sqlite3_stmt*, int, const void*, sqlite3_uint64,
                        void(*)(void*));
           int sqlite3_bind_double(sqlite3_stmt*, int, double);
           int sqlite3_bind_int(sqlite3_stmt*, int, int);
           int sqlite3_bind_int64(sqlite3_stmt*, int, sqlite3_int64);
           int sqlite3_bind_null(sqlite3_stmt*, int);
           int sqlite3_bind_text(sqlite3_stmt*,int,const char*,int,void(*)(void*));
           int sqlite3_bind_text16(sqlite3_stmt*, int, const void*, int, void(*)(void*));
           int sqlite3_bind_text64(sqlite3_stmt*, int, const char*, sqlite3_uint64,
                         void(*)(void*), unsigned char encoding);
           int sqlite3_bind_value(sqlite3_stmt*, int, const sqlite3_value*);
           int sqlite3_bind_pointer(sqlite3_stmt*, int, void*, const char*,void(*)(void*));
           int sqlite3_bind_zeroblob(sqlite3_stmt*, int, int n);
           int sqlite3_bind_zeroblob64(sqlite3_stmt*, int, sqlite3_uint64);
           int sqlite3_bind_parameter_count(sqlite3_stmt*);
           const char *sqlite3_bind_parameter_name(sqlite3_stmt*, int);
           int sqlite3_bind_parameter_index(sqlite3_stmt*, const char *zName);
           int sqlite3_clear_bindings(sqlite3_stmt*);
           int sqlite3_column_count(sqlite3_stmt *pStmt);
           const char *sqlite3_column_name(sqlite3_stmt*, int N);
           const void *sqlite3_column_name16(sqlite3_stmt*, int N);
           const char *sqlite3_column_database_name(sqlite3_stmt*,int);
           const void *sqlite3_column_database_name16(sqlite3_stmt*,int);
           const char *sqlite3_column_table_name(sqlite3_stmt*,int);
           const void *sqlite3_column_table_name16(sqlite3_stmt*,int);
           const char *sqlite3_column_origin_name(sqlite3_stmt*,int);
           const void *sqlite3_column_origin_name16(sqlite3_stmt*,int);
           const char *sqlite3_column_decltype(sqlite3_stmt*,int);
           const void *sqlite3_column_decltype16(sqlite3_stmt*,int);
           int sqlite3_step(sqlite3_stmt*);
           int sqlite3_data_count(sqlite3_stmt *pStmt);
           const void *sqlite3_column_blob(sqlite3_stmt*, int iCol);
           double sqlite3_column_double(sqlite3_stmt*, int iCol);
           int sqlite3_column_int(sqlite3_stmt*, int iCol);
           sqlite3_int64 sqlite3_column_int64(sqlite3_stmt*, int iCol);
           const unsigned char *sqlite3_column_text(sqlite3_stmt*, int iCol);
           const void *sqlite3_column_text16(sqlite3_stmt*, int iCol);
           sqlite3_value *sqlite3_column_value(sqlite3_stmt*, int iCol);
           int sqlite3_column_bytes(sqlite3_stmt*, int iCol);
           int sqlite3_column_bytes16(sqlite3_stmt*, int iCol);
           int sqlite3_column_type(sqlite3_stmt*, int iCol);
           int sqlite3_finalize(sqlite3_stmt *pStmt);
           int sqlite3_reset(sqlite3_stmt *pStmt);
           int sqlite3_create_function(
  sqlite3 *db,
  const char *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xFunc)(sqlite3_context*,int,sqlite3_value**),
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*)
);
           int sqlite3_create_function16(
  sqlite3 *db,
  const void *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xFunc)(sqlite3_context*,int,sqlite3_value**),
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*)
);
           int sqlite3_create_function_v2(
  sqlite3 *db,
  const char *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xFunc)(sqlite3_context*,int,sqlite3_value**),
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*),
  void(*xDestroy)(void*)
);
           int sqlite3_create_window_function(
  sqlite3 *db,
  const char *zFunctionName,
  int nArg,
  int eTextRep,
  void *pApp,
  void (*xStep)(sqlite3_context*,int,sqlite3_value**),
  void (*xFinal)(sqlite3_context*),
  void (*xValue)(sqlite3_context*),
  void (*xInverse)(sqlite3_context*,int,sqlite3_value**),
  void(*xDestroy)(void*)
);
                             int sqlite3_aggregate_count(sqlite3_context*);
                             int sqlite3_expired(sqlite3_stmt*);
                             int sqlite3_transfer_bindings(sqlite3_stmt*, sqlite3_stmt*);
                             int sqlite3_global_recover(void);
                             void sqlite3_thread_cleanup(void);
                             int sqlite3_memory_alarm(void(*)(void*,sqlite3_int64,int),
                      void*,sqlite3_int64);
           const void *sqlite3_value_blob(sqlite3_value*);
           double sqlite3_value_double(sqlite3_value*);
           int sqlite3_value_int(sqlite3_value*);
           sqlite3_int64 sqlite3_value_int64(sqlite3_value*);
           void *sqlite3_value_pointer(sqlite3_value*, const char*);
           const unsigned char *sqlite3_value_text(sqlite3_value*);
           const void *sqlite3_value_text16(sqlite3_value*);
           const void *sqlite3_value_text16le(sqlite3_value*);
           const void *sqlite3_value_text16be(sqlite3_value*);
           int sqlite3_value_bytes(sqlite3_value*);
           int sqlite3_value_bytes16(sqlite3_value*);
           int sqlite3_value_type(sqlite3_value*);
           int sqlite3_value_numeric_type(sqlite3_value*);
           int sqlite3_value_nochange(sqlite3_value*);
           int sqlite3_value_frombind(sqlite3_value*);
           int sqlite3_value_encoding(sqlite3_value*);
           unsigned int sqlite3_value_subtype(sqlite3_value*);
           sqlite3_value *sqlite3_value_dup(const sqlite3_value*);
           void sqlite3_value_free(sqlite3_value*);
           void *sqlite3_aggregate_context(sqlite3_context*, int nBytes);
           void *sqlite3_user_data(sqlite3_context*);
           sqlite3 *sqlite3_context_db_handle(sqlite3_context*);
           void *sqlite3_get_auxdata(sqlite3_context*, int N);
           void sqlite3_set_auxdata(sqlite3_context*, int N, void*, void (*)(void*));
           void *sqlite3_get_clientdata(sqlite3*,const char*);
           int sqlite3_set_clientdata(sqlite3*, const char*, void*, void(*)(void*));
typedef void (*sqlite3_destructor_type)(void*);
           void sqlite3_result_blob(sqlite3_context*, const void*, int, void(*)(void*));
           void sqlite3_result_blob64(sqlite3_context*,const void*,
                           sqlite3_uint64,void(*)(void*));
           void sqlite3_result_double(sqlite3_context*, double);
           void sqlite3_result_error(sqlite3_context*, const char*, int);
           void sqlite3_result_error16(sqlite3_context*, const void*, int);
           void sqlite3_result_error_toobig(sqlite3_context*);
           void sqlite3_result_error_nomem(sqlite3_context*);
           void sqlite3_result_error_code(sqlite3_context*, int);
           void sqlite3_result_int(sqlite3_context*, int);
           void sqlite3_result_int64(sqlite3_context*, sqlite3_int64);
           void sqlite3_result_null(sqlite3_context*);
           void sqlite3_result_text(sqlite3_context*, const char*, int, void(*)(void*));
           void sqlite3_result_text64(sqlite3_context*, const char*,sqlite3_uint64,
                           void(*)(void*), unsigned char encoding);
           void sqlite3_result_text16(sqlite3_context*, const void*, int, void(*)(void*));
           void sqlite3_result_text16le(sqlite3_context*, const void*, int,void(*)(void*));
           void sqlite3_result_text16be(sqlite3_context*, const void*, int,void(*)(void*));
           void sqlite3_result_value(sqlite3_context*, sqlite3_value*);
           void sqlite3_result_pointer(sqlite3_context*, void*,const char*,void(*)(void*));
           void sqlite3_result_zeroblob(sqlite3_context*, int n);
           int sqlite3_result_zeroblob64(sqlite3_context*, sqlite3_uint64 n);
           void sqlite3_result_subtype(sqlite3_context*,unsigned int);
           int sqlite3_create_collation(
  sqlite3*,
  const char *zName,
  int eTextRep,
  void *pArg,
  int(*xCompare)(void*,int,const void*,int,const void*)
);
           int sqlite3_create_collation_v2(
  sqlite3*,
  const char *zName,
  int eTextRep,
  void *pArg,
  int(*xCompare)(void*,int,const void*,int,const void*),
  void(*xDestroy)(void*)
);
           int sqlite3_create_collation16(
  sqlite3*,
  const void *zName,
  int eTextRep,
  void *pArg,
  int(*xCompare)(void*,int,const void*,int,const void*)
);
           int sqlite3_collation_needed(
  sqlite3*,
  void*,
  void(*)(void*,sqlite3*,int eTextRep,const char*)
);
           int sqlite3_collation_needed16(
  sqlite3*,
  void*,
  void(*)(void*,sqlite3*,int eTextRep,const void*)
);
           int sqlite3_sleep(int);
           extern char *sqlite3_temp_directory;
           extern char *sqlite3_data_directory;
           int sqlite3_win32_set_directory(
  unsigned long type,
  void *zValue
);
           int sqlite3_win32_set_directory8(unsigned long type, const char *zValue);
           int sqlite3_win32_set_directory16(unsigned long type, const void *zValue);
           int sqlite3_get_autocommit(sqlite3*);
           sqlite3 *sqlite3_db_handle(sqlite3_stmt*);
           const char *sqlite3_db_name(sqlite3 *db, int N);
           sqlite3_filename sqlite3_db_filename(sqlite3 *db, const char *zDbName);
           int sqlite3_db_readonly(sqlite3 *db, const char *zDbName);
           int sqlite3_txn_state(sqlite3*,const char *zSchema);
           sqlite3_stmt *sqlite3_next_stmt(sqlite3 *pDb, sqlite3_stmt *pStmt);
           void *sqlite3_commit_hook(sqlite3*, int(*)(void*), void*);
           void *sqlite3_rollback_hook(sqlite3*, void(*)(void *), void*);
           int sqlite3_autovacuum_pages(
  sqlite3 *db,
  unsigned int(*)(void*,const char*,unsigned int,unsigned int,unsigned int),
  void*,
  void(*)(void*)
);
           void *sqlite3_update_hook(
  sqlite3*,
  void(*)(void *,int ,char const *,char const *,sqlite3_int64),
  void*
);
           int sqlite3_enable_shared_cache(int);
           int sqlite3_release_memory(int);
           int sqlite3_db_release_memory(sqlite3*);
           sqlite3_int64 sqlite3_soft_heap_limit64(sqlite3_int64 N);
           sqlite3_int64 sqlite3_hard_heap_limit64(sqlite3_int64 N);
                             void sqlite3_soft_heap_limit(int N);
           int sqlite3_table_column_metadata(
  sqlite3 *db,
  const char *zDbName,
  const char *zTableName,
  const char *zColumnName,
  char const **pzDataType,
  char const **pzCollSeq,
  int *pNotNull,
  int *pPrimaryKey,
  int *pAutoinc
);
           int sqlite3_load_extension(
  sqlite3 *db,
  const char *zFile,
  const char *zProc,
  char **pzErrMsg
);
           int sqlite3_enable_load_extension(sqlite3 *db, int onoff);
           int sqlite3_auto_extension(void(*xEntryPoint)(void));
           int sqlite3_cancel_auto_extension(void(*xEntryPoint)(void));
           void sqlite3_reset_auto_extension(void);
typedef struct sqlite3_vtab sqlite3_vtab;
typedef struct sqlite3_index_info sqlite3_index_info;
typedef struct sqlite3_vtab_cursor sqlite3_vtab_cursor;
typedef struct sqlite3_module sqlite3_module;
struct sqlite3_module {
  int iVersion;
  int (*xCreate)(sqlite3*, void *pAux,
               int argc, const char *const*argv,
               sqlite3_vtab **ppVTab, char**);
  int (*xConnect)(sqlite3*, void *pAux,
               int argc, const char *const*argv,
               sqlite3_vtab **ppVTab, char**);
  int (*xBestIndex)(sqlite3_vtab *pVTab, sqlite3_index_info*);
  int (*xDisconnect)(sqlite3_vtab *pVTab);
  int (*xDestroy)(sqlite3_vtab *pVTab);
  int (*xOpen)(sqlite3_vtab *pVTab, sqlite3_vtab_cursor **ppCursor);
  int (*xClose)(sqlite3_vtab_cursor*);
  int (*xFilter)(sqlite3_vtab_cursor*, int idxNum, const char *idxStr,
                int argc, sqlite3_value **argv);
  int (*xNext)(sqlite3_vtab_cursor*);
  int (*xEof)(sqlite3_vtab_cursor*);
  int (*xColumn)(sqlite3_vtab_cursor*, sqlite3_context*, int);
  int (*xRowid)(sqlite3_vtab_cursor*, sqlite3_int64 *pRowid);
  int (*xUpdate)(sqlite3_vtab *, int, sqlite3_value **, sqlite3_int64 *);
  int (*xBegin)(sqlite3_vtab *pVTab);
  int (*xSync)(sqlite3_vtab *pVTab);
  int (*xCommit)(sqlite3_vtab *pVTab);
  int (*xRollback)(sqlite3_vtab *pVTab);
  int (*xFindFunction)(sqlite3_vtab *pVtab, int nArg, const char *zName,
                       void (**pxFunc)(sqlite3_context*,int,sqlite3_value**),
                       void **ppArg);
  int (*xRename)(sqlite3_vtab *pVtab, const char *zNew);
  int (*xSavepoint)(sqlite3_vtab *pVTab, int);
  int (*xRelease)(sqlite3_vtab *pVTab, int);
  int (*xRollbackTo)(sqlite3_vtab *pVTab, int);
  int (*xShadowName)(const char*);
  int (*xIntegrity)(sqlite3_vtab *pVTab, const char *zSchema,
                    const char *zTabName, int mFlags, char **pzErr);
};
struct sqlite3_index_info {
  int nConstraint;
  struct sqlite3_index_constraint {
     int iColumn;
     unsigned char op;
     unsigned char usable;
     int iTermOffset;
  } *aConstraint;
  int nOrderBy;
  struct sqlite3_index_orderby {
     int iColumn;
     unsigned char desc;
  } *aOrderBy;
  struct sqlite3_index_constraint_usage {
    int argvIndex;
    unsigned char omit;
  } *aConstraintUsage;
  int idxNum;
  char *idxStr;
  int needToFreeIdxStr;
  int orderByConsumed;
  double estimatedCost;
  sqlite3_int64 estimatedRows;
  int idxFlags;
  sqlite3_uint64 colUsed;
};
           int sqlite3_create_module(
  sqlite3 *db,
  const char *zName,
  const sqlite3_module *p,
  void *pClientData
);
           int sqlite3_create_module_v2(
  sqlite3 *db,
  const char *zName,
  const sqlite3_module *p,
  void *pClientData,
  void(*xDestroy)(void*)
);
           int sqlite3_drop_modules(
  sqlite3 *db,
  const char **azKeep
);
struct sqlite3_vtab {
  const sqlite3_module *pModule;
  int nRef;
  char *zErrMsg;
};
struct sqlite3_vtab_cursor {
  sqlite3_vtab *pVtab;
};
           int sqlite3_declare_vtab(sqlite3*, const char *zSQL);
           int sqlite3_overload_function(sqlite3*, const char *zFuncName, int nArg);
typedef struct sqlite3_blob sqlite3_blob;
           int sqlite3_blob_open(
  sqlite3*,
  const char *zDb,
  const char *zTable,
  const char *zColumn,
  sqlite3_int64 iRow,
  int flags,
  sqlite3_blob **ppBlob
);
           int sqlite3_blob_reopen(sqlite3_blob *, sqlite3_int64);
           int sqlite3_blob_close(sqlite3_blob *);
           int sqlite3_blob_bytes(sqlite3_blob *);
           int sqlite3_blob_read(sqlite3_blob *, void *Z, int N, int iOffset);
           int sqlite3_blob_write(sqlite3_blob *, const void *z, int n, int iOffset);
           sqlite3_vfs *sqlite3_vfs_find(const char *zVfsName);
           int sqlite3_vfs_register(sqlite3_vfs*, int makeDflt);
           int sqlite3_vfs_unregister(sqlite3_vfs*);
           sqlite3_mutex *sqlite3_mutex_alloc(int);
           void sqlite3_mutex_free(sqlite3_mutex*);
           void sqlite3_mutex_enter(sqlite3_mutex*);
           int sqlite3_mutex_try(sqlite3_mutex*);
           void sqlite3_mutex_leave(sqlite3_mutex*);
typedef struct sqlite3_mutex_methods sqlite3_mutex_methods;
struct sqlite3_mutex_methods {
  int (*xMutexInit)(void);
  int (*xMutexEnd)(void);
  sqlite3_mutex *(*xMutexAlloc)(int);
  void (*xMutexFree)(sqlite3_mutex *);
  void (*xMutexEnter)(sqlite3_mutex *);
  int (*xMutexTry)(sqlite3_mutex *);
  void (*xMutexLeave)(sqlite3_mutex *);
  int (*xMutexHeld)(sqlite3_mutex *);
  int (*xMutexNotheld)(sqlite3_mutex *);
};
           int sqlite3_mutex_held(sqlite3_mutex*);
           int sqlite3_mutex_notheld(sqlite3_mutex*);
           sqlite3_mutex *sqlite3_db_mutex(sqlite3*);
           int sqlite3_file_control(sqlite3*, const char *zDbName, int op, void*);
           int sqlite3_test_control(int op, ...);
           int sqlite3_keyword_count(void);
           int sqlite3_keyword_name(int,const char**,int*);
           int sqlite3_keyword_check(const char*,int);
typedef struct sqlite3_str sqlite3_str;
           sqlite3_str *sqlite3_str_new(sqlite3*);
           char *sqlite3_str_finish(sqlite3_str*);
           void sqlite3_str_appendf(sqlite3_str*, const char *zFormat, ...);
           void sqlite3_str_vappendf(sqlite3_str*, const char *zFormat, va_list);
           void sqlite3_str_append(sqlite3_str*, const char *zIn, int N);
           void sqlite3_str_appendall(sqlite3_str*, const char *zIn);
           void sqlite3_str_appendchar(sqlite3_str*, int N, char C);
           void sqlite3_str_reset(sqlite3_str*);
           int sqlite3_str_errcode(sqlite3_str*);
           int sqlite3_str_length(sqlite3_str*);
           char *sqlite3_str_value(sqlite3_str*);
           int sqlite3_status(int op, int *pCurrent, int *pHighwater, int resetFlag);
           int sqlite3_status64(
  int op,
  sqlite3_int64 *pCurrent,
  sqlite3_int64 *pHighwater,
  int resetFlag
);
           int sqlite3_db_status(sqlite3*, int op, int *pCur, int *pHiwtr, int resetFlg);
           int sqlite3_db_status64(sqlite3*,int,sqlite3_int64*,sqlite3_int64*,int);
           int sqlite3_stmt_status(sqlite3_stmt*, int op,int resetFlg);
typedef struct sqlite3_pcache sqlite3_pcache;
typedef struct sqlite3_pcache_page sqlite3_pcache_page;
struct sqlite3_pcache_page {
  void *pBuf;
  void *pExtra;
};
typedef struct sqlite3_pcache_methods2 sqlite3_pcache_methods2;
struct sqlite3_pcache_methods2 {
  int iVersion;
  void *pArg;
  int (*xInit)(void*);
  void (*xShutdown)(void*);
  sqlite3_pcache *(*xCreate)(int szPage, int szExtra, int bPurgeable);
  void (*xCachesize)(sqlite3_pcache*, int nCachesize);
  int (*xPagecount)(sqlite3_pcache*);
  sqlite3_pcache_page *(*xFetch)(sqlite3_pcache*, unsigned key, int createFlag);
  void (*xUnpin)(sqlite3_pcache*, sqlite3_pcache_page*, int discard);
  void (*xRekey)(sqlite3_pcache*, sqlite3_pcache_page*,
      unsigned oldKey, unsigned newKey);
  void (*xTruncate)(sqlite3_pcache*, unsigned iLimit);
  void (*xDestroy)(sqlite3_pcache*);
  void (*xShrink)(sqlite3_pcache*);
};
typedef struct sqlite3_pcache_methods sqlite3_pcache_methods;
struct sqlite3_pcache_methods {
  void *pArg;
  int (*xInit)(void*);
  void (*xShutdown)(void*);
  sqlite3_pcache *(*xCreate)(int szPage, int bPurgeable);
  void (*xCachesize)(sqlite3_pcache*, int nCachesize);
  int (*xPagecount)(sqlite3_pcache*);
  void *(*xFetch)(sqlite3_pcache*, unsigned key, int createFlag);
  void (*xUnpin)(sqlite3_pcache*, void*, int discard);
  void (*xRekey)(sqlite3_pcache*, void*, unsigned oldKey, unsigned newKey);
  void (*xTruncate)(sqlite3_pcache*, unsigned iLimit);
  void (*xDestroy)(sqlite3_pcache*);
};
typedef struct sqlite3_backup sqlite3_backup;
           sqlite3_backup *sqlite3_backup_init(
  sqlite3 *pDest,
  const char *zDestName,
  sqlite3 *pSource,
  const char *zSourceName
);
           int sqlite3_backup_step(sqlite3_backup *p, int nPage);
           int sqlite3_backup_finish(sqlite3_backup *p);
           int sqlite3_backup_remaining(sqlite3_backup *p);
           int sqlite3_backup_pagecount(sqlite3_backup *p);
           int sqlite3_unlock_notify(
  sqlite3 *pBlocked,
  void (*xNotify)(void **apArg, int nArg),
  void *pNotifyArg
);
           int sqlite3_stricmp(const char *, const char *);
           int sqlite3_strnicmp(const char *, const char *, int);
           int sqlite3_strglob(const char *zGlob, const char *zStr);
           int sqlite3_strlike(const char *zGlob, const char *zStr, unsigned int cEsc);
           void sqlite3_log(int iErrCode, const char *zFormat, ...);
           void *sqlite3_wal_hook(
  sqlite3*,
  int(*)(void *,sqlite3*,const char*,int),
  void*
);
           int sqlite3_wal_autocheckpoint(sqlite3 *db, int N);
           int sqlite3_wal_checkpoint(sqlite3 *db, const char *zDb);
           int sqlite3_wal_checkpoint_v2(
  sqlite3 *db,
  const char *zDb,
  int eMode,
  int *pnLog,
  int *pnCkpt
);
           int sqlite3_vtab_config(sqlite3*, int op, ...);
           int sqlite3_vtab_on_conflict(sqlite3 *);
           int sqlite3_vtab_nochange(sqlite3_context*);
           const char *sqlite3_vtab_collation(sqlite3_index_info*,int);
           int sqlite3_vtab_distinct(sqlite3_index_info*);
           int sqlite3_vtab_in(sqlite3_index_info*, int iCons, int bHandle);
           int sqlite3_vtab_in_first(sqlite3_value *pVal, sqlite3_value **ppOut);
           int sqlite3_vtab_in_next(sqlite3_value *pVal, sqlite3_value **ppOut);
           int sqlite3_vtab_rhs_value(sqlite3_index_info*, int, sqlite3_value **ppVal);
           int sqlite3_stmt_scanstatus(
  sqlite3_stmt *pStmt,
  int idx,
  int iScanStatusOp,
  void *pOut
);
           int sqlite3_stmt_scanstatus_v2(
  sqlite3_stmt *pStmt,
  int idx,
  int iScanStatusOp,
  int flags,
  void *pOut
);
           void sqlite3_stmt_scanstatus_reset(sqlite3_stmt*);
           int sqlite3_db_cacheflush(sqlite3*);
           int sqlite3_system_errno(sqlite3*);
typedef struct sqlite3_snapshot {
  unsigned char hidden[48];
} sqlite3_snapshot;
           int sqlite3_snapshot_get(
  sqlite3 *db,
  const char *zSchema,
  sqlite3_snapshot **ppSnapshot
);
           int sqlite3_snapshot_open(
  sqlite3 *db,
  const char *zSchema,
  sqlite3_snapshot *pSnapshot
);
           void sqlite3_snapshot_free(sqlite3_snapshot*);
           int sqlite3_snapshot_cmp(
  sqlite3_snapshot *p1,
  sqlite3_snapshot *p2
);
           int sqlite3_snapshot_recover(sqlite3 *db, const char *zDb);
           unsigned char *sqlite3_serialize(
  sqlite3 *db,
  const char *zSchema,
  sqlite3_int64 *piSize,
  unsigned int mFlags
);
           int sqlite3_deserialize(
  sqlite3 *db,
  const char *zSchema,
  unsigned char *pData,
  sqlite3_int64 szDb,
  sqlite3_int64 szBuf,
  unsigned mFlags
);
           int sqlite3_carray_bind(
  sqlite3_stmt *pStmt,
  int i,
  void *aData,
  int nData,
  int mFlags,
  void (*xDel)(void*)
);
typedef struct sqlite3_rtree_geometry sqlite3_rtree_geometry;
typedef struct sqlite3_rtree_query_info sqlite3_rtree_query_info;
  typedef double sqlite3_rtree_dbl;
           int sqlite3_rtree_geometry_callback(
  sqlite3 *db,
  const char *zGeom,
  int (*xGeom)(sqlite3_rtree_geometry*, int, sqlite3_rtree_dbl*,int*),
  void *pContext
);
struct sqlite3_rtree_geometry {
  void *pContext;
  int nParam;
  sqlite3_rtree_dbl *aParam;
  void *pUser;
  void (*xDelUser)(void *);
};
           int sqlite3_rtree_query_callback(
  sqlite3 *db,
  const char *zQueryFunc,
  int (*xQueryFunc)(sqlite3_rtree_query_info*),
  void *pContext,
  void (*xDestructor)(void*)
);
struct sqlite3_rtree_query_info {
  void *pContext;
  int nParam;
  sqlite3_rtree_dbl *aParam;
  void *pUser;
  void (*xDelUser)(void*);
  sqlite3_rtree_dbl *aCoord;
  unsigned int *anQueue;
  int nCoord;
  int iLevel;
  int mxLevel;
  sqlite3_int64 iRowid;
  sqlite3_rtree_dbl rParentScore;
  int eParentWithin;
  int eWithin;
  sqlite3_rtree_dbl rScore;
  sqlite3_value **apSqlParam;
};
typedef struct Fts5ExtensionApi Fts5ExtensionApi;
typedef struct Fts5Context Fts5Context;
typedef struct Fts5PhraseIter Fts5PhraseIter;
typedef void (*fts5_extension_function)(
  const Fts5ExtensionApi *pApi,
  Fts5Context *pFts,
  sqlite3_context *pCtx,
  int nVal,
  sqlite3_value **apVal
);
struct Fts5PhraseIter {
  const unsigned char *a;
  const unsigned char *b;
};
struct Fts5ExtensionApi {
  int iVersion;
  void *(*xUserData)(Fts5Context*);
  int (*xColumnCount)(Fts5Context*);
  int (*xRowCount)(Fts5Context*, sqlite3_int64 *pnRow);
  int (*xColumnTotalSize)(Fts5Context*, int iCol, sqlite3_int64 *pnToken);
  int (*xTokenize)(Fts5Context*,
    const char *pText, int nText,
    void *pCtx,
    int (*xToken)(void*, int, const char*, int, int, int)
  );
  int (*xPhraseCount)(Fts5Context*);
  int (*xPhraseSize)(Fts5Context*, int iPhrase);
  int (*xInstCount)(Fts5Context*, int *pnInst);
  int (*xInst)(Fts5Context*, int iIdx, int *piPhrase, int *piCol, int *piOff);
  sqlite3_int64 (*xRowid)(Fts5Context*);
  int (*xColumnText)(Fts5Context*, int iCol, const char **pz, int *pn);
  int (*xColumnSize)(Fts5Context*, int iCol, int *pnToken);
  int (*xQueryPhrase)(Fts5Context*, int iPhrase, void *pUserData,
    int(*)(const Fts5ExtensionApi*,Fts5Context*,void*)
  );
  int (*xSetAuxdata)(Fts5Context*, void *pAux, void(*xDelete)(void*));
  void *(*xGetAuxdata)(Fts5Context*, int bClear);
  int (*xPhraseFirst)(Fts5Context*, int iPhrase, Fts5PhraseIter*, int*, int*);
  void (*xPhraseNext)(Fts5Context*, Fts5PhraseIter*, int *piCol, int *piOff);
  int (*xPhraseFirstColumn)(Fts5Context*, int iPhrase, Fts5PhraseIter*, int*);
  void (*xPhraseNextColumn)(Fts5Context*, Fts5PhraseIter*, int *piCol);
  int (*xQueryToken)(Fts5Context*,
      int iPhrase, int iToken,
      const char **ppToken, int *pnToken
  );
  int (*xInstToken)(Fts5Context*, int iIdx, int iToken, const char**, int*);
  int (*xColumnLocale)(Fts5Context*, int iCol, const char **pz, int *pn);
  int (*xTokenize_v2)(Fts5Context*,
    const char *pText, int nText,
    const char *pLocale, int nLocale,
    void *pCtx,
    int (*xToken)(void*, int, const char*, int, int, int)
  );
};
typedef struct Fts5Tokenizer Fts5Tokenizer;
typedef struct fts5_tokenizer_v2 fts5_tokenizer_v2;
struct fts5_tokenizer_v2 {
  int iVersion;
  int (*xCreate)(void*, const char **azArg, int nArg, Fts5Tokenizer **ppOut);
  void (*xDelete)(Fts5Tokenizer*);
  int (*xTokenize)(Fts5Tokenizer*,
      void *pCtx,
      int flags,
      const char *pText, int nText,
      const char *pLocale, int nLocale,
      int (*xToken)(
        void *pCtx,
        int tflags,
        const char *pToken,
        int nToken,
        int iStart,
        int iEnd
      )
  );
};
typedef struct fts5_tokenizer fts5_tokenizer;
struct fts5_tokenizer {
  int (*xCreate)(void*, const char **azArg, int nArg, Fts5Tokenizer **ppOut);
  void (*xDelete)(Fts5Tokenizer*);
  int (*xTokenize)(Fts5Tokenizer*,
      void *pCtx,
      int flags,
      const char *pText, int nText,
      int (*xToken)(
        void *pCtx,
        int tflags,
        const char *pToken,
        int nToken,
        int iStart,
        int iEnd
      )
  );
};
typedef struct fts5_api fts5_api;
struct fts5_api {
  int iVersion;
  int (*xCreateTokenizer)(
    fts5_api *pApi,
    const char *zName,
    void *pUserData,
    fts5_tokenizer *pTokenizer,
    void (*xDestroy)(void*)
  );
  int (*xFindTokenizer)(
    fts5_api *pApi,
    const char *zName,
    void **ppUserData,
    fts5_tokenizer *pTokenizer
  );
  int (*xCreateFunction)(
    fts5_api *pApi,
    const char *zName,
    void *pUserData,
    fts5_extension_function xFunction,
    void (*xDestroy)(void*)
  );
  int (*xCreateTokenizer_v2)(
    fts5_api *pApi,
    const char *zName,
    void *pUserData,
    fts5_tokenizer_v2 *pTokenizer,
    void (*xDestroy)(void*)
  );
  int (*xFindTokenizer_v2)(
    fts5_api *pApi,
    const char *zName,
    void **ppUserData,
    fts5_tokenizer_v2 **ppTokenizer
  );
};
struct flb_split_entry {
    char *value;
    int len;
    off_t last_pos;
    struct mk_list _head;
};
void flb_utils_error(int err);
void flb_utils_error_c(const char *msg);
void flb_utils_warn_c(const char *msg);
void flb_message(int type, const char *file, int line, const char *fmt, ...);
int flb_utils_set_daemon(struct flb_config *config);
void flb_utils_print_setup(struct flb_config *config);
struct mk_list *flb_utils_split(const char *line, int separator, int max_split);
struct mk_list *flb_utils_split_quoted(const char *line, int separator, int max_split);
void flb_utils_split_free_entry(struct flb_split_entry *entry);
void flb_utils_split_free(struct mk_list *list);
int flb_utils_timer_consume(int fd);
int64_t flb_utils_size_to_bytes(const char *size);
int64_t flb_utils_size_to_binary_bytes(const char *size);
int64_t flb_utils_hex2int(char *hex, int len);
int flb_utils_time_to_seconds(const char *time);
int flb_utils_pipe_byte_consume(int fd);
int flb_utils_bool(const char *val);
void flb_utils_bytes_to_human_readable_size(size_t bytes,
                                            char *out_buf, size_t size);
int flb_utils_time_split(const char *time, int *sec, long *nsec);
int flb_utils_write_str(char *buf, int *off, size_t size,
                        const char *str, size_t str_len, int escape_unicode);
int flb_utils_write_str_buf(const char *str, size_t str_len,
                            char **out, size_t *out_size, int escape_unicode);
int flb_utils_url_split(const char *in_url, char **out_protocol,
                        char **out_host, char **out_port, char **out_uri);
int flb_utils_proxy_url_split(const char *in_url, char **out_protocol,
                              char **out_username, char **out_password,
                              char **out_host, char **out_port);
int flb_utils_read_file(char *path, char **out_buf, size_t *out_size);
int flb_utils_read_file_offset(char *path, off_t offset_start, off_t offset_end, char **out_buf, size_t *out_size);
char *flb_utils_get_os_name();
int flb_utils_uuid_v4_gen(char *buf);
int flb_utils_get_machine_id(char **out_id, size_t *out_size);
void flb_utils_set_plugin_string_property(const char *name,
                                          flb_sds_t *field_storage,
                                          flb_sds_t new_value);
int flb_utils_mkdir(const char *dir, int perms);
int flb_utils_url_split_sds(const flb_sds_t in_url, flb_sds_t *out_protocol,
                            flb_sds_t *out_host, flb_sds_t *out_port, flb_sds_t *out_uri);

static unsigned char flb_motd_text[] = {
    0x5f, 0x5f, 0x5f, 0x5f, 0x5f, 0x5f, 0x20, 0x5f, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x5f, 0x20, 0x20, 0x20, 0x20, 0x5f, 0x5f, 0x5f, 0x5f, 0x5f,
    0x5f, 0x20, 0x5f, 0x20, 0x5f, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x20, 0x20, 0x5f, 0x5f, 0x5f, 0x5f, 0x5f, 0x20, 0x20, 0x5f,
    0x5f, 0x20, 0x20, 0x0a, 0x7c, 0x20, 0x20, 0x5f, 0x5f, 0x5f, 0x7c, 0x20,
    0x7c, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,
    0x20, 0x20, 0x20, 0x20, 0x20, 0x7c, 0x20, 0x7c, 0x20, 0x20, 0x20, 0x7c,
    0x20, 0x5f, 0x5f, 0x5f, 0x20, 0x28, 0x5f, 0x29, 0x20, 0x7c, 0x20, 0x20,
    0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x7c, 0x20, 0x20, 0x5f, 0x5f,
    0x5f, 0x7c, 0x2f, 0x20, 0x20, 0x7c, 0x20, 0x0a, 0x7c, 0x20, 0x7c, 0x5f,
    0x20, 0x20, 0x7c, 0x20, 0x7c, 0x5f, 0x20, 0x20, 0x20, 0x5f, 0x20, 0x20,
    0x5f, 0x5f, 0x5f, 0x20, 0x5f, 0x20, 0x5f, 0x5f, 0x20, 0x7c, 0x20, 0x7c,
    0x5f, 0x20, 0x20, 0x7c, 0x20, 0x7c, 0x5f, 0x2f, 0x20, 0x2f, 0x5f, 0x7c,
    0x20, 0x7c, 0x5f, 0x20, 0x20, 0x5f, 0x5f, 0x20, 0x20, 0x20, 0x5f, 0x7c,
    0x5f, 0x5f, 0x5f, 0x20, 0x5c, 0x20, 0x60, 0x7c, 0x20, 0x7c, 0x20, 0x0a,
    0x7c, 0x20, 0x20, 0x5f, 0x7c, 0x20, 0x7c, 0x20, 0x7c, 0x20, 0x7c, 0x20,
    0x7c, 0x20, 0x7c, 0x2f, 0x20, 0x5f, 0x20, 0x5c, 0x20, 0x27, 0x5f, 0x20,
    0x5c, 0x7c, 0x20, 0x5f, 0x5f, 0x7c, 0x20, 0x7c, 0x20, 0x5f, 0x5f, 0x5f,
    0x20, 0x5c, 0x20, 0x7c, 0x20, 0x5f, 0x5f, 0x7c, 0x20, 0x5c, 0x20, 0x5c,
    0x20, 0x2f, 0x20, 0x2f, 0x20, 0x20, 0x20, 0x5c, 0x20, 0x5c, 0x20, 0x7c,
    0x20, 0x7c, 0x20, 0x0a, 0x7c, 0x20, 0x7c, 0x20, 0x20, 0x20, 0x7c, 0x20,
    0x7c, 0x20, 0x7c, 0x5f, 0x7c, 0x20, 0x7c, 0x20, 0x20, 0x5f, 0x5f, 0x2f,
    0x20, 0x7c, 0x20, 0x7c, 0x20, 0x7c, 0x20, 0x7c, 0x5f, 0x20, 0x20, 0x7c,
    0x20, 0x7c, 0x5f, 0x2f, 0x20, 0x2f, 0x20, 0x7c, 0x20, 0x7c, 0x5f, 0x20,
    0x20, 0x20, 0x5c, 0x20, 0x56, 0x20, 0x2f, 0x2f, 0x5c, 0x5f, 0x5f, 0x2f,
    0x20, 0x2f, 0x5f, 0x7c, 0x20, 0x7c, 0x5f, 0x0a, 0x5c, 0x5f, 0x7c, 0x20,
    0x20, 0x20, 0x7c, 0x5f, 0x7c, 0x5c, 0x5f, 0x5f, 0x2c, 0x5f, 0x7c, 0x5c,
    0x5f, 0x5f, 0x5f, 0x7c, 0x5f, 0x7c, 0x20, 0x7c, 0x5f, 0x7c, 0x5c, 0x5f,
    0x5f, 0x7c, 0x20, 0x5c, 0x5f, 0x5f, 0x5f, 0x5f, 0x2f, 0x7c, 0x5f, 0x7c,
    0x5c, 0x5f, 0x5f, 0x7c, 0x20, 0x20, 0x20, 0x5c, 0x5f, 0x2f, 0x20, 0x5c,
    0x5f, 0x5f, 0x5f, 0x5f, 0x28, 0x5f, 0x29, 0x5f, 0x5f, 0x5f, 0x2f, 0x0a,
    0x0a, 0x0a, 0x00,
};
static inline void flb_version()
{
    printf("Fluent Bit v%s\n", "5.1.3");
    printf("Git commit: %s\n", "34155955e4962a56d94eb23c03a002880899a0d1");
    exit(0);
}
static inline void flb_version_banner()
{
    const char *copyright_color = "\033[1m" "\033[93m";
    const char *bold_color = "\033[1m";
    const char *reset_color = "\033[0m";
    if (!isatty(1)) {
        copyright_color = "";
        bold_color = "";
        reset_color = "";
    }
    fprintf(stderr,
            "%sFluent Bit v%s%s\n", bold_color, "5.1.3", reset_color);
    fprintf(stderr, "* %sCopyright (C) 2015-2026 The Fluent Bit Authors%s\n",
            copyright_color, reset_color);
    fprintf(stderr, "* Fluent Bit is a CNCF graduated project under the "
            "Fluent organization\n");
    fprintf(stderr, "* https://fluentbit.io\n\n");
    fprintf(stderr, "%s", flb_motd_text);
}
struct flb_input_instance;
struct flb_lib_ctx {
    int status;
    struct mk_event_loop *event_loop;
    struct mk_event *event_channel;
    struct flb_config *config;
};
struct flb_lib_out_cb {
    int (*cb) (void *record, size_t size, void *data);
    void *data;
};
typedef struct flb_lib_ctx flb_ctx_t;
struct flb_processor;
__attribute__ ((visibility ("default"))) void flb_init_env();
__attribute__ ((visibility ("default"))) flb_ctx_t *flb_create();
__attribute__ ((visibility ("default"))) void flb_destroy(flb_ctx_t *ctx);
__attribute__ ((visibility ("default"))) int flb_input(flb_ctx_t *ctx, const char *input, void *data);
__attribute__ ((visibility ("default"))) int flb_input_set_processor(flb_ctx_t *ctx, int ffd, struct flb_processor *proc);
__attribute__ ((visibility ("default"))) int flb_output(flb_ctx_t *ctx, const char *output, struct flb_lib_out_cb *cb);
__attribute__ ((visibility ("default"))) int flb_output_set_processor(flb_ctx_t *ctx, int ffd, struct flb_processor *proc);
__attribute__ ((visibility ("default"))) int flb_filter(flb_ctx_t *ctx, const char *filter, void *data);
__attribute__ ((visibility ("default"))) int flb_input_set(flb_ctx_t *ctx, int ffd, ...);
__attribute__ ((visibility ("default"))) int flb_input_set_test(flb_ctx_t *ctx, int ffd, char *test_name,
                                  void (*in_callback) (void *, int, int,
                                                       void *, size_t, void *),
                                  void *in_callback_data);
__attribute__ ((visibility ("default"))) int flb_input_property_check(flb_ctx_t *ctx, int ffd, char *key, char *val);
__attribute__ ((visibility ("default"))) int flb_output_property_check(flb_ctx_t *ctx, int ffd, char *key, char *val);
__attribute__ ((visibility ("default"))) int flb_filter_property_check(flb_ctx_t *ctx, int ffd, char *key, char *val);
__attribute__ ((visibility ("default"))) int flb_output_set(flb_ctx_t *ctx, int ffd, ...);
__attribute__ ((visibility ("default"))) int flb_output_set_test(flb_ctx_t *ctx, int ffd, char *test_name,
                                   void (*out_callback) (void *, int, int,
                                                         void *, size_t, void *),
                                   void *out_callback_data,
                                   void *test_ctx);
__attribute__ ((visibility ("default"))) int flb_output_set_test_with_ctx_callback(
                                   flb_ctx_t *ctx, int ffd, char *test_name,
                                   void (*out_callback) (void *, int, int,
                                                         void *, size_t, void *),
                                   void *out_callback_data,
                                   void *test_ctx,
                                   void *(*test_ctx_callback) (
                                           struct flb_config *,
                                           struct flb_input_instance *,
                                           void *, void *));
__attribute__ ((visibility ("default"))) int flb_output_set_callback(flb_ctx_t *ctx, int ffd, char *name,
                                       void (*cb)(char *, void *, void *));
__attribute__ ((visibility ("default"))) int flb_output_set_http_test(flb_ctx_t *ctx, int ffd, char *test_name,
                                        void (*out_response) (void *, int, int, void *, size_t, void *),
                                        void *out_callback_data);
__attribute__ ((visibility ("default"))) int flb_filter_set(flb_ctx_t *ctx, int ffd, ...);
__attribute__ ((visibility ("default"))) int flb_service_set(flb_ctx_t *ctx, ...);
__attribute__ ((visibility ("default"))) int flb_lib_free(void *data);
__attribute__ ((visibility ("default"))) double flb_time_now();
__attribute__ ((visibility ("default"))) int flb_start(flb_ctx_t *ctx);
__attribute__ ((visibility ("default"))) int flb_start_trace(flb_ctx_t *ctx);
__attribute__ ((visibility ("default"))) int flb_stop(flb_ctx_t *ctx);
__attribute__ ((visibility ("default"))) int flb_loop(flb_ctx_t *ctx);
__attribute__ ((visibility ("default"))) int flb_lib_push(flb_ctx_t *ctx, int ffd, const void *data, size_t len);
__attribute__ ((visibility ("default"))) int flb_lib_config_file(flb_ctx_t *ctx, const char *path);
__attribute__ ((visibility ("default"))) int flb_lib_response(flb_ctx_t *ctx, int ffd, int status, const void *data, size_t len);
__attribute__ ((visibility ("default"))) void flb_context_set(flb_ctx_t *ctx);
__attribute__ ((visibility ("default"))) flb_ctx_t *flb_context_get();
__attribute__ ((visibility ("default"))) void flb_cf_context_set(struct flb_cf *cf);
__attribute__ ((visibility ("default"))) struct flb_cf *flb_cf_context_get();
struct flb_sqldb {
    char *path;
    char *desc;
    int shared;
    int users;
    void *parent;
    sqlite3 *handler;
    flb_lock_t lock;
    struct mk_list _head;
};
struct flb_sqldb *flb_sqldb_open(const char *path, const char *desc,
                                 struct flb_config *config);
int flb_sqldb_close(struct flb_sqldb *db);
int flb_sqldb_query(struct flb_sqldb *db, const char *sql,
                    int (*callback) (void *, int, char **, char **),
                    void *data);
int64_t flb_sqldb_last_id(struct flb_sqldb *db);
int flb_sqldb_lock(struct flb_sqldb *db);
int flb_sqldb_unlock(struct flb_sqldb *db);
struct flb_log_event {
    msgpack_object *group_attributes;
    msgpack_object *group_metadata;
    msgpack_object *raw_timestamp;
    struct flb_time timestamp;
    msgpack_object *metadata;
    int format;
    msgpack_object *body;
    msgpack_object *root;
};
struct flb_log_event_decoder {
    msgpack_object *current_group_attributes;
    msgpack_unpacked unpacked_group_record;
    int dynamically_allocated;
    msgpack_object *current_group_metadata;
    msgpack_unpacked unpacked_empty_map;
    size_t previous_offset;
    msgpack_unpacked unpacked_event;
    size_t record_length;
    const char *record_base;
    int initialized;
    msgpack_object *empty_map;
    const char *buffer;
    size_t offset;
    size_t length;
    int last_result;
    int read_groups;
    unsigned int recursion_depth;
};
void flb_log_event_decoder_reset(struct flb_log_event_decoder *context,
                                 char *input_buffer,
                                 size_t input_length);
int flb_log_event_decoder_read_groups(struct flb_log_event_decoder *context,
                                      int read_groups);
int flb_log_event_decoder_init(struct flb_log_event_decoder *context,
                               char *input_buffer,
                               size_t input_length);
struct flb_log_event_decoder *flb_log_event_decoder_create(char *input_buffer,
                                                           size_t input_length);
void flb_log_event_decoder_destroy(struct flb_log_event_decoder *context);
int flb_log_event_decoder_decode_timestamp(msgpack_object *input,
                                           struct flb_time *output);
int flb_event_decoder_decode_object(struct flb_log_event_decoder *context,
                                    struct flb_log_event *event,
                                    msgpack_object *input);
int flb_log_event_decoder_get_last_result(struct flb_log_event_decoder *context);
int flb_log_event_decoder_next(struct flb_log_event_decoder *context,
                               struct flb_log_event *record);
const char *flb_log_event_decoder_get_error_description(int error_code);
int flb_log_event_decoder_get_record_type(struct flb_log_event *event, int32_t *type);
struct flb_log_event_encoder_dynamic_field_scope {
    size_t offset;
    struct flb_mp_map_header header;
    int type;
    struct cfl_list _head;
};
struct flb_log_event_encoder_dynamic_field {
    int initialized;
    size_t entry_count;
    size_t data_offset;
    msgpack_packer packer;
    msgpack_sbuffer buffer;
    struct cfl_list scopes;
    char *data;
    size_t size;
    int type;
};
struct flb_log_event_encoder_dynamic_field_scope *
    flb_log_event_encoder_dynamic_field_scope_current(
        struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_scope_enter(
    struct flb_log_event_encoder_dynamic_field *field,
    int type);
int flb_log_event_encoder_dynamic_field_scope_leave(
    struct flb_log_event_encoder_dynamic_field *field,
    struct flb_log_event_encoder_dynamic_field_scope *scope,
    int commit);
int flb_log_event_encoder_dynamic_field_begin_map(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_begin_array(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_commit_map(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_commit_array(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_rollback_map(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_rollback_array(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_append(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_flush(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_reset(
    struct flb_log_event_encoder_dynamic_field *field);
int flb_log_event_encoder_dynamic_field_init(
    struct flb_log_event_encoder_dynamic_field *field,
    int type);
void flb_log_event_encoder_dynamic_field_destroy(
    struct flb_log_event_encoder_dynamic_field *field);

typedef size_t flb_log_event_encoder_size_t;
typedef int64_t flb_log_event_encoder_int64_t;
typedef uint64_t flb_log_event_encoder_uint64_t;
struct flb_log_event_encoder {
    int dynamically_allocated;
    char *output_buffer;
    size_t output_length;
    int initialized;
    struct flb_time timestamp;
    struct flb_log_event_encoder_dynamic_field metadata;
    struct flb_log_event_encoder_dynamic_field body;
    struct flb_log_event_encoder_dynamic_field root;
    msgpack_packer packer;
    msgpack_sbuffer buffer;
    int format;
};
int flb_log_event_encoder_init(struct flb_log_event_encoder *context,
                               int format);
struct flb_log_event_encoder *flb_log_event_encoder_create(int format);
void flb_log_event_encoder_destroy(struct flb_log_event_encoder *context);
void flb_log_event_encoder_reset(struct flb_log_event_encoder *context);
void flb_log_event_encoder_claim_internal_buffer_ownership(
        struct flb_log_event_encoder *context);
int flb_log_event_encoder_emit_record(struct flb_log_event_encoder *context);
int flb_log_event_encoder_reset_record(struct flb_log_event_encoder *context);
int flb_log_event_encoder_begin_record(struct flb_log_event_encoder *context);
int flb_log_event_encoder_commit_record(struct flb_log_event_encoder *context);
int flb_log_event_encoder_rollback_record(struct flb_log_event_encoder *context);
int flb_log_event_encoder_emit_raw_record(struct flb_log_event_encoder *context,
                                          const char *buffer,
                                          size_t length);
int flb_log_event_encoder_set_timestamp(
        struct flb_log_event_encoder *context,
        struct flb_time *timestamp);
int flb_log_event_encoder_set_current_timestamp(
        struct flb_log_event_encoder *context);
int flb_log_event_encoder_append_metadata_values_unsafe(
        struct flb_log_event_encoder *context,
        ...);
int flb_log_event_encoder_append_body_values_unsafe(
        struct flb_log_event_encoder *context,
        ...);
int flb_log_event_encoder_append_root_values_unsafe(
        struct flb_log_event_encoder *context,
        ...);
const char *flb_log_event_encoder_get_error_description(int error_code);
int flb_log_event_encoder_group_init(struct flb_log_event_encoder *context);
int flb_log_event_encoder_group_header_end(struct flb_log_event_encoder *context);
int flb_log_event_encoder_group_end(struct flb_log_event_encoder *context);
int flb_log_event_encoder_append_values_unsafe(
        struct flb_log_event_encoder *context,
        int field,
        va_list arguments);
int flb_log_event_encoder_append_binary_length(
        struct flb_log_event_encoder *context,
        int target_field,
        size_t length);
int flb_log_event_encoder_append_binary_body(
        struct flb_log_event_encoder *context,
        int target_field,
        char *value,
        size_t length);
int flb_log_event_encoder_append_ext_length(
        struct flb_log_event_encoder *context,
        int target_field,
        int8_t type,
        size_t length);
int flb_log_event_encoder_append_ext_body(
        struct flb_log_event_encoder *context,
        int target_field,
        char *value,
        size_t length);
int flb_log_event_encoder_append_string_length(
        struct flb_log_event_encoder *context,
        int target_field,
        size_t length);
int flb_log_event_encoder_append_string_body(
        struct flb_log_event_encoder *context,
        int target_field,
        char *value,
        size_t length);
int flb_log_event_encoder_append_int8(
        struct flb_log_event_encoder *context,
        int target_field,
        int8_t value);
int flb_log_event_encoder_append_int16(
        struct flb_log_event_encoder *context,
        int target_field,
        int16_t value);
int flb_log_event_encoder_append_int32(
        struct flb_log_event_encoder *context,
        int target_field,
        int32_t value);
int flb_log_event_encoder_append_int64(
        struct flb_log_event_encoder *context,
        int target_field,
        int64_t value);
int flb_log_event_encoder_append_uint8(
        struct flb_log_event_encoder *context,
        int target_field,
        uint8_t value);
int flb_log_event_encoder_append_uint16(
        struct flb_log_event_encoder *context,
        int target_field,
        uint16_t value);
int flb_log_event_encoder_append_uint32(
        struct flb_log_event_encoder *context,
        int target_field,
        uint32_t value);
int flb_log_event_encoder_append_uint64(
        struct flb_log_event_encoder *context,
        int target_field,
        uint64_t value);
int flb_log_event_encoder_append_double(
    struct flb_log_event_encoder *context,
    int target_field,
    double value);
int flb_log_event_encoder_append_boolean(
    struct flb_log_event_encoder *context,
    int target_field,
    int value);
int flb_log_event_encoder_append_character(
        struct flb_log_event_encoder *context,
        int target_field,
        char value);
int flb_log_event_encoder_append_binary(
        struct flb_log_event_encoder *context,
        int target_field,
        char *value,
        size_t length);
int flb_log_event_encoder_append_string(
        struct flb_log_event_encoder *context,
        int target_field,
        char *value,
        size_t length);
int flb_log_event_encoder_append_ext(
        struct flb_log_event_encoder *context,
        int target_field,
        int8_t type,
        char *value,
        size_t length);
int flb_log_event_encoder_append_cstring(
        struct flb_log_event_encoder *context,
        int target_field,
        char *value);
int flb_log_event_encoder_append_null(
        struct flb_log_event_encoder *context,
        int target_field);
int flb_log_event_encoder_append_msgpack_object(
    struct flb_log_event_encoder *context,
    int target_field,
    msgpack_object *value);
int flb_log_event_encoder_append_raw_msgpack(
    struct flb_log_event_encoder *context,
    int target_field,
    char *value_buffer,
    size_t value_size);
int flb_log_event_encoder_append_timestamp(
    struct flb_log_event_encoder *context,
    int target_field,
    struct flb_time *value);
int flb_log_event_encoder_append_legacy_timestamp(
    struct flb_log_event_encoder *context,
    int target_field,
    struct flb_time *value);
int flb_log_event_encoder_append_forward_v1_timestamp(
    struct flb_log_event_encoder *context,
    int target_field,
    struct flb_time *timestamp);
int flb_log_event_encoder_append_fluent_bit_v1_timestamp(
    struct flb_log_event_encoder *context,
    int target_field,
    struct flb_time *value);
int flb_log_event_encoder_append_fluent_bit_v2_timestamp(
    struct flb_log_event_encoder *context,
    int target_field,
    struct flb_time *value);
static inline int flb_log_event_encoder_get_field(
        struct flb_log_event_encoder *context,
        int target_field,
        struct flb_log_event_encoder_dynamic_field **field)
{
    if (target_field == 2) {
        *field = &context->metadata;
    }
    else if (target_field == 3) {
        *field = &context->body;
    }
    else if (target_field == 1) {
        *field = &context->root;
    }
    else {
        return -4;
    }
    return 0;
}
static inline int flb_log_event_encoder_begin_map(
        struct flb_log_event_encoder *context,
        int target_field)
{
    struct flb_log_event_encoder_dynamic_field *field;
    int result;
    result = flb_log_event_encoder_get_field(context, target_field, &field);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_begin_map(field);
    }
    return result;
}
static inline int flb_log_event_encoder_commit_map(
        struct flb_log_event_encoder *context,
        int target_field)
{
    struct flb_log_event_encoder_dynamic_field *field;
    int result;
    result = flb_log_event_encoder_get_field(context, target_field, &field);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_commit_map(field);
    }
    return result;
}
static inline int flb_log_event_encoder_rollback_map(
        struct flb_log_event_encoder *context,
        int target_field)
{
    struct flb_log_event_encoder_dynamic_field *field;
    int result;
    result = flb_log_event_encoder_get_field(context, target_field, &field);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_rollback_map(field);
    }
    return result;
}
static inline int flb_log_event_encoder_begin_array(
        struct flb_log_event_encoder *context,
        int target_field)
{
    struct flb_log_event_encoder_dynamic_field *field;
    int result;
    result = flb_log_event_encoder_get_field(context, target_field, &field);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_begin_array(field);
    }
    return result;
}
static inline int flb_log_event_encoder_commit_array(
        struct flb_log_event_encoder *context,
        int target_field)
{
    struct flb_log_event_encoder_dynamic_field *field;
    int result;
    result = flb_log_event_encoder_get_field(context, target_field, &field);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_commit_array(field);
    }
    return result;
}
static inline int flb_log_event_encoder_rollback_array(
        struct flb_log_event_encoder *context,
        int target_field)
{
    struct flb_log_event_encoder_dynamic_field *field;
    int result;
    result = flb_log_event_encoder_get_field(context, target_field, &field);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_rollback_array(field);
    }
    return result;
}
static inline int flb_log_event_encoder_set_root_from_msgpack_object(
        struct flb_log_event_encoder *context,
        msgpack_object *value)
{
    int result;
    result = flb_log_event_encoder_dynamic_field_reset(&context->metadata);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_reset(&context->body);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_reset(&context->root);
    }
    if (result == 0) {
        result = flb_log_event_encoder_append_msgpack_object(context, 1, value);
        if (result == 0) {
            result = flb_log_event_encoder_dynamic_field_flush(&context->root);
        }
    }
    return result;
}
static inline int flb_log_event_encoder_set_root_from_raw_msgpack(
        struct flb_log_event_encoder *context,
        char *value_buffer,
        size_t value_size)
{
    int result;
    result = flb_log_event_encoder_dynamic_field_reset(&context->metadata);
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_reset(&context->body);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_reset(&context->root);
    }
    if (result == 0) {
        result = flb_log_event_encoder_append_raw_msgpack(context, 1, value_buffer, value_size);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_flush(&context->root);
    }
    return result;
}
static inline int flb_log_event_encoder_set_metadata_from_msgpack_object(
        struct flb_log_event_encoder *context,
        msgpack_object *value)
{
    int result;
    result = flb_log_event_encoder_dynamic_field_reset(&context->metadata);
    if (result == 0) {
        result = flb_log_event_encoder_append_msgpack_object(context, 2, value);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_flush(&context->metadata);
    }
    return result;
}
static inline int flb_log_event_encoder_set_metadata_from_raw_msgpack(
    struct flb_log_event_encoder *context,
    char *value_buffer,
    size_t value_size)
{
    int result;
    result = flb_log_event_encoder_dynamic_field_reset(&context->metadata);
    if (result == 0) {
        result = flb_log_event_encoder_append_raw_msgpack(context, 2, value_buffer, value_size);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_flush(&context->metadata);
    }
    return result;
}
static inline int flb_log_event_encoder_set_body_from_msgpack_object(
        struct flb_log_event_encoder *context,
        msgpack_object *value)
{
    int result;
    result = flb_log_event_encoder_dynamic_field_reset(&context->body);
    if (result == 0) {
        result = flb_log_event_encoder_append_msgpack_object(context, 3, value);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_flush(&context->body);
    }
    return result;
}
static inline int flb_log_event_encoder_set_body_from_raw_msgpack(
        struct flb_log_event_encoder *context,
        char *value_buffer,
        size_t value_size)
{
    int result;
    result = flb_log_event_encoder_dynamic_field_reset(&context->body);
    if (result == 0) {
        result = flb_log_event_encoder_append_raw_msgpack(context, 3, value_buffer, value_size);
    }
    if (result == 0) {
        result = flb_log_event_encoder_dynamic_field_flush(&context->body);
    }
    return result;
}
struct flb_ml;
struct flb_ml_parser;
struct flb_ml_stream;
struct flb_ml_rule {
    int start_state;
    struct mk_list from_states;
    flb_sds_t to_state;
    struct mk_list to_state_map;
    struct flb_regex *regex;
    struct flb_regex *regex_end;
    struct mk_list _head;
};
struct flb_ml_stream_group {
    flb_sds_t name;
    uint64_t last_flush;
    int counter_lines;
    flb_sds_t buf;
    int first_line;
    struct flb_ml_rule *rule_to_state;
    msgpack_sbuffer mp_md_sbuf;
    msgpack_packer mp_md_pck;
    struct mk_list metadata_objects;
    int metadata_objects_initialized;
    msgpack_sbuffer mp_sbuf;
    msgpack_packer mp_pck;
    struct flb_time mp_time;
    int truncated;
    struct flb_ml_stream *stream;
    struct mk_list _head;
};
struct flb_ml_stream {
    uint64_t id;
    flb_sds_t name;
    struct mk_list groups;
    int (*cb_flush) (struct flb_ml_parser *,
                     struct flb_ml_stream *,
                     void *cb_data,
                     char *buf_data,
                     size_t buf_size);
    void *cb_data;
    struct flb_ml_stream_group *last_stream_group;
    int forced_flush;
    struct flb_ml *ml;
    struct flb_ml_parser_ins *parser;
    struct mk_list _head;
};
struct flb_ml_parser {
    int type;
    int negate;
    int flush_ms;
    flb_sds_t name;
    flb_sds_t match_str;
    flb_sds_t key_content;
    flb_sds_t key_pattern;
    flb_sds_t key_group;
    struct flb_parser *parser;
    flb_sds_t parser_name;
    struct mk_list regex_rules;
    struct flb_config *config;
    struct mk_list _head;
};
struct flb_ml_parser_ins {
    struct flb_ml_parser *ml_parser;
    int (*cb_flush)(struct flb_ml_parser *,
                    struct flb_ml_stream *,
                    void *,
                    char *,
                    size_t);
    void *cb_data;
    flb_sds_t key_content;
    flb_sds_t key_pattern;
    flb_sds_t key_group;
    uint64_t last_stream_id;
    struct flb_ml_stream_group *last_stream_group;
    struct mk_list streams;
    struct mk_list _head;
};
struct flb_ml_group {
    int id;
    struct mk_list parsers;
    struct flb_ml_parser_ins *lru_parser;
    int flush_ms;
    int (*cb_flush)(struct flb_ml_parser *,
                    struct flb_ml_stream *,
                    void *,
                    char *,
                    size_t);
    void *cb_data;
    struct flb_ml *ml;
    struct mk_list _head;
};
struct flb_ml {
    flb_sds_t name;
    int flush_ms;
    uint64_t last_flush;
    struct mk_list groups;
    struct flb_log_event_encoder log_event_encoder;
    struct flb_log_event_decoder log_event_decoder;
    struct flb_config *config;
    size_t buffer_limit;
};
struct flb_ml *flb_ml_create(struct flb_config *ctx, char *name);
int flb_ml_destroy(struct flb_ml *ml);
int flb_ml_register_context(struct flb_ml_stream_group *group,
                            struct flb_time *tm, msgpack_object *map);
int flb_ml_append_text(struct flb_ml *ml,
                  uint64_t stream_id,
                  struct flb_time *tm,
                  void *buf,
                  size_t size);
int flb_ml_append_object(struct flb_ml *ml,
                         uint64_t stream_id,
                         struct flb_time *tm,
                         msgpack_object *metadata,
                         msgpack_object *obj);
int flb_ml_append_event(struct flb_ml *ml,
                        uint64_t stream_id,
                        struct flb_log_event *event);
int flb_ml_parsers_init(struct flb_config *ctx);
void flb_ml_flush_pending_now(struct flb_ml *ml);
void flb_ml_flush_parser_instance(struct flb_ml *ml,
                                  struct flb_ml_parser_ins *parser_i,
                                  uint64_t stream_id,
                                  int forced_flush);
int flb_ml_auto_flush_init(struct flb_ml *ml);
int flb_ml_flush_stream_group(struct flb_ml_parser *ml_parser,
                              struct flb_ml_stream *mst,
                              struct flb_ml_stream_group *group,
                              int forced_flush);
int flb_ml_stream_create(struct flb_ml *ml,
                         char *name,
                         int name_len,
                         int (*cb_flush) (struct flb_ml_parser *,
                                          struct flb_ml_stream *,
                                          void *cb_data,
                                          char *buf_data,
                                          size_t buf_size),
                         void *cb_data,
                         uint64_t *stream_id);
int flb_ml_stream_destroy(struct flb_ml_stream *mst);
void flb_ml_stream_id_destroy_all(struct flb_ml *ml, uint64_t stream_id);
struct flb_ml_stream *flb_ml_stream_get(struct flb_ml_parser_ins *parser,
                                        uint64_t stream_id);
struct flb_ml_stream_group *flb_ml_stream_group_get(struct flb_ml_parser_ins *ins,
                                                    struct flb_ml_stream *mst,
                                                    msgpack_object *group_name);
int flb_ml_init(struct flb_config *config);
int flb_ml_exit(struct flb_config *config);
int flb_ml_type_lookup(char *str);
int flb_ml_flush_stdout(struct flb_ml_parser *parser,
                        struct flb_ml_stream *mst,
                        void *data, char *buf_data, size_t buf_size);
int flb_ml_stream_group_add_metadata(struct flb_ml_stream_group *group,
                                     msgpack_object *metadata);
void flb_ml_stream_group_purge_metadata(struct flb_ml_stream_group *group);
struct flb_ml *flb_ml_mode_create(struct flb_config *config, char *mode,
                                  int flush_ms, char *key);
struct flb_ml *flb_ml_mode_python(struct flb_config *config,
                                  int flush_ms, char *key);
struct flb_ml *flb_ml_mode_java(struct flb_config *config,
                                int flush_ms, char *key);
struct flb_ml *flb_ml_mode_go(struct flb_config *config,
                              int flush_ms, char *key);
struct flb_tail_config {
    int fd_notify;
    int ch_manager[2];
    int ch_pending[2];
    int ch_reads;
    int ch_writes;
    int max_open_files;
    struct flb_tail_file_budget *file_budget;
    int files_deferred;
    size_t buf_chunk_size;
    size_t buf_max_size;
    int truncate_long_lines;
    size_t static_batch_size;
    size_t event_batch_size;
    int coll_fd_static;
    int coll_fd_scan;
    int coll_fd_watcher;
    int coll_fd_rotated;
    int coll_fd_pending;
    int coll_fd_inactive;
    int coll_fd_dmode_flush;
    int coll_fd_mult_flush;
    int coll_fd_fs1;
    int coll_fd_fs2;
    int coll_fd_progress_check;
    int dynamic_tag;
    struct flb_regex *tag_regex;
    int refresh_interval_sec;
    long refresh_interval_nsec;
    int read_newly_discovered_files_from_head;
    int read_from_head;
    int rotate_wait;
    int watcher_interval;
    int ignore_older;
    int ignore_active_older_files;
    time_t last_pending;
    struct mk_list *path_list;
    flb_sds_t path_key;
    flb_sds_t key;
    int skip_long_lines;
    int skip_empty_lines;
    int exit_on_eof;
    int file_cache_advise;
    int progress_check_interval;
    int progress_check_interval_nsec;
    int inotify_watcher;
    flb_sds_t offset_key;
    struct flb_sqldb *db;
    int db_sync;
    int db_locking;
    int compare_filename;
    flb_sds_t db_journal_mode;
    sqlite3_stmt *stmt_get_file;
    sqlite3_stmt *stmt_insert_file;
    sqlite3_stmt *stmt_delete_file;
    sqlite3_stmt *stmt_rotate_file;
    sqlite3_stmt *stmt_offset;
    struct flb_parser *parser;
    int preferred_input_encoding;
    int generic_input_encoding_type;
    const char *generic_input_encoding_name;
    int multiline;
    int multiline_flush;
    struct flb_parser *mult_parser_firstline;
    struct mk_list mult_parsers;
    int docker_mode;
    int docker_mode_flush;
    struct flb_parser *docker_mode_parser;
    struct flb_ml *ml_ctx;
    struct mk_list *multiline_parsers;
    uint64_t files_static_count;
    struct mk_list files_static;
    struct mk_list files_event;
    struct mk_list files_rotated;
    struct mk_list *exclude_list;
    struct flb_input_instance *ins;
    struct flb_log_event_encoder log_event_encoder;
    struct flb_log_event_decoder log_event_decoder;
    struct cmt_counter *cmt_files_opened;
    struct cmt_counter *cmt_files_closed;
    struct cmt_counter *cmt_files_rotated;
    struct cmt_counter *cmt_multiline_truncated;
    struct cmt_counter *cmt_long_line_truncated;
    struct cmt_counter *cmt_long_line_skipped;
    struct flb_hash_table *static_hash;
    struct flb_hash_table *event_hash;
    struct mk_list files_dormant;
    int dormant_scan_failed;
    struct flb_hash_table *dormant_files;
    struct flb_hash_table *dormant_inodes;
    struct flb_hash_table *ignored_file_sizes;
    struct flb_hash_table *aged_out_file_inodes;
    struct flb_config *config;
};
struct flb_tail_config *flb_tail_config_create(struct flb_input_instance *ins,
                                               struct flb_config *config);
int flb_tail_config_destroy(struct flb_tail_config *config);
struct flb_decompression_context;
int flb_gzip_compress(void *in_data, size_t in_len,
                      void **out_data, size_t *out_len);
int flb_gzip_uncompress(void *in_data, size_t in_len,
                        void **out_data, size_t *out_size);
int flb_gzip_uncompress_multi(void *in_data, size_t in_len,
                        void **out_data, size_t *out_size, size_t *in_remaining);
void *flb_gzip_decompression_context_create();
void flb_gzip_decompression_context_destroy(void *context);
int flb_gzip_decompressor_dispatch(struct flb_decompression_context *context,
                                   void *out_data, size_t *out_size);
int flb_is_http_session_gzip_compressed(struct mk_http_session *session);
struct flb_decompression_context {
    size_t input_buffer_length;
    size_t input_buffer_size;
    uint8_t *input_buffer;
    uint8_t *read_buffer;
    int algorithm;
    int state;
    void *inner_context;
};
uint8_t *flb_decompression_context_get_append_buffer(
            struct flb_decompression_context *context);
size_t flb_decompression_context_get_available_space(
            struct flb_decompression_context *context);
int flb_decompression_context_resize_buffer(
        struct flb_decompression_context *context, size_t new_size);
struct flb_decompression_context *flb_decompression_context_create(
                                    int algorithm,
                                    size_t input_buffer_size);
void flb_decompression_context_destroy(
        struct flb_decompression_context *context);
int flb_decompress(struct flb_decompression_context *context,
                   void *output_buffer,
                   size_t *output_length);
struct flb_tail_file {
    int watch_fd;
    int fd;
    int64_t size;
    int64_t offset;
    int64_t last_line;
    uint64_t dev_id;
    uint64_t inode;
    uint64_t link_inode;
    int is_link;
    char *name;
    char *real_name;
    char *orig_name;
    size_t name_len;
    size_t orig_name_len;
    time_t rotated;
    int64_t pending_bytes;
    size_t stream_offset;
    int tag_len;
    char *tag_buf;
    time_t mult_flush_timeout;
    int mult_firstline;
    int mult_firstline_append;
    int mult_skipping;
    int mult_keys;
    int mult_records;
    msgpack_sbuffer mult_sbuf;
    msgpack_packer mult_pck;
    struct flb_time mult_time;
    time_t dmode_flush_timeout;
    flb_sds_t dmode_buf;
    flb_sds_t dmode_lastline;
    _Bool dmode_complete;
    _Bool dmode_firstline;
    uint64_t ml_stream_id;
    size_t parsed;
    size_t buf_len;
    size_t buf_size;
    char *buf_data;
    struct flb_decompression_context *decompression_context;
    size_t last_processed_bytes;
    int skip_next;
    int skip_warn;
    void *fs_backend;
    uint64_t db_id;
    uint64_t db_offset_marker;
    size_t db_offset_marker_size;
    uint64_t hash_bits;
    flb_sds_t hash_key;
    struct flb_log_event_encoder *ml_log_event_encoder;
    struct flb_log_event_encoder *sl_log_event_encoder;
    int tail_mode;
    struct flb_tail_config *config;
    struct mk_list _head;
    struct mk_list _rotate_head;
};

int flb_tail_fs_stat_init(struct flb_input_instance *in,
                          struct flb_tail_config *ctx, struct flb_config *config);
int flb_tail_fs_stat_add(struct flb_tail_file *file);
int flb_tail_fs_stat_remove(struct flb_tail_file *file);
int flb_tail_fs_stat_exit(struct flb_tail_config *ctx);
void flb_tail_fs_stat_pause(struct flb_tail_config *ctx);
void flb_tail_fs_stat_resume(struct flb_tail_config *ctx);

int flb_tail_fs_inotify_init(struct flb_input_instance *in,
                          struct flb_tail_config *ctx, struct flb_config *config);
int flb_tail_fs_inotify_add(struct flb_tail_file *file);
int flb_tail_fs_inotify_remove(struct flb_tail_file *file);
int flb_tail_fs_inotify_exit(struct flb_tail_config *ctx);
void flb_tail_fs_inotify_pause(struct flb_tail_config *ctx);
void flb_tail_fs_inotify_resume(struct flb_tail_config *ctx);
static inline int flb_tail_fs_init(struct flb_input_instance *in,
                     struct flb_tail_config *ctx, struct flb_config *config)
{
    if (ctx->inotify_watcher) {
        return flb_tail_fs_inotify_init(in, ctx, config);
    }
    return flb_tail_fs_stat_init(in, ctx, config);
}
static inline void flb_tail_fs_pause(struct flb_tail_config *ctx)
{
    if (ctx->inotify_watcher) {
        return flb_tail_fs_inotify_pause(ctx);
    }
    return flb_tail_fs_stat_pause(ctx);
}
static inline void flb_tail_fs_resume(struct flb_tail_config *ctx)
{
    if (ctx->inotify_watcher) {
        return flb_tail_fs_inotify_resume(ctx);
    }
    return flb_tail_fs_stat_resume(ctx);
}
static inline int flb_tail_fs_add(struct flb_tail_config *ctx, struct flb_tail_file *file)
{
    if (ctx->inotify_watcher) {
        return flb_tail_fs_inotify_add(file);
    }
    return flb_tail_fs_stat_add(file);
}
static inline int flb_tail_fs_remove(struct flb_tail_config *ctx, struct flb_tail_file *file)
{
    if (ctx->inotify_watcher) {
        return flb_tail_fs_inotify_remove(file);
    }
    return flb_tail_fs_stat_remove(file);
}
static inline int flb_tail_fs_exit(struct flb_tail_config *ctx)
{
    if (ctx->inotify_watcher) {
        return flb_tail_fs_inotify_exit(ctx);
    }
    return flb_tail_fs_stat_exit(ctx);
}
static inline int64_t flb_tail_stat_mtime(struct stat *st)
{
    return (int64_t) st->st_mtim.tv_sec;
    return -1;
}
static inline int flb_tail_target_file_name_cmp(char *name,
                                                struct flb_tail_file *file)
{
    int ret;
    char *name_a = ((void*)0);
    char *name_b = ((void*)0);
    char *base_a = ((void*)0);
    char *base_b = ((void*)0);
    name_a = flb_strdup(name);
    if (!name_a) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/plugins/in_tail/tail_file.h", 75);
        ret = -1;
        goto out;
    }
    base_a = flb_strdup(__xpg_basename(name_a));
    if (!base_a) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/plugins/in_tail/tail_file.h", 82);
        ret = -1;
        goto out;
    }
    name_b = flb_strdup(file->real_name);
    if (!name_b) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/plugins/in_tail/tail_file.h", 100);
        ret = -1;
        goto out;
    }
    base_b = __xpg_basename(name_b);
    ret = strcmp(base_a, base_b);
 out:
    flb_free(name_a);
    flb_free(name_b);
    flb_free(base_a);
    return ret;
}
int flb_tail_file_name_dup(char *path, struct flb_tail_file *file);
int flb_tail_file_to_event(struct flb_tail_file *file);
int flb_tail_file_chunk(struct flb_tail_file *file);
int flb_tail_file_append(char *path, struct stat *st, int mode,
                         ssize_t offset,
                         struct flb_tail_config *ctx);
void flb_tail_file_remove(struct flb_tail_file *file);
void flb_tail_file_dormant_scan_begin(struct flb_tail_config *ctx);
void flb_tail_file_dormant_seen(struct flb_tail_config *ctx, const char *path, struct stat *st);
void flb_tail_file_dormant_scan_end(struct flb_tail_config *ctx);
void flb_tail_file_dormant_clear(struct flb_tail_config *ctx);
void flb_tail_file_reclaim(struct flb_tail_config *ctx);
int flb_tail_file_remove_all(struct flb_tail_config *ctx);
char *flb_tail_file_name(struct flb_tail_file *file);
int flb_tail_file_is_rotated(struct flb_tail_config *ctx,
                             struct flb_tail_file *file);
int flb_tail_file_rotated(struct flb_tail_file *file);
int flb_tail_file_purge(struct flb_input_instance *ins,
                        struct flb_config *config, void *context);
int flb_tail_pack_line_map(struct flb_time *time, char **data,
                           size_t *data_size, struct flb_tail_file *file,
                           size_t processed_bytes);
int flb_tail_file_pack_line(struct flb_time *time, char *data, size_t data_size,
                            struct flb_tail_file *file, size_t processed_bytes);
static inline off_t flb_tail_file_db_offset(struct flb_tail_file *file)
{
    if (file->decompression_context != ((void*)0)) {
        return file->offset;
    }
    if (file->buf_len > 0 && file->offset >= (off_t) file->buf_len) {
        return file->offset - file->buf_len;
    }
    return file->offset;
}
int flb_tail_file_update_offset_marker(struct flb_tail_file *file);
int flb_tail_file_offset_marker_matches(struct flb_tail_file *file);
int flb_tail_file_reset_on_truncate(struct flb_tail_file *file,
                                    int64_t size_delta,
                                    const char *caller);
struct flb_tail_config;
struct flb_tail_file_budget;
struct flb_tail_file_budget *flb_tail_file_budget_create(struct flb_tail_config *ctx);
void flb_tail_file_budget_destroy(struct flb_tail_file_budget *budget);
int flb_tail_file_budget_reserve(struct flb_tail_config *ctx);
int flb_tail_file_budget_pressure(struct flb_tail_config *ctx);
void flb_tail_file_budget_release(struct flb_tail_config *ctx);

struct flb_sqldb *flb_tail_db_open(const char *path,
                                   struct flb_input_instance *in,
                                   struct flb_tail_config *ctx,
                                   struct flb_config *config);
int flb_tail_db_close(struct flb_sqldb *db);
int flb_tail_db_file_set(struct flb_tail_file *file,
                         struct flb_tail_config *ctx);
int flb_tail_db_file_offset(struct flb_tail_file *file,
                            struct flb_tail_config *ctx);
int flb_tail_db_file_rotate(const char *new_name,
                            struct flb_tail_file *file,
                            struct flb_tail_config *ctx);
int flb_tail_db_file_delete_id(struct flb_tail_config *ctx, uint64_t id);
int flb_tail_db_file_delete(struct flb_tail_file *file,
                            struct flb_tail_config *ctx);
int flb_tail_db_stale_file_delete(struct flb_input_instance *ins,
                                  struct flb_config *config,
                                  struct flb_tail_config *ctx);
static inline int tail_signal_manager(struct flb_tail_config *ctx)
{
    int n;
    uint64_t val = 0xc001;
    if (ctx->ch_reads < ctx->ch_writes) {
        return 1;
    }
    if (ctx->ch_reads == ctx->ch_writes) {
        ctx->ch_reads = 0;
        ctx->ch_writes = 0;
    }
    n = write(ctx->ch_manager[1], (const char *) &val, sizeof(val));
    if (n == -1) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/plugins/in_tail/tail_signal.h", 48);
        return -1;
    }
    else {
        ctx->ch_writes++;
    }
    return n;
}
static inline int tail_signal_pending(struct flb_tail_config *ctx)
{
    int n;
    uint64_t val = 0xc002;
    n = write(ctx->ch_pending[1], (const char *) &val, sizeof(val));
    if (n == -1 && !((*__errno_location ()) == 11 || (*__errno_location ()) == 11)) {
        flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/plugins/in_tail/tail_signal.h", 71);
        return -1;
    }
    return n;
}
static inline int tail_consume_pending(struct flb_tail_config *ctx)
{
    int ret;
    uint64_t val;
    do {
        ret = read(ctx->ch_pending[0], (char *) &val, sizeof(val));
        if (ret <= 0 && !((*__errno_location ()) == 11 || (*__errno_location ()) == 11)) {
            flb_errno_print((*__errno_location ()), "/home/cosmo/Documents/GitHub/qcore-c/private/w47-tail/attempt-1/prep/fluent-bit-clang-source/plugins/in_tail/tail_signal.h", 90);
            return -1;
        }
    } while (!((*__errno_location ()) == 11 || (*__errno_location ()) == 11));
    return 0;
}
int flb_tail_dmode_create(struct flb_tail_config *ctx,
                          struct flb_input_instance *ins, struct flb_config *config);
int flb_tail_dmode_process_content(time_t now,
                                   char* line, size_t line_len,
                                   char **repl_line, size_t *repl_line_len,
                                   struct flb_tail_file *file,
                                   struct flb_tail_config *ctx);
void flb_tail_dmode_flush(struct flb_tail_file *file, struct flb_tail_config *ctx);
int flb_tail_dmode_pending_flush(struct flb_input_instance *ins,
                                 struct flb_config *config, void *context);
int flb_tail_dmode_pending_flush_all(struct flb_tail_config *ctx);
struct flb_tail_mult {
    struct flb_parser *parser;
    struct mk_list _head;
};
int flb_tail_mult_create(struct flb_tail_config *ctx,
                         struct flb_input_instance *ins,
                         struct flb_config *config);
int flb_tail_mult_destroy(struct flb_tail_config *ctx);
int flb_tail_mult_process_content(time_t now,
                                  char *buf, size_t len,
                                  struct flb_tail_file *file,
                                  struct flb_tail_config *ctx,
                                  size_t processed_bytes);
int flb_tail_mult_flush(struct flb_tail_file *file,
                        struct flb_tail_config *ctx);
int flb_tail_mult_pending_flush(struct flb_input_instance *ins,
                                struct flb_config *config, void *context);
int flb_tail_mult_pending_flush_all(struct flb_tail_config *ctx);
int flb_tail_scan(struct mk_list *path, struct flb_tail_config *ctx);
int flb_tail_scan_callback(struct flb_input_instance *ins,
                           struct flb_config *config, void *context);
void flb_tail_scan_register_ignored_file_size(struct flb_tail_config *ctx, const char *path, size_t path_length, size_t size);
void flb_tail_scan_unregister_ignored_file_size(struct flb_tail_config *ctx, const char *path, size_t path_length);
ssize_t flb_tail_scan_fetch_ignored_file_size(struct flb_tail_config *ctx, const char *path, size_t path_length);
void flb_tail_scan_register_aged_out_inode(struct flb_tail_config *ctx,
                                           const char *path,
                                           size_t path_length,
                                           uint64_t inode);
void flb_tail_scan_unregister_aged_out_inode(struct flb_tail_config *ctx,
                                             const char *path,
                                             size_t path_length);
int flb_tail_scan_fetch_aged_out_inode(struct flb_tail_config *ctx,
                                       const char *path,
                                       size_t path_length,
                                       uint64_t *inode);
typedef unsigned int flb_wchar;
typedef enum flb_enc
{
    FLB_STR_ASCII = 0,
    FLB_UTF8,
    FLB_WIN1256,
    FLB_WIN866,
    FLB_WIN874,
    FLB_WIN1251,
    FLB_WIN1252,
    FLB_WIN1250,
    FLB_WIN1253,
    FLB_WIN1254,
    FLB_WIN1255,
    FLB_SJIS,
    FLB_BIG5,
    FLB_GBK,
    FLB_UHC,
    FLB_GB18030,
    _FLB_LAST_ENCODING_
} flb_enc;
typedef int (*mb2wchar_with_len_converter) (const unsigned char *from,
                                            flb_wchar *to,
                                            int len);
typedef int (*wchar2mb_with_len_converter) (const flb_wchar *from,
                                            unsigned char *to,
                                            int len);
typedef int (*mblen_converter) (const unsigned char *mbstr);
typedef int (*mbdisplaylen_converter) (const unsigned char *mbstr);
typedef _Bool (*mbcharacter_incrementer) (unsigned char *mbstr, int len);
typedef int (*mbchar_verifier) (const unsigned char *mbstr, int len);
typedef int (*mbstr_verifier) (const unsigned char *mbstr, int len);
typedef struct
{
    mb2wchar_with_len_converter mb2wchar_with_len;
    wchar2mb_with_len_converter wchar2mb_with_len;
    mblen_converter mblen;
    mbdisplaylen_converter dsplen;
    mbchar_verifier mbverifychar;
    mbstr_verifier mbverifystr;
    int maxmblen;
} flb_wchar_tbl;
extern const flb_wchar_tbl flb_wchar_table[];
typedef struct {
    const uint16_t *chars16;
    const uint32_t *chars32;
    uint32_t b1root;
    uint8_t b1_lower;
    uint8_t b1_upper;
    uint32_t b2root;
    uint8_t b2_1_lower;
    uint8_t b2_1_upper;
    uint8_t b2_2_lower;
    uint8_t b2_2_upper;
    uint32_t b3root;
    uint8_t b3_1_lower;
    uint8_t b3_1_upper;
    uint8_t b3_2_lower;
    uint8_t b3_2_upper;
    uint8_t b3_3_lower;
    uint8_t b3_3_upper;
    uint32_t b4root;
    uint8_t b4_1_lower;
    uint8_t b4_1_upper;
    uint8_t b4_2_lower;
    uint8_t b4_2_upper;
    uint8_t b4_3_lower;
    uint8_t b4_3_upper;
    uint8_t b4_4_lower;
    uint8_t b4_4_upper;
} flb_mb_radix_tree;
typedef struct {
    uint32_t utf1;
    uint32_t utf2;
    uint32_t code;
} flb_utf_to_local_combined;
typedef struct {
    uint32_t code;
    uint32_t utf1;
    uint32_t utf2;
} flb_local_to_utf_combined;
typedef uint32_t (*utf_local_conversion_func) (uint32_t code);
extern void flb_encoding_set_invalid(int encoding, char *dst);
extern int flb_encoding_mblen(int encoding, const char *mbstr);
extern int flb_encoding_mblen_or_incomplete(int encoding, const char *mbstr,
                                            size_t remaining);
extern int flb_encoding_mblen_bounded(int encoding, const char *mbstr);
extern int flb_encoding_dsplen(int encoding, const char *mbstr);
extern int flb_encoding_verifymbchar(int encoding, const char *mbstr, int len);
extern int flb_encoding_verifymbstr(int encoding, const char *mbstr, int len);
extern int flb_encoding_max_length(int encoding);
extern _Bool flb_utf8_islegal(const unsigned char *source, int length);
extern int flb_utf_mblen(const unsigned char *s);
extern int flb_convert_to_local_internal(const unsigned char *utf, int len,
                                          unsigned char *iso,
                                          const flb_mb_radix_tree *map,
                                          const flb_utf_to_local_combined *cmap, int cmapsize,
                                          utf_local_conversion_func conv_func,
                                          int encoding, _Bool noError);
extern int flb_convert_to_utf_internal(const unsigned char *iso, int len,
                                        unsigned char *utf,
                                         const flb_mb_radix_tree *map,
                                        const flb_local_to_utf_combined *cmap, int cmapsize,
                                        utf_local_conversion_func conv_func,
                                        int encoding, _Bool noError);
extern _Bool flb_verifymbstr(const char *mbstr, int len, _Bool noError);
extern _Bool flb_verify_mbstr(int encoding, const char *mbstr, int len,
                            _Bool noError);
extern int flb_verify_mbstr_len(int encoding, const char *mbstr, int len,
                                _Bool noError);
extern void flb_report_invalid_encoding(int encoding, const char *mbstr, int len);
extern void flb_report_untranslatable_char(int src_encoding, int dest_encoding,
                                           const char *mbstr, int len);
struct flb_unicode_converter {
    const char *name;
    const char *aliases[4];
    const char *desc;
    int encoding;
    int max_width;
    int (*cb_to_utf8) (const unsigned char *src, unsigned char **dest,
                       size_t len, _Bool no_error, int encoding);
    int (*cb_from_utf8) (const unsigned char *src, unsigned char **dest,
                         size_t len, _Bool no_error, int encoding);
    struct mk_list _head;
};
struct flb_unicode_converter *flb_conv_select_converter(const char *encoding_name);
int flb_conv_supported_encoding(const char *encoding_name);
int flb_conv_select_encoding_type(const char *encoding_name);
int flb_conv_convert_to_utf8(const char *encoding_name,
                             const unsigned char *src, unsigned char **dest,
                             size_t len, _Bool no_error);
int flb_conv_convert_from_utf8(const char *encoding_name,
                               const unsigned char *src, unsigned char **dest,
                               size_t len, _Bool no_error);
extern struct flb_unicode_converter sjis_converter;
extern struct flb_unicode_converter gb18030_converter;
extern struct flb_unicode_converter uhc_converter;
extern struct flb_unicode_converter big5_converter;
extern struct flb_unicode_converter win866_converter;
extern struct flb_unicode_converter win874_converter;
extern struct flb_unicode_converter win1250_converter;
extern struct flb_unicode_converter win1251_converter;
extern struct flb_unicode_converter win1252_converter;
extern struct flb_unicode_converter win1253_converter;
extern struct flb_unicode_converter win1254_converter;
extern struct flb_unicode_converter win1255_converter;
extern struct flb_unicode_converter win1256_converter;
extern struct flb_unicode_converter gbk_converter;
enum flb_unicode_generic_enc_type {
    FLB_GENERIC_ASCII = FLB_STR_ASCII,
    FLB_GENERIC_WIN1256 = FLB_WIN1256,
    FLB_GENERIC_WIN866 = FLB_WIN866,
    FLB_GENERIC_WIN874 = FLB_WIN874,
    FLB_GENERIC_WIN1251 = FLB_WIN1251,
    FLB_GENERIC_WIN1252 = FLB_WIN1252,
    FLB_GENERIC_WIN1250 = FLB_WIN1250,
    FLB_GENERIC_WIN1253 = FLB_WIN1253,
    FLB_GENERIC_WIN1254 = FLB_WIN1254,
    FLB_GENERIC_WIN1255 = FLB_WIN1255,
    FLB_GENERIC_SJIS = FLB_SJIS,
    FLB_GENERIC_BIG5 = FLB_BIG5,
    FLB_GENERIC_GBK = FLB_GBK,
    FLB_GENERIC_UHC = FLB_UHC,
    FLB_GENERIC_GB18030 = FLB_GB18030,
    FLB_GENERIC_UNSPECIFIED = -1,
    _FLB_GENERIC_LAST_ENCODING_
};
typedef __mbstate_t mbstate_t;
typedef __uint_least16_t char16_t;
typedef __uint_least32_t char32_t;
extern size_t mbrtoc16 (char16_t *__restrict __pc16,
   const char *__restrict __s, size_t __n,
   mbstate_t *__restrict __p) __attribute__ ((__nothrow__ ));
extern size_t c16rtomb (char *__restrict __s, char16_t __c16,
   mbstate_t *__restrict __ps) __attribute__ ((__nothrow__ ));
extern size_t mbrtoc32 (char32_t *__restrict __pc32,
   const char *__restrict __s, size_t __n,
   mbstate_t *__restrict __p) __attribute__ ((__nothrow__ ));
extern size_t c32rtomb (char *__restrict __s, char32_t __c32,
   mbstate_t *__restrict __ps) __attribute__ ((__nothrow__ ));
typedef char16_t CHAR16_T;
enum flb_simdutf_encoding_type {
    FLB_SIMDUTF_ENCODING_TYPE_UTF8 = 1,
    FLB_SIMDUTF_ENCODING_TYPE_UTF16_LE = 2,
    FLB_SIMDUTF_ENCODING_TYPE_UTF16_BE = 4,
    FLB_SIMDUTF_ENCODING_TYPE_UTF32_LE = 8,
    FLB_SIMDUTF_ENCODING_TYPE_UTF32_BE = 16,
    FLB_SIMDUTF_ENCODING_TYPE_Latin1 = 32,
    FLB_SIMDUTF_ENCODING_TYPE_UNSPECIFIED = 0,
    FLB_SIMDUTF_ENCODING_TYPE_UNICODE_AUTO = 1 << 10,
};
enum flb_simdutf_error_code {
    FLB_SIMDUTF_ERROR_CODE_SUCCESS = 0,
    FLB_SIMDUTF_ERROR_CODE_HEADER_BITS,
    FLB_SIMDUTF_ERROR_CODE_TOO_SHORT,
    FLB_SIMDUTF_ERROR_CODE_TOO_LONG,
    FLB_SIMDUTF_ERROR_CODE_OVERLONG,
    FLB_SIMDUTF_ERROR_CODE_TOO_LARGE,
    FLB_SIMDUTF_ERROR_CODE_SURROGATE,
    FLB_SIMDUTF_ERROR_CODE_INVALID_BASE64_CHARACTER,
    FLB_SIMDUTF_ERROR_CODE_BASE64_INPUT_REMAINDER,
    FLB_SIMDUTF_ERROR_CODE_OUTPUT_BUFFER_TOO_SMALL,
    FLB_SIMDUTF_ERROR_CODE_OTHER,
};
int flb_simdutf_connector_utf8_length_from_utf16le(const CHAR16_T *buf, size_t len);
int flb_simdutf_connector_utf8_length_from_utf16be(const CHAR16_T *buf, size_t len);
int flb_simdutf_connector_utf8_length_from_utf16(const CHAR16_T *buf, size_t len);
int flb_simdutf_connector_validate_utf8(const char *buf, size_t len);
int flb_simdutf_connector_validate_utf16le(const CHAR16_T *buf, size_t len);
int flb_simdutf_connector_validate_utf16be(const CHAR16_T *buf, size_t len);
int flb_simdutf_connector_validate_utf16(const CHAR16_T *buf, size_t len);
int flb_simdutf_connector_convert_utf16le_to_utf8(const CHAR16_T *buf, size_t len,
                                                  char **utf8_output, size_t *out_size);
int flb_simdutf_connector_convert_utf16be_to_utf8(const CHAR16_T *buf, size_t len,
                                                  char **utf8_output, size_t *out_size);
int flb_simdutf_connector_convert_utf16_to_utf8(const CHAR16_T *buf, size_t len,
                                                char **utf8_output, size_t *out_size);
void flb_simdutf_connector_change_endianness_utf16(const CHAR16_T *input, size_t length, CHAR16_T *output);
int flb_simdutf_connector_detect_encodings(const char *input, size_t length);
int flb_simdutf_connector_convert_from_unicode(int preferred_encoding,
                                               const char *input, size_t length,
                                               char **output, size_t *out_size);
enum flb_unicode_encoding_type {
    FLB_UNICODE_ENCODING_UTF8 = FLB_SIMDUTF_ENCODING_TYPE_UTF8,
    FLB_UNICODE_ENCODING_UTF16_LE = FLB_SIMDUTF_ENCODING_TYPE_UTF16_LE,
    FLB_UNICODE_ENCODING_UTF16_BE = FLB_SIMDUTF_ENCODING_TYPE_UTF16_BE,
    FLB_UNICODE_ENCODING_UTF32_LE = FLB_SIMDUTF_ENCODING_TYPE_UTF32_LE,
    FLB_UNICODE_ENCODING_UTF32_BE = FLB_SIMDUTF_ENCODING_TYPE_UTF32_BE,
    FLB_UNICODE_ENCODING_Latin1 = FLB_SIMDUTF_ENCODING_TYPE_Latin1,
    FLB_UNICODE_ENCODING_UNSPECIFIED = FLB_SIMDUTF_ENCODING_TYPE_UNSPECIFIED,
    FLB_UNICODE_ENCODING_AUTO = FLB_SIMDUTF_ENCODING_TYPE_UNICODE_AUTO,
};
int flb_unicode_convert(int preferred_encoding, const char *input, size_t length,
                        char **output, size_t *out_size);
int flb_unicode_validate(const char *record, size_t size);
int flb_unicode_generic_supported_encoding(const char *encoding_name);
int flb_unicode_generic_select_encoding_type(const char *encoding_name);
int flb_unicode_generic_convert_to_utf8(const char *encoding_name,
                                        const unsigned char *input, unsigned char **output, size_t length);
int flb_unicode_generic_convert_from_utf8(const char *encoding_name,
                                          const unsigned char *input, unsigned char **output, size_t length);
struct tail_dormant_file {
    struct stat st;
    int64_t offset;
    uint64_t marker;
    size_t marker_size;
    flb_sds_t path;
    flb_sds_t inode_key;
    uint64_t db_id;
    int seen_path;
    int seen_inode;
    int retired;
    struct mk_list _head;
};
static int dormant_file_unchanged(struct tail_dormant_file *dormant, struct stat *st)
{
    struct stat *previous = &dormant->st;
    if (previous->st_dev != st->st_dev || previous->st_ino != st->st_ino ||
        previous->st_size != st->st_size || previous->st_mtim.tv_sec != st->st_mtim.tv_sec ||
        previous->st_ctim.tv_sec != st->st_ctim.tv_sec) {
        return 0;
    }
    return previous->st_mtim.tv_nsec == st->st_mtim.tv_nsec &&
           previous->st_ctim.tv_nsec == st->st_ctim.tv_nsec;
}
static inline int tail_file_open(struct flb_tail_config *ctx, const char *path,
                                 int flags)
{
    (void) ctx;
    return open(path, flags);
}
static inline int tail_file_stat(struct flb_tail_config *ctx, const char *path,
                                 struct stat *st)
{
    (void) ctx;
    return stat(path, st);
}
static inline int tail_file_lstat(struct flb_tail_config *ctx, const char *path,
                                  struct stat *st)
{
    (void) ctx;
    return lstat(path, st);
}
static inline void consume_bytes(char *buf, int bytes, int length)
{
    memmove(buf, buf + bytes, length - bytes);
}
static int compute_offset_marker(struct flb_tail_file *file,
                                 int64_t offset,
                                 uint64_t *marker,
                                 size_t *marker_size)
{
    off_t current;
    off_t start;
    ssize_t bytes;
    size_t window;
    char buf[32];
    *marker = 0;
    *marker_size = 0;
    if (offset <= 0) {
        return 0;
    }
    current = lseek(file->fd, 0, 1);
    if (current == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 182);
        return -1;
    }
    window = offset;
    if (window > sizeof(buf)) {
        window = sizeof(buf);
    }
    start = offset - window;
    if (lseek(file->fd, start, 0) == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 193);
        return -1;
    }
    bytes = read(file->fd, buf, window);
    if (bytes == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 199);
        lseek(file->fd, current, 0);
        return -1;
    }
    if (lseek(file->fd, current, 0) == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 205);
        return -1;
    }
    if (bytes != window) {
        return -1;
    }
    *marker = XXH_INLINE_XXH3_64bits(buf, window);
    *marker_size = window;
    return 0;
}
int flb_tail_file_update_offset_marker(struct flb_tail_file *file)
{
    int ret;
    uint64_t marker;
    size_t marker_size;
    off_t db_offset;
    db_offset = flb_tail_file_db_offset(file);
    ret = compute_offset_marker(file, db_offset, &marker, &marker_size);
    if (ret != 0) {
        file->db_offset_marker = 0;
        file->db_offset_marker_size = 0;
        return -1;
    }
    file->db_offset_marker = marker;
    file->db_offset_marker_size = marker_size;
    return 0;
}
int flb_tail_file_offset_marker_matches(struct flb_tail_file *file)
{
    int ret;
    uint64_t marker;
    size_t marker_size;
    off_t db_offset;
    db_offset = flb_tail_file_db_offset(file);
    if (db_offset <= 0 || file->db_offset_marker_size == 0) {
        return 1;
    }
    ret = compute_offset_marker(file, db_offset, &marker, &marker_size);
    if (ret != 0) {
        return 0;
    }
    if (marker_size != file->db_offset_marker_size) {
        return 0;
    }
    if (marker != file->db_offset_marker) {
        return 0;
    }
    return 1;
}
static void update_resumable_offset_state(struct flb_tail_file *file)
{
    if (file->config->db) {
        flb_tail_db_file_offset(file, file->config);
        return;
    }
    flb_tail_file_update_offset_marker(file);
}
int flb_tail_file_reset_on_truncate(struct flb_tail_file *file,
                                    int64_t size_delta,
                                    const char *caller)
{
    int64_t offset;
    struct flb_tail_config *ctx = file->config;
    offset = lseek(file->fd, 0, 0);
    if (offset == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 289);
        return -1;
    }
    if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "%s: inode=%""l" "u"" file truncated %s (diff: %""l" "d"" bytes)", caller, file->inode, file->name, size_delta) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "%s: inode=%""l" "u"" file truncated %s (diff: %""l" "d"" bytes)", ctx->ins->p->name, flb_input_name(ctx->ins), caller, file->inode, file->name, size_delta);
    file->offset = offset;
    file->stream_offset = offset;
    file->last_processed_bytes = 0;
    file->buf_len = 0;
    update_resumable_offset_state(file);
    return 0;
}
static uint64_t stat_get_st_dev(struct stat *st)
{
    return st->st_dev;
}
static int stat_to_hash_bits(struct flb_tail_config *ctx, struct stat *st,
                             uint64_t *out_hash)
{
    int len;
    uint64_t st_dev;
    char tmp[64];
    st_dev = stat_get_st_dev(st);
    len = snprintf(tmp, sizeof(tmp) - 1, "%" "l" "u" ":%" "l" "u",
                   st_dev, (uint64_t)st->st_ino);
    *out_hash = XXH_INLINE_XXH3_64bits(tmp, len);
    return 0;
}
static int stat_to_hash_key(struct flb_tail_config *ctx, struct stat *st,
                            flb_sds_t *key)
{
    uint64_t st_dev;
    flb_sds_t tmp;
    flb_sds_t buf;
    buf = flb_sds_create_size(64);
    if (!buf) {
        return -1;
    }
    st_dev = stat_get_st_dev(st);
    tmp = flb_sds_printf(&buf, "%" "l" "u" ":%" "l" "u",
                         st_dev, (uint64_t)st->st_ino);
    if (!tmp) {
        flb_sds_destroy(buf);
        return -1;
    }
    *key = buf;
    return 0;
}
static void dormant_detach_path(struct flb_tail_config *ctx, struct tail_dormant_file *file)
{
    if (flb_hash_table_get_ptr(ctx->dormant_files, file->path,
                              flb_sds_len(file->path)) == file) {
        flb_hash_table_del(ctx->dormant_files, file->path);
    }
    file->seen_path = 0;
}
static void dormant_retire(struct flb_tail_config *ctx, struct tail_dormant_file *file)
{
    dormant_detach_path(ctx, file);
    if (flb_hash_table_get_ptr(ctx->dormant_inodes, file->inode_key,
                              flb_sds_len(file->inode_key)) == file) {
        flb_hash_table_del(ctx->dormant_inodes, file->inode_key);
    }
    file->retired = 1;
}
static void dormant_destroy(struct flb_tail_config *ctx, struct tail_dormant_file *file,
                            int delete_db)
{
    struct mk_list *head;
    struct flb_tail_file *active;
    struct tail_dormant_file *owner;
    if (delete_db && ctx->db && file->db_id != 0) {
        owner = flb_hash_table_get_ptr(ctx->dormant_inodes, file->inode_key,
                                      flb_sds_len(file->inode_key));
        if (owner && owner != file && owner->db_id == file->db_id) {
            file->db_id = 0;
        }
        for( head = (&ctx->files_static)->next; head != (&ctx->files_static); head = head->next ) {
            active = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
            if (active->db_id == file->db_id) {
                file->db_id = 0;
                break;
            }
        }
        for( head = (&ctx->files_event)->next; head != (&ctx->files_event); head = head->next ) {
            active = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
            if (active->db_id == file->db_id) {
                file->db_id = 0;
                break;
            }
        }
        if (file->db_id != 0 && flb_tail_db_file_delete_id(ctx, file->db_id) != 0) {
            return;
        }
    }
    mk_list_del(&file->_head);
    flb_sds_destroy(file->path);
    flb_sds_destroy(file->inode_key);
    flb_free(file);
}
void flb_tail_file_dormant_scan_begin(struct flb_tail_config *ctx)
{
    struct mk_list *head;
    struct tail_dormant_file *file;
    ctx->dormant_scan_failed = 0;
    for( head = (&ctx->files_dormant)->next; head != (&ctx->files_dormant); head = head->next ) {
        file = ({ const typeof( ((struct tail_dormant_file *)0)->_head ) *__mptr = (head); (struct tail_dormant_file *)( (char *)__mptr - __builtin_offsetof(struct tail_dormant_file, _head) );});
        file->seen_path = 0;
        file->seen_inode = 0;
    }
}
void flb_tail_file_dormant_seen(struct flb_tail_config *ctx, const char *path, struct stat *st)
{
    struct tail_dormant_file *file;
    flb_sds_t key;
    if (mk_list_is_empty(&ctx->files_dormant) == 0) {
        return;
    }
    file = flb_hash_table_get_ptr(ctx->dormant_files, path, strlen(path));
    if (file) {
        file->seen_path = 1;
    }
    if (stat_to_hash_key(ctx, st, &key) != 0) {
        ctx->dormant_scan_failed = 1;
        return;
    }
    file = flb_hash_table_get_ptr(ctx->dormant_inodes, key, flb_sds_len(key));
    if (file) {
        file->seen_inode = 1;
    }
    flb_sds_destroy(key);
}
void flb_tail_file_dormant_scan_end(struct flb_tail_config *ctx)
{
    struct mk_list *head;
    struct mk_list *tmp;
    struct tail_dormant_file *file;
    for (head = (&ctx->files_dormant)->next, tmp = head->next; head != (&ctx->files_dormant); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct tail_dormant_file *)0)->_head ) *__mptr = (head); (struct tail_dormant_file *)( (char *)__mptr - __builtin_offsetof(struct tail_dormant_file, _head) );});
        if (file->retired || (!ctx->dormant_scan_failed &&
                             !file->seen_path && !file->seen_inode)) {
            if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "discarding dormant file: %s", file->path) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "discarding dormant file: %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->path);
            dormant_retire(ctx, file);
            dormant_destroy(ctx, file, 1);
        }
    }
    if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "dormant files retained=%i", mk_list_size(&ctx->files_dormant)) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "dormant files retained=%i", ctx->ins->p->name, flb_input_name(ctx->ins), mk_list_size(&ctx->files_dormant));
}
void flb_tail_file_dormant_clear(struct flb_tail_config *ctx)
{
    struct mk_list *head;
    struct mk_list *tmp;
    struct tail_dormant_file *file;
    for (head = (&ctx->files_dormant)->next, tmp = head->next; head != (&ctx->files_dormant); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct tail_dormant_file *)0)->_head ) *__mptr = (head); (struct tail_dormant_file *)( (char *)__mptr - __builtin_offsetof(struct tail_dormant_file, _head) );});
        dormant_retire(ctx, file);
        dormant_destroy(ctx, file, 0);
    }
}
static int record_append_custom_keys(struct flb_tail_file *file,
                                     char *in_data, size_t in_size,
                                     char **out_data, size_t *out_size)
{
    int i;
    int ret;
    int records = 0;
    msgpack_object k;
    msgpack_object v;
    struct flb_log_event event;
    struct flb_tail_config *ctx;
    struct flb_log_event_encoder encoder;
    struct flb_log_event_decoder decoder;
    ctx = (struct flb_tail_config *) file->config;
    ret = flb_log_event_decoder_init(&decoder, in_data, in_size);
    if (ret != 0) {
        return -1;
    }
    ret = flb_log_event_encoder_init(&encoder, 4);
    if (ret != 0) {
        flb_log_event_decoder_destroy(&decoder);
        return -2;
    }
    while (flb_log_event_decoder_next(&decoder, &event) ==
            0) {
        ret = flb_log_event_encoder_begin_record(&encoder);
        if (ret == 0) {
            ret = flb_log_event_encoder_set_timestamp(&encoder, &event.timestamp);
        }
        for (i = 0; i < event.body->via.map.size; i++) {
            k = event.body->via.map.ptr[i].key;
            v = event.body->via.map.ptr[i].val;
            if (ret == 0) {
                ret = flb_log_event_encoder_append_msgpack_object(&encoder, 3, &k);
            }
            if (ret == 0) {
                ret = flb_log_event_encoder_append_msgpack_object(&encoder, 3, &v);
            }
        }
        if (ctx->path_key != ((void*)0)) {
            if (ret == 0) {
                ret = flb_log_event_encoder_append_cstring(&encoder, 3, file->config->path_key);
            }
            if (ret == 0) {
                ret = flb_log_event_encoder_append_cstring(&encoder, 3, file->orig_name);
            }
        }
        if (ctx->offset_key != ((void*)0)) {
            if (ret == 0) {
                ret = flb_log_event_encoder_append_cstring(&encoder, 3, file->config->offset_key);
            }
            if (ret == 0) {
                ret = flb_log_event_encoder_append_uint64(&encoder, 3, file->stream_offset + file->last_processed_bytes);
            }
        }
        if (ret == 0) {
            ret = flb_log_event_encoder_commit_record(&encoder);
        }
        else {
            if (flb_log_check_level(file->config->ins->log_level, 1)) if (flb_log_suppress_check(file->config->ins->log_suppress_interval, "error packing event : %d", ret) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error packing event : %d", file->config->ins->p->name, flb_input_name(file->config->ins), ret);
            flb_log_event_encoder_rollback_record(&encoder);
        }
        records++;
    }
    *out_data = encoder.output_buffer;
    *out_size = encoder.output_length;
    flb_log_event_encoder_claim_internal_buffer_ownership(&encoder);
    flb_log_event_decoder_destroy(&decoder);
    flb_log_event_encoder_destroy(&encoder);
    return records;
}
static int flb_tail_repack_map(struct flb_log_event_encoder *encoder,
                               char *data,
                               size_t data_size)
{
    msgpack_unpacked source_map;
    size_t offset;
    int result;
    size_t index;
    msgpack_object value;
    msgpack_object key;
    result = 0;
    if (data_size > 0) {
        msgpack_unpacked_init(&source_map);
        offset = 0;
        result = msgpack_unpack_next(&source_map,
                                     data,
                                     data_size,
                                     &offset);
        if (result == MSGPACK_UNPACK_SUCCESS) {
            result = 0;
        }
        else {
            result = -11;
        }
        for (index = 0;
             index < source_map.data.via.map.size &&
             result == 0;
             index++) {
            key = source_map.data.via.map.ptr[index].key;
            value = source_map.data.via.map.ptr[index].val;
            result = flb_log_event_encoder_append_msgpack_object(encoder, 3, &key);
            if (result == 0) {
                result = flb_log_event_encoder_append_msgpack_object(encoder, 3, &value);
            }
        }
        msgpack_unpacked_destroy(&source_map);
    }
    return result;
}
int flb_tail_pack_line_map(struct flb_time *time, char **data,
                           size_t *data_size, struct flb_tail_file *file,
                           size_t processed_bytes)
{
    int result;
    result = flb_log_event_encoder_begin_record(file->sl_log_event_encoder);
    if (result == 0) {
        result = flb_log_event_encoder_set_timestamp(
                    file->sl_log_event_encoder, time);
    }
    if (result == 0) {
        result = flb_tail_repack_map(file->sl_log_event_encoder,
                                     *data,
                                     *data_size);
    }
    if (file->config->path_key != ((void*)0)) {
        if (result == 0) {
            result = flb_log_event_encoder_append_body_values_unsafe( file->sl_log_event_encoder, (int) 1, (flb_log_event_encoder_size_t) strlen(file->config->path_key), (int) 2, (char *) file->config->path_key, (flb_log_event_encoder_size_t) strlen(file->config->path_key), (int) 1, (flb_log_event_encoder_size_t) file->orig_name_len, (int) 2, (char *) file->orig_name, (flb_log_event_encoder_size_t) file->orig_name_len, (int) 0);;
        }
    }
    if (file->config->offset_key != ((void*)0)) {
        if (result == 0) {
            result = flb_log_event_encoder_append_body_values_unsafe( file->sl_log_event_encoder, (int) 1, (flb_log_event_encoder_size_t) strlen(file->config->offset_key), (int) 2, (char *) file->config->offset_key, (flb_log_event_encoder_size_t) strlen(file->config->offset_key), (int) 0);;
        }
        if (result == 0) {
            result = flb_log_event_encoder_append_uint64(file->sl_log_event_encoder, 3, (uint64_t)(file->stream_offset + processed_bytes));
        }
    }
    if (result == 0) {
        result = flb_log_event_encoder_commit_record(file->sl_log_event_encoder);
    }
    else {
        flb_log_event_encoder_rollback_record(file->sl_log_event_encoder);
    }
    if (result != 0) {
        if (flb_log_check_level(file->config->ins->log_level, 1)) if (flb_log_suppress_check(file->config->ins->log_suppress_interval, "error packing event") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error packing event", file->config->ins->p->name, flb_input_name(file->config->ins));
        return -1;
    }
    return 0;
}
int flb_tail_file_pack_line(struct flb_time *time, char *data, size_t data_size,
                            struct flb_tail_file *file, size_t processed_bytes)
{
    int result;
    result = flb_log_event_encoder_begin_record(file->sl_log_event_encoder);
    if (result == 0) {
        result = flb_log_event_encoder_set_timestamp(
                    file->sl_log_event_encoder, time);
    }
    if (file->config->path_key != ((void*)0)) {
        if (result == 0) {
            result = flb_log_event_encoder_append_body_values_unsafe( file->sl_log_event_encoder, (int) 1, (flb_log_event_encoder_size_t) strlen(file->config->path_key), (int) 2, (char *) file->config->path_key, (flb_log_event_encoder_size_t) strlen(file->config->path_key), (int) 1, (flb_log_event_encoder_size_t) file->orig_name_len, (int) 2, (char *) file->orig_name, (flb_log_event_encoder_size_t) file->orig_name_len, (int) 0);;
        }
    }
    if (file->config->offset_key != ((void*)0)) {
        if (result == 0) {
            result = flb_log_event_encoder_append_body_values_unsafe( file->sl_log_event_encoder, (int) 1, (flb_log_event_encoder_size_t) strlen(file->config->offset_key), (int) 2, (char *) file->config->offset_key, (flb_log_event_encoder_size_t) strlen(file->config->offset_key), (int) 0);;
        }
        if (result == 0) {
            result = flb_log_event_encoder_append_uint64(file->sl_log_event_encoder, 3, (uint64_t)(file->stream_offset + processed_bytes));
        }
    }
    if (result == 0) {
        result = flb_log_event_encoder_append_body_values_unsafe( file->sl_log_event_encoder, (int) 1, (flb_log_event_encoder_size_t) strlen(file->config->key), (int) 2, (char *) file->config->key, (flb_log_event_encoder_size_t) strlen(file->config->key), (int) 1, (flb_log_event_encoder_size_t) data_size, (int) 2, (char *) data, (flb_log_event_encoder_size_t) data_size, (int) 0);;
    }
    if (result == 0) {
        result = flb_log_event_encoder_commit_record(file->sl_log_event_encoder);
    }
    if (result != 0) {
        if (flb_log_check_level(file->config->ins->log_level, 1)) if (flb_log_suppress_check(file->config->ins->log_suppress_interval, "error packing event : %d", result) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error packing event : %d", file->config->ins->p->name, flb_input_name(file->config->ins), result);
        return -1;
    }
    return 0;
}
static int ml_stream_buffer_append(struct flb_tail_file *file, char *buf_data, size_t buf_size)
{
    int result;
    result = flb_log_event_encoder_emit_raw_record(
                 file->ml_log_event_encoder,
                 buf_data, buf_size);
    if (result != 0) {
        if (flb_log_check_level(file->config->ins->log_level, 1)) if (flb_log_suppress_check(file->config->ins->log_suppress_interval, "log event raw append error : %d", result) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "log event raw append error : %d", file->config->ins->p->name, flb_input_name(file->config->ins), result);
        return -1;
    }
    return 0;
}
static int ml_stream_buffer_flush(struct flb_tail_config *ctx, struct flb_tail_file *file)
{
    if (file->ml_log_event_encoder->output_length > 0) {
        flb_input_log_append(ctx->ins,
                             file->tag_buf,
                             file->tag_len,
                             file->ml_log_event_encoder->output_buffer,
                             file->ml_log_event_encoder->output_length);
        flb_log_event_encoder_reset(file->ml_log_event_encoder);
    }
    return 0;
}
static inline __attribute__((always_inline)) const char *flb_skip_leading_zeros_simd(const char *data, const char *end, size_t *processed_bytes)
{
    const size_t vlen = sizeof(flb_vector8);
    while ((size_t)(end - data) >= vlen) {
        size_t i;
        flb_vector8 v;
        flb_vector8_load(&v, (const uint8_t *)data);
        if (!flb_vector8_has(v, (uint8_t)'\0')) {
            return data;
        }
        for (i = 0; i < vlen; i++) {
            if (data[i] != '\0') {
                *processed_bytes += i;
                return data + i;
            }
        }
        data += vlen;
        *processed_bytes += vlen;
    }
    while (data < end && *data == '\0') {
        data++;
        (*processed_bytes)++;
    }
    return data;
}
static size_t utf8_safe_truncate_pos(const char *s, size_t len, size_t max)
{
    size_t cut = 0;
    cut = (len <= max) ? len : max;
    if (cut == len) {
        return cut;
    }
    while (cut > 0 && ((unsigned char)s[cut] & 0xC0) == 0x80) {
        cut--;
    }
    return cut;
}
static int process_content(struct flb_tail_file *file, size_t *bytes)
{
    size_t len;
    int lines = 0;
    int ret;
    int data_len;
    size_t processed_bytes = 0;
    char *data;
    char *end;
    char *p;
    void *out_buf;
    size_t out_size;
    int crlf;
    char *line;
    size_t line_len;
    char *repl_line;
    size_t repl_line_len;
    size_t original_len = 0;
    time_t now = time(((void*)0));
    struct flb_time out_time = {0};
    struct flb_tail_config *ctx;
    char *decoded = ((void*)0);
    size_t decoded_len;
    size_t cut = 0;
    size_t eff_max = 0;
    size_t dec_len = 0;
    size_t window = 0;
    int truncation_happened = 0;
    size_t bytes_override = 0;
    void *nl = ((void*)0);
    uint64_t ts;
    char *name;
    ctx = (struct flb_tail_config *) file->config;
    data = file->buf_data;
    end = data + file->buf_len;
    file->last_processed_bytes = 0;
    if (ctx->preferred_input_encoding != FLB_UNICODE_ENCODING_UNSPECIFIED) {
        original_len = end - data;
        decoded = ((void*)0);
        ret = flb_unicode_convert(ctx->preferred_input_encoding,
                                  data, end - data, &decoded, &decoded_len);
        if (ret == 0) {
            data = decoded;
            end = data + decoded_len;
        }
        else if (ret == -1) {
            data_len = (int) (end - data);
            if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "nothing to convert encoding '%.*s'", data_len, data) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "nothing to convert encoding '%.*s'", ctx->ins->p->name, flb_input_name(ctx->ins), data_len, data);
            if (file->buf_len >= 3 &&
                data[0] == '\xEF' &&
                data[1] == '\xBB' &&
                data[2] == '\xBF') {
                data += 3;
                processed_bytes += 3;
            }
        }
        else {
            data_len = (int) (end - data);
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "encoding failed '%.*s'", data_len, data) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "encoding failed '%.*s'", ctx->ins->p->name, flb_input_name(ctx->ins), data_len, data);
        }
    }
    if (ctx->generic_input_encoding_type != FLB_GENERIC_UNSPECIFIED) {
        original_len = end - data;
        decoded = ((void*)0);
        ret = flb_unicode_generic_convert_to_utf8(ctx->generic_input_encoding_name,
                                                  (unsigned char*)data, (unsigned char**)&decoded,
                                                  end - data);
        if (ret > 0) {
            data = decoded;
            end = data + (size_t) ret;
        }
        else {
            data_len = (int) (end - data);
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "encoding failed '%.*s' with status %d", data_len, data, ret) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "encoding failed '%.*s' with status %d", ctx->ins->p->name, flb_input_name(ctx->ins), data_len, data, ret);
        }
    }
    if (data < end) {
        data = (char *)flb_skip_leading_zeros_simd(data, end, &processed_bytes);
    }
    if (ctx->truncate_long_lines == 1 &&
        file->buf_size >= ctx->buf_max_size) {
        if (ctx->buf_max_size > 0) {
            eff_max = ctx->buf_max_size - 1;
        }
        else {
            eff_max = 0;
        }
        dec_len = (size_t)(end - data);
        window = ctx->buf_max_size + 1;
        if (window > dec_len) {
            window = dec_len;
        }
        nl = memchr(data, '\n', window);
        if (nl == ((void*)0) && eff_max > 0 && dec_len >= eff_max) {
            if (file->skip_next == 1) {
                bytes_override = (original_len > 0) ? original_len : file->buf_len;
                goto truncation_end;
            }
            cut = utf8_safe_truncate_pos(data, dec_len, eff_max);
            if (cut > 0) {
                if (ctx->multiline == 1) {
                    flb_tail_mult_flush(file, ctx);
                }
                flb_tail_file_pack_line(((void*)0), data, cut, file, processed_bytes);
                file->skip_next = 1;
                cmt_counter_inc(ctx->cmt_long_line_truncated,
                                cfl_time_now(), 1,
                                (char*[]){ (char*) flb_input_name(ctx->ins) });
                flb_metrics_sum(104, 1, ctx->ins->metrics);
                if (original_len > 0) {
                    bytes_override = original_len;
                }
                else {
                    bytes_override = file->buf_len;
                }
                truncation_happened = 1;
                lines++;
                goto truncation_end;
            }
        }
    }
    while (data < end && (p = memchr(data, '\n', end - data))) {
        len = (p - data);
        crlf = 0;
        if (file->skip_next == 1) {
            data += len + 1;
            processed_bytes += len + 1;
            file->skip_next = 0;
            continue;
        }
        if (ctx->skip_empty_lines) {
            if (len == 0) {
                data++;
                processed_bytes++;
                continue;
            }
            else if (len == 1 && data[0] == '\r') {
                data += 2;
                processed_bytes += 2;
                continue;
            }
        }
        if (len >= 2) {
            crlf = (data[len-1] == '\r');
            if (len == 1 && crlf) {
                data += 2;
                processed_bytes += 2;
                continue;
            }
        }
        flb_time_zero(&out_time);
        line = data;
        line_len = len - crlf;
        repl_line = ((void*)0);
        if (ctx->ml_ctx) {
            ret = flb_ml_append_text(ctx->ml_ctx,
                                     file->ml_stream_id,
                                     &out_time,
                                     line,
                                     line_len);
            if (ret == 2) {
                if (flb_log_check_level(ctx->ins->log_level, 2)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "multiline message truncated due to buffer limit") == 0) flb_log_print(2, ((void*)0), 0, "[input:%s:%s] " "multiline message truncated due to buffer limit", ctx->ins->p->name, flb_input_name(ctx->ins));
                name = (char *) flb_input_name(ctx->ins);
                ts = cfl_time_now();
                cmt_counter_inc(ctx->cmt_multiline_truncated, ts, 1, (char *[]) {name});
                flb_metrics_sum(103, 1, ctx->ins->metrics);
            }
            goto go_next;
        }
        else if (ctx->docker_mode) {
            ret = flb_tail_dmode_process_content(now, line, line_len,
                                                 &repl_line, &repl_line_len,
                                                 file, ctx);
            if (ret >= 0) {
                if (repl_line == line) {
                    repl_line = ((void*)0);
                }
                else {
                    line = repl_line;
                    line_len = repl_line_len;
                }
                goto go_next;
            }
            else {
                flb_tail_dmode_flush(file, ctx);
            }
        }
        if (ctx->parser) {
            ret = flb_parser_do(ctx->parser, line, line_len,
                                &out_buf, &out_size, &out_time);
            if (ret >= 0) {
                if (flb_time_to_nanosec(&out_time) == 0L) {
                    flb_time_get(&out_time);
                }
                if (ctx->multiline == 1) {
                    flb_tail_mult_flush(file, ctx);
                }
                flb_tail_pack_line_map(&out_time,
                                       (char**) &out_buf, &out_size, file,
                                       processed_bytes);
                flb_free(out_buf);
            }
            else {
                flb_tail_file_pack_line(((void*)0), data, len, file, processed_bytes);
            }
        }
        else if (ctx->multiline == 1) {
            ret = flb_tail_mult_process_content(now,
                                                line, line_len,
                                                file, ctx, processed_bytes);
            if (ret == -1) {
                flb_tail_mult_flush(file, ctx);
                flb_tail_file_pack_line(((void*)0),
                                        line, line_len, file, processed_bytes);
            }
            else if (ret == 1) {
                goto go_next;
            }
            else if (ret == 0) {
            }
        }
        else {
            flb_tail_file_pack_line(((void*)0),
                                    line, line_len, file, processed_bytes);
        }
    go_next:
        flb_free(repl_line);
        repl_line = ((void*)0);
        data += len + 1;
        processed_bytes += len + 1;
        lines++;
        file->parsed = 0;
        file->last_processed_bytes = processed_bytes;
    }
truncation_end:
    if (decoded) {
        flb_free(decoded);
        decoded = ((void*)0);
    }
    file->parsed = file->buf_len;
    if (lines > 0) {
        if (truncation_happened) {
            *bytes = bytes_override;
        }
        else if (original_len > 0) {
            *bytes = original_len;
        }
        else {
            *bytes = processed_bytes;
        }
        if (file->sl_log_event_encoder->output_length > 0) {
            flb_input_log_append_records(ctx->ins,
                                         lines,
                                         file->tag_buf,
                                         file->tag_len,
                                         file->sl_log_event_encoder->output_buffer,
                                         file->sl_log_event_encoder->output_length);
            flb_log_event_encoder_reset(file->sl_log_event_encoder);
        }
    }
    else if (file->skip_next) {
        *bytes = file->buf_len;
    }
    else {
        if (original_len > 0) {
            *bytes = original_len;
        } else {
            *bytes = processed_bytes;
        }
    }
    if (ctx->ml_ctx) {
        ml_stream_buffer_flush(ctx, file);
    }
    return lines;
}
static inline void drop_bytes(char *buf, size_t len, int pos, int bytes)
{
    memmove(buf + pos,
            buf + pos + bytes,
            len - pos - bytes);
}
static void cb_results(const char *name, const char *value,
                       size_t vlen, void *data)
{
    struct flb_hash_table *ht = data;
    if (vlen == 0) {
        return;
    }
    flb_hash_table_add(ht, name, strlen(name), (void *) value, vlen);
}
static int tag_compose(char *tag, struct flb_regex *tag_regex, char *fname,
                       char *out_buf, size_t *out_size,
                       struct flb_tail_config *ctx)
{
    int i;
    size_t len;
    char *p;
    size_t buf_s = 0;
    ssize_t n;
    struct flb_regex_search result;
    struct flb_hash_table *ht;
    char *beg;
    char *end;
    int ret;
    const char *tmp;
    size_t tmp_s;
    if (tag_regex) {
        n = flb_regex_do(tag_regex, fname, strlen(fname), &result);
        if (n <= 0) {
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "invalid tag_regex pattern for file %s", fname) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "invalid tag_regex pattern for file %s", ctx->ins->p->name, flb_input_name(ctx->ins), fname);
            return -1;
        }
        else {
            ht = flb_hash_table_create(0,
                                       50, 50);
            flb_regex_parse(tag_regex, &result, cb_results, ht);
            for (p = tag, beg = p; (beg = strchr(p, '<')); p = end + 2) {
                if (beg != p) {
                    len = (beg - p);
                    memcpy(out_buf + buf_s, p, len);
                    buf_s += len;
                }
                beg++;
                end = strchr(beg, '>');
                if (end && !memchr(beg, '<', end - beg)) {
                    end--;
                    len = end - beg + 1;
                    ret = flb_hash_table_get(ht, beg, len, (void *) &tmp, &tmp_s);
                    if (ret != -1) {
                        memcpy(out_buf + buf_s, tmp, tmp_s);
                        buf_s += tmp_s;
                    }
                    else {
                        memcpy(out_buf + buf_s, "_", 1);
                        buf_s++;
                    }
                }
                else {
                    if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "missing closing angle bracket in tag %s " "at position %lu", tag, beg - tag) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "missing closing angle bracket in tag %s " "at position %lu", ctx->ins->p->name, flb_input_name(ctx->ins), tag, beg - tag);
                    flb_hash_table_destroy(ht);
                    return -1;
                }
            }
            flb_hash_table_destroy(ht);
            if (*p) {
                len = strlen(p);
                memcpy(out_buf + buf_s, p, len);
                buf_s += len;
            }
        }
    }
    else {
        p = strchr(tag, '*');
        if (!p) {
            return -1;
        }
        len = (p - tag);
        if (len > 0) {
            memcpy(out_buf, tag, len);
            buf_s += len;
        }
        len = strlen(fname);
        memcpy(out_buf + buf_s, fname, len);
        buf_s += len;
        p++;
        if (*p) {
            len = strlen(tag);
            memcpy(out_buf + buf_s, p, (len - (p - tag)));
            buf_s += (len - (p - tag));
        }
        for (i = 0; i < buf_s; i++) {
            if (out_buf[i] == '/' || out_buf[i] == '\\' || out_buf[i] == ':') {
                if (i > 0) {
                    out_buf[i] = '.';
                }
                else {
                    drop_bytes(out_buf, buf_s, i, 1);
                    buf_s--;
                    i--;
                }
            }
            if (i > 0 && out_buf[i] == '.') {
                if (out_buf[i - 1] == '.') {
                    drop_bytes(out_buf, buf_s, i, 1);
                    buf_s--;
                    i--;
                }
            }
            else if (out_buf[i] == '*') {
                    drop_bytes(out_buf, buf_s, i, 1);
                    buf_s--;
                    i--;
            }
        }
        if (out_buf[buf_s - 1] == '.') {
            drop_bytes(out_buf, buf_s, buf_s - 1, 1);
            buf_s--;
        }
    }
    out_buf[buf_s] = '\0';
    *out_size = buf_s;
    return 0;
}
static inline int flb_tail_file_exists(struct stat *st,
                                       struct flb_tail_config *ctx)
{
    int ret;
    uint64_t hash;
    ret = stat_to_hash_bits(ctx, st, &hash);
    if (ret != 0) {
        return -1;
    }
    if (flb_hash_table_exists(ctx->static_hash, hash)) {
        return 1;
    }
    if (flb_hash_table_exists(ctx->event_hash, hash)) {
        return 1;
    }
    return 0;
}
static int set_file_position(struct flb_tail_config *ctx,
                             struct flb_tail_file *file,
                             int explicit_offset)
{
    int64_t ret;
    if (ctx->db) {
        ret = flb_tail_db_file_set(file, ctx);
        if (ret == 0) {
            if (file->offset > file->size ||
                flb_tail_file_offset_marker_matches(file) != 1) {
                file->offset = 0;
                file->stream_offset = 0;
                flb_tail_db_file_offset(file, ctx);
            }
            if (file->offset > 0) {
                ret = lseek(file->fd, file->offset, 0);
                if (ret == -1) {
                    flb_errno_print((*__errno_location ()), "<stdin>", 1436);
                    return -1;
                }
                if (file->decompression_context == ((void*)0)) {
                    file->stream_offset = ret;
                }
            }
            else if (ctx->read_from_head == 0) {
                ret = lseek(file->fd, 0, 2);
                if (ret == -1) {
                    flb_errno_print((*__errno_location ()), "<stdin>", 1446);
                    return -1;
                }
                file->offset = ret;
                if (file->decompression_context == ((void*)0)) {
                    file->stream_offset = ret;
                }
                flb_tail_db_file_offset(file, ctx);
            }
            return 0;
        }
    }
    if (explicit_offset) {
        ret = lseek(file->fd, file->offset, 0);
        if (ret == -1) {
            flb_errno_print((*__errno_location ()), "<stdin>", 1467);
            return -1;
        }
        if (file->decompression_context == ((void*)0)) {
            file->stream_offset = ret;
        }
        return 0;
    }
    if (ctx->read_from_head == 1) {
        return 0;
    }
    ret = lseek(file->fd, 0, 2);
    if (ret == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1486);
        return -1;
    }
    file->offset = ret;
    if (file->decompression_context == ((void*)0)) {
        file->stream_offset = ret;
    }
    return 0;
}
static int ml_flush_callback(struct flb_ml_parser *parser,
                             struct flb_ml_stream *mst,
                             void *data, char *buf_data, size_t buf_size)
{
    int result;
    size_t mult_size = 0;
    char *mult_buf = ((void*)0);
    struct flb_tail_file *file = data;
    struct flb_tail_config *ctx = file->config;
    if (ctx->path_key == ((void*)0) && ctx->offset_key == ((void*)0)) {
        ml_stream_buffer_append(file, buf_data, buf_size);
    }
    else {
        result = record_append_custom_keys(file,
                                           buf_data,
                                           buf_size,
                                           &mult_buf,
                                           &mult_size);
        if (result < 0) {
            ml_stream_buffer_append(file, buf_data, buf_size);
        }
        else {
            ml_stream_buffer_append(file, mult_buf, mult_size);
            flb_free(mult_buf);
        }
    }
    if (mst->forced_flush) {
        ml_stream_buffer_flush(ctx, file);
    }
    return 0;
}
int flb_tail_file_append(char *path, struct stat *st, int mode,
                         ssize_t offset,
                         struct flb_tail_config *ctx)
{
    int fd = -1;
    int ret;
    uint64_t stream_id;
    uint64_t ts;
    uint64_t hash_bits;
    flb_sds_t hash_key;
    size_t len;
    char *tag;
    char *name;
    size_t tag_len;
    struct flb_tail_file *file;
    struct stat lst;
    struct stat opened_st;
    struct tail_dormant_file *dormant;
    struct tail_dormant_file *opened_dormant;
    struct tail_dormant_file *path_dormant;
    flb_sds_t dormant_key;
    flb_sds_t inode_str;
    if (!((((st->st_mode)) & 0170000) == (0100000))) {
        return -1;
    }
    if (flb_tail_file_exists(st, ctx) == 1) {
        return -1;
    }
    if (stat_to_hash_key(ctx, st, &dormant_key) != 0) {
        return -1;
    }
    dormant = flb_hash_table_get_ptr(ctx->dormant_inodes, dormant_key, flb_sds_len(dormant_key));
    flb_sds_destroy(dormant_key);
    path_dormant = flb_hash_table_get_ptr(ctx->dormant_files, path, strlen(path));
    if (dormant == ((void*)0)) {
        dormant = path_dormant;
    }
    if (dormant != ((void*)0) && dormant_file_unchanged(dormant, st)) {
        return -1;
    }
    if (ctx->file_cache_advise) {
        if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "file will be read in POSIX_FADV_DONTNEED mode %s", path) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "file will be read in POSIX_FADV_DONTNEED mode %s", ctx->ins->p->name, flb_input_name(ctx->ins), path);
    }
    if (!flb_tail_file_budget_reserve(ctx)) {
        return -1;
    }
    fd = tail_file_open(ctx, path, 00);
    if (fd == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1605);
        flb_tail_file_budget_release(ctx);
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "cannot open %s", path) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "cannot open %s", ctx->ins->p->name, flb_input_name(ctx->ins), path);
        return -1;
    }
    if (fstat(fd, &opened_st) == -1 || !((((opened_st.st_mode)) & 0170000) == (0100000))) {
        goto err_close_fd;
    }
    st = &opened_st;
    if (flb_tail_file_exists(st, ctx) == 1) {
        goto err_close_fd;
    }
    file = flb_calloc(1, sizeof(struct flb_tail_file));
    if (!file) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1622);
        goto err_close_fd;
    }
    file->config = ctx;
    file->fd = fd;
    file->watch_fd = -1;
    file->tail_mode = mode;
    ret = tail_file_lstat(ctx, path, &lst);
    if (ret == 0) {
        if (((((lst.st_mode)) & 0170000) == (0120000))) {
            file->is_link = 1;
            file->link_inode = lst.st_ino;
        }
    }
    ret = stat_to_hash_bits(ctx, st, &hash_bits);
    if (ret != 0) {
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "error procesisng hash bits for file %s", path) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error procesisng hash bits for file %s", ctx->ins->p->name, flb_input_name(ctx->ins), path);
        goto err_free_file;
    }
    file->hash_bits = hash_bits;
    ret = stat_to_hash_key(ctx, st, &hash_key);
    if (ret != 0) {
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "error procesisng hash key for file %s", path) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error procesisng hash key for file %s", ctx->ins->p->name, flb_input_name(ctx->ins), path);
        goto err_free_file;
    }
    file->hash_key = hash_key;
    opened_dormant = flb_hash_table_get_ptr(ctx->dormant_inodes, hash_key, flb_sds_len(hash_key));
    if (opened_dormant != ((void*)0)) {
        dormant = opened_dormant;
    }
    file->inode = st->st_ino;
    file->offset = 0;
    file->size = st->st_size;
    file->buf_len = 0;
    file->parsed = 0;
    file->tag_len = 0;
    file->tag_buf = ((void*)0);
    file->rotated = 0;
    file->pending_bytes = 0;
    file->stream_offset = 0;
    file->mult_firstline = 0;
    file->mult_keys = 0;
    file->mult_flush_timeout = 0;
    file->mult_skipping = 0;
    if (offset != -1) {
        file->offset = offset;
    }
    if (strlen(path) >= 3 &&
        strcasecmp(&path[strlen(path) - 3], ".gz") == 0) {
        file->decompression_context =
            flb_decompression_context_create(1,
                                             ctx->buf_max_size);
        if (file->decompression_context == ((void*)0)) {
            goto err_free_hash_key;
        }
    }
    ret = flb_tail_file_name_dup(path, file);
    if (!file->name) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1704);
        goto err_free_decomp;
    }
    file->orig_name = flb_strdup(file->name);
    if (!file->orig_name) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1712);
        goto err_free_name;
    }
    file->orig_name_len = file->name_len;
    file->mult_records = 0;
    msgpack_sbuffer_init(&file->mult_sbuf);
    msgpack_packer_init(&file->mult_pck, &file->mult_sbuf,
                        msgpack_sbuffer_write);
    file->dmode_flush_timeout = 0;
    file->dmode_complete = 1;
    file->dmode_buf = flb_sds_create_size(ctx->docker_mode == 1 ? 65536 : 0);
    if (!file->dmode_buf) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1728);
        goto err_destroy_sbuf;
    }
    file->dmode_lastline = flb_sds_create_size(ctx->docker_mode == 1 ? 20000 : 0);
    if (!file->dmode_lastline) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1733);
        goto err_free_dmode_buf;
    }
    file->dmode_firstline = 0;
    file->db_id = 0;
    file->db_offset_marker = 0;
    file->db_offset_marker_size = 0;
    file->skip_next = 0;
    file->skip_warn = 0;
    if (ctx->ml_ctx) {
        inode_str = flb_sds_create_size(64);
        flb_sds_printf(&inode_str, "%""l" "u", file->inode);
        ret = flb_ml_stream_create(ctx->ml_ctx,
                                   inode_str, flb_sds_len(inode_str),
                                   ml_flush_callback, file,
                                   &stream_id);
        if (ret != 0) {
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "could not create multiline stream for file: %s", inode_str) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "could not create multiline stream for file: %s", ctx->ins->p->name, flb_input_name(ctx->ins), inode_str);
            flb_sds_destroy(inode_str);
            goto err_free_dmode_lastline;
        }
        file->ml_stream_id = stream_id;
        flb_sds_destroy(inode_str);
    }
    file->buf_size = ctx->buf_chunk_size;
    file->buf_data = flb_malloc(file->buf_size);
    if (!file->buf_data) {
        flb_errno_print((*__errno_location ()), "<stdin>", 1788);
        goto err_destroy_ml_stream;
    }
    if (ctx->dynamic_tag == 1) {
        len = ctx->ins->tag_len + strlen(path) + 1;
        tag = flb_malloc(len);
        if (!tag) {
            flb_errno_print((*__errno_location ()), "<stdin>", 1797);
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "failed to allocate tag buffer") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "failed to allocate tag buffer", ctx->ins->p->name, flb_input_name(ctx->ins));
            goto err_free_buf_data;
        }
        ret = tag_compose(ctx->ins->tag, ctx->tag_regex, path, tag, &tag_len, ctx);
        if (ret == 0) {
            file->tag_len = tag_len;
            file->tag_buf = flb_strdup(tag);
        }
        flb_free(tag);
        if (ret != 0) {
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "failed to compose tag for file: %s", path) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "failed to compose tag for file: %s", ctx->ins->p->name, flb_input_name(ctx->ins), path);
            goto err_free_buf_data;
        }
    }
    else {
        file->tag_len = strlen(ctx->ins->tag);
        file->tag_buf = flb_strdup(ctx->ins->tag);
    }
    if (!file->tag_buf) {
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "failed to set tag for file: %s", path) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "failed to set tag for file: %s", ctx->ins->p->name, flb_input_name(ctx->ins), path);
        flb_errno_print((*__errno_location ()), "<stdin>", 1822);
        goto err_free_buf_data;
    }
    if (mode == 0) {
        mk_list_add(&file->_head, &ctx->files_static);
        ctx->files_static_count++;
        ret = flb_hash_table_add(ctx->static_hash,
                                 file->hash_key, flb_sds_len(file->hash_key),
                                 file, sizeof(file));
        if (ret < 0) {
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "could not register file in static hash") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "could not register file in static hash", ctx->ins->p->name, flb_input_name(ctx->ins));
            goto err_unlist;
        }
        tail_signal_manager(file->config);
    }
    else if (mode == 1) {
        mk_list_add(&file->_head, &ctx->files_event);
        ret = flb_hash_table_add(ctx->event_hash,
                                 file->hash_key, flb_sds_len(file->hash_key),
                                 file, sizeof(file));
        if (ret < 0) {
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "could not register file in event hash") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "could not register file in event hash", ctx->ins->p->name, flb_input_name(ctx->ins));
            goto err_unlist;
        }
        ret = flb_tail_fs_add(ctx, file);
        if (ret == -1) {
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "could not register file into fs_events") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "could not register file into fs_events", ctx->ins->p->name, flb_input_name(ctx->ins));
            goto err_unlist;
        }
    }
    ret = set_file_position(ctx, file, (offset != -1));
    if (ret == -1) {
        goto err_fs_remove;
    }
    if (dormant != ((void*)0)) {
        file->offset = 0;
        if (dormant->st.st_dev == st->st_dev && dormant->st.st_ino == st->st_ino &&
            dormant->offset <= file->size) {
            file->offset = dormant->offset;
            file->db_offset_marker = dormant->marker;
            file->db_offset_marker_size = dormant->marker_size;
            if (flb_tail_file_offset_marker_matches(file) != 1) {
                file->offset = 0;
            }
        }
        if (lseek(fd, file->offset, 0) == -1) {
            goto err_fs_remove;
        }
        file->stream_offset = file->offset;
        update_resumable_offset_state(file);
    }
    file->pending_bytes = file->size - file->offset;
    file->sl_log_event_encoder = flb_log_event_encoder_create(
                                    4);
    if (file->sl_log_event_encoder == ((void*)0)) {
        goto err_set_pos;
    }
    file->ml_log_event_encoder = flb_log_event_encoder_create(
                                    4);
    if (file->ml_log_event_encoder == ((void*)0)) {
        goto err_destroy_sl;
    }
    if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" with offset=%""l" "d"" appended as %s", file->inode, file->offset, path) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" with offset=%""l" "d"" appended as %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->offset, path);
    name = (char *) flb_input_name(ctx->ins);
    ts = cfl_time_now();
    cmt_counter_inc(ctx->cmt_files_opened, ts, 1, (char *[]) {name});
    flb_metrics_sum(100, 1, ctx->ins->metrics);
    if (path_dormant != ((void*)0)) {
        dormant_detach_path(ctx, path_dormant);
        if (path_dormant->db_id == file->db_id) {
            path_dormant->db_id = 0;
        }
    }
    if (dormant != ((void*)0) && dormant->st.st_dev == st->st_dev &&
        dormant->st.st_ino == st->st_ino) {
        if (dormant->db_id == file->db_id) {
            dormant->db_id = 0;
        }
        dormant_retire(ctx, dormant);
        dormant_destroy(ctx, dormant, 1);
    }
    return 0;
err_destroy_sl:
    flb_log_event_encoder_destroy(file->sl_log_event_encoder);
err_set_pos:
err_fs_remove:
    if (mode == 1) {
        flb_tail_fs_remove(ctx, file);
    }
err_unlist:
    if (mode == 0) {
        mk_list_del(&file->_head);
        if (ctx->files_static_count > 0) {
            ctx->files_static_count--;
        }
        flb_hash_table_del(ctx->static_hash, file->hash_key);
    }
    else if (mode == 1) {
        mk_list_del(&file->_head);
        flb_hash_table_del(ctx->event_hash, file->hash_key);
    }
    flb_free(file->tag_buf);
err_free_buf_data:
    flb_free(file->buf_data);
err_destroy_ml_stream:
    if (ctx->ml_ctx && file->ml_stream_id > 0) {
        flb_ml_stream_id_destroy_all(ctx->ml_ctx, file->ml_stream_id);
    }
err_free_dmode_lastline:
    flb_sds_destroy(file->dmode_lastline);
err_free_dmode_buf:
    flb_sds_destroy(file->dmode_buf);
err_destroy_sbuf:
    msgpack_sbuffer_destroy(&file->mult_sbuf);
    flb_free(file->orig_name);
err_free_name:
    flb_free(file->name);
    if (file->real_name) {
        flb_free(file->real_name);
    }
err_free_decomp:
    if (file->decompression_context) {
        flb_decompression_context_destroy(file->decompression_context);
    }
err_free_hash_key:
    flb_sds_destroy(file->hash_key);
err_free_file:
    flb_free(file);
err_close_fd:
    close(fd);
    flb_tail_file_budget_release(ctx);
    return -1;
}
void flb_tail_file_remove(struct flb_tail_file *file)
{
    uint64_t ts;
    char *name;
    struct flb_tail_config *ctx;
    ctx = file->config;
    if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" removing file name %s", file->inode, file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" removing file name %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name);
    if (file->decompression_context != ((void*)0)) {
        flb_decompression_context_destroy(file->decompression_context);
    }
    if (file->sl_log_event_encoder != ((void*)0)) {
        flb_log_event_encoder_destroy(file->sl_log_event_encoder);
    }
    if (ctx->ml_ctx && file->ml_stream_id > 0) {
        flb_ml_stream_id_destroy_all(ctx->ml_ctx, file->ml_stream_id);
    }
    if (file->ml_log_event_encoder != ((void*)0)) {
        flb_log_event_encoder_destroy(file->ml_log_event_encoder);
    }
    if (file->rotated > 0) {
        if (ctx->db) {
            flb_tail_db_file_delete(file, file->config);
        }
        mk_list_del(&file->_rotate_head);
    }
    msgpack_sbuffer_destroy(&file->mult_sbuf);
    flb_sds_destroy(file->dmode_buf);
    flb_sds_destroy(file->dmode_lastline);
    if (file->tail_mode == 0 && ctx->files_static_count > 0) {
        ctx->files_static_count--;
    }
    mk_list_del(&file->_head);
    flb_tail_fs_remove(ctx, file);
    if (file->fd != -1) {
        close(file->fd);
        flb_tail_file_budget_release(ctx);
    }
    if (file->tag_buf) {
        flb_free(file->tag_buf);
    }
    flb_hash_table_del(ctx->static_hash, file->hash_key);
    flb_hash_table_del(ctx->event_hash, file->hash_key);
    flb_free(file->buf_data);
    flb_free(file->name);
    flb_free(file->orig_name);
    flb_free(file->real_name);
    flb_sds_destroy(file->hash_key);
    name = (char *) flb_input_name(ctx->ins);
    ts = cfl_time_now();
    cmt_counter_inc(ctx->cmt_files_closed, ts, 1, (char *[]) {name});
    flb_metrics_sum(101, 1, ctx->ins->metrics);
    flb_free(file);
}
void flb_tail_file_reclaim(struct flb_tail_config *ctx)
{
    int ret;
    struct mk_list *head;
    struct mk_list *tmp;
    struct flb_tail_file *file;
    struct stat path_st;
    struct tail_dormant_file snapshot = {0};
    struct tail_dormant_file *dormant;
    if (ctx->multiline || ctx->ml_ctx || ctx->docker_mode) {
        return;
    }
    for (head = (&ctx->files_event)->next, tmp = head->next; head != (&ctx->files_event); head = tmp, tmp = head->next) {
        if (!flb_tail_file_budget_pressure(ctx)) {
            break;
        }
        file = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
        if (file->rotated || file->is_link || file->decompression_context ||
            file->buf_len != 0 || file->pending_bytes != 0 || file->skip_next ||
            file->sl_log_event_encoder->output_length != 0) {
            continue;
        }
        if (fstat(file->fd, &snapshot.st) == -1 ||
            tail_file_stat(ctx, file->name, &path_st) == -1 ||
            snapshot.st.st_dev != path_st.st_dev || snapshot.st.st_ino != path_st.st_ino ||
            snapshot.st.st_size != file->offset ||
            flb_tail_file_is_rotated(ctx, file) != 0 ||
            flb_tail_file_offset_marker_matches(file) != 1) {
            continue;
        }
        if (file->offset > 0 && file->db_offset_marker_size == 0 &&
            flb_tail_file_update_offset_marker(file) != 0) {
            continue;
        }
        dormant = flb_calloc(1, sizeof(*dormant));
        if (!dormant) {
            continue;
        }
        dormant->st = snapshot.st;
        dormant->offset = file->offset;
        dormant->marker = file->db_offset_marker;
        dormant->marker_size = file->db_offset_marker_size;
        dormant->db_id = file->db_id;
        dormant->path = flb_sds_create(file->name);
        dormant->inode_key = flb_sds_create(file->hash_key);
        if (!dormant->path || !dormant->inode_key) {
            flb_sds_destroy(dormant->path);
            flb_sds_destroy(dormant->inode_key);
            flb_free(dormant);
            continue;
        }
        ret = flb_hash_table_add(ctx->dormant_files, dormant->path,
                                flb_sds_len(dormant->path), dormant, 0);
        if (ret != -1) {
            ret = flb_hash_table_add(ctx->dormant_inodes, dormant->inode_key,
                                    flb_sds_len(dormant->inode_key), dormant, 0);
            if (ret == -1) {
                flb_hash_table_del(ctx->dormant_files, dormant->path);
            }
        }
        if (ret == -1) {
            flb_sds_destroy(dormant->path);
            flb_sds_destroy(dormant->inode_key);
            flb_free(dormant);
            continue;
        }
        mk_list_add(&dormant->_head, &ctx->files_dormant);
        if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "releasing dormant file at 75%% budget usage: %s", file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "releasing dormant file at 75%% budget usage: %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
        flb_tail_file_remove(file);
    }
}
int flb_tail_file_remove_all(struct flb_tail_config *ctx)
{
    int count = 0;
    struct mk_list *head;
    struct mk_list *tmp;
    struct flb_tail_file *file;
    for (head = (&ctx->files_static)->next, tmp = head->next; head != (&ctx->files_static); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
        flb_tail_file_remove(file);
        count++;
    }
    for (head = (&ctx->files_event)->next, tmp = head->next; head != (&ctx->files_event); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
        flb_tail_file_remove(file);
        count++;
    }
    return count;
}
static int adjust_counters(struct flb_tail_config *ctx, struct flb_tail_file *file)
{
    int ret;
    struct stat st;
    (void) ctx;
    ret = fstat(file->fd, &st);
    if (ret == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2185);
        return -1;
    }
    int64_t size_delta = st.st_size - file->size;
    if (size_delta != 0) {
        file->size = st.st_size;
    }
    if (size_delta < 0) {
        if (flb_tail_file_reset_on_truncate(file, size_delta,
                                            "adjust_counters") == -1) {
            return -1;
        }
    }
    else {
        file->pending_bytes = (st.st_size > file->offset) ? (st.st_size - file->offset) : 0;
    }
    return 0;
}
int flb_tail_file_chunk(struct flb_tail_file *file)
{
    size_t decompression_buffer_capacity;
    size_t decompressed_data_length;
    size_t file_buffer_capacity;
    size_t stream_data_length;
    ssize_t raw_data_length;
    size_t processed_bytes = 0;
    uint8_t *read_buffer;
    size_t read_size;
    size_t size;
    char *tmp;
    int ret;
    int lines;
    struct flb_tail_config *ctx;
    ctx = file->config;
    if (flb_input_buf_paused(ctx->ins) == 1) {
        return 2;
    }
    file_buffer_capacity = (file->buf_size - file->buf_len) - 1;
    stream_data_length = 0;
    if (file_buffer_capacity < 1) {
        if (ctx->truncate_long_lines == 1) {
            lines = process_content(file, &processed_bytes);
            if (lines < 0) {
                if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" file=%s process content ERROR", file->inode, file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" file=%s process content ERROR", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name);
                return -1;
            }
            if (lines > 0) {
                file->stream_offset += processed_bytes;
                file->last_processed_bytes = 0;
                consume_bytes(file->buf_data, processed_bytes, file->buf_len);
                file->buf_len -= processed_bytes;
                file->buf_data[file->buf_len] = '\0';
                update_resumable_offset_state(file);
                return adjust_counters(ctx, file);
            }
        }
        if (file->buf_size >= ctx->buf_max_size) {
            if (ctx->skip_long_lines == 0) {
                if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "file=%s requires a larger buffer size, " "lines are too long. Skipping file.", file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "file=%s requires a larger buffer size, " "lines are too long. Skipping file.", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
                return -1;
            }
            if (file->skip_next == 0) {
                cmt_counter_inc(ctx->cmt_long_line_skipped,
                                cfl_time_now(), 1,
                                (char *[]) { (char *) flb_input_name(ctx->ins) });
                flb_metrics_sum(105, 1, ctx->ins->metrics);
            }
            if (file->skip_warn == 0) {
                if (flb_log_check_level(ctx->ins->log_level, 2)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "file=%s have long lines. " "Skipping long lines.", file->name) == 0) flb_log_print(2, ((void*)0), 0, "[input:%s:%s] " "file=%s have long lines. " "Skipping long lines.", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
                file->skip_warn = 1;
            }
            file->buf_len = 0;
            file->skip_next = 1;
        }
        else {
            size = file->buf_size + ctx->buf_chunk_size;
            if (size > ctx->buf_max_size) {
                size = ctx->buf_max_size;
            }
            tmp = flb_realloc(file->buf_data, size);
            if (tmp) {
                if (flb_log_check_level(ctx->ins->log_level, 5)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "file=%s increase buffer size " "%lu => %lu bytes", file->name, file->buf_size, size) == 0) flb_log_print(5, ((void*)0), 0, "[input:%s:%s at %s:%i] " "file=%s increase buffer size " "%lu => %lu bytes", ctx->ins->p->name, flb_input_name(ctx->ins), "<stdin>", 2300, file->name, file->buf_size, size);
                file->buf_data = tmp;
                file->buf_size = size;
            }
            else {
                flb_errno_print((*__errno_location ()), "<stdin>", 2305);
                if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "cannot increase buffer size for %s, " "skipping file.", file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "cannot increase buffer size for %s, " "skipping file.", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
                return -1;
            }
        }
        file_buffer_capacity = (file->buf_size - file->buf_len) - 1;
    }
    if (ctx->file_cache_advise) {
        if (posix_fadvise(file->fd, 0, 0, 4) == -1) {
            flb_errno_print((*__errno_location ()), "<stdin>", 2318);
            if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "error during posix_fadvise") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error during posix_fadvise", ctx->ins->p->name, flb_input_name(ctx->ins));
        }
    }
    read_size = file_buffer_capacity;
    if (file->decompression_context != ((void*)0)) {
        flb_decompression_context_get_append_buffer(
            file->decompression_context);
        decompression_buffer_capacity =
            flb_decompression_context_get_available_space(
                file->decompression_context);
        if (decompression_buffer_capacity == 0) {
            if (file->decompression_context->input_buffer_size <
                ctx->buf_max_size) {
                decompression_buffer_capacity += ctx->buf_chunk_size;
                if (decompression_buffer_capacity > ctx->buf_max_size) {
                    decompression_buffer_capacity = ctx->buf_max_size;
                }
                ret = flb_decompression_context_resize_buffer(
                        file->decompression_context,
                        decompression_buffer_capacity);
                if (ret != 0) {
                    if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "decompression buffer resize failed for %s.", file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "decompression buffer resize failed for %s.", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
                    return -1;
                }
                decompression_buffer_capacity = flb_decompression_context_get_available_space(
                        file->decompression_context);
            }
        }
        if (decompression_buffer_capacity > 0) {
            if (read_size > decompression_buffer_capacity) {
                read_size = decompression_buffer_capacity;
            }
            read_buffer = flb_decompression_context_get_append_buffer(
                            file->decompression_context);
            raw_data_length = read(file->fd, read_buffer, read_size);
        }
        else {
            raw_data_length = 0;
        }
        if (raw_data_length >= 0) {
            file->decompression_context->input_buffer_length += (size_t) raw_data_length;
            if (file->decompression_context->input_buffer_length > 0) {
                decompressed_data_length = file_buffer_capacity;
                ret = flb_decompress(file->decompression_context,
                                     &file->buf_data[file->buf_len],
                                     &decompressed_data_length);
                if (ret != 0) {
                    if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "decompression failed for %s.", file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "decompression failed for %s.", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
                    return -1;
                }
                stream_data_length = decompressed_data_length;
            }
        }
    }
    else {
        raw_data_length = read(file->fd,
                               &file->buf_data[file->buf_len],
                               read_size);
        stream_data_length = (size_t) raw_data_length;
    }
    if (stream_data_length > 0 || raw_data_length > 0) {
        file->offset += raw_data_length;
        file->buf_len += stream_data_length;
        file->buf_data[file->buf_len] = '\0';
        ret = process_content(file, &processed_bytes);
        if (ret < 0) {
            if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" file=%s process content ERROR", file->inode, file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" file=%s process content ERROR", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name);
            return -1;
        }
        file->stream_offset += processed_bytes;
        file->last_processed_bytes = 0;
        consume_bytes(file->buf_data, processed_bytes, file->buf_len);
        file->buf_len -= processed_bytes;
        file->buf_data[file->buf_len] = '\0';
        update_resumable_offset_state(file);
        ret = adjust_counters(ctx, file);
        return ret;
    }
    else if (raw_data_length == 0) {
        ret = adjust_counters(ctx, file);
        if (ret == 0) {
            return 1;
        }
        else {
            return -1;
        }
    }
    else {
        flb_errno_print((*__errno_location ()), "<stdin>", 2459);
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "error reading %s", file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "error reading %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
        return -1;
    }
    return -1;
}
int flb_tail_file_is_rotated(struct flb_tail_config *ctx,
                             struct flb_tail_file *file)
{
    int ret;
    char *name;
    struct stat st;
    if (file->rotated != 0) {
        return 0;
    }
    if (file->is_link == 1) {
        ret = tail_file_lstat(ctx, file->name, &st);
        if (ret == -1) {
            if ((*__errno_location ()) == 2) {
                if (flb_log_check_level(ctx->ins->log_level, 3)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" link_rotated: %s", file->link_inode, file->name) == 0) flb_log_print(3, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" link_rotated: %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->link_inode, file->name);
                return 1;
            }
            else {
                flb_errno_print((*__errno_location ()), "<stdin>", 2494);
                if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "link_inode=%""l" "u"" cannot detect if file: %s", file->link_inode, file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "link_inode=%""l" "u"" cannot detect if file: %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->link_inode, file->name);
                return -1;
            }
        }
        else {
            if (st.st_ino != file->link_inode) {
                return 1;
            }
        }
    }
    name = flb_tail_file_name(file);
    if (!name) {
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" cannot detect if file was rotated: %s", file->inode, file->name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" cannot detect if file was rotated: %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name);
        return -1;
    }
    ret = tail_file_stat(ctx, name, &st);
    if (ret == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2522);
        flb_free(name);
        return -1;
    }
    if (file->inode == st.st_ino &&
        flb_tail_target_file_name_cmp(name, file) == 0) {
        flb_free(name);
        return 0;
    }
    if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" rotated: %s => %s", file->inode, file->name, name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" rotated: %s => %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name, name);
    flb_free(name);
    return 1;
}
int flb_tail_file_to_event(struct flb_tail_file *file)
{
    int ret;
    struct stat st;
    struct flb_tail_config *ctx = file->config;
    ret = fstat(file->fd, &st);
    if (ret != 0) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2551);
        return -1;
    }
    if (file->offset < st.st_size) {
        file->pending_bytes = (st.st_size - file->offset);
        tail_signal_pending(file->config);
    }
    else {
        file->pending_bytes = 0;
    }
    ret = flb_tail_file_is_rotated(ctx, file);
    if (ret == 1) {
        flb_tail_file_rotated(file);
    }
    ret = flb_tail_fs_add(ctx, file);
    if (ret == -1) {
        return -1;
    }
    ret = flb_hash_table_add(ctx->event_hash,
                             file->hash_key, flb_sds_len(file->hash_key),
                             file, sizeof(file));
    if (ret < 0) {
        if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "could not register file in event hash") == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "could not register file in event hash", ctx->ins->p->name, flb_input_name(ctx->ins));
        flb_tail_fs_remove(ctx, file);
        return -1;
    }
    mk_list_del(&file->_head);
    ctx->files_static_count--;
    flb_hash_table_del(ctx->static_hash, file->hash_key);
    mk_list_add(&file->_head, &file->config->files_event);
    file->tail_mode = 1;
    return 0;
}
char *flb_tail_file_name(struct flb_tail_file *file)
{
    int ret;
    char *buf;
    ssize_t s;
    char tmp[128];
    buf = flb_malloc(4096);
    if (!buf) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2619);
        return ((void*)0);
    }
    ret = snprintf(tmp, sizeof(tmp) - 1, "/proc/%i/fd/%i", getpid(), file->fd);
    if (ret == -1) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2626);
        flb_free(buf);
        return ((void*)0);
    }
    s = readlink(tmp, buf, 4096);
    if (s == -1) {
        flb_free(buf);
        flb_errno_print((*__errno_location ()), "<stdin>", 2634);
        return ((void*)0);
    }
    buf[s] = '\0';
    return buf;
}
int flb_tail_file_name_dup(char *path, struct flb_tail_file *file)
{
    file->name = flb_strdup(path);
    if (!file->name) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2725);
        return -1;
    }
    file->name_len = strlen(file->name);
    if (file->real_name) {
        flb_free(file->real_name);
    }
    file->real_name = flb_tail_file_name(file);
    if (!file->real_name) {
        flb_errno_print((*__errno_location ()), "<stdin>", 2736);
        flb_free(file->name);
        file->name = ((void*)0);
        return -1;
    }
    return 0;
}
int flb_tail_file_rotated(struct flb_tail_file *file)
{
    int ret;
    uint64_t ts;
    char *name;
    char *i_name;
    char *tmp;
    struct stat st;
    struct flb_tail_config *ctx = file->config;
    name = flb_tail_file_name(file);
    if (!name) {
        return -1;
    }
    if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" rotated %s -> %s", file->inode, file->name, name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" rotated %s -> %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name, name);
    tmp = file->name;
    flb_tail_file_name_dup(name, file);
    if (flb_log_check_level(ctx->ins->log_level, 3)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" handle rotation(): %s => %s", file->inode, tmp, file->name) == 0) flb_log_print(3, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" handle rotation(): %s => %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, tmp, file->name);
    if (file->rotated == 0) {
        file->rotated = time(((void*)0));
        mk_list_add(&file->_rotate_head, &file->config->files_rotated);
        if (file->config->db) {
            ret = flb_tail_db_file_rotate(name, file, file->config);
            if (ret == -1) {
                if (flb_log_check_level(ctx->ins->log_level, 1)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "could not rotate file %s->%s in database", file->name, name) == 0) flb_log_print(1, ((void*)0), 0, "[input:%s:%s] " "could not rotate file %s->%s in database", ctx->ins->p->name, flb_input_name(ctx->ins), file->name, name);
            }
        }
        i_name = (char *) flb_input_name(ctx->ins);
        ts = cfl_time_now();
        cmt_counter_inc(ctx->cmt_files_rotated, ts, 1, (char *[]) {i_name});
        flb_metrics_sum(102,
                        1, file->config->ins->metrics);
        ret = tail_file_stat(ctx, tmp, &st);
        if (ret == 0 && st.st_ino != file->inode) {
            if (flb_tail_file_exists(&st, ctx) == 0) {
                ret = flb_tail_file_append(tmp, &st, 0, -1, ctx);
                if (ret == -1) {
                    flb_tail_scan(ctx->path_list, ctx);
                }
                else {
                    tail_signal_manager(file->config);
                }
            }
        }
    }
    flb_free(tmp);
    flb_free(name);
    return 0;
}
static int check_purge_deleted_file(struct flb_tail_config *ctx,
                                    struct flb_tail_file *file, time_t ts)
{
    int ret;
    int64_t mtime;
    struct stat st;
    ret = fstat(file->fd, &st);
    if (ret == -1) {
        if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "error stat(2) %s, removing", file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "error stat(2) %s, removing", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
        flb_tail_file_remove(file);
        return 1;
    }
    if (st.st_nlink == 0) {
        if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "purge: monitored file has been deleted: %s", file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "purge: monitored file has been deleted: %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
        if (ctx->db) {
            flb_tail_db_file_delete(file, file->config);
        }
        flb_tail_file_remove(file);
        return 1;
    }
    if (ctx->ignore_older > 0 && ctx->ignore_active_older_files) {
        mtime = flb_tail_stat_mtime(&st);
        if (mtime > 0) {
            if ((ts - ctx->ignore_older) > mtime) {
                if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "purge: monitored file (ignore older): %s", file->name) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "purge: monitored file (ignore older): %s", ctx->ins->p->name, flb_input_name(ctx->ins), file->name);
                flb_tail_scan_register_aged_out_inode(ctx,
                                                      file->name,
                                                      strlen(file->name),
                                                      file->inode);
                flb_tail_scan_register_ignored_file_size(ctx,
                                                         file->name,
                                                         strlen(file->name),
                                                         flb_tail_file_db_offset(file));
                flb_tail_file_remove(file);
                return 1;
            }
        }
    }
    return 0;
}
int flb_tail_file_purge(struct flb_input_instance *ins,
                        struct flb_config *config, void *context)
{
    int ret;
    int count = 0;
    struct mk_list *tmp;
    struct mk_list *head;
    struct flb_tail_file *file;
    struct flb_tail_config *ctx = context;
    time_t now;
    struct stat st;
    now = time(((void*)0));
    for (head = (&ctx->files_rotated)->next, tmp = head->next; head != (&ctx->files_rotated); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct flb_tail_file *)0)->_rotate_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _rotate_head) );});
        if ((file->rotated + ctx->rotate_wait) <= now) {
            ret = fstat(file->fd, &st);
            if (ret == 0) {
                if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" purge rotated file %s " "(offset=%""l" "d"" / size = %""l" "u"")", file->inode, file->name, file->offset, (uint64_t)st.st_size) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" purge rotated file %s " "(offset=%""l" "d"" / size = %""l" "u"")", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name, file->offset, (uint64_t)st.st_size);
                if (file->pending_bytes > 0 && flb_input_buf_paused(ins)) {
                    if (flb_log_check_level(ctx->ins->log_level, 2)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "purged rotated file while data " "ingestion is paused, consider increasing " "rotate_wait") == 0) flb_log_print(2, ((void*)0), 0, "[input:%s:%s] " "purged rotated file while data " "ingestion is paused, consider increasing " "rotate_wait", ctx->ins->p->name, flb_input_name(ctx->ins));
                }
            }
            else {
                if (flb_log_check_level(ctx->ins->log_level, 4)) if (flb_log_suppress_check(ctx->ins->log_suppress_interval, "inode=%""l" "u"" purge rotated file %s (offset=%""l" "d"")", file->inode, file->name, file->offset) == 0) flb_log_print(4, ((void*)0), 0, "[input:%s:%s] " "inode=%""l" "u"" purge rotated file %s (offset=%""l" "d"")", ctx->ins->p->name, flb_input_name(ctx->ins), file->inode, file->name, file->offset);
            }
            flb_tail_file_remove(file);
            count++;
        }
    }
    for (head = (&ctx->files_static)->next, tmp = head->next; head != (&ctx->files_static); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
        check_purge_deleted_file(ctx, file, now);
    }
    for (head = (&ctx->files_event)->next, tmp = head->next; head != (&ctx->files_event); head = tmp, tmp = head->next) {
        file = ({ const typeof( ((struct flb_tail_file *)0)->_head ) *__mptr = (head); (struct flb_tail_file *)( (char *)__mptr - __builtin_offsetof(struct flb_tail_file, _head) );});
        check_purge_deleted_file(ctx, file, now);
    }
    return count;
}
