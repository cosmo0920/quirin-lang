import pathlib,subprocess,os,json,time,fcntl,datetime,hashlib
p=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path.cwd()
env=dict(os.environ,CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',QCORE_CLANG='/usr/bin/clang')
base=pathlib.Path('/home/cosmo/Documents/GitHub/qcore-c/private/premise-resolution-cycle2')
steps=[('build',['cargo','build','-p','qcore-audit','--example','libc_local_source_domains','-j1']),('corpus',[str(repo/'target/debug/examples/libc_local_source_domains'),str(base/'base-freeze/inputs'),'/home/cosmo/Documents/GitHub/qcore-c/build/cycle19/c-gateway-wave-pin/fluent-bit-clang-source',str(repo),str(base/'measure-1/corpus/base/corpus/resource-diagnostics.json'),str(base/'measure-1/corpus/base/invocation.json'),str(p/'result'),'contract-hypothesis-graph.v1:c1625baf713e4d8498c39282238675749237005d'])]
rows=[]
with open('/tmp/qcore-c-cycle2-small-compile.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 (p/'acquired.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid(),'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()},indent=2)+'\n')
 for name,cmd in steps:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.time()
  with(p/(name+'.log')).open('w')as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
  rows.append({'step':name,'command':cmd,'cwd':str(repo),'exit':r.returncode,'seconds':time.time()-t,'started':start,'ended':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'driver_source_sha256':hashlib.sha256((repo/'crates/qcore-audit/examples/libc_local_source_domains.rs').read_bytes()).hexdigest(),'environment':{k:env[k]for k in ['QCORE_CLANG','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL']}})
  (p/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
  if name=='build' and r.returncode:break
 (p/'released.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pid':os.getpid()},indent=2)+'\n')
