typedef long int ptrdiff_t;
typedef long unsigned int size_t;
typedef int wchar_t;
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
__attribute__ ((visibility ("default"))) int LZ4_versionNumber (void);
__attribute__ ((visibility ("default"))) const char* LZ4_versionString (void);
__attribute__ ((visibility ("default"))) int LZ4_compress_default(const char* src, char* dst, int srcSize, int dstCapacity);
__attribute__ ((visibility ("default"))) int LZ4_decompress_safe (const char* src, char* dst, int compressedSize, int dstCapacity);
__attribute__ ((visibility ("default"))) int LZ4_compressBound(int inputSize);
__attribute__ ((visibility ("default"))) int LZ4_compress_fast (const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
__attribute__ ((visibility ("default"))) int LZ4_sizeofState(void);
__attribute__ ((visibility ("default"))) int LZ4_compress_fast_extState (void* state, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
__attribute__ ((visibility ("default"))) int LZ4_compress_destSize (const char* src, char* dst, int* srcSizePtr, int targetDstSize);
__attribute__ ((visibility ("default"))) int LZ4_decompress_safe_partial (const char* src, char* dst, int srcSize, int targetOutputSize, int dstCapacity);
typedef union LZ4_stream_u LZ4_stream_t;
__attribute__ ((visibility ("default"))) LZ4_stream_t* LZ4_createStream(void);
__attribute__ ((visibility ("default"))) int LZ4_freeStream (LZ4_stream_t* streamPtr);
__attribute__ ((visibility ("default"))) void LZ4_resetStream_fast (LZ4_stream_t* streamPtr);
__attribute__ ((visibility ("default"))) int LZ4_loadDict (LZ4_stream_t* streamPtr, const char* dictionary, int dictSize);
__attribute__ ((visibility ("default"))) int LZ4_compress_fast_continue (LZ4_stream_t* streamPtr, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
__attribute__ ((visibility ("default"))) int LZ4_saveDict (LZ4_stream_t* streamPtr, char* safeBuffer, int maxDictSize);
typedef union LZ4_streamDecode_u LZ4_streamDecode_t;
__attribute__ ((visibility ("default"))) LZ4_streamDecode_t* LZ4_createStreamDecode(void);
__attribute__ ((visibility ("default"))) int LZ4_freeStreamDecode (LZ4_streamDecode_t* LZ4_stream);
__attribute__ ((visibility ("default"))) int LZ4_setStreamDecode (LZ4_streamDecode_t* LZ4_streamDecode, const char* dictionary, int dictSize);
__attribute__ ((visibility ("default"))) int LZ4_decoderRingBufferSize(int maxBlockSize);
__attribute__ ((visibility ("default"))) int
LZ4_decompress_safe_continue (LZ4_streamDecode_t* LZ4_streamDecode,
                        const char* src, char* dst,
                        int srcSize, int dstCapacity);
__attribute__ ((visibility ("default"))) int
LZ4_decompress_safe_usingDict(const char* src, char* dst,
                              int srcSize, int dstCapacity,
                              const char* dictStart, int dictSize);
__attribute__ ((visibility ("default"))) int
LZ4_decompress_safe_partial_usingDict(const char* src, char* dst,
                                      int compressedSize,
                                      int targetOutputSize, int maxOutputSize,
                                      const char* dictStart, int dictSize);
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef long int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
 typedef int8_t LZ4_i8;
  typedef uint8_t LZ4_byte;
  typedef uint16_t LZ4_u16;
  typedef uint32_t LZ4_u32;
typedef struct LZ4_stream_t_internal LZ4_stream_t_internal;
struct LZ4_stream_t_internal {
    LZ4_u32 hashTable[(1 << (14 -2))];
    const LZ4_byte* dictionary;
    const LZ4_stream_t_internal* dictCtx;
    LZ4_u32 currentOffset;
    LZ4_u32 tableType;
    LZ4_u32 dictSize;
};
union LZ4_stream_u {
    char minStateSize[((1UL << 14) + 32)];
    LZ4_stream_t_internal internal_donotuse;
};
__attribute__ ((visibility ("default"))) LZ4_stream_t* LZ4_initStream (void* buffer, size_t size);
typedef struct {
    const LZ4_byte* externalDict;
    const LZ4_byte* prefixEnd;
    size_t extDictSize;
    size_t prefixSize;
} LZ4_streamDecode_t_internal;
union LZ4_streamDecode_u {
    char minStateSize[32];
    LZ4_streamDecode_t_internal internal_donotuse;
} ;
__attribute__((deprecated("use LZ4_compress_default() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compress (const char* src, char* dest, int srcSize);
__attribute__((deprecated("use LZ4_compress_default() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compress_limitedOutput (const char* src, char* dest, int srcSize, int maxOutputSize);
__attribute__((deprecated("use LZ4_compress_fast_extState() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compress_withState (void* state, const char* source, char* dest, int inputSize);
__attribute__((deprecated("use LZ4_compress_fast_extState() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compress_limitedOutput_withState (void* state, const char* source, char* dest, int inputSize, int maxOutputSize);
__attribute__((deprecated("use LZ4_compress_fast_continue() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compress_continue (LZ4_stream_t* LZ4_streamPtr, const char* source, char* dest, int inputSize);
__attribute__((deprecated("use LZ4_compress_fast_continue() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compress_limitedOutput_continue (LZ4_stream_t* LZ4_streamPtr, const char* source, char* dest, int inputSize, int maxOutputSize);
__attribute__((deprecated("use LZ4_decompress_fast() instead"))) __attribute__ ((visibility ("default"))) int LZ4_uncompress (const char* source, char* dest, int outputSize);
__attribute__((deprecated("use LZ4_decompress_safe() instead"))) __attribute__ ((visibility ("default"))) int LZ4_uncompress_unknownOutputSize (const char* source, char* dest, int isize, int maxOutputSize);
__attribute__((deprecated("Use LZ4_createStream() instead"))) __attribute__ ((visibility ("default"))) void* LZ4_create (char* inputBuffer);
__attribute__((deprecated("Use LZ4_createStream() instead"))) __attribute__ ((visibility ("default"))) int LZ4_sizeofStreamState(void);
__attribute__((deprecated("Use LZ4_resetStream() instead"))) __attribute__ ((visibility ("default"))) int LZ4_resetStreamState(void* state, char* inputBuffer);
__attribute__((deprecated("Use LZ4_saveDict() instead"))) __attribute__ ((visibility ("default"))) char* LZ4_slideInputBuffer (void* state);
__attribute__((deprecated("use LZ4_decompress_safe_usingDict() instead"))) __attribute__ ((visibility ("default"))) int LZ4_decompress_safe_withPrefix64k (const char* src, char* dst, int compressedSize, int maxDstSize);
__attribute__((deprecated("use LZ4_decompress_fast_usingDict() instead"))) __attribute__ ((visibility ("default"))) int LZ4_decompress_fast_withPrefix64k (const char* src, char* dst, int originalSize);
__attribute__((deprecated("This function is deprecated and unsafe. Consider using LZ4_decompress_safe() instead")))
__attribute__ ((visibility ("default"))) int LZ4_decompress_fast (const char* src, char* dst, int originalSize);
__attribute__((deprecated("This function is deprecated and unsafe. Consider using LZ4_decompress_safe_continue() instead")))
__attribute__ ((visibility ("default"))) int LZ4_decompress_fast_continue (LZ4_streamDecode_t* LZ4_streamDecode, const char* src, char* dst, int originalSize);
__attribute__((deprecated("This function is deprecated and unsafe. Consider using LZ4_decompress_safe_usingDict() instead")))
__attribute__ ((visibility ("default"))) int LZ4_decompress_fast_usingDict (const char* src, char* dst, int originalSize, const char* dictStart, int dictSize);
__attribute__ ((visibility ("default"))) void LZ4_resetStream (LZ4_stream_t* streamPtr);
__attribute__ ((visibility ("default"))) int LZ4_compress_HC (const char* src, char* dst, int srcSize, int dstCapacity, int compressionLevel);
__attribute__ ((visibility ("default"))) int LZ4_sizeofStateHC(void);
__attribute__ ((visibility ("default"))) int LZ4_compress_HC_extStateHC(void* stateHC, const char* src, char* dst, int srcSize, int maxDstSize, int compressionLevel);
__attribute__ ((visibility ("default"))) int LZ4_compress_HC_destSize(void* stateHC,
                                  const char* src, char* dst,
                                        int* srcSizePtr, int targetDstSize,
                                        int compressionLevel);
 typedef union LZ4_streamHC_u LZ4_streamHC_t;
__attribute__ ((visibility ("default"))) LZ4_streamHC_t* LZ4_createStreamHC(void);
__attribute__ ((visibility ("default"))) int LZ4_freeStreamHC (LZ4_streamHC_t* streamHCPtr);
__attribute__ ((visibility ("default"))) void LZ4_resetStreamHC_fast(LZ4_streamHC_t* streamHCPtr, int compressionLevel);
__attribute__ ((visibility ("default"))) int LZ4_loadDictHC (LZ4_streamHC_t* streamHCPtr, const char* dictionary, int dictSize);
__attribute__ ((visibility ("default"))) int LZ4_compress_HC_continue (LZ4_streamHC_t* streamHCPtr,
                                   const char* src, char* dst,
                                         int srcSize, int maxDstSize);
__attribute__ ((visibility ("default"))) int LZ4_compress_HC_continue_destSize(LZ4_streamHC_t* LZ4_streamHCPtr,
                                           const char* src, char* dst,
                                                 int* srcSizePtr, int targetDstSize);
__attribute__ ((visibility ("default"))) int LZ4_saveDictHC (LZ4_streamHC_t* streamHCPtr, char* safeBuffer, int maxDictSize);
typedef struct LZ4HC_CCtx_internal LZ4HC_CCtx_internal;
struct LZ4HC_CCtx_internal
{
    LZ4_u32 hashTable[(1 << 15)];
    LZ4_u16 chainTable[(1<<16)];
    const LZ4_byte* end;
    const LZ4_byte* prefixStart;
    const LZ4_byte* dictStart;
    LZ4_u32 dictLimit;
    LZ4_u32 lowLimit;
    LZ4_u32 nextToUpdate;
    short compressionLevel;
    LZ4_i8 favorDecSpeed;
    LZ4_i8 dirty;
    const LZ4HC_CCtx_internal* dictCtx;
};
union LZ4_streamHC_u {
    char minStateSize[262200];
    LZ4HC_CCtx_internal internal_donotuse;
};
__attribute__ ((visibility ("default"))) LZ4_streamHC_t* LZ4_initStreamHC(void* buffer, size_t size);
__attribute__((deprecated("use LZ4_compress_HC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC (const char* source, char* dest, int inputSize);
__attribute__((deprecated("use LZ4_compress_HC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC_limitedOutput (const char* source, char* dest, int inputSize, int maxOutputSize);
__attribute__((deprecated("use LZ4_compress_HC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC2 (const char* source, char* dest, int inputSize, int compressionLevel);
__attribute__((deprecated("use LZ4_compress_HC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC2_limitedOutput(const char* source, char* dest, int inputSize, int maxOutputSize, int compressionLevel);
__attribute__((deprecated("use LZ4_compress_HC_extStateHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC_withStateHC (void* state, const char* source, char* dest, int inputSize);
__attribute__((deprecated("use LZ4_compress_HC_extStateHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC_limitedOutput_withStateHC (void* state, const char* source, char* dest, int inputSize, int maxOutputSize);
__attribute__((deprecated("use LZ4_compress_HC_extStateHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC2_withStateHC (void* state, const char* source, char* dest, int inputSize, int compressionLevel);
__attribute__((deprecated("use LZ4_compress_HC_extStateHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC2_limitedOutput_withStateHC(void* state, const char* source, char* dest, int inputSize, int maxOutputSize, int compressionLevel);
__attribute__((deprecated("use LZ4_compress_HC_continue() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC_continue (LZ4_streamHC_t* LZ4_streamHCPtr, const char* source, char* dest, int inputSize);
__attribute__((deprecated("use LZ4_compress_HC_continue() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC_limitedOutput_continue (LZ4_streamHC_t* LZ4_streamHCPtr, const char* source, char* dest, int inputSize, int maxOutputSize);
__attribute__((deprecated("use LZ4_createStreamHC() instead"))) __attribute__ ((visibility ("default"))) void* LZ4_createHC (const char* inputBuffer);
__attribute__((deprecated("use LZ4_freeStreamHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_freeHC (void* LZ4HC_Data);
__attribute__((deprecated("use LZ4_saveDictHC() instead"))) __attribute__ ((visibility ("default"))) char* LZ4_slideInputBufferHC (void* LZ4HC_Data);
__attribute__((deprecated("use LZ4_compress_HC_continue() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC2_continue (void* LZ4HC_Data, const char* source, char* dest, int inputSize, int compressionLevel);
__attribute__((deprecated("use LZ4_compress_HC_continue() instead"))) __attribute__ ((visibility ("default"))) int LZ4_compressHC2_limitedOutput_continue (void* LZ4HC_Data, const char* source, char* dest, int inputSize, int maxOutputSize, int compressionLevel);
__attribute__((deprecated("use LZ4_createStreamHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_sizeofStreamStateHC(void);
__attribute__((deprecated("use LZ4_initStreamHC() instead"))) __attribute__ ((visibility ("default"))) int LZ4_resetStreamStateHC(void* state, char* inputBuffer);
__attribute__ ((visibility ("default"))) void LZ4_resetStreamHC (LZ4_streamHC_t* streamHCPtr, int compressionLevel);
 int LZ4_compress_fast_extState_fastReset (void* state, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
                  void
LZ4_attach_dictionary(LZ4_stream_t* workingStream,
                const LZ4_stream_t* dictionaryStream);
 void LZ4_setCompressionLevel(
    LZ4_streamHC_t* LZ4_streamHCPtr, int compressionLevel);
                  void LZ4_favorDecompressionSpeed(
    LZ4_streamHC_t* LZ4_streamHCPtr, int favor);
                  void LZ4_resetStreamHC_fast(
    LZ4_streamHC_t* LZ4_streamHCPtr, int compressionLevel);
                  int LZ4_compress_HC_extStateHC_fastReset (
    void* state,
    const char* src, char* dst,
    int srcSize, int dstCapacity,
    int compressionLevel);
                  void LZ4_attach_HC_dictionary(
          LZ4_streamHC_t *working_stream,
    const LZ4_streamHC_t *dictionary_stream);
#pragma GCC diagnostic ignored "-Wunused-function"
#pragma clang diagnostic ignored "-Wunused-function"
struct rdkafka_s;
extern void *rd_kafka_mem_malloc(struct rdkafka_s *rk, size_t s);
extern void *rd_kafka_mem_calloc(struct rdkafka_s *rk, size_t n, size_t s);
extern void rd_kafka_mem_free(struct rdkafka_s *rk, void *p);
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void *memset_explicit (void *__s, int __c, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
struct __locale_struct
{
  struct __locale_data *__locales[13];
  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;
  const char *__names[13];
};
typedef struct __locale_struct *__locale_t;

typedef __locale_t locale_t;
extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;
extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
                                         ;
extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                          ;
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
static const int LZ4_minLength = (12 +1);
static int LZ4_isAligned(const void* ptr, size_t alignment)
{
    return ((size_t)ptr & (alignment -1)) == 0;
}
 typedef uint8_t BYTE;
  typedef uint16_t U16;
  typedef uint32_t U32;
  typedef int32_t S32;
  typedef uint64_t U64;
  typedef uintptr_t uptrval;
  typedef U64 reg_t;
typedef enum {
    notLimited = 0,
    limitedOutput = 1,
    fillOutput = 2
} limitedOutput_directive;
static unsigned LZ4_isLittleEndian(void)
{
    const union { U32 u; BYTE c[4]; } one = { 1 };
    return one.c[0];
}
typedef union { U16 u16; U32 u32; reg_t uArch; } __attribute__((packed)) LZ4_unalign;
static U16 LZ4_read16(const void* ptr) { return ((const LZ4_unalign*)ptr)->u16; }
static U32 LZ4_read32(const void* ptr) { return ((const LZ4_unalign*)ptr)->u32; }
static reg_t LZ4_read_ARCH(const void* ptr) { return ((const LZ4_unalign*)ptr)->uArch; }
static void LZ4_write16(void* memPtr, U16 value) { ((LZ4_unalign*)memPtr)->u16 = value; }
static void LZ4_write32(void* memPtr, U32 value) { ((LZ4_unalign*)memPtr)->u32 = value; }
static U16 LZ4_readLE16(const void* memPtr)
{
    if (LZ4_isLittleEndian()) {
        return LZ4_read16(memPtr);
    } else {
        const BYTE* p = (const BYTE*)memPtr;
        return (U16)((U16)p[0] + (p[1]<<8));
    }
}
static void LZ4_writeLE16(void* memPtr, U16 value)
{
    if (LZ4_isLittleEndian()) {
        LZ4_write16(memPtr, value);
    } else {
        BYTE* p = (BYTE*)memPtr;
        p[0] = (BYTE) value;
        p[1] = (BYTE)(value>>8);
    }
}
static inline __attribute__((always_inline))
void LZ4_wildCopy8(void* dstPtr, const void* srcPtr, void* dstEnd)
{
    BYTE* d = (BYTE*)dstPtr;
    const BYTE* s = (const BYTE*)srcPtr;
    BYTE* const e = (BYTE*)dstEnd;
    do { __builtin_memcpy(d, s, 8); d+=8; s+=8; } while (d<e);
}
static const unsigned inc32table[8] = {0, 1, 2, 1, 0, 4, 4, 4};
static const int dec64table[8] = {0, 0, 0, -1, -4, 1, 2, 3};
static inline __attribute__((always_inline)) void
LZ4_memcpy_using_offset_base(BYTE* dstPtr, const BYTE* srcPtr, BYTE* dstEnd, const size_t offset)
{
    ((void)0);
    if (offset < 8) {
        LZ4_write32(dstPtr, 0);
        dstPtr[0] = srcPtr[0];
        dstPtr[1] = srcPtr[1];
        dstPtr[2] = srcPtr[2];
        dstPtr[3] = srcPtr[3];
        srcPtr += inc32table[offset];
        __builtin_memcpy(dstPtr+4, srcPtr, 4);
        srcPtr -= dec64table[offset];
        dstPtr += 8;
    } else {
        __builtin_memcpy(dstPtr, srcPtr, 8);
        dstPtr += 8;
        srcPtr += 8;
    }
    LZ4_wildCopy8(dstPtr, srcPtr, dstEnd);
}
static inline __attribute__((always_inline)) void
LZ4_wildCopy32(void* dstPtr, const void* srcPtr, void* dstEnd)
{
    BYTE* d = (BYTE*)dstPtr;
    const BYTE* s = (const BYTE*)srcPtr;
    BYTE* const e = (BYTE*)dstEnd;
    do { __builtin_memcpy(d, s, 16); __builtin_memcpy(d+16, s+16, 16); d+=32; s+=32; } while (d<e);
}
static inline __attribute__((always_inline)) void
LZ4_memcpy_using_offset(BYTE* dstPtr, const BYTE* srcPtr, BYTE* dstEnd, const size_t offset)
{
    BYTE v[8];
    ((void)0);
    switch(offset) {
    case 1:
        memset(((v)),((*srcPtr)),((8)));
        break;
    case 2:
        __builtin_memcpy(v, srcPtr, 2);
        __builtin_memcpy(&v[2], srcPtr, 2);
        __builtin_memcpy(&v[4], v, 4);
        break;
    case 4:
        __builtin_memcpy(v, srcPtr, 4);
        __builtin_memcpy(&v[4], srcPtr, 4);
        break;
    default:
        LZ4_memcpy_using_offset_base(dstPtr, srcPtr, dstEnd, offset);
        return;
    }
    __builtin_memcpy(dstPtr, v, 8);
    dstPtr += 8;
    while (dstPtr < dstEnd) {
        __builtin_memcpy(dstPtr, v, 8);
        dstPtr += 8;
    }
}
static unsigned LZ4_NbCommonBytes (reg_t val)
{
    ((void)0);
    if (LZ4_isLittleEndian()) {
        if (sizeof(val) == 8) {
            return (unsigned)__builtin_ctzll((U64)val) >> 3;
        } else {
            return (unsigned)__builtin_ctz((U32)val) >> 3;
        }
    } else {
        if (sizeof(val)==8) {
            return (unsigned)__builtin_clzll((U64)val) >> 3;
        } else {
            return (unsigned)__builtin_clz((U32)val) >> 3;
        }
    }
}
static inline __attribute__((always_inline))
unsigned LZ4_count(const BYTE* pIn, const BYTE* pMatch, const BYTE* pInLimit)
{
    const BYTE* const pStart = pIn;
    if ((__builtin_expect (((pIn < pInLimit-(sizeof(reg_t)-1)) != 0),(1)) )) {
        reg_t const diff = LZ4_read_ARCH(pMatch) ^ LZ4_read_ARCH(pIn);
        if (!diff) {
            pIn+=sizeof(reg_t); pMatch+=sizeof(reg_t);
        } else {
            return LZ4_NbCommonBytes(diff);
    } }
    while ((__builtin_expect (((pIn < pInLimit-(sizeof(reg_t)-1)) != 0),(1)) )) {
        reg_t const diff = LZ4_read_ARCH(pMatch) ^ LZ4_read_ARCH(pIn);
        if (!diff) { pIn+=sizeof(reg_t); pMatch+=sizeof(reg_t); continue; }
        pIn += LZ4_NbCommonBytes(diff);
        return (unsigned)(pIn - pStart);
    }
    if ((sizeof(reg_t)==8) && (pIn<(pInLimit-3)) && (LZ4_read32(pMatch) == LZ4_read32(pIn))) { pIn+=4; pMatch+=4; }
    if ((pIn<(pInLimit-1)) && (LZ4_read16(pMatch) == LZ4_read16(pIn))) { pIn+=2; pMatch+=2; }
    if ((pIn<pInLimit) && (*pMatch == *pIn)) pIn++;
    return (unsigned)(pIn - pStart);
}
typedef enum { noDictCtx, usingDictCtxHc } dictCtx_directive;
static U32 LZ4HC_hashPtr(const void* ptr) { return (((LZ4_read32(ptr)) * 2654435761U) >> ((4*8)-15)); }
static void LZ4HC_clearTables (LZ4HC_CCtx_internal* hc4)
{
    memset(((hc4->hashTable)),((0)),((sizeof(hc4->hashTable))));
    memset(((hc4->chainTable)),((0xFF)),((sizeof(hc4->chainTable))));
}
static void LZ4HC_init_internal (LZ4HC_CCtx_internal* hc4, const BYTE* start)
{
    size_t const bufferSize = (size_t)(hc4->end - hc4->prefixStart);
    size_t newStartingOffset = bufferSize + hc4->dictLimit;
    ((void)0);
    if (newStartingOffset > 1 *(1U<<30)) {
        LZ4HC_clearTables(hc4);
        newStartingOffset = 0;
    }
    newStartingOffset += 64 *(1 <<10);
    hc4->nextToUpdate = (U32)newStartingOffset;
    hc4->prefixStart = start;
    hc4->end = start;
    hc4->dictStart = start;
    hc4->dictLimit = (U32)newStartingOffset;
    hc4->lowLimit = (U32)newStartingOffset;
}
static inline __attribute__((always_inline)) void LZ4HC_Insert (LZ4HC_CCtx_internal* hc4, const BYTE* ip)
{
    U16* const chainTable = hc4->chainTable;
    U32* const hashTable = hc4->hashTable;
    const BYTE* const prefixPtr = hc4->prefixStart;
    U32 const prefixIdx = hc4->dictLimit;
    U32 const target = (U32)(ip - prefixPtr) + prefixIdx;
    U32 idx = hc4->nextToUpdate;
    ((void)0);
    ((void)0);
    while (idx < target) {
        U32 const h = LZ4HC_hashPtr(prefixPtr+idx-prefixIdx);
        size_t delta = idx - hashTable[h];
        if (delta>65535) delta = 65535;
        chainTable[(U16)(idx)] = (U16)delta;
        hashTable[h] = idx;
        idx++;
    }
    hc4->nextToUpdate = target;
}
static inline __attribute__((always_inline))
int LZ4HC_countBack(const BYTE* const ip, const BYTE* const match,
                    const BYTE* const iMin, const BYTE* const mMin)
{
    int back = 0;
    int const min = (int)( (iMin - ip) > (mMin - match) ? (iMin - ip) : (mMin - match) );
    ((void)0);
    ((void)0); ((void)0);
    ((void)0); ((void)0);
    while ( (back > min)
         && (ip[back-1] == match[back-1]) )
            back--;
    return back;
}
static U32 LZ4HC_rotatePattern(size_t const rotate, U32 const pattern)
{
    size_t const bitsToRotate = (rotate & (sizeof(pattern) - 1)) << 3;
    if (bitsToRotate == 0) return pattern;
    return ((pattern << (int)bitsToRotate) | (pattern >> (32 - (int)bitsToRotate)));
}
static unsigned
LZ4HC_countPattern(const BYTE* ip, const BYTE* const iEnd, U32 const pattern32)
{
    const BYTE* const iStart = ip;
    reg_t const pattern = (sizeof(pattern)==8) ?
        (reg_t)pattern32 + (((reg_t)pattern32) << (sizeof(pattern)*4)) : pattern32;
    while ((__builtin_expect (((ip < iEnd-(sizeof(pattern)-1)) != 0),(1)) )) {
        reg_t const diff = LZ4_read_ARCH(ip) ^ pattern;
        if (!diff) { ip+=sizeof(pattern); continue; }
        ip += LZ4_NbCommonBytes(diff);
        return (unsigned)(ip - iStart);
    }
    if (LZ4_isLittleEndian()) {
        reg_t patternByte = pattern;
        while ((ip<iEnd) && (*ip == (BYTE)patternByte)) {
            ip++; patternByte >>= 8;
        }
    } else {
        U32 bitOffset = (sizeof(pattern)*8) - 8;
        while (ip < iEnd) {
            BYTE const byte = (BYTE)(pattern >> bitOffset);
            if (*ip != byte) break;
            ip ++; bitOffset -= 8;
    } }
    return (unsigned)(ip - iStart);
}
static unsigned
LZ4HC_reverseCountPattern(const BYTE* ip, const BYTE* const iLow, U32 pattern)
{
    const BYTE* const iStart = ip;
    while ((__builtin_expect (((ip >= iLow+4) != 0),(1)) )) {
        if (LZ4_read32(ip-4) != pattern) break;
        ip -= 4;
    }
    { const BYTE* bytePtr = (const BYTE*)(&pattern) + 3;
        while ((__builtin_expect (((ip>iLow) != 0),(1)) )) {
            if (ip[-1] != *bytePtr) break;
            ip--; bytePtr--;
    } }
    return (unsigned)(iStart - ip);
}
static int LZ4HC_protectDictEnd(U32 const dictLimit, U32 const matchIndex)
{
    return ((U32)((dictLimit - 1) - matchIndex) >= 3);
}
typedef enum { rep_untested, rep_not, rep_confirmed } repeat_state_e;
typedef enum { favorCompressionRatio=0, favorDecompressionSpeed } HCfavor_e;
static inline __attribute__((always_inline)) int
LZ4HC_InsertAndGetWiderMatch (
        LZ4HC_CCtx_internal* const hc4,
        const BYTE* const ip,
        const BYTE* const iLowLimit, const BYTE* const iHighLimit,
        int longest,
        const BYTE** matchpos,
        const BYTE** startpos,
        const int maxNbAttempts,
        const int patternAnalysis, const int chainSwap,
        const dictCtx_directive dict,
        const HCfavor_e favorDecSpeed)
{
    U16* const chainTable = hc4->chainTable;
    U32* const HashTable = hc4->hashTable;
    const LZ4HC_CCtx_internal * const dictCtx = hc4->dictCtx;
    const BYTE* const prefixPtr = hc4->prefixStart;
    const U32 prefixIdx = hc4->dictLimit;
    const U32 ipIndex = (U32)(ip - prefixPtr) + prefixIdx;
    const int withinStartDistance = (hc4->lowLimit + (65535 + 1) > ipIndex);
    const U32 lowestMatchIndex = (withinStartDistance) ? hc4->lowLimit : ipIndex - 65535;
    const BYTE* const dictStart = hc4->dictStart;
    const U32 dictIdx = hc4->lowLimit;
    const BYTE* const dictEnd = dictStart + prefixIdx - dictIdx;
    int const lookBackLength = (int)(ip-iLowLimit);
    int nbAttempts = maxNbAttempts;
    U32 matchChainPos = 0;
    U32 const pattern = LZ4_read32(ip);
    U32 matchIndex;
    repeat_state_e repeat = rep_untested;
    size_t srcPatternLength = 0;
    {};
    LZ4HC_Insert(hc4, ip);
    matchIndex = HashTable[LZ4HC_hashPtr(ip)];
    {};
    while ((matchIndex>=lowestMatchIndex) && (nbAttempts>0)) {
        int matchLength=0;
        nbAttempts--;
        ((void)0);
        if (favorDecSpeed && (ipIndex - matchIndex < 8)) {
        } else if (matchIndex >= prefixIdx) {
            const BYTE* const matchPtr = prefixPtr + matchIndex - prefixIdx;
            ((void)0);
            ((void)0);
            if (LZ4_read16(iLowLimit + longest - 1) == LZ4_read16(matchPtr - lookBackLength + longest - 1)) {
                if (LZ4_read32(matchPtr) == pattern) {
                    int const back = lookBackLength ? LZ4HC_countBack(ip, matchPtr, iLowLimit, prefixPtr) : 0;
                    matchLength = 4 + (int)LZ4_count(ip+4, matchPtr+4, iHighLimit);
                    matchLength -= back;
                    if (matchLength > longest) {
                        longest = matchLength;
                        *matchpos = matchPtr + back;
                        *startpos = ip + back;
            } } }
        } else {
            const BYTE* const matchPtr = dictStart + (matchIndex - dictIdx);
            ((void)0);
            if ( (__builtin_expect (((matchIndex <= prefixIdx - 4) != 0),(1)) )
              && (LZ4_read32(matchPtr) == pattern) ) {
                int back = 0;
                const BYTE* vLimit = ip + (prefixIdx - matchIndex);
                if (vLimit > iHighLimit) vLimit = iHighLimit;
                matchLength = (int)LZ4_count(ip+4, matchPtr+4, vLimit) + 4;
                if ((ip+matchLength == vLimit) && (vLimit < iHighLimit))
                    matchLength += LZ4_count(ip+matchLength, prefixPtr, iHighLimit);
                back = lookBackLength ? LZ4HC_countBack(ip, matchPtr, iLowLimit, dictStart) : 0;
                matchLength -= back;
                if (matchLength > longest) {
                    longest = matchLength;
                    *matchpos = prefixPtr - prefixIdx + matchIndex + back;
                    *startpos = ip + back;
        } } }
        if (chainSwap && matchLength==longest) {
            ((void)0);
            if (matchIndex + (U32)longest <= ipIndex) {
                int const kTrigger = 4;
                U32 distanceToNextMatch = 1;
                int const end = longest - 4 + 1;
                int step = 1;
                int accel = 1 << kTrigger;
                int pos;
                for (pos = 0; pos < end; pos += step) {
                    U32 const candidateDist = chainTable[(U16)(matchIndex + (U32)pos)];
                    step = (accel++ >> kTrigger);
                    if (candidateDist > distanceToNextMatch) {
                        distanceToNextMatch = candidateDist;
                        matchChainPos = (U32)pos;
                        accel = 1 << kTrigger;
                } }
                if (distanceToNextMatch > 1) {
                    if (distanceToNextMatch > matchIndex) break;
                    matchIndex -= distanceToNextMatch;
                    continue;
        } } }
        { U32 const distNextMatch = chainTable[(U16)(matchIndex)];
            if (patternAnalysis && distNextMatch==1 && matchChainPos==0) {
                U32 const matchCandidateIdx = matchIndex-1;
                if (repeat == rep_untested) {
                    if ( ((pattern & 0xFFFF) == (pattern >> 16))
                      & ((pattern & 0xFF) == (pattern >> 24)) ) {
                        repeat = rep_confirmed;
                        srcPatternLength = LZ4HC_countPattern(ip+sizeof(pattern), iHighLimit, pattern) + sizeof(pattern);
                    } else {
                        repeat = rep_not;
                } }
                if ( (repeat == rep_confirmed) && (matchCandidateIdx >= lowestMatchIndex)
                  && LZ4HC_protectDictEnd(prefixIdx, matchCandidateIdx) ) {
                    const int extDict = matchCandidateIdx < prefixIdx;
                    const BYTE* const matchPtr = (extDict ? dictStart - dictIdx : prefixPtr - prefixIdx) + matchCandidateIdx;
                    if (LZ4_read32(matchPtr) == pattern) {
                        const BYTE* const iLimit = extDict ? dictEnd : iHighLimit;
                        size_t forwardPatternLength = LZ4HC_countPattern(matchPtr+sizeof(pattern), iLimit, pattern) + sizeof(pattern);
                        if (extDict && matchPtr + forwardPatternLength == iLimit) {
                            U32 const rotatedPattern = LZ4HC_rotatePattern(forwardPatternLength, pattern);
                            forwardPatternLength += LZ4HC_countPattern(prefixPtr, iHighLimit, rotatedPattern);
                        }
                        { const BYTE* const lowestMatchPtr = extDict ? dictStart : prefixPtr;
                            size_t backLength = LZ4HC_reverseCountPattern(matchPtr, lowestMatchPtr, pattern);
                            size_t currentSegmentLength;
                            if (!extDict
                              && matchPtr - backLength == prefixPtr
                              && dictIdx < prefixIdx) {
                                U32 const rotatedPattern = LZ4HC_rotatePattern((U32)(-(int)backLength), pattern);
                                backLength += LZ4HC_reverseCountPattern(dictEnd, dictStart, rotatedPattern);
                            }
                            backLength = matchCandidateIdx - ( (matchCandidateIdx - (U32)backLength) > (lowestMatchIndex) ? (matchCandidateIdx - (U32)backLength) : (lowestMatchIndex) );
                            ((void)0);
                            currentSegmentLength = backLength + forwardPatternLength;
                            if ( (currentSegmentLength >= srcPatternLength)
                              && (forwardPatternLength <= srcPatternLength) ) {
                                U32 const newMatchIndex = matchCandidateIdx + (U32)forwardPatternLength - (U32)srcPatternLength;
                                if (LZ4HC_protectDictEnd(prefixIdx, newMatchIndex))
                                    matchIndex = newMatchIndex;
                                else {
                                    ((void)0);
                                    matchIndex = prefixIdx;
                                }
                            } else {
                                U32 const newMatchIndex = matchCandidateIdx - (U32)backLength;
                                if (!LZ4HC_protectDictEnd(prefixIdx, newMatchIndex)) {
                                    ((void)0);
                                    matchIndex = prefixIdx;
                                } else {
                                    matchIndex = newMatchIndex;
                                    if (lookBackLength==0) {
                                        size_t const maxML = ( (currentSegmentLength) < (srcPatternLength) ? (currentSegmentLength) : (srcPatternLength) );
                                        if ((size_t)longest < maxML) {
                                            ((void)0);
                                            if ((size_t)(ip - prefixPtr) + prefixIdx - matchIndex > 65535) break;
                                            ((void)0);
                                            longest = (int)maxML;
                                            *matchpos = prefixPtr - prefixIdx + matchIndex;
                                            *startpos = ip;
                                        }
                                        { U32 const distToNextPattern = chainTable[(U16)(matchIndex)];
                                            if (distToNextPattern > matchIndex) break;
                                            matchIndex -= distToNextPattern;
                        } } } } }
                        continue;
                } }
        } }
        matchIndex -= chainTable[(U16)(matchIndex + matchChainPos)];
    }
    if ( dict == usingDictCtxHc
      && nbAttempts > 0
      && ipIndex - lowestMatchIndex < 65535) {
        size_t const dictEndOffset = (size_t)(dictCtx->end - dictCtx->prefixStart) + dictCtx->dictLimit;
        U32 dictMatchIndex = dictCtx->hashTable[LZ4HC_hashPtr(ip)];
        ((void)0);
        matchIndex = dictMatchIndex + lowestMatchIndex - (U32)dictEndOffset;
        while (ipIndex - matchIndex <= 65535 && nbAttempts--) {
            const BYTE* const matchPtr = dictCtx->prefixStart - dictCtx->dictLimit + dictMatchIndex;
            if (LZ4_read32(matchPtr) == pattern) {
                int mlt;
                int back = 0;
                const BYTE* vLimit = ip + (dictEndOffset - dictMatchIndex);
                if (vLimit > iHighLimit) vLimit = iHighLimit;
                mlt = (int)LZ4_count(ip+4, matchPtr+4, vLimit) + 4;
                back = lookBackLength ? LZ4HC_countBack(ip, matchPtr, iLowLimit, dictCtx->prefixStart) : 0;
                mlt -= back;
                if (mlt > longest) {
                    longest = mlt;
                    *matchpos = prefixPtr - prefixIdx + matchIndex + back;
                    *startpos = ip + back;
            } }
            { U32 const nextOffset = dictCtx->chainTable[(U16)(dictMatchIndex)];
                dictMatchIndex -= nextOffset;
                matchIndex -= nextOffset;
    } } }
    return longest;
}
static inline __attribute__((always_inline)) int
LZ4HC_InsertAndFindBestMatch(LZ4HC_CCtx_internal* const hc4,
                       const BYTE* const ip, const BYTE* const iLimit,
                       const BYTE** matchpos,
                       const int maxNbAttempts,
                       const int patternAnalysis,
                       const dictCtx_directive dict)
{
    const BYTE* uselessPtr = ip;
    return LZ4HC_InsertAndGetWiderMatch(hc4, ip, ip, iLimit, 4 -1, matchpos, &uselessPtr, maxNbAttempts, patternAnalysis, 0 , dict, favorCompressionRatio);
}
static inline __attribute__((always_inline)) int LZ4HC_encodeSequence (
    const BYTE** _ip,
    BYTE** _op,
    const BYTE** _anchor,
    int matchLength,
    const BYTE* const match,
    limitedOutput_directive limit,
    BYTE* oend)
{
    size_t length;
    BYTE* const token = (*_op)++;
    length = (size_t)((*_ip) - (*_anchor));
    { enum { LZ4_static_assert = 1/(int)(!!(notLimited == 0)) }; };
    if (limit && (((*_op) + (length / 255) + length + (2 + 1 + 5)) > oend)) {
        {};
        return 1;
    }
    if (length >= ((1U<<(8-4))-1)) {
        size_t len = length - ((1U<<(8-4))-1);
        *token = (((1U<<(8-4))-1) << 4);
        for(; len >= 255 ; len -= 255) *(*_op)++ = 255;
        *(*_op)++ = (BYTE)len;
    } else {
        *token = (BYTE)(length << 4);
    }
    LZ4_wildCopy8((*_op), (*_anchor), (*_op) + length);
    (*_op) += length;
    ((void)0);
    LZ4_writeLE16((*_op), (U16)((*_ip) - match)); (*_op) += 2;
    ((void)0);
    length = (size_t)matchLength - 4;
    if (limit && ((*_op) + (length / 255) + (1 + 5) > oend)) {
        {};
        return 1;
    }
    if (length >= ((1U<<4)-1)) {
        *token += ((1U<<4)-1);
        length -= ((1U<<4)-1);
        for(; length >= 510 ; length -= 510) { *(*_op)++ = 255; *(*_op)++ = 255; }
        if (length >= 255) { length -= 255; *(*_op)++ = 255; }
        *(*_op)++ = (BYTE)length;
    } else {
        *token += (BYTE)(length);
    }
    (*_ip) += matchLength;
    (*_anchor) = (*_ip);
    return 0;
}
static inline __attribute__((always_inline)) int LZ4HC_compress_hashChain (
    LZ4HC_CCtx_internal* const ctx,
    const char* const source,
    char* const dest,
    int* srcSizePtr,
    int const maxOutputSize,
    int maxNbAttempts,
    const limitedOutput_directive limit,
    const dictCtx_directive dict
    )
{
    const int inputSize = *srcSizePtr;
    const int patternAnalysis = (maxNbAttempts > 128);
    const BYTE* ip = (const BYTE*) source;
    const BYTE* anchor = ip;
    const BYTE* const iend = ip + inputSize;
    const BYTE* const mflimit = iend - 12;
    const BYTE* const matchlimit = (iend - 5);
    BYTE* optr = (BYTE*) dest;
    BYTE* op = (BYTE*) dest;
    BYTE* oend = op + maxOutputSize;
    int ml0, ml, ml2, ml3;
    const BYTE* start0;
    const BYTE* ref0;
    const BYTE* ref = ((void*)0);
    const BYTE* start2 = ((void*)0);
    const BYTE* ref2 = ((void*)0);
    const BYTE* start3 = ((void*)0);
    const BYTE* ref3 = ((void*)0);
    *srcSizePtr = 0;
    if (limit == fillOutput) oend -= 5;
    if (inputSize < LZ4_minLength) goto _last_literals;
    while (ip <= mflimit) {
        ml = LZ4HC_InsertAndFindBestMatch(ctx, ip, matchlimit, &ref, maxNbAttempts, patternAnalysis, dict);
        if (ml<4) { ip++; continue; }
        start0 = ip; ref0 = ref; ml0 = ml;
_Search2:
        if (ip+ml <= mflimit) {
            ml2 = LZ4HC_InsertAndGetWiderMatch(ctx,
                            ip + ml - 2, ip + 0, matchlimit, ml, &ref2, &start2,
                            maxNbAttempts, patternAnalysis, 0, dict, favorCompressionRatio);
        } else {
            ml2 = ml;
        }
        if (ml2 == ml) {
            optr = op;
            if (LZ4HC_encodeSequence(&ip, &op, &anchor, ml, ref, limit, oend)) goto _dest_overflow;
            continue;
        }
        if (start0 < ip) {
            if (start2 < ip + ml0) {
                ip = start0; ref = ref0; ml = ml0;
        } }
        if ((start2 - ip) < 3) {
            ml = ml2;
            ip = start2;
            ref =ref2;
            goto _Search2;
        }
_Search3:
        if ((start2 - ip) < (int)((((1U<<4)-1)-1)+4)) {
            int correction;
            int new_ml = ml;
            if (new_ml > (int)((((1U<<4)-1)-1)+4)) new_ml = (int)((((1U<<4)-1)-1)+4);
            if (ip+new_ml > start2 + ml2 - 4) new_ml = (int)(start2 - ip) + ml2 - 4;
            correction = new_ml - (int)(start2 - ip);
            if (correction > 0) {
                start2 += correction;
                ref2 += correction;
                ml2 -= correction;
            }
        }
        if (start2 + ml2 <= mflimit) {
            ml3 = LZ4HC_InsertAndGetWiderMatch(ctx,
                            start2 + ml2 - 3, start2, matchlimit, ml2, &ref3, &start3,
                            maxNbAttempts, patternAnalysis, 0, dict, favorCompressionRatio);
        } else {
            ml3 = ml2;
        }
        if (ml3 == ml2) {
            if (start2 < ip+ml) ml = (int)(start2 - ip);
            optr = op;
            if (LZ4HC_encodeSequence(&ip, &op, &anchor, ml, ref, limit, oend)) goto _dest_overflow;
            ip = start2;
            optr = op;
            if (LZ4HC_encodeSequence(&ip, &op, &anchor, ml2, ref2, limit, oend)) {
                ml = ml2;
                ref = ref2;
                goto _dest_overflow;
            }
            continue;
        }
        if (start3 < ip+ml+3) {
            if (start3 >= (ip+ml)) {
                if (start2 < ip+ml) {
                    int correction = (int)(ip+ml - start2);
                    start2 += correction;
                    ref2 += correction;
                    ml2 -= correction;
                    if (ml2 < 4) {
                        start2 = start3;
                        ref2 = ref3;
                        ml2 = ml3;
                    }
                }
                optr = op;
                if (LZ4HC_encodeSequence(&ip, &op, &anchor, ml, ref, limit, oend)) goto _dest_overflow;
                ip = start3;
                ref = ref3;
                ml = ml3;
                start0 = start2;
                ref0 = ref2;
                ml0 = ml2;
                goto _Search2;
            }
            start2 = start3;
            ref2 = ref3;
            ml2 = ml3;
            goto _Search3;
        }
        if (start2 < ip+ml) {
            if ((start2 - ip) < (int)((((1U<<4)-1)-1)+4)) {
                int correction;
                if (ml > (int)((((1U<<4)-1)-1)+4)) ml = (int)((((1U<<4)-1)-1)+4);
                if (ip + ml > start2 + ml2 - 4) ml = (int)(start2 - ip) + ml2 - 4;
                correction = ml - (int)(start2 - ip);
                if (correction > 0) {
                    start2 += correction;
                    ref2 += correction;
                    ml2 -= correction;
                }
            } else {
                ml = (int)(start2 - ip);
            }
        }
        optr = op;
        if (LZ4HC_encodeSequence(&ip, &op, &anchor, ml, ref, limit, oend)) goto _dest_overflow;
        ip = start2; ref = ref2; ml = ml2;
        start2 = start3; ref2 = ref3; ml2 = ml3;
        goto _Search3;
    }
_last_literals:
    { size_t lastRunSize = (size_t)(iend - anchor);
        size_t llAdd = (lastRunSize + 255 - ((1U<<(8-4))-1)) / 255;
        size_t const totalSize = 1 + llAdd + lastRunSize;
        if (limit == fillOutput) oend += 5;
        if (limit && (op + totalSize > oend)) {
            if (limit == limitedOutput) return 0;
            lastRunSize = (size_t)(oend - op) - 1 ;
            llAdd = (lastRunSize + 256 - ((1U<<(8-4))-1)) / 256;
            lastRunSize -= llAdd;
        }
        {};
        ip = anchor + lastRunSize;
        if (lastRunSize >= ((1U<<(8-4))-1)) {
            size_t accumulator = lastRunSize - ((1U<<(8-4))-1);
            *op++ = (((1U<<(8-4))-1) << 4);
            for(; accumulator >= 255 ; accumulator -= 255) *op++ = 255;
            *op++ = (BYTE) accumulator;
        } else {
            *op++ = (BYTE)(lastRunSize << 4);
        }
        __builtin_memcpy(op, anchor, lastRunSize);
        op += lastRunSize;
    }
    *srcSizePtr = (int) (((const char*)ip) - source);
    return (int) (((char*)op)-dest);
_dest_overflow:
    if (limit == fillOutput) {
        size_t const ll = (size_t)(ip - anchor);
        size_t const ll_addbytes = (ll + 240) / 255;
        size_t const ll_totalCost = 1 + ll_addbytes + ll;
        BYTE* const maxLitPos = oend - 3;
        {};
        op = optr;
        if (op + ll_totalCost <= maxLitPos) {
            size_t const bytesLeftForMl = (size_t)(maxLitPos - (op+ll_totalCost));
            size_t const maxMlSize = 4 + (((1U<<4)-1)-1) + (bytesLeftForMl * 255);
            ((void)0); ((void)0);
            if ((size_t)ml > maxMlSize) ml = (int)maxMlSize;
            if ((oend + 5) - (op + ll_totalCost + 2) - 1 + ml >= 12) {
                LZ4HC_encodeSequence(&ip, &op, &anchor, ml, ref, notLimited, oend);
        } }
        goto _last_literals;
    }
    return 0;
}
static int LZ4HC_compress_optimal( LZ4HC_CCtx_internal* ctx,
    const char* const source, char* dst,
    int* srcSizePtr, int dstCapacity,
    int const nbSearches, size_t sufficient_len,
    const limitedOutput_directive limit, int const fullUpdate,
    const dictCtx_directive dict,
    const HCfavor_e favorDecSpeed);
static inline __attribute__((always_inline)) int LZ4HC_compress_generic_internal (
    LZ4HC_CCtx_internal* const ctx,
    const char* const src,
    char* const dst,
    int* const srcSizePtr,
    int const dstCapacity,
    int cLevel,
    const limitedOutput_directive limit,
    const dictCtx_directive dict
    )
{
    typedef enum { lz4hc, lz4opt } lz4hc_strat_e;
    typedef struct {
        lz4hc_strat_e strat;
        int nbSearches;
        U32 targetLength;
    } cParams_t;
    static const cParams_t clTable[12 +1] = {
        { lz4hc, 2, 16 },
        { lz4hc, 2, 16 },
        { lz4hc, 2, 16 },
        { lz4hc, 4, 16 },
        { lz4hc, 8, 16 },
        { lz4hc, 16, 16 },
        { lz4hc, 32, 16 },
        { lz4hc, 64, 16 },
        { lz4hc, 128, 16 },
        { lz4hc, 256, 16 },
        { lz4opt, 96, 64 },
        { lz4opt, 512,128 },
        { lz4opt,16384,(1<<12) },
    };
    {};
    if (limit == fillOutput && dstCapacity < 1) return 0;
    if ((U32)*srcSizePtr > (U32)0x7E000000) return 0;
    ctx->end += *srcSizePtr;
    if (cLevel < 1) cLevel = 9;
    cLevel = ( (12) < (cLevel) ? (12) : (cLevel) );
    { cParams_t const cParam = clTable[cLevel];
        HCfavor_e const favor = ctx->favorDecSpeed ? favorDecompressionSpeed : favorCompressionRatio;
        int result;
        if (cParam.strat == lz4hc) {
            result = LZ4HC_compress_hashChain(ctx,
                                src, dst, srcSizePtr, dstCapacity,
                                cParam.nbSearches, limit, dict);
        } else {
            ((void)0);
            result = LZ4HC_compress_optimal(ctx,
                                src, dst, srcSizePtr, dstCapacity,
                                cParam.nbSearches, cParam.targetLength, limit,
                                cLevel == 12,
                                dict, favor);
        }
        if (result <= 0) ctx->dirty = 1;
        return result;
    }
}
static void LZ4HC_setExternalDict(LZ4HC_CCtx_internal* ctxPtr, const BYTE* newBlock);
static int
LZ4HC_compress_generic_noDictCtx (
        LZ4HC_CCtx_internal* const ctx,
        const char* const src,
        char* const dst,
        int* const srcSizePtr,
        int const dstCapacity,
        int cLevel,
        limitedOutput_directive limit
        )
{
    ((void)0);
    return LZ4HC_compress_generic_internal(ctx, src, dst, srcSizePtr, dstCapacity, cLevel, limit, noDictCtx);
}
static int
LZ4HC_compress_generic_dictCtx (
        LZ4HC_CCtx_internal* const ctx,
        const char* const src,
        char* const dst,
        int* const srcSizePtr,
        int const dstCapacity,
        int cLevel,
        limitedOutput_directive limit
        )
{
    const size_t position = (size_t)(ctx->end - ctx->prefixStart) + (ctx->dictLimit - ctx->lowLimit);
    ((void)0);
    if (position >= 64 *(1 <<10)) {
        ctx->dictCtx = ((void*)0);
        return LZ4HC_compress_generic_noDictCtx(ctx, src, dst, srcSizePtr, dstCapacity, cLevel, limit);
    } else if (position == 0 && *srcSizePtr > 4 *(1 <<10)) {
        __builtin_memcpy(ctx, ctx->dictCtx, sizeof(LZ4HC_CCtx_internal));
        LZ4HC_setExternalDict(ctx, (const BYTE *)src);
        ctx->compressionLevel = (short)cLevel;
        return LZ4HC_compress_generic_noDictCtx(ctx, src, dst, srcSizePtr, dstCapacity, cLevel, limit);
    } else {
        return LZ4HC_compress_generic_internal(ctx, src, dst, srcSizePtr, dstCapacity, cLevel, limit, usingDictCtxHc);
    }
}
static int
LZ4HC_compress_generic (
        LZ4HC_CCtx_internal* const ctx,
        const char* const src,
        char* const dst,
        int* const srcSizePtr,
        int const dstCapacity,
        int cLevel,
        limitedOutput_directive limit
        )
{
    if (ctx->dictCtx == ((void*)0)) {
        return LZ4HC_compress_generic_noDictCtx(ctx, src, dst, srcSizePtr, dstCapacity, cLevel, limit);
    } else {
        return LZ4HC_compress_generic_dictCtx(ctx, src, dst, srcSizePtr, dstCapacity, cLevel, limit);
    }
}
int LZ4_sizeofStateHC(void) { return (int)sizeof(LZ4_streamHC_t); }
static size_t LZ4_streamHC_t_alignment(void)
{
    typedef struct { char c; LZ4_streamHC_t t; } t_a;
    return sizeof(t_a) - sizeof(LZ4_streamHC_t);
}
int LZ4_compress_HC_extStateHC_fastReset (void* state, const char* src, char* dst, int srcSize, int dstCapacity, int compressionLevel)
{
    LZ4HC_CCtx_internal* const ctx = &((LZ4_streamHC_t*)state)->internal_donotuse;
    if (!LZ4_isAligned(state, LZ4_streamHC_t_alignment())) return 0;
    LZ4_resetStreamHC_fast((LZ4_streamHC_t*)state, compressionLevel);
    LZ4HC_init_internal (ctx, (const BYTE*)src);
    if (dstCapacity < LZ4_compressBound(srcSize))
        return LZ4HC_compress_generic (ctx, src, dst, &srcSize, dstCapacity, compressionLevel, limitedOutput);
    else
        return LZ4HC_compress_generic (ctx, src, dst, &srcSize, dstCapacity, compressionLevel, notLimited);
}
int LZ4_compress_HC_extStateHC (void* state, const char* src, char* dst, int srcSize, int dstCapacity, int compressionLevel)
{
    LZ4_streamHC_t* const ctx = LZ4_initStreamHC(state, sizeof(*ctx));
    if (ctx==((void*)0)) return 0;
    return LZ4_compress_HC_extStateHC_fastReset(state, src, dst, srcSize, dstCapacity, compressionLevel);
}
int LZ4_compress_HC(const char* src, char* dst, int srcSize, int dstCapacity, int compressionLevel)
{
    int cSize;
    LZ4_streamHC_t* const statePtr = (LZ4_streamHC_t*)rd_kafka_mem_malloc(((void*)0), sizeof(LZ4_streamHC_t));
    if (statePtr==((void*)0)) return 0;
    cSize = LZ4_compress_HC_extStateHC(statePtr, src, dst, srcSize, dstCapacity, compressionLevel);
    rd_kafka_mem_free(((void*)0), statePtr);
    return cSize;
}
int LZ4_compress_HC_destSize(void* state, const char* source, char* dest, int* sourceSizePtr, int targetDestSize, int cLevel)
{
    LZ4_streamHC_t* const ctx = LZ4_initStreamHC(state, sizeof(*ctx));
    if (ctx==((void*)0)) return 0;
    LZ4HC_init_internal(&ctx->internal_donotuse, (const BYTE*) source);
    LZ4_setCompressionLevel(ctx, cLevel);
    return LZ4HC_compress_generic(&ctx->internal_donotuse, source, dest, sourceSizePtr, targetDestSize, cLevel, fillOutput);
}
LZ4_streamHC_t* LZ4_createStreamHC(void)
{
    LZ4_streamHC_t* const state =
        (LZ4_streamHC_t*)rd_kafka_mem_calloc(((void*)0), 1, sizeof(LZ4_streamHC_t));
    if (state == ((void*)0)) return ((void*)0);
    LZ4_setCompressionLevel(state, 9);
    return state;
}
int LZ4_freeStreamHC (LZ4_streamHC_t* LZ4_streamHCPtr)
{
    {};
    if (!LZ4_streamHCPtr) return 0;
    rd_kafka_mem_free(((void*)0), LZ4_streamHCPtr);
    return 0;
}
LZ4_streamHC_t* LZ4_initStreamHC (void* buffer, size_t size)
{
    LZ4_streamHC_t* const LZ4_streamHCPtr = (LZ4_streamHC_t*)buffer;
    {};
    if (buffer == ((void*)0)) return ((void*)0);
    if (size < sizeof(LZ4_streamHC_t)) return ((void*)0);
    if (!LZ4_isAligned(buffer, LZ4_streamHC_t_alignment())) return ((void*)0);
    { LZ4HC_CCtx_internal* const hcstate = &(LZ4_streamHCPtr->internal_donotuse);
      memset(((hcstate)),((0)),((sizeof(*hcstate)))); }
    LZ4_setCompressionLevel(LZ4_streamHCPtr, 9);
    return LZ4_streamHCPtr;
}
void LZ4_resetStreamHC (LZ4_streamHC_t* LZ4_streamHCPtr, int compressionLevel)
{
    LZ4_initStreamHC(LZ4_streamHCPtr, sizeof(*LZ4_streamHCPtr));
    LZ4_setCompressionLevel(LZ4_streamHCPtr, compressionLevel);
}
void LZ4_resetStreamHC_fast (LZ4_streamHC_t* LZ4_streamHCPtr, int compressionLevel)
{
    {};
    if (LZ4_streamHCPtr->internal_donotuse.dirty) {
        LZ4_initStreamHC(LZ4_streamHCPtr, sizeof(*LZ4_streamHCPtr));
    } else {
        if (LZ4_streamHCPtr->internal_donotuse.end != ((void*)0)) {
            LZ4_streamHCPtr->internal_donotuse.end -= (uptrval)LZ4_streamHCPtr->internal_donotuse.prefixStart;
        } else {
            ((void)0);
        }
        LZ4_streamHCPtr->internal_donotuse.prefixStart = ((void*)0);
        LZ4_streamHCPtr->internal_donotuse.dictCtx = ((void*)0);
    }
    LZ4_setCompressionLevel(LZ4_streamHCPtr, compressionLevel);
}
void LZ4_setCompressionLevel(LZ4_streamHC_t* LZ4_streamHCPtr, int compressionLevel)
{
    {};
    if (compressionLevel < 1) compressionLevel = 9;
    if (compressionLevel > 12) compressionLevel = 12;
    LZ4_streamHCPtr->internal_donotuse.compressionLevel = (short)compressionLevel;
}
void LZ4_favorDecompressionSpeed(LZ4_streamHC_t* LZ4_streamHCPtr, int favor)
{
    LZ4_streamHCPtr->internal_donotuse.favorDecSpeed = (favor!=0);
}
int LZ4_loadDictHC (LZ4_streamHC_t* LZ4_streamHCPtr,
              const char* dictionary, int dictSize)
{
    LZ4HC_CCtx_internal* const ctxPtr = &LZ4_streamHCPtr->internal_donotuse;
    {};
    ((void)0);
    if (dictSize > 64 *(1 <<10)) {
        dictionary += (size_t)dictSize - 64 *(1 <<10);
        dictSize = 64 *(1 <<10);
    }
    { int const cLevel = ctxPtr->compressionLevel;
        LZ4_initStreamHC(LZ4_streamHCPtr, sizeof(*LZ4_streamHCPtr));
        LZ4_setCompressionLevel(LZ4_streamHCPtr, cLevel);
    }
    LZ4HC_init_internal (ctxPtr, (const BYTE*)dictionary);
    ctxPtr->end = (const BYTE*)dictionary + dictSize;
    if (dictSize >= 4) LZ4HC_Insert (ctxPtr, ctxPtr->end-3);
    return dictSize;
}
void LZ4_attach_HC_dictionary(LZ4_streamHC_t *working_stream, const LZ4_streamHC_t *dictionary_stream) {
    working_stream->internal_donotuse.dictCtx = dictionary_stream != ((void*)0) ? &(dictionary_stream->internal_donotuse) : ((void*)0);
}
static void LZ4HC_setExternalDict(LZ4HC_CCtx_internal* ctxPtr, const BYTE* newBlock)
{
    {};
    if (ctxPtr->end >= ctxPtr->prefixStart + 4)
        LZ4HC_Insert (ctxPtr, ctxPtr->end-3);
    ctxPtr->lowLimit = ctxPtr->dictLimit;
    ctxPtr->dictStart = ctxPtr->prefixStart;
    ctxPtr->dictLimit += (U32)(ctxPtr->end - ctxPtr->prefixStart);
    ctxPtr->prefixStart = newBlock;
    ctxPtr->end = newBlock;
    ctxPtr->nextToUpdate = ctxPtr->dictLimit;
    ctxPtr->dictCtx = ((void*)0);
}
static int
LZ4_compressHC_continue_generic (LZ4_streamHC_t* LZ4_streamHCPtr,
                                 const char* src, char* dst,
                                 int* srcSizePtr, int dstCapacity,
                                 limitedOutput_directive limit)
{
    LZ4HC_CCtx_internal* const ctxPtr = &LZ4_streamHCPtr->internal_donotuse;
    {};
    ((void)0);
    if (ctxPtr->prefixStart == ((void*)0)) LZ4HC_init_internal (ctxPtr, (const BYTE*) src);
    if ((size_t)(ctxPtr->end - ctxPtr->prefixStart) + ctxPtr->dictLimit > 2 *(1U<<30)) {
        size_t dictSize = (size_t)(ctxPtr->end - ctxPtr->prefixStart);
        if (dictSize > 64 *(1 <<10)) dictSize = 64 *(1 <<10);
        LZ4_loadDictHC(LZ4_streamHCPtr, (const char*)(ctxPtr->end) - dictSize, (int)dictSize);
    }
    if ((const BYTE*)src != ctxPtr->end)
        LZ4HC_setExternalDict(ctxPtr, (const BYTE*)src);
    { const BYTE* sourceEnd = (const BYTE*) src + *srcSizePtr;
        const BYTE* const dictBegin = ctxPtr->dictStart;
        const BYTE* const dictEnd = ctxPtr->dictStart + (ctxPtr->dictLimit - ctxPtr->lowLimit);
        if ((sourceEnd > dictBegin) && ((const BYTE*)src < dictEnd)) {
            if (sourceEnd > dictEnd) sourceEnd = dictEnd;
            ctxPtr->lowLimit += (U32)(sourceEnd - ctxPtr->dictStart);
            ctxPtr->dictStart += (U32)(sourceEnd - ctxPtr->dictStart);
            if (ctxPtr->dictLimit - ctxPtr->lowLimit < 4) {
                ctxPtr->lowLimit = ctxPtr->dictLimit;
                ctxPtr->dictStart = ctxPtr->prefixStart;
    } } }
    return LZ4HC_compress_generic (ctxPtr, src, dst, srcSizePtr, dstCapacity, ctxPtr->compressionLevel, limit);
}
int LZ4_compress_HC_continue (LZ4_streamHC_t* LZ4_streamHCPtr, const char* src, char* dst, int srcSize, int dstCapacity)
{
    if (dstCapacity < LZ4_compressBound(srcSize))
        return LZ4_compressHC_continue_generic (LZ4_streamHCPtr, src, dst, &srcSize, dstCapacity, limitedOutput);
    else
        return LZ4_compressHC_continue_generic (LZ4_streamHCPtr, src, dst, &srcSize, dstCapacity, notLimited);
}
int LZ4_compress_HC_continue_destSize (LZ4_streamHC_t* LZ4_streamHCPtr, const char* src, char* dst, int* srcSizePtr, int targetDestSize)
{
    return LZ4_compressHC_continue_generic(LZ4_streamHCPtr, src, dst, srcSizePtr, targetDestSize, fillOutput);
}
int LZ4_saveDictHC (LZ4_streamHC_t* LZ4_streamHCPtr, char* safeBuffer, int dictSize)
{
    LZ4HC_CCtx_internal* const streamPtr = &LZ4_streamHCPtr->internal_donotuse;
    int const prefixSize = (int)(streamPtr->end - streamPtr->prefixStart);
    {};
    ((void)0);
    if (dictSize > 64 *(1 <<10)) dictSize = 64 *(1 <<10);
    if (dictSize < 4) dictSize = 0;
    if (dictSize > prefixSize) dictSize = prefixSize;
    if (safeBuffer == ((void*)0)) ((void)0);
    if (dictSize > 0)
        __builtin_memmove(safeBuffer, streamPtr->end - dictSize, dictSize);
    { U32 const endIndex = (U32)(streamPtr->end - streamPtr->prefixStart) + streamPtr->dictLimit;
        streamPtr->end = (const BYTE*)safeBuffer + dictSize;
        streamPtr->prefixStart = streamPtr->end - dictSize;
        streamPtr->dictLimit = endIndex - (U32)dictSize;
        streamPtr->lowLimit = endIndex - (U32)dictSize;
        streamPtr->dictStart = streamPtr->prefixStart;
        if (streamPtr->nextToUpdate < streamPtr->dictLimit)
            streamPtr->nextToUpdate = streamPtr->dictLimit;
    }
    return dictSize;
}
int LZ4_compressHC(const char* src, char* dst, int srcSize) { return LZ4_compress_HC (src, dst, srcSize, LZ4_compressBound(srcSize), 0); }
int LZ4_compressHC_limitedOutput(const char* src, char* dst, int srcSize, int maxDstSize) { return LZ4_compress_HC(src, dst, srcSize, maxDstSize, 0); }
int LZ4_compressHC2(const char* src, char* dst, int srcSize, int cLevel) { return LZ4_compress_HC (src, dst, srcSize, LZ4_compressBound(srcSize), cLevel); }
int LZ4_compressHC2_limitedOutput(const char* src, char* dst, int srcSize, int maxDstSize, int cLevel) { return LZ4_compress_HC(src, dst, srcSize, maxDstSize, cLevel); }
int LZ4_compressHC_withStateHC (void* state, const char* src, char* dst, int srcSize) { return LZ4_compress_HC_extStateHC (state, src, dst, srcSize, LZ4_compressBound(srcSize), 0); }
int LZ4_compressHC_limitedOutput_withStateHC (void* state, const char* src, char* dst, int srcSize, int maxDstSize) { return LZ4_compress_HC_extStateHC (state, src, dst, srcSize, maxDstSize, 0); }
int LZ4_compressHC2_withStateHC (void* state, const char* src, char* dst, int srcSize, int cLevel) { return LZ4_compress_HC_extStateHC(state, src, dst, srcSize, LZ4_compressBound(srcSize), cLevel); }
int LZ4_compressHC2_limitedOutput_withStateHC (void* state, const char* src, char* dst, int srcSize, int maxDstSize, int cLevel) { return LZ4_compress_HC_extStateHC(state, src, dst, srcSize, maxDstSize, cLevel); }
int LZ4_compressHC_continue (LZ4_streamHC_t* ctx, const char* src, char* dst, int srcSize) { return LZ4_compress_HC_continue (ctx, src, dst, srcSize, LZ4_compressBound(srcSize)); }
int LZ4_compressHC_limitedOutput_continue (LZ4_streamHC_t* ctx, const char* src, char* dst, int srcSize, int maxDstSize) { return LZ4_compress_HC_continue (ctx, src, dst, srcSize, maxDstSize); }
int LZ4_sizeofStreamStateHC(void) { return sizeof(LZ4_streamHC_t); }
int LZ4_resetStreamStateHC(void* state, char* inputBuffer)
{
    LZ4_streamHC_t* const hc4 = LZ4_initStreamHC(state, sizeof(*hc4));
    if (hc4 == ((void*)0)) return 1;
    LZ4HC_init_internal (&hc4->internal_donotuse, (const BYTE*)inputBuffer);
    return 0;
}
void* LZ4_createHC (const char* inputBuffer)
{
    LZ4_streamHC_t* const hc4 = LZ4_createStreamHC();
    if (hc4 == ((void*)0)) return ((void*)0);
    LZ4HC_init_internal (&hc4->internal_donotuse, (const BYTE*)inputBuffer);
    return hc4;
}
int LZ4_freeHC (void* LZ4HC_Data)
{
    if (!LZ4HC_Data) return 0;
    rd_kafka_mem_free(((void*)0), LZ4HC_Data);
    return 0;
}
int LZ4_compressHC2_continue (void* LZ4HC_Data, const char* src, char* dst, int srcSize, int cLevel)
{
    return LZ4HC_compress_generic (&((LZ4_streamHC_t*)LZ4HC_Data)->internal_donotuse, src, dst, &srcSize, 0, cLevel, notLimited);
}
int LZ4_compressHC2_limitedOutput_continue (void* LZ4HC_Data, const char* src, char* dst, int srcSize, int dstCapacity, int cLevel)
{
    return LZ4HC_compress_generic (&((LZ4_streamHC_t*)LZ4HC_Data)->internal_donotuse, src, dst, &srcSize, dstCapacity, cLevel, limitedOutput);
}
char* LZ4_slideInputBufferHC(void* LZ4HC_Data)
{
    LZ4_streamHC_t* const ctx = (LZ4_streamHC_t*)LZ4HC_Data;
    const BYTE* bufferStart = ctx->internal_donotuse.prefixStart - ctx->internal_donotuse.dictLimit + ctx->internal_donotuse.lowLimit;
    LZ4_resetStreamHC_fast(ctx, ctx->internal_donotuse.compressionLevel);
    return (char*)(uptrval)bufferStart;
}
typedef struct {
    int price;
    int off;
    int mlen;
    int litlen;
} LZ4HC_optimal_t;
static inline __attribute__((always_inline)) int LZ4HC_literalsPrice(int const litlen)
{
    int price = litlen;
    ((void)0);
    if (litlen >= (int)((1U<<(8-4))-1))
        price += 1 + ((litlen-(int)((1U<<(8-4))-1)) / 255);
    return price;
}
static inline __attribute__((always_inline)) int LZ4HC_sequencePrice(int litlen, int mlen)
{
    int price = 1 + 2 ;
    ((void)0);
    ((void)0);
    price += LZ4HC_literalsPrice(litlen);
    if (mlen >= (int)(((1U<<4)-1)+4))
        price += 1 + ((mlen-(int)(((1U<<4)-1)+4)) / 255);
    return price;
}
typedef struct {
    int off;
    int len;
} LZ4HC_match_t;
static inline __attribute__((always_inline)) LZ4HC_match_t
LZ4HC_FindLongerMatch(LZ4HC_CCtx_internal* const ctx,
                      const BYTE* ip, const BYTE* const iHighLimit,
                      int minLen, int nbSearches,
                      const dictCtx_directive dict,
                      const HCfavor_e favorDecSpeed)
{
    LZ4HC_match_t match = { 0 , 0 };
    const BYTE* matchPtr = ((void*)0);
    int matchLength = LZ4HC_InsertAndGetWiderMatch(ctx, ip, ip, iHighLimit, minLen, &matchPtr, &ip, nbSearches, 1 , 1 , dict, favorDecSpeed);
    if (matchLength <= minLen) return match;
    if (favorDecSpeed) {
        if ((matchLength>18) & (matchLength<=36)) matchLength=18;
    }
    match.len = matchLength;
    match.off = (int)(ip-matchPtr);
    return match;
}
static int LZ4HC_compress_optimal ( LZ4HC_CCtx_internal* ctx,
                                    const char* const source,
                                    char* dst,
                                    int* srcSizePtr,
                                    int dstCapacity,
                                    int const nbSearches,
                                    size_t sufficient_len,
                                    const limitedOutput_directive limit,
                                    int const fullUpdate,
                                    const dictCtx_directive dict,
                                    const HCfavor_e favorDecSpeed)
{
    int retval = 0;
    LZ4HC_optimal_t* const opt = (LZ4HC_optimal_t*)rd_kafka_mem_malloc(((void*)0), sizeof(LZ4HC_optimal_t) * ((1<<12) + 3));
    const BYTE* ip = (const BYTE*) source;
    const BYTE* anchor = ip;
    const BYTE* const iend = ip + *srcSizePtr;
    const BYTE* const mflimit = iend - 12;
    const BYTE* const matchlimit = iend - 5;
    BYTE* op = (BYTE*) dst;
    BYTE* opSaved = (BYTE*) dst;
    BYTE* oend = op + dstCapacity;
    int ovml = 4;
    const BYTE* ovref = ((void*)0);
    if (opt == ((void*)0)) goto _return_label;
    {};
    *srcSizePtr = 0;
    if (limit == fillOutput) oend -= 5;
    if (sufficient_len >= (1<<12)) sufficient_len = (1<<12)-1;
    while (ip <= mflimit) {
         int const llen = (int)(ip - anchor);
         int best_mlen, best_off;
         int cur, last_match_pos = 0;
         LZ4HC_match_t const firstMatch = LZ4HC_FindLongerMatch(ctx, ip, matchlimit, 4 -1, nbSearches, dict, favorDecSpeed);
         if (firstMatch.len==0) { ip++; continue; }
         if ((size_t)firstMatch.len > sufficient_len) {
             int const firstML = firstMatch.len;
             const BYTE* const matchPos = ip - firstMatch.off;
             opSaved = op;
             if ( LZ4HC_encodeSequence(&ip, &op, &anchor, firstML, matchPos, limit, oend) ) {
                 ovml = firstML;
                 ovref = matchPos;
                 goto _dest_overflow;
             }
             continue;
         }
         { int rPos;
             for (rPos = 0 ; rPos < 4 ; rPos++) {
                 int const cost = LZ4HC_literalsPrice(llen + rPos);
                 opt[rPos].mlen = 1;
                 opt[rPos].off = 0;
                 opt[rPos].litlen = llen + rPos;
                 opt[rPos].price = cost;
                 {};
         } }
         { int mlen = 4;
             int const matchML = firstMatch.len;
             int const offset = firstMatch.off;
             ((void)0);
             for ( ; mlen <= matchML ; mlen++) {
                 int const cost = LZ4HC_sequencePrice(llen, mlen);
                 opt[mlen].mlen = mlen;
                 opt[mlen].off = offset;
                 opt[mlen].litlen = llen;
                 opt[mlen].price = cost;
                 {};
         } }
         last_match_pos = firstMatch.len;
         { int addLit;
             for (addLit = 1; addLit <= 3; addLit ++) {
                 opt[last_match_pos+addLit].mlen = 1;
                 opt[last_match_pos+addLit].off = 0;
                 opt[last_match_pos+addLit].litlen = addLit;
                 opt[last_match_pos+addLit].price = opt[last_match_pos].price + LZ4HC_literalsPrice(addLit);
                 {};
         } }
         for (cur = 1; cur < last_match_pos; cur++) {
             const BYTE* const curPtr = ip + cur;
             LZ4HC_match_t newMatch;
             if (curPtr > mflimit) break;
             {};
             if (fullUpdate) {
                 if ( (opt[cur+1].price <= opt[cur].price)
                   && (opt[cur+4].price < opt[cur].price + 3 ) )
                     continue;
             } else {
                 if (opt[cur+1].price <= opt[cur].price) continue;
             }
             {};
             if (fullUpdate)
                 newMatch = LZ4HC_FindLongerMatch(ctx, curPtr, matchlimit, 4 -1, nbSearches, dict, favorDecSpeed);
             else
                 newMatch = LZ4HC_FindLongerMatch(ctx, curPtr, matchlimit, last_match_pos - cur, nbSearches, dict, favorDecSpeed);
             if (!newMatch.len) continue;
             if ( ((size_t)newMatch.len > sufficient_len)
               || (newMatch.len + cur >= (1<<12)) ) {
                 best_mlen = newMatch.len;
                 best_off = newMatch.off;
                 last_match_pos = cur + 1;
                 goto encode;
             }
             { int const baseLitlen = opt[cur].litlen;
                 int litlen;
                 for (litlen = 1; litlen < 4; litlen++) {
                     int const price = opt[cur].price - LZ4HC_literalsPrice(baseLitlen) + LZ4HC_literalsPrice(baseLitlen+litlen);
                     int const pos = cur + litlen;
                     if (price < opt[pos].price) {
                         opt[pos].mlen = 1;
                         opt[pos].off = 0;
                         opt[pos].litlen = baseLitlen+litlen;
                         opt[pos].price = price;
                         {};
             } } }
             { int const matchML = newMatch.len;
                 int ml = 4;
                 ((void)0);
                 for ( ; ml <= matchML ; ml++) {
                     int const pos = cur + ml;
                     int const offset = newMatch.off;
                     int price;
                     int ll;
                     {};
                     if (opt[cur].mlen == 1) {
                         ll = opt[cur].litlen;
                         price = ((cur > ll) ? opt[cur - ll].price : 0)
                               + LZ4HC_sequencePrice(ll, ml);
                     } else {
                         ll = 0;
                         price = opt[cur].price + LZ4HC_sequencePrice(0, ml);
                     }
                    ((void)0);
                     if (pos > last_match_pos+3
                      || price <= opt[pos].price - (int)favorDecSpeed) {
                         {};
                         ((void)0);
                         if ( (ml == matchML)
                           && (last_match_pos < pos) )
                             last_match_pos = pos;
                         opt[pos].mlen = ml;
                         opt[pos].off = offset;
                         opt[pos].litlen = ll;
                         opt[pos].price = price;
             } } }
             { int addLit;
                 for (addLit = 1; addLit <= 3; addLit ++) {
                     opt[last_match_pos+addLit].mlen = 1;
                     opt[last_match_pos+addLit].off = 0;
                     opt[last_match_pos+addLit].litlen = addLit;
                     opt[last_match_pos+addLit].price = opt[last_match_pos].price + LZ4HC_literalsPrice(addLit);
                     {};
             } }
         }
         ((void)0);
         best_mlen = opt[last_match_pos].mlen;
         best_off = opt[last_match_pos].off;
         cur = last_match_pos - best_mlen;
encode:
         ((void)0);
         ((void)0);
         {};
         { int candidate_pos = cur;
             int selected_matchLength = best_mlen;
             int selected_offset = best_off;
             while (1) {
                 int const next_matchLength = opt[candidate_pos].mlen;
                 int const next_offset = opt[candidate_pos].off;
                 {};
                 opt[candidate_pos].mlen = selected_matchLength;
                 opt[candidate_pos].off = selected_offset;
                 selected_matchLength = next_matchLength;
                 selected_offset = next_offset;
                 if (next_matchLength > candidate_pos) break;
                 ((void)0);
                 candidate_pos -= next_matchLength;
         } }
         { int rPos = 0;
             while (rPos < last_match_pos) {
                 int const ml = opt[rPos].mlen;
                 int const offset = opt[rPos].off;
                 if (ml == 1) { ip++; rPos++; continue; }
                 rPos += ml;
                 ((void)0);
                 ((void)0);
                 opSaved = op;
                 if ( LZ4HC_encodeSequence(&ip, &op, &anchor, ml, ip - offset, limit, oend) ) {
                     ovml = ml;
                     ovref = ip - offset;
                     goto _dest_overflow;
         } } }
     }
_last_literals:
     { size_t lastRunSize = (size_t)(iend - anchor);
         size_t llAdd = (lastRunSize + 255 - ((1U<<(8-4))-1)) / 255;
         size_t const totalSize = 1 + llAdd + lastRunSize;
         if (limit == fillOutput) oend += 5;
         if (limit && (op + totalSize > oend)) {
             if (limit == limitedOutput) {
                retval = 0;
                goto _return_label;
             }
             lastRunSize = (size_t)(oend - op) - 1 ;
             llAdd = (lastRunSize + 256 - ((1U<<(8-4))-1)) / 256;
             lastRunSize -= llAdd;
         }
         {};
         ip = anchor + lastRunSize;
         if (lastRunSize >= ((1U<<(8-4))-1)) {
             size_t accumulator = lastRunSize - ((1U<<(8-4))-1);
             *op++ = (((1U<<(8-4))-1) << 4);
             for(; accumulator >= 255 ; accumulator -= 255) *op++ = 255;
             *op++ = (BYTE) accumulator;
         } else {
             *op++ = (BYTE)(lastRunSize << 4);
         }
         __builtin_memcpy(op, anchor, lastRunSize);
         op += lastRunSize;
     }
     *srcSizePtr = (int) (((const char*)ip) - source);
     retval = (int) ((char*)op-dst);
     goto _return_label;
_dest_overflow:
if (limit == fillOutput) {
     size_t const ll = (size_t)(ip - anchor);
     size_t const ll_addbytes = (ll + 240) / 255;
     size_t const ll_totalCost = 1 + ll_addbytes + ll;
     BYTE* const maxLitPos = oend - 3;
     {};
     op = opSaved;
     if (op + ll_totalCost <= maxLitPos) {
         size_t const bytesLeftForMl = (size_t)(maxLitPos - (op+ll_totalCost));
         size_t const maxMlSize = 4 + (((1U<<4)-1)-1) + (bytesLeftForMl * 255);
         ((void)0); ((void)0);
         if ((size_t)ovml > maxMlSize) ovml = (int)maxMlSize;
         if ((oend + 5) - (op + ll_totalCost + 2) - 1 + ovml >= 12) {
             {};
             {};
             LZ4HC_encodeSequence(&ip, &op, &anchor, ovml, ovref, notLimited, oend);
             {};
     } }
     goto _last_literals;
}
_return_label:
     rd_kafka_mem_free(((void*)0), opt);
     return retval;
}
