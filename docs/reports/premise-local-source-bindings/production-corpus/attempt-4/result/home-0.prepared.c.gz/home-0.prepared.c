typedef long int ptrdiff_t;
typedef long unsigned int size_t;
typedef int wchar_t;
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
__attribute__ ((visibility ("default"))) int LZ4_versionNumber (void);
__attribute__ ((visibility ("default"))) const char* LZ4_versionString (void);
__attribute__ ((visibility ("default"))) int LZ4_compress_default(const char* src, char* dst, int srcSize, int dstCapacity);
__attribute__ ((visibility ("default"))) int LZ4_decompress_safe (const char* src, char* dst, int compressedSize, int dstCapacity);
__attribute__ ((visibility ("default"))) int LZ4_compressBound(int inputSize);
__attribute__ ((visibility ("default"))) int LZ4_compress_fast (const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
__attribute__ ((visibility ("default"))) int LZ4_sizeofState(void);
__attribute__ ((visibility ("default"))) int LZ4_compress_fast_extState (void* state, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
__attribute__ ((visibility ("default"))) int LZ4_compress_destSize (const char* src, char* dst, int* srcSizePtr, int targetDstSize);
__attribute__ ((visibility ("default"))) int LZ4_decompress_safe_partial (const char* src, char* dst, int srcSize, int targetOutputSize, int dstCapacity);
typedef union LZ4_stream_u LZ4_stream_t;
__attribute__ ((visibility ("default"))) LZ4_stream_t* LZ4_createStream(void);
__attribute__ ((visibility ("default"))) int LZ4_freeStream (LZ4_stream_t* streamPtr);
__attribute__ ((visibility ("default"))) void LZ4_resetStream_fast (LZ4_stream_t* streamPtr);
__attribute__ ((visibility ("default"))) int LZ4_loadDict (LZ4_stream_t* streamPtr, const char* dictionary, int dictSize);
__attribute__ ((visibility ("default"))) int LZ4_compress_fast_continue (LZ4_stream_t* streamPtr, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
__attribute__ ((visibility ("default"))) int LZ4_saveDict (LZ4_stream_t* streamPtr, char* safeBuffer, int maxDictSize);
typedef union LZ4_streamDecode_u LZ4_streamDecode_t;
__attribute__ ((visibility ("default"))) LZ4_streamDecode_t* LZ4_createStreamDecode(void);
__attribute__ ((visibility ("default"))) int LZ4_freeStreamDecode (LZ4_streamDecode_t* LZ4_stream);
__attribute__ ((visibility ("default"))) int LZ4_setStreamDecode (LZ4_streamDecode_t* LZ4_streamDecode, const char* dictionary, int dictSize);
__attribute__ ((visibility ("default"))) int LZ4_decoderRingBufferSize(int maxBlockSize);
__attribute__ ((visibility ("default"))) int
LZ4_decompress_safe_continue (LZ4_streamDecode_t* LZ4_streamDecode,
                        const char* src, char* dst,
                        int srcSize, int dstCapacity);
__attribute__ ((visibility ("default"))) int
LZ4_decompress_safe_usingDict(const char* src, char* dst,
                              int srcSize, int dstCapacity,
                              const char* dictStart, int dictSize);
__attribute__ ((visibility ("default"))) int
LZ4_decompress_safe_partial_usingDict(const char* src, char* dst,
                                      int compressedSize,
                                      int targetOutputSize, int maxOutputSize,
                                      const char* dictStart, int dictSize);
                  int LZ4_compress_fast_extState_fastReset (void* state, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration);
                  void
LZ4_attach_dictionary(LZ4_stream_t* workingStream,
                const LZ4_stream_t* dictionaryStream);
typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef long int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef long int intptr_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
 typedef int8_t LZ4_i8;
  typedef uint8_t LZ4_byte;
  typedef uint16_t LZ4_u16;
  typedef uint32_t LZ4_u32;
typedef struct LZ4_stream_t_internal LZ4_stream_t_internal;
struct LZ4_stream_t_internal {
    LZ4_u32 hashTable[(1 << (14 -2))];
    const LZ4_byte* dictionary;
    const LZ4_stream_t_internal* dictCtx;
    LZ4_u32 currentOffset;
    LZ4_u32 tableType;
    LZ4_u32 dictSize;
};
union LZ4_stream_u {
    char minStateSize[((1UL << 14) + 32)];
    LZ4_stream_t_internal internal_donotuse;
};
__attribute__ ((visibility ("default"))) LZ4_stream_t* LZ4_initStream (void* buffer, size_t size);
typedef struct {
    const LZ4_byte* externalDict;
    const LZ4_byte* prefixEnd;
    size_t extDictSize;
    size_t prefixSize;
} LZ4_streamDecode_t_internal;
union LZ4_streamDecode_u {
    char minStateSize[32];
    LZ4_streamDecode_t_internal internal_donotuse;
} ;
                                                           __attribute__ ((visibility ("default"))) int LZ4_compress (const char* src, char* dest, int srcSize);
                                                           __attribute__ ((visibility ("default"))) int LZ4_compress_limitedOutput (const char* src, char* dest, int srcSize, int maxOutputSize);
                                                           __attribute__ ((visibility ("default"))) int LZ4_compress_withState (void* state, const char* source, char* dest, int inputSize);
                                                           __attribute__ ((visibility ("default"))) int LZ4_compress_limitedOutput_withState (void* state, const char* source, char* dest, int inputSize, int maxOutputSize);
                                                           __attribute__ ((visibility ("default"))) int LZ4_compress_continue (LZ4_stream_t* LZ4_streamPtr, const char* source, char* dest, int inputSize);
                                                           __attribute__ ((visibility ("default"))) int LZ4_compress_limitedOutput_continue (LZ4_stream_t* LZ4_streamPtr, const char* source, char* dest, int inputSize, int maxOutputSize);
                                                    __attribute__ ((visibility ("default"))) int LZ4_uncompress (const char* source, char* dest, int outputSize);
                                                    __attribute__ ((visibility ("default"))) int LZ4_uncompress_unknownOutputSize (const char* source, char* dest, int isize, int maxOutputSize);
                                                 __attribute__ ((visibility ("default"))) void* LZ4_create (char* inputBuffer);
                                                 __attribute__ ((visibility ("default"))) int LZ4_sizeofStreamState(void);
                                                 __attribute__ ((visibility ("default"))) int LZ4_resetStreamState(void* state, char* inputBuffer);
                                                 __attribute__ ((visibility ("default"))) char* LZ4_slideInputBuffer (void* state);
                                                              __attribute__ ((visibility ("default"))) int LZ4_decompress_safe_withPrefix64k (const char* src, char* dst, int compressedSize, int maxDstSize);
                                                              __attribute__ ((visibility ("default"))) int LZ4_decompress_fast_withPrefix64k (const char* src, char* dst, int originalSize);
__attribute__ ((visibility ("default"))) int LZ4_decompress_fast (const char* src, char* dst, int originalSize);
__attribute__ ((visibility ("default"))) int LZ4_decompress_fast_continue (LZ4_streamDecode_t* LZ4_streamDecode, const char* src, char* dst, int originalSize);
__attribute__ ((visibility ("default"))) int LZ4_decompress_fast_usingDict (const char* src, char* dst, int originalSize, const char* dictStart, int dictSize);
__attribute__ ((visibility ("default"))) void LZ4_resetStream (LZ4_stream_t* streamPtr);
struct rdkafka_s;
extern void *rd_kafka_mem_malloc(struct rdkafka_s *rk, size_t s);
extern void *rd_kafka_mem_calloc(struct rdkafka_s *rk, size_t n, size_t s);
extern void rd_kafka_mem_free(struct rdkafka_s *rk, void *p);
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void *memset_explicit (void *__s, int __c, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
struct __locale_struct
{
  struct __locale_data *__locales[13];
  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;
  const char *__names[13];
};
typedef struct __locale_struct *__locale_t;

typedef __locale_t locale_t;
extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;
extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
                                         ;
extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                          ;
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
static const int LZ4_minLength = (12 +1);
static int LZ4_isAligned(const void* ptr, size_t alignment)
{
    return ((size_t)ptr & (alignment -1)) == 0;
}
 typedef uint8_t BYTE;
  typedef uint16_t U16;
  typedef uint32_t U32;
  typedef int32_t S32;
  typedef uint64_t U64;
  typedef uintptr_t uptrval;
  typedef U64 reg_t;
typedef enum {
    notLimited = 0,
    limitedOutput = 1,
    fillOutput = 2
} limitedOutput_directive;
static unsigned LZ4_isLittleEndian(void)
{
    const union { U32 u; BYTE c[4]; } one = { 1 };
    return one.c[0];
}
typedef union { U16 u16; U32 u32; reg_t uArch; } __attribute__((packed)) LZ4_unalign;
static U16 LZ4_read16(const void* ptr) { return ((const LZ4_unalign*)ptr)->u16; }
static U32 LZ4_read32(const void* ptr) { return ((const LZ4_unalign*)ptr)->u32; }
static reg_t LZ4_read_ARCH(const void* ptr) { return ((const LZ4_unalign*)ptr)->uArch; }
static void LZ4_write16(void* memPtr, U16 value) { ((LZ4_unalign*)memPtr)->u16 = value; }
static void LZ4_write32(void* memPtr, U32 value) { ((LZ4_unalign*)memPtr)->u32 = value; }
static U16 LZ4_readLE16(const void* memPtr)
{
    if (LZ4_isLittleEndian()) {
        return LZ4_read16(memPtr);
    } else {
        const BYTE* p = (const BYTE*)memPtr;
        return (U16)((U16)p[0] + (p[1]<<8));
    }
}
static void LZ4_writeLE16(void* memPtr, U16 value)
{
    if (LZ4_isLittleEndian()) {
        LZ4_write16(memPtr, value);
    } else {
        BYTE* p = (BYTE*)memPtr;
        p[0] = (BYTE) value;
        p[1] = (BYTE)(value>>8);
    }
}
static inline __attribute__((always_inline))
void LZ4_wildCopy8(void* dstPtr, const void* srcPtr, void* dstEnd)
{
    BYTE* d = (BYTE*)dstPtr;
    const BYTE* s = (const BYTE*)srcPtr;
    BYTE* const e = (BYTE*)dstEnd;
    do { __builtin_memcpy(d, s, 8); d+=8; s+=8; } while (d<e);
}
static const unsigned inc32table[8] = {0, 1, 2, 1, 0, 4, 4, 4};
static const int dec64table[8] = {0, 0, 0, -1, -4, 1, 2, 3};
static inline __attribute__((always_inline)) void
LZ4_memcpy_using_offset_base(BYTE* dstPtr, const BYTE* srcPtr, BYTE* dstEnd, const size_t offset)
{
    ((void)0);
    if (offset < 8) {
        LZ4_write32(dstPtr, 0);
        dstPtr[0] = srcPtr[0];
        dstPtr[1] = srcPtr[1];
        dstPtr[2] = srcPtr[2];
        dstPtr[3] = srcPtr[3];
        srcPtr += inc32table[offset];
        __builtin_memcpy(dstPtr+4, srcPtr, 4);
        srcPtr -= dec64table[offset];
        dstPtr += 8;
    } else {
        __builtin_memcpy(dstPtr, srcPtr, 8);
        dstPtr += 8;
        srcPtr += 8;
    }
    LZ4_wildCopy8(dstPtr, srcPtr, dstEnd);
}
static inline __attribute__((always_inline)) void
LZ4_wildCopy32(void* dstPtr, const void* srcPtr, void* dstEnd)
{
    BYTE* d = (BYTE*)dstPtr;
    const BYTE* s = (const BYTE*)srcPtr;
    BYTE* const e = (BYTE*)dstEnd;
    do { __builtin_memcpy(d, s, 16); __builtin_memcpy(d+16, s+16, 16); d+=32; s+=32; } while (d<e);
}
static inline __attribute__((always_inline)) void
LZ4_memcpy_using_offset(BYTE* dstPtr, const BYTE* srcPtr, BYTE* dstEnd, const size_t offset)
{
    BYTE v[8];
    ((void)0);
    switch(offset) {
    case 1:
        memset(((v)),((*srcPtr)),((8)));
        break;
    case 2:
        __builtin_memcpy(v, srcPtr, 2);
        __builtin_memcpy(&v[2], srcPtr, 2);
        __builtin_memcpy(&v[4], v, 4);
        break;
    case 4:
        __builtin_memcpy(v, srcPtr, 4);
        __builtin_memcpy(&v[4], srcPtr, 4);
        break;
    default:
        LZ4_memcpy_using_offset_base(dstPtr, srcPtr, dstEnd, offset);
        return;
    }
    __builtin_memcpy(dstPtr, v, 8);
    dstPtr += 8;
    while (dstPtr < dstEnd) {
        __builtin_memcpy(dstPtr, v, 8);
        dstPtr += 8;
    }
}
static unsigned LZ4_NbCommonBytes (reg_t val)
{
    ((void)0);
    if (LZ4_isLittleEndian()) {
        if (sizeof(val) == 8) {
            return (unsigned)__builtin_ctzll((U64)val) >> 3;
        } else {
            return (unsigned)__builtin_ctz((U32)val) >> 3;
        }
    } else {
        if (sizeof(val)==8) {
            return (unsigned)__builtin_clzll((U64)val) >> 3;
        } else {
            return (unsigned)__builtin_clz((U32)val) >> 3;
        }
    }
}
static inline __attribute__((always_inline))
unsigned LZ4_count(const BYTE* pIn, const BYTE* pMatch, const BYTE* pInLimit)
{
    const BYTE* const pStart = pIn;
    if ((__builtin_expect (((pIn < pInLimit-(sizeof(reg_t)-1)) != 0),(1)) )) {
        reg_t const diff = LZ4_read_ARCH(pMatch) ^ LZ4_read_ARCH(pIn);
        if (!diff) {
            pIn+=sizeof(reg_t); pMatch+=sizeof(reg_t);
        } else {
            return LZ4_NbCommonBytes(diff);
    } }
    while ((__builtin_expect (((pIn < pInLimit-(sizeof(reg_t)-1)) != 0),(1)) )) {
        reg_t const diff = LZ4_read_ARCH(pMatch) ^ LZ4_read_ARCH(pIn);
        if (!diff) { pIn+=sizeof(reg_t); pMatch+=sizeof(reg_t); continue; }
        pIn += LZ4_NbCommonBytes(diff);
        return (unsigned)(pIn - pStart);
    }
    if ((sizeof(reg_t)==8) && (pIn<(pInLimit-3)) && (LZ4_read32(pMatch) == LZ4_read32(pIn))) { pIn+=4; pMatch+=4; }
    if ((pIn<(pInLimit-1)) && (LZ4_read16(pMatch) == LZ4_read16(pIn))) { pIn+=2; pMatch+=2; }
    if ((pIn<pInLimit) && (*pMatch == *pIn)) pIn++;
    return (unsigned)(pIn - pStart);
}
static const int LZ4_64Klimit = ((64 *(1 <<10)) + (12 -1));
static const U32 LZ4_skipTrigger = 6;
typedef enum { clearedTable = 0, byPtr, byU32, byU16 } tableType_t;
typedef enum { noDict = 0, withPrefix64k, usingExtDict, usingDictCtx } dict_directive;
typedef enum { noDictIssue = 0, dictSmall } dictIssue_directive;
int LZ4_versionNumber (void) { return (1 *100*100 + 9 *100 + 4); }
const char* LZ4_versionString(void) { return "1.9.4"; }
int LZ4_compressBound(int isize) { return ((unsigned)(isize) > (unsigned)0x7E000000 ? 0 : (isize) + ((isize)/255) + 16); }
int LZ4_sizeofState(void) { return sizeof(LZ4_stream_t); }
int LZ4_compress_forceExtDict (LZ4_stream_t* LZ4_dict, const char* source, char* dest, int srcSize);
int LZ4_decompress_safe_forceExtDict(const char* source, char* dest,
                                     int compressedSize, int maxOutputSize,
                                     const void* dictStart, size_t dictSize);
int LZ4_decompress_safe_partial_forceExtDict(const char* source, char* dest,
                                     int compressedSize, int targetOutputSize, int dstCapacity,
                                     const void* dictStart, size_t dictSize);
static inline __attribute__((always_inline)) U32 LZ4_hash4(U32 sequence, tableType_t const tableType)
{
    if (tableType == byU16)
        return ((sequence * 2654435761U) >> ((4*8)-((14 -2)+1)));
    else
        return ((sequence * 2654435761U) >> ((4*8)-(14 -2)));
}
static inline __attribute__((always_inline)) U32 LZ4_hash5(U64 sequence, tableType_t const tableType)
{
    const U32 hashLog = (tableType == byU16) ? (14 -2)+1 : (14 -2);
    if (LZ4_isLittleEndian()) {
        const U64 prime5bytes = 889523592379ULL;
        return (U32)(((sequence << 24) * prime5bytes) >> (64 - hashLog));
    } else {
        const U64 prime8bytes = 11400714785074694791ULL;
        return (U32)(((sequence >> 24) * prime8bytes) >> (64 - hashLog));
    }
}
static inline __attribute__((always_inline)) U32 LZ4_hashPosition(const void* const p, tableType_t const tableType)
{
    if ((sizeof(reg_t)==8) && (tableType != byU16)) return LZ4_hash5(LZ4_read_ARCH(p), tableType);
    return LZ4_hash4(LZ4_read32(p), tableType);
}
static inline __attribute__((always_inline)) void LZ4_clearHash(U32 h, void* tableBase, tableType_t const tableType)
{
    switch (tableType)
    {
    default:
    case clearedTable: { ((void)0); return; }
    case byPtr: { const BYTE** hashTable = (const BYTE**)tableBase; hashTable[h] = ((void*)0); return; }
    case byU32: { U32* hashTable = (U32*) tableBase; hashTable[h] = 0; return; }
    case byU16: { U16* hashTable = (U16*) tableBase; hashTable[h] = 0; return; }
    }
}
static inline __attribute__((always_inline)) void LZ4_putIndexOnHash(U32 idx, U32 h, void* tableBase, tableType_t const tableType)
{
    switch (tableType)
    {
    default:
    case clearedTable:
    case byPtr: { ((void)0); return; }
    case byU32: { U32* hashTable = (U32*) tableBase; hashTable[h] = idx; return; }
    case byU16: { U16* hashTable = (U16*) tableBase; ((void)0); hashTable[h] = (U16)idx; return; }
    }
}
static inline __attribute__((always_inline)) void LZ4_putPositionOnHash(const BYTE* p, U32 h,
                                  void* tableBase, tableType_t const tableType,
                            const BYTE* srcBase)
{
    switch (tableType)
    {
    case clearedTable: { ((void)0); return; }
    case byPtr: { const BYTE** hashTable = (const BYTE**)tableBase; hashTable[h] = p; return; }
    case byU32: { U32* hashTable = (U32*) tableBase; hashTable[h] = (U32)(p-srcBase); return; }
    case byU16: { U16* hashTable = (U16*) tableBase; hashTable[h] = (U16)(p-srcBase); return; }
    }
}
static inline __attribute__((always_inline)) void LZ4_putPosition(const BYTE* p, void* tableBase, tableType_t tableType, const BYTE* srcBase)
{
    U32 const h = LZ4_hashPosition(p, tableType);
    LZ4_putPositionOnHash(p, h, tableBase, tableType, srcBase);
}
static inline __attribute__((always_inline)) U32 LZ4_getIndexOnHash(U32 h, const void* tableBase, tableType_t tableType)
{
    { enum { LZ4_static_assert = 1/(int)(!!(14 > 2)) }; };
    if (tableType == byU32) {
        const U32* const hashTable = (const U32*) tableBase;
        ((void)0);
        return hashTable[h];
    }
    if (tableType == byU16) {
        const U16* const hashTable = (const U16*) tableBase;
        ((void)0);
        return hashTable[h];
    }
    ((void)0); return 0;
}
static const BYTE* LZ4_getPositionOnHash(U32 h, const void* tableBase, tableType_t tableType, const BYTE* srcBase)
{
    if (tableType == byPtr) { const BYTE* const* hashTable = (const BYTE* const*) tableBase; return hashTable[h]; }
    if (tableType == byU32) { const U32* const hashTable = (const U32*) tableBase; return hashTable[h] + srcBase; }
    { const U16* const hashTable = (const U16*) tableBase; return hashTable[h] + srcBase; }
}
static inline __attribute__((always_inline)) const BYTE*
LZ4_getPosition(const BYTE* p,
                const void* tableBase, tableType_t tableType,
                const BYTE* srcBase)
{
    U32 const h = LZ4_hashPosition(p, tableType);
    return LZ4_getPositionOnHash(h, tableBase, tableType, srcBase);
}
static inline __attribute__((always_inline)) void
LZ4_prepareTable(LZ4_stream_t_internal* const cctx,
           const int inputSize,
           const tableType_t tableType) {
    if ((tableType_t)cctx->tableType != clearedTable) {
        ((void)0);
        if ((tableType_t)cctx->tableType != tableType
          || ((tableType == byU16) && cctx->currentOffset + (unsigned)inputSize >= 0xFFFFU)
          || ((tableType == byU32) && cctx->currentOffset > 1 *(1U<<30))
          || tableType == byPtr
          || inputSize >= 4 *(1 <<10))
        {
            {};
            memset(((cctx->hashTable)),((0)),(((1 << 14))));
            cctx->currentOffset = 0;
            cctx->tableType = (U32)clearedTable;
        } else {
            {};
        }
    }
    if (cctx->currentOffset != 0 && tableType == byU32) {
        {};
        cctx->currentOffset += 64 *(1 <<10);
    }
    cctx->dictCtx = ((void*)0);
    cctx->dictionary = ((void*)0);
    cctx->dictSize = 0;
}
static inline __attribute__((always_inline)) int LZ4_compress_generic_validated(
                 LZ4_stream_t_internal* const cctx,
                 const char* const source,
                 char* const dest,
                 const int inputSize,
                 int* inputConsumed,
                 const int maxOutputSize,
                 const limitedOutput_directive outputDirective,
                 const tableType_t tableType,
                 const dict_directive dictDirective,
                 const dictIssue_directive dictIssue,
                 const int acceleration)
{
    int result;
    const BYTE* ip = (const BYTE*) source;
    U32 const startIndex = cctx->currentOffset;
    const BYTE* base = (const BYTE*) source - startIndex;
    const BYTE* lowLimit;
    const LZ4_stream_t_internal* dictCtx = (const LZ4_stream_t_internal*) cctx->dictCtx;
    const BYTE* const dictionary =
        dictDirective == usingDictCtx ? dictCtx->dictionary : cctx->dictionary;
    const U32 dictSize =
        dictDirective == usingDictCtx ? dictCtx->dictSize : cctx->dictSize;
    const U32 dictDelta = (dictDirective == usingDictCtx) ? startIndex - dictCtx->currentOffset : 0;
    int const maybe_extMem = (dictDirective == usingExtDict) || (dictDirective == usingDictCtx);
    U32 const prefixIdxLimit = startIndex - dictSize;
    const BYTE* const dictEnd = dictionary ? dictionary + dictSize : dictionary;
    const BYTE* anchor = (const BYTE*) source;
    const BYTE* const iend = ip + inputSize;
    const BYTE* const mflimitPlusOne = iend - 12 + 1;
    const BYTE* const matchlimit = iend - 5;
    const BYTE* dictBase = (dictionary == ((void*)0)) ? ((void*)0) :
                           (dictDirective == usingDictCtx) ?
                            dictionary + dictSize - dictCtx->currentOffset :
                            dictionary + dictSize - startIndex;
    BYTE* op = (BYTE*) dest;
    BYTE* const olimit = op + maxOutputSize;
    U32 offset = 0;
    U32 forwardH;
    {};
    ((void)0);
    if (outputDirective == fillOutput && maxOutputSize < 1) { return 0; }
    if ((tableType == byU16) && (inputSize>=LZ4_64Klimit)) { return 0; }
    if (tableType==byPtr) ((void)0);
    ((void)0);
    lowLimit = (const BYTE*)source - (dictDirective == withPrefix64k ? dictSize : 0);
    if (dictDirective == usingDictCtx) {
        cctx->dictCtx = ((void*)0);
        cctx->dictSize = (U32)inputSize;
    } else {
        cctx->dictSize += (U32)inputSize;
    }
    cctx->currentOffset += (U32)inputSize;
    cctx->tableType = (U32)tableType;
    if (inputSize<LZ4_minLength) goto _last_literals;
    LZ4_putPosition(ip, cctx->hashTable, tableType, base);
    ip++; forwardH = LZ4_hashPosition(ip, tableType);
    for ( ; ; ) {
        const BYTE* match;
        BYTE* token;
        const BYTE* filledIp;
        if (tableType == byPtr) {
            const BYTE* forwardIp = ip;
            int step = 1;
            int searchMatchNb = acceleration << LZ4_skipTrigger;
            do {
                U32 const h = forwardH;
                ip = forwardIp;
                forwardIp += step;
                step = (searchMatchNb++ >> LZ4_skipTrigger);
                if ((__builtin_expect (((forwardIp > mflimitPlusOne) != 0),(0)) )) goto _last_literals;
                ((void)0);
                match = LZ4_getPositionOnHash(h, cctx->hashTable, tableType, base);
                forwardH = LZ4_hashPosition(forwardIp, tableType);
                LZ4_putPositionOnHash(ip, h, cctx->hashTable, tableType, base);
            } while ( (match+65535 < ip)
                   || (LZ4_read32(match) != LZ4_read32(ip)) );
        } else {
            const BYTE* forwardIp = ip;
            int step = 1;
            int searchMatchNb = acceleration << LZ4_skipTrigger;
            do {
                U32 const h = forwardH;
                U32 const current = (U32)(forwardIp - base);
                U32 matchIndex = LZ4_getIndexOnHash(h, cctx->hashTable, tableType);
                ((void)0);
                ((void)0);
                ip = forwardIp;
                forwardIp += step;
                step = (searchMatchNb++ >> LZ4_skipTrigger);
                if ((__builtin_expect (((forwardIp > mflimitPlusOne) != 0),(0)) )) goto _last_literals;
                ((void)0);
                if (dictDirective == usingDictCtx) {
                    if (matchIndex < startIndex) {
                        ((void)0);
                        matchIndex = LZ4_getIndexOnHash(h, dictCtx->hashTable, byU32);
                        match = dictBase + matchIndex;
                        matchIndex += dictDelta;
                        lowLimit = dictionary;
                    } else {
                        match = base + matchIndex;
                        lowLimit = (const BYTE*)source;
                    }
                } else if (dictDirective == usingExtDict) {
                    if (matchIndex < startIndex) {
                        {};
                        ((void)0);
                        ((void)0);
                        match = dictBase + matchIndex;
                        lowLimit = dictionary;
                    } else {
                        match = base + matchIndex;
                        lowLimit = (const BYTE*)source;
                    }
                } else {
                    match = base + matchIndex;
                }
                forwardH = LZ4_hashPosition(forwardIp, tableType);
                LZ4_putIndexOnHash(current, h, cctx->hashTable, tableType);
                {};
                if ((dictIssue == dictSmall) && (matchIndex < prefixIdxLimit)) { continue; }
                ((void)0);
                if ( ((tableType != byU16) || (65535 < 65535))
                  && (matchIndex+65535 < current)) {
                    continue;
                }
                ((void)0);
                if (LZ4_read32(match) == LZ4_read32(ip)) {
                    if (maybe_extMem) offset = current - matchIndex;
                    break;
                }
            } while(1);
        }
        filledIp = ip;
        while (((ip>anchor) & (match > lowLimit)) && ((__builtin_expect (((ip[-1]==match[-1]) != 0),(0)) ))) { ip--; match--; }
        { unsigned const litLength = (unsigned)(ip - anchor);
            token = op++;
            if ((outputDirective == limitedOutput) &&
                ((__builtin_expect (((op + litLength + (2 + 1 + 5) + (litLength/255) > olimit) != 0),(0)) )) ) {
                return 0;
            }
            if ((outputDirective == fillOutput) &&
                ((__builtin_expect (((op + (litLength+240)/255 + litLength + 2 + 1 + 12 - 4 > olimit) != 0),(0)) ))) {
                op--;
                goto _last_literals;
            }
            if (litLength >= ((1U<<(8-4))-1)) {
                int len = (int)(litLength - ((1U<<(8-4))-1));
                *token = (((1U<<(8-4))-1)<<4);
                for(; len >= 255 ; len-=255) *op++ = 255;
                *op++ = (BYTE)len;
            }
            else *token = (BYTE)(litLength<<4);
            LZ4_wildCopy8(op, anchor, op+litLength);
            op+=litLength;
            {};
        }
_next_match:
        if ((outputDirective == fillOutput) &&
            (op + 2 + 1 + 12 - 4 > olimit)) {
            op = token;
            goto _last_literals;
        }
        if (maybe_extMem) {
            {};
            ((void)0);
            LZ4_writeLE16(op, (U16)offset); op+=2;
        } else {
            {};
            ((void)0);
            LZ4_writeLE16(op, (U16)(ip - match)); op+=2;
        }
        { unsigned matchCode;
            if ( (dictDirective==usingExtDict || dictDirective==usingDictCtx)
              && (lowLimit==dictionary) ) {
                const BYTE* limit = ip + (dictEnd-match);
                ((void)0);
                if (limit > matchlimit) limit = matchlimit;
                matchCode = LZ4_count(ip+4, match+4, limit);
                ip += (size_t)matchCode + 4;
                if (ip==limit) {
                    unsigned const more = LZ4_count(limit, (const BYTE*)source, matchlimit);
                    matchCode += more;
                    ip += more;
                }
                {};
            } else {
                matchCode = LZ4_count(ip+4, match+4, matchlimit);
                ip += (size_t)matchCode + 4;
                {};
            }
            if ((outputDirective) &&
                ((__builtin_expect (((op + (1 + 5) + (matchCode+240)/255 > olimit) != 0),(0)) )) ) {
                if (outputDirective == fillOutput) {
                    U32 newMatchCode = 15 - 1 + ((U32)(olimit - op) - 1 - 5) * 255;
                    ip -= matchCode - newMatchCode;
                    ((void)0);
                    matchCode = newMatchCode;
                    if ((__builtin_expect (((ip <= filledIp) != 0),(0)) )) {
                        const BYTE* ptr;
                        {};
                        for (ptr = ip; ptr <= filledIp; ++ptr) {
                            U32 const h = LZ4_hashPosition(ptr, tableType);
                            LZ4_clearHash(h, cctx->hashTable, tableType);
                        }
                    }
                } else {
                    ((void)0);
                    return 0;
                }
            }
            if (matchCode >= ((1U<<4)-1)) {
                *token += ((1U<<4)-1);
                matchCode -= ((1U<<4)-1);
                LZ4_write32(op, 0xFFFFFFFF);
                while (matchCode >= 4*255) {
                    op+=4;
                    LZ4_write32(op, 0xFFFFFFFF);
                    matchCode -= 4*255;
                }
                op += matchCode / 255;
                *op++ = (BYTE)(matchCode % 255);
            } else
                *token += (BYTE)(matchCode);
        }
        ((void)0);
        anchor = ip;
        if (ip >= mflimitPlusOne) break;
        LZ4_putPosition(ip-2, cctx->hashTable, tableType, base);
        if (tableType == byPtr) {
            match = LZ4_getPosition(ip, cctx->hashTable, tableType, base);
            LZ4_putPosition(ip, cctx->hashTable, tableType, base);
            if ( (match+65535 >= ip)
              && (LZ4_read32(match) == LZ4_read32(ip)) )
            { token=op++; *token=0; goto _next_match; }
        } else {
            U32 const h = LZ4_hashPosition(ip, tableType);
            U32 const current = (U32)(ip-base);
            U32 matchIndex = LZ4_getIndexOnHash(h, cctx->hashTable, tableType);
            ((void)0);
            if (dictDirective == usingDictCtx) {
                if (matchIndex < startIndex) {
                    matchIndex = LZ4_getIndexOnHash(h, dictCtx->hashTable, byU32);
                    match = dictBase + matchIndex;
                    lowLimit = dictionary;
                    matchIndex += dictDelta;
                } else {
                    match = base + matchIndex;
                    lowLimit = (const BYTE*)source;
                }
            } else if (dictDirective==usingExtDict) {
                if (matchIndex < startIndex) {
                    ((void)0);
                    match = dictBase + matchIndex;
                    lowLimit = dictionary;
                } else {
                    match = base + matchIndex;
                    lowLimit = (const BYTE*)source;
                }
            } else {
                match = base + matchIndex;
            }
            LZ4_putIndexOnHash(current, h, cctx->hashTable, tableType);
            ((void)0);
            if ( ((dictIssue==dictSmall) ? (matchIndex >= prefixIdxLimit) : 1)
              && (((tableType==byU16) && (65535 == 65535)) ? 1 : (matchIndex+65535 >= current))
              && (LZ4_read32(match) == LZ4_read32(ip)) ) {
                token=op++;
                *token=0;
                if (maybe_extMem) offset = current - matchIndex;
                {};
                goto _next_match;
            }
        }
        forwardH = LZ4_hashPosition(++ip, tableType);
    }
_last_literals:
    { size_t lastRun = (size_t)(iend - anchor);
        if ( (outputDirective) &&
            (op + lastRun + 1 + ((lastRun+255-((1U<<(8-4))-1))/255) > olimit)) {
            if (outputDirective == fillOutput) {
                ((void)0);
                lastRun = (size_t)(olimit-op) - 1 ;
                lastRun -= (lastRun + 256 - ((1U<<(8-4))-1)) / 256;
            } else {
                ((void)0);
                return 0;
            }
        }
        {};
        if (lastRun >= ((1U<<(8-4))-1)) {
            size_t accumulator = lastRun - ((1U<<(8-4))-1);
            *op++ = ((1U<<(8-4))-1) << 4;
            for(; accumulator >= 255 ; accumulator-=255) *op++ = 255;
            *op++ = (BYTE) accumulator;
        } else {
            *op++ = (BYTE)(lastRun<<4);
        }
        __builtin_memcpy(op, anchor, lastRun);
        ip = anchor + lastRun;
        op += lastRun;
    }
    if (outputDirective == fillOutput) {
        *inputConsumed = (int) (((const char*)ip)-source);
    }
    result = (int)(((char*)op) - dest);
    ((void)0);
    {};
    return result;
}
static inline __attribute__((always_inline)) int LZ4_compress_generic(
                 LZ4_stream_t_internal* const cctx,
                 const char* const src,
                 char* const dst,
                 const int srcSize,
                 int *inputConsumed,
                 const int dstCapacity,
                 const limitedOutput_directive outputDirective,
                 const tableType_t tableType,
                 const dict_directive dictDirective,
                 const dictIssue_directive dictIssue,
                 const int acceleration)
{
    {};
    if ((U32)srcSize > (U32)0x7E000000) { return 0; }
    if (srcSize == 0) {
        if (outputDirective != notLimited && dstCapacity <= 0) return 0;
        {};
        ((void)0);
        ((void)0);
        dst[0] = 0;
        if (outputDirective == fillOutput) {
            ((void)0);
            *inputConsumed = 0;
        }
        return 1;
    }
    ((void)0);
    return LZ4_compress_generic_validated(cctx, src, dst, srcSize,
                inputConsumed,
                dstCapacity, outputDirective,
                tableType, dictDirective, dictIssue, acceleration);
}
int LZ4_compress_fast_extState(void* state, const char* source, char* dest, int inputSize, int maxOutputSize, int acceleration)
{
    LZ4_stream_t_internal* const ctx = & LZ4_initStream(state, sizeof(LZ4_stream_t)) -> internal_donotuse;
    ((void)0);
    if (acceleration < 1) acceleration = 1;
    if (acceleration > 65537) acceleration = 65537;
    if (maxOutputSize >= LZ4_compressBound(inputSize)) {
        if (inputSize < LZ4_64Klimit) {
            return LZ4_compress_generic(ctx, source, dest, inputSize, ((void*)0), 0, notLimited, byU16, noDict, noDictIssue, acceleration);
        } else {
            const tableType_t tableType = ((sizeof(void*)==4) && ((uptrval)source > 65535)) ? byPtr : byU32;
            return LZ4_compress_generic(ctx, source, dest, inputSize, ((void*)0), 0, notLimited, tableType, noDict, noDictIssue, acceleration);
        }
    } else {
        if (inputSize < LZ4_64Klimit) {
            return LZ4_compress_generic(ctx, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, byU16, noDict, noDictIssue, acceleration);
        } else {
            const tableType_t tableType = ((sizeof(void*)==4) && ((uptrval)source > 65535)) ? byPtr : byU32;
            return LZ4_compress_generic(ctx, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, noDict, noDictIssue, acceleration);
        }
    }
}
int LZ4_compress_fast_extState_fastReset(void* state, const char* src, char* dst, int srcSize, int dstCapacity, int acceleration)
{
    LZ4_stream_t_internal* ctx = &((LZ4_stream_t*)state)->internal_donotuse;
    if (acceleration < 1) acceleration = 1;
    if (acceleration > 65537) acceleration = 65537;
    if (dstCapacity >= LZ4_compressBound(srcSize)) {
        if (srcSize < LZ4_64Klimit) {
            const tableType_t tableType = byU16;
            LZ4_prepareTable(ctx, srcSize, tableType);
            if (ctx->currentOffset) {
                return LZ4_compress_generic(ctx, src, dst, srcSize, ((void*)0), 0, notLimited, tableType, noDict, dictSmall, acceleration);
            } else {
                return LZ4_compress_generic(ctx, src, dst, srcSize, ((void*)0), 0, notLimited, tableType, noDict, noDictIssue, acceleration);
            }
        } else {
            const tableType_t tableType = ((sizeof(void*)==4) && ((uptrval)src > 65535)) ? byPtr : byU32;
            LZ4_prepareTable(ctx, srcSize, tableType);
            return LZ4_compress_generic(ctx, src, dst, srcSize, ((void*)0), 0, notLimited, tableType, noDict, noDictIssue, acceleration);
        }
    } else {
        if (srcSize < LZ4_64Klimit) {
            const tableType_t tableType = byU16;
            LZ4_prepareTable(ctx, srcSize, tableType);
            if (ctx->currentOffset) {
                return LZ4_compress_generic(ctx, src, dst, srcSize, ((void*)0), dstCapacity, limitedOutput, tableType, noDict, dictSmall, acceleration);
            } else {
                return LZ4_compress_generic(ctx, src, dst, srcSize, ((void*)0), dstCapacity, limitedOutput, tableType, noDict, noDictIssue, acceleration);
            }
        } else {
            const tableType_t tableType = ((sizeof(void*)==4) && ((uptrval)src > 65535)) ? byPtr : byU32;
            LZ4_prepareTable(ctx, srcSize, tableType);
            return LZ4_compress_generic(ctx, src, dst, srcSize, ((void*)0), dstCapacity, limitedOutput, tableType, noDict, noDictIssue, acceleration);
        }
    }
}
int LZ4_compress_fast(const char* source, char* dest, int inputSize, int maxOutputSize, int acceleration)
{
    int result;
    LZ4_stream_t ctx;
    LZ4_stream_t* const ctxPtr = &ctx;
    result = LZ4_compress_fast_extState(ctxPtr, source, dest, inputSize, maxOutputSize, acceleration);
    return result;
}
int LZ4_compress_default(const char* src, char* dst, int srcSize, int maxOutputSize)
{
    return LZ4_compress_fast(src, dst, srcSize, maxOutputSize, 1);
}
static int LZ4_compress_destSize_extState (LZ4_stream_t* state, const char* src, char* dst, int* srcSizePtr, int targetDstSize)
{
    void* const s = LZ4_initStream(state, sizeof (*state));
    ((void)0); (void)s;
    if (targetDstSize >= LZ4_compressBound(*srcSizePtr)) {
        return LZ4_compress_fast_extState(state, src, dst, *srcSizePtr, targetDstSize, 1);
    } else {
        if (*srcSizePtr < LZ4_64Klimit) {
            return LZ4_compress_generic(&state->internal_donotuse, src, dst, *srcSizePtr, srcSizePtr, targetDstSize, fillOutput, byU16, noDict, noDictIssue, 1);
        } else {
            tableType_t const addrMode = ((sizeof(void*)==4) && ((uptrval)src > 65535)) ? byPtr : byU32;
            return LZ4_compress_generic(&state->internal_donotuse, src, dst, *srcSizePtr, srcSizePtr, targetDstSize, fillOutput, addrMode, noDict, noDictIssue, 1);
    } }
}
int LZ4_compress_destSize(const char* src, char* dst, int* srcSizePtr, int targetDstSize)
{
    LZ4_stream_t ctxBody;
    LZ4_stream_t* ctx = &ctxBody;
    int result = LZ4_compress_destSize_extState(ctx, src, dst, srcSizePtr, targetDstSize);
    return result;
}
LZ4_stream_t* LZ4_createStream(void)
{
    LZ4_stream_t* const lz4s = (LZ4_stream_t*)rd_kafka_mem_malloc(((void*)0), sizeof(LZ4_stream_t));
    { enum { LZ4_static_assert = 1/(int)(!!(sizeof(LZ4_stream_t) >= sizeof(LZ4_stream_t_internal))) }; };
    {};
    if (lz4s == ((void*)0)) return ((void*)0);
    LZ4_initStream(lz4s, sizeof(*lz4s));
    return lz4s;
}
static size_t LZ4_stream_t_alignment(void)
{
    typedef struct { char c; LZ4_stream_t t; } t_a;
    return sizeof(t_a) - sizeof(LZ4_stream_t);
}
LZ4_stream_t* LZ4_initStream (void* buffer, size_t size)
{
    {};
    if (buffer == ((void*)0)) { return ((void*)0); }
    if (size < sizeof(LZ4_stream_t)) { return ((void*)0); }
    if (!LZ4_isAligned(buffer, LZ4_stream_t_alignment())) return ((void*)0);
    memset(((buffer)),((0)),((sizeof(LZ4_stream_t_internal))));
    return (LZ4_stream_t*)buffer;
}
void LZ4_resetStream (LZ4_stream_t* LZ4_stream)
{
    {};
    memset(((LZ4_stream)),((0)),((sizeof(LZ4_stream_t_internal))));
}
void LZ4_resetStream_fast(LZ4_stream_t* ctx) {
    LZ4_prepareTable(&(ctx->internal_donotuse), 0, byU32);
}
int LZ4_freeStream (LZ4_stream_t* LZ4_stream)
{
    if (!LZ4_stream) return 0;
    {};
    rd_kafka_mem_free(((void*)0), LZ4_stream);
    return (0);
}
int LZ4_loadDict (LZ4_stream_t* LZ4_dict, const char* dictionary, int dictSize)
{
    LZ4_stream_t_internal* dict = &LZ4_dict->internal_donotuse;
    const tableType_t tableType = byU32;
    const BYTE* p = (const BYTE*)dictionary;
    const BYTE* const dictEnd = p + dictSize;
    const BYTE* base;
    {};
    LZ4_resetStream(LZ4_dict);
    dict->currentOffset += 64 *(1 <<10);
    if (dictSize < (int)sizeof(reg_t)) {
        return 0;
    }
    if ((dictEnd - p) > 64 *(1 <<10)) p = dictEnd - 64 *(1 <<10);
    base = dictEnd - dict->currentOffset;
    dict->dictionary = p;
    dict->dictSize = (U32)(dictEnd - p);
    dict->tableType = (U32)tableType;
    while (p <= dictEnd-sizeof(reg_t)) {
        LZ4_putPosition(p, dict->hashTable, tableType, base);
        p+=3;
    }
    return (int)dict->dictSize;
}
void LZ4_attach_dictionary(LZ4_stream_t* workingStream, const LZ4_stream_t* dictionaryStream)
{
    const LZ4_stream_t_internal* dictCtx = (dictionaryStream == ((void*)0)) ? ((void*)0) :
        &(dictionaryStream->internal_donotuse);
    {};
    if (dictCtx != ((void*)0)) {
        if (workingStream->internal_donotuse.currentOffset == 0) {
            workingStream->internal_donotuse.currentOffset = 64 *(1 <<10);
        }
        if (dictCtx->dictSize == 0) {
            dictCtx = ((void*)0);
        }
    }
    workingStream->internal_donotuse.dictCtx = dictCtx;
}
static void LZ4_renormDictT(LZ4_stream_t_internal* LZ4_dict, int nextSize)
{
    ((void)0);
    if (LZ4_dict->currentOffset + (unsigned)nextSize > 0x80000000) {
        U32 const delta = LZ4_dict->currentOffset - 64 *(1 <<10);
        const BYTE* dictEnd = LZ4_dict->dictionary + LZ4_dict->dictSize;
        int i;
        {};
        for (i=0; i<(1 << (14 -2)); i++) {
            if (LZ4_dict->hashTable[i] < delta) LZ4_dict->hashTable[i]=0;
            else LZ4_dict->hashTable[i] -= delta;
        }
        LZ4_dict->currentOffset = 64 *(1 <<10);
        if (LZ4_dict->dictSize > 64 *(1 <<10)) LZ4_dict->dictSize = 64 *(1 <<10);
        LZ4_dict->dictionary = dictEnd - LZ4_dict->dictSize;
    }
}
int LZ4_compress_fast_continue (LZ4_stream_t* LZ4_stream,
                                const char* source, char* dest,
                                int inputSize, int maxOutputSize,
                                int acceleration)
{
    const tableType_t tableType = byU32;
    LZ4_stream_t_internal* const streamPtr = &LZ4_stream->internal_donotuse;
    const char* dictEnd = streamPtr->dictSize ? (const char*)streamPtr->dictionary + streamPtr->dictSize : ((void*)0);
    {};
    LZ4_renormDictT(streamPtr, inputSize);
    if (acceleration < 1) acceleration = 1;
    if (acceleration > 65537) acceleration = 65537;
    if ( (streamPtr->dictSize < 4)
      && (dictEnd != source)
      && (inputSize > 0)
      && (streamPtr->dictCtx == ((void*)0))
      ) {
        {};
        streamPtr->dictSize = 0;
        streamPtr->dictionary = (const BYTE*)source;
        dictEnd = source;
    }
    { const char* const sourceEnd = source + inputSize;
        if ((sourceEnd > (const char*)streamPtr->dictionary) && (sourceEnd < dictEnd)) {
            streamPtr->dictSize = (U32)(dictEnd - sourceEnd);
            if (streamPtr->dictSize > 64 *(1 <<10)) streamPtr->dictSize = 64 *(1 <<10);
            if (streamPtr->dictSize < 4) streamPtr->dictSize = 0;
            streamPtr->dictionary = (const BYTE*)dictEnd - streamPtr->dictSize;
        }
    }
    if (dictEnd == source) {
        if ((streamPtr->dictSize < 64 *(1 <<10)) && (streamPtr->dictSize < streamPtr->currentOffset))
            return LZ4_compress_generic(streamPtr, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, withPrefix64k, dictSmall, acceleration);
        else
            return LZ4_compress_generic(streamPtr, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, withPrefix64k, noDictIssue, acceleration);
    }
    { int result;
        if (streamPtr->dictCtx) {
            if (inputSize > 4 *(1 <<10)) {
                __builtin_memcpy(streamPtr, streamPtr->dictCtx, sizeof(*streamPtr));
                result = LZ4_compress_generic(streamPtr, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, usingExtDict, noDictIssue, acceleration);
            } else {
                result = LZ4_compress_generic(streamPtr, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, usingDictCtx, noDictIssue, acceleration);
            }
        } else {
            if ((streamPtr->dictSize < 64 *(1 <<10)) && (streamPtr->dictSize < streamPtr->currentOffset)) {
                result = LZ4_compress_generic(streamPtr, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, usingExtDict, dictSmall, acceleration);
            } else {
                result = LZ4_compress_generic(streamPtr, source, dest, inputSize, ((void*)0), maxOutputSize, limitedOutput, tableType, usingExtDict, noDictIssue, acceleration);
            }
        }
        streamPtr->dictionary = (const BYTE*)source;
        streamPtr->dictSize = (U32)inputSize;
        return result;
    }
}
int LZ4_compress_forceExtDict (LZ4_stream_t* LZ4_dict, const char* source, char* dest, int srcSize)
{
    LZ4_stream_t_internal* streamPtr = &LZ4_dict->internal_donotuse;
    int result;
    LZ4_renormDictT(streamPtr, srcSize);
    if ((streamPtr->dictSize < 64 *(1 <<10)) && (streamPtr->dictSize < streamPtr->currentOffset)) {
        result = LZ4_compress_generic(streamPtr, source, dest, srcSize, ((void*)0), 0, notLimited, byU32, usingExtDict, dictSmall, 1);
    } else {
        result = LZ4_compress_generic(streamPtr, source, dest, srcSize, ((void*)0), 0, notLimited, byU32, usingExtDict, noDictIssue, 1);
    }
    streamPtr->dictionary = (const BYTE*)source;
    streamPtr->dictSize = (U32)srcSize;
    return result;
}
int LZ4_saveDict (LZ4_stream_t* LZ4_dict, char* safeBuffer, int dictSize)
{
    LZ4_stream_t_internal* const dict = &LZ4_dict->internal_donotuse;
    {};
    if ((U32)dictSize > 64 *(1 <<10)) { dictSize = 64 *(1 <<10); }
    if ((U32)dictSize > dict->dictSize) { dictSize = (int)dict->dictSize; }
    if (safeBuffer == ((void*)0)) ((void)0);
    if (dictSize > 0) {
        const BYTE* const previousDictEnd = dict->dictionary + dict->dictSize;
        ((void)0);
        __builtin_memmove(safeBuffer, previousDictEnd - dictSize, (size_t)dictSize);
    }
    dict->dictionary = (const BYTE*)safeBuffer;
    dict->dictSize = (U32)dictSize;
    return dictSize;
}
typedef enum { decode_full_block = 0, partial_decode = 1 } earlyEnd_directive;
size_t read_long_length_no_check(const BYTE** pp)
{
    size_t b, l = 0;
    do { b = **pp; (*pp)++; l += b; } while (b==255);
    {}
    return l;
}
static inline __attribute__((always_inline)) int
LZ4_decompress_unsafe_generic(
                 const BYTE* const istart,
                 BYTE* const ostart,
                 int decompressedSize,
                 size_t prefixSize,
                 const BYTE* const dictStart,
                 const size_t dictSize
                 )
{
    const BYTE* ip = istart;
    BYTE* op = (BYTE*)ostart;
    BYTE* const oend = ostart + decompressedSize;
    const BYTE* const prefixStart = ostart - prefixSize;
    {};
    if (dictStart == ((void*)0)) ((void)0);
    while (1) {
        unsigned token = *ip++;
        { size_t ll = token >> 4;
            if (ll==15) {
                ll += read_long_length_no_check(&ip);
            }
            if ((size_t)(oend-op) < ll) return -1;
            __builtin_memmove(op, ip, ll);
            op += ll;
            ip += ll;
            if ((size_t)(oend-op) < 12) {
                if (op==oend) break;
                {};
                return -1;
        } }
        { size_t ml = token & 15;
            size_t const offset = LZ4_readLE16(ip);
            ip+=2;
            if (ml==15) {
                ml += read_long_length_no_check(&ip);
            }
            ml += 4;
            if ((size_t)(oend-op) < ml) return -1;
            { const BYTE* match = op - offset;
                if (offset > (size_t)(op - prefixStart) + dictSize) {
                    {};
                    return -1;
                }
                if (offset > (size_t)(op - prefixStart)) {
                    const BYTE* const dictEnd = dictStart + dictSize;
                    const BYTE* extMatch = dictEnd - (offset - (size_t)(op-prefixStart));
                    size_t const extml = (size_t)(dictEnd - extMatch);
                    if (extml > ml) {
                        __builtin_memmove(op, extMatch, ml);
                        op += ml;
                        ml = 0;
                    } else {
                        __builtin_memmove(op, extMatch, extml);
                        op += extml;
                        ml -= extml;
                    }
                    match = prefixStart;
                }
                { size_t u;
                    for (u=0; u<ml; u++) {
                        op[u] = match[u];
            } } }
            op += ml;
            if ((size_t)(oend-op) < 5) {
                {};
                return -1;
            }
        }
    }
    return (int)(ip - istart);
}
typedef size_t Rvl_t;
static const Rvl_t rvl_error = (Rvl_t)(-1);
static inline __attribute__((always_inline)) Rvl_t
read_variable_length(const BYTE** ip, const BYTE* ilimit,
                     int initial_check)
{
    Rvl_t s, length = 0;
    ((void)0);
    ((void)0);
    ((void)0);
    if (initial_check && (__builtin_expect ((((*ip) >= ilimit) != 0),(0)) )) {
        return rvl_error;
    }
    do {
        s = **ip;
        (*ip)++;
        length += s;
        if ((__builtin_expect ((((*ip) > ilimit) != 0),(0)) )) {
            return rvl_error;
        }
        if ((sizeof(length)<8) && (__builtin_expect (((length > ((Rvl_t)(-1)/2)) != 0),(0)) ) ) {
            return rvl_error;
        }
    } while (s==255);
    return length;
}
static inline __attribute__((always_inline)) int
LZ4_decompress_generic(
                 const char* const src,
                 char* const dst,
                 int srcSize,
                 int outputSize,
                 earlyEnd_directive partialDecoding,
                 dict_directive dict,
                 const BYTE* const lowPrefix,
                 const BYTE* const dictStart,
                 const size_t dictSize
                 )
{
    if ((src == ((void*)0)) || (outputSize < 0)) { return -1; }
    { const BYTE* ip = (const BYTE*) src;
        const BYTE* const iend = ip + srcSize;
        BYTE* op = (BYTE*) dst;
        BYTE* const oend = op + outputSize;
        BYTE* cpy;
        const BYTE* const dictEnd = (dictStart == ((void*)0)) ? ((void*)0) : dictStart + dictSize;
        const int checkOffset = (dictSize < (int)(64 *(1 <<10)));
        const BYTE* const shortiend = iend - 14 - 2 ;
        const BYTE* const shortoend = oend - 14 - 18 ;
        const BYTE* match;
        size_t offset;
        unsigned token;
        size_t length;
        {};
        ((void)0);
        if ((__builtin_expect (((outputSize==0) != 0),(0)) )) {
            if (partialDecoding) return 0;
            return ((srcSize==1) && (*ip==0)) ? 0 : -1;
        }
        if ((__builtin_expect (((srcSize==0) != 0),(0)) )) { return -1; }
        if ((oend - op) < 64) {
            {};
            goto safe_decode;
        }
        while (1) {
            ((void)0);
            ((void)0);
            token = *ip++;
            length = token >> 4;
            if (length == ((1U<<(8-4))-1)) {
                size_t const addl = read_variable_length(&ip, iend-((1U<<(8-4))-1), 1);
                if (addl == rvl_error) { goto _output_error; }
                length += addl;
                if ((__builtin_expect ((((uptrval)(op)+length<(uptrval)(op)) != 0),(0)) )) { goto _output_error; }
                if ((__builtin_expect ((((uptrval)(ip)+length<(uptrval)(ip)) != 0),(0)) )) { goto _output_error; }
                cpy = op+length;
                { enum { LZ4_static_assert = 1/(int)(!!(12 >= 8)) }; };
                if ((cpy>oend-32) || (ip+length>iend-32)) { goto safe_literal_copy; }
                LZ4_wildCopy32(op, ip, cpy);
                ip += length; op = cpy;
            } else {
                cpy = op+length;
                {};
                if (ip > iend-(16 + 1 )) { goto safe_literal_copy; }
                __builtin_memcpy(op, ip, 16);
                ip += length; op = cpy;
            }
            offset = LZ4_readLE16(ip); ip+=2;
            match = op - offset;
            ((void)0);
            length = token & ((1U<<4)-1);
            if (length == ((1U<<4)-1)) {
                size_t const addl = read_variable_length(&ip, iend - 5 + 1, 0);
                if (addl == rvl_error) { goto _output_error; }
                length += addl;
                length += 4;
                if ((__builtin_expect ((((uptrval)(op)+length<(uptrval)op) != 0),(0)) )) { goto _output_error; }
                if ((checkOffset) && ((__builtin_expect (((match + dictSize < lowPrefix) != 0),(0)) ))) { goto _output_error; }
                if (op + length >= oend - 64) {
                    goto safe_match_copy;
                }
            } else {
                length += 4;
                if (op + length >= oend - 64) {
                    goto safe_match_copy;
                }
                if ((dict == withPrefix64k) || (match >= lowPrefix)) {
                    if (offset >= 8) {
                        ((void)0);
                        ((void)0);
                        ((void)0);
                        __builtin_memcpy(op, match, 8);
                        __builtin_memcpy(op+8, match+8, 8);
                        __builtin_memcpy(op+16, match+16, 2);
                        op += length;
                        continue;
            } } }
            if (checkOffset && ((__builtin_expect (((match + dictSize < lowPrefix) != 0),(0)) ))) { goto _output_error; }
            if ((dict==usingExtDict) && (match < lowPrefix)) {
                ((void)0);
                if ((__builtin_expect (((op+length > oend-5) != 0),(0)) )) {
                    if (partialDecoding) {
                        {};
                        length = ( (length) < ((size_t)(oend-op)) ? (length) : ((size_t)(oend-op)) );
                    } else {
                        goto _output_error;
                } }
                if (length <= (size_t)(lowPrefix-match)) {
                    __builtin_memmove(op, dictEnd - (lowPrefix-match), length);
                    op += length;
                } else {
                    size_t const copySize = (size_t)(lowPrefix - match);
                    size_t const restSize = length - copySize;
                    __builtin_memcpy(op, dictEnd - copySize, copySize);
                    op += copySize;
                    if (restSize > (size_t)(op - lowPrefix)) {
                        BYTE* const endOfMatch = op + restSize;
                        const BYTE* copyFrom = lowPrefix;
                        while (op < endOfMatch) { *op++ = *copyFrom++; }
                    } else {
                        __builtin_memcpy(op, lowPrefix, restSize);
                        op += restSize;
                } }
                continue;
            }
            cpy = op + length;
            ((void)0);
            if ((__builtin_expect (((offset<16) != 0),(0)) )) {
                LZ4_memcpy_using_offset(op, match, cpy, offset);
            } else {
                LZ4_wildCopy32(op, match, cpy);
            }
            op = cpy;
        }
    safe_decode:
        while (1) {
            ((void)0);
            token = *ip++;
            length = token >> 4;
            if ( (length != ((1U<<(8-4))-1))
              && (__builtin_expect ((((ip < shortiend) & (op <= shortoend)) != 0),(1)) ) ) {
                __builtin_memcpy(op, ip, 16);
                op += length; ip += length;
                length = token & ((1U<<4)-1);
                offset = LZ4_readLE16(ip); ip += 2;
                match = op - offset;
                ((void)0);
                if ( (length != ((1U<<4)-1))
                  && (offset >= 8)
                  && (dict==withPrefix64k || match >= lowPrefix) ) {
                    __builtin_memcpy(op + 0, match + 0, 8);
                    __builtin_memcpy(op + 8, match + 8, 8);
                    __builtin_memcpy(op +16, match +16, 2);
                    op += length + 4;
                    continue;
                }
                goto _copy_match;
            }
            if (length == ((1U<<(8-4))-1)) {
                size_t const addl = read_variable_length(&ip, iend-((1U<<(8-4))-1), 1);
                if (addl == rvl_error) { goto _output_error; }
                length += addl;
                if ((__builtin_expect ((((uptrval)(op)+length<(uptrval)(op)) != 0),(0)) )) { goto _output_error; }
                if ((__builtin_expect ((((uptrval)(ip)+length<(uptrval)(ip)) != 0),(0)) )) { goto _output_error; }
            }
            cpy = op+length;
        safe_literal_copy:
            { enum { LZ4_static_assert = 1/(int)(!!(12 >= 8)) }; };
            if ((cpy>oend-12) || (ip+length>iend-(2+1+5))) {
                if (partialDecoding) {
                    {}
                    {};
                    {};
                    {};
                    if (ip+length > iend) {
                        length = (size_t)(iend-ip);
                        cpy = op + length;
                    }
                    if (cpy > oend) {
                        cpy = oend;
                        ((void)0);
                        length = (size_t)(oend-op);
                    }
                } else {
                    if ((ip+length != iend) || (cpy > oend)) {
                        {}
                        {};
                        {};
                        goto _output_error;
                    }
                }
                __builtin_memmove(op, ip, length);
                ip += length;
                op += length;
                if (!partialDecoding || (cpy == oend) || (ip >= (iend-2))) {
                    break;
                }
            } else {
                LZ4_wildCopy8(op, ip, cpy);
                ip += length; op = cpy;
            }
            offset = LZ4_readLE16(ip); ip+=2;
            match = op - offset;
            length = token & ((1U<<4)-1);
    _copy_match:
            if (length == ((1U<<4)-1)) {
                size_t const addl = read_variable_length(&ip, iend - 5 + 1, 0);
                if (addl == rvl_error) { goto _output_error; }
                length += addl;
                if ((__builtin_expect ((((uptrval)(op)+length<(uptrval)op) != 0),(0)) )) goto _output_error;
            }
            length += 4;
        safe_match_copy:
            if ((checkOffset) && ((__builtin_expect (((match + dictSize < lowPrefix) != 0),(0)) ))) goto _output_error;
            if ((dict==usingExtDict) && (match < lowPrefix)) {
                ((void)0);
                if ((__builtin_expect (((op+length > oend-5) != 0),(0)) )) {
                    if (partialDecoding) length = ( (length) < ((size_t)(oend-op)) ? (length) : ((size_t)(oend-op)) );
                    else goto _output_error;
                }
                if (length <= (size_t)(lowPrefix-match)) {
                    __builtin_memmove(op, dictEnd - (lowPrefix-match), length);
                    op += length;
                } else {
                    size_t const copySize = (size_t)(lowPrefix - match);
                    size_t const restSize = length - copySize;
                    __builtin_memcpy(op, dictEnd - copySize, copySize);
                    op += copySize;
                    if (restSize > (size_t)(op - lowPrefix)) {
                        BYTE* const endOfMatch = op + restSize;
                        const BYTE* copyFrom = lowPrefix;
                        while (op < endOfMatch) *op++ = *copyFrom++;
                    } else {
                        __builtin_memcpy(op, lowPrefix, restSize);
                        op += restSize;
                } }
                continue;
            }
            ((void)0);
            cpy = op + length;
            ((void)0);
            if (partialDecoding && (cpy > oend-((2*8) - 4))) {
                size_t const mlen = ( (length) < ((size_t)(oend-op)) ? (length) : ((size_t)(oend-op)) );
                const BYTE* const matchEnd = match + mlen;
                BYTE* const copyEnd = op + mlen;
                if (matchEnd > op) {
                    while (op < copyEnd) { *op++ = *match++; }
                } else {
                    __builtin_memcpy(op, match, mlen);
                }
                op = copyEnd;
                if (op == oend) { break; }
                continue;
            }
            if ((__builtin_expect (((offset<8) != 0),(0)) )) {
                LZ4_write32(op, 0);
                op[0] = match[0];
                op[1] = match[1];
                op[2] = match[2];
                op[3] = match[3];
                match += inc32table[offset];
                __builtin_memcpy(op+4, match, 4);
                match -= dec64table[offset];
            } else {
                __builtin_memcpy(op, match, 8);
                match += 8;
            }
            op += 8;
            if ((__builtin_expect (((cpy > oend-((2*8) - 4)) != 0),(0)) )) {
                BYTE* const oCopyLimit = oend - (8 -1);
                if (cpy > oend-5) { goto _output_error; }
                if (op < oCopyLimit) {
                    LZ4_wildCopy8(op, match, oCopyLimit);
                    match += oCopyLimit - op;
                    op = oCopyLimit;
                }
                while (op < cpy) { *op++ = *match++; }
            } else {
                __builtin_memcpy(op, match, 8);
                if (length > 16) { LZ4_wildCopy8(op+8, match+8, cpy); }
            }
            op = cpy;
        }
        {};
        return (int) (((char*)op)-dst);
    _output_error:
        return (int) (-(((const char*)ip)-src))-1;
    }
}
int LZ4_decompress_safe(const char* source, char* dest, int compressedSize, int maxDecompressedSize)
{
    return LZ4_decompress_generic(source, dest, compressedSize, maxDecompressedSize,
                                  decode_full_block, noDict,
                                  (BYTE*)dest, ((void*)0), 0);
}
int LZ4_decompress_safe_partial(const char* src, char* dst, int compressedSize, int targetOutputSize, int dstCapacity)
{
    dstCapacity = ( (targetOutputSize) < (dstCapacity) ? (targetOutputSize) : (dstCapacity) );
    return LZ4_decompress_generic(src, dst, compressedSize, dstCapacity,
                                  partial_decode,
                                  noDict, (BYTE*)dst, ((void*)0), 0);
}
int LZ4_decompress_fast(const char* source, char* dest, int originalSize)
{
    {};
    return LZ4_decompress_unsafe_generic(
                (const BYTE*)source, (BYTE*)dest, originalSize,
                0, ((void*)0), 0);
}
int LZ4_decompress_safe_withPrefix64k(const char* source, char* dest, int compressedSize, int maxOutputSize)
{
    return LZ4_decompress_generic(source, dest, compressedSize, maxOutputSize,
                                  decode_full_block, withPrefix64k,
                                  (BYTE*)dest - 64 *(1 <<10), ((void*)0), 0);
}
static int LZ4_decompress_safe_partial_withPrefix64k(const char* source, char* dest, int compressedSize, int targetOutputSize, int dstCapacity)
{
    dstCapacity = ( (targetOutputSize) < (dstCapacity) ? (targetOutputSize) : (dstCapacity) );
    return LZ4_decompress_generic(source, dest, compressedSize, dstCapacity,
                                  partial_decode, withPrefix64k,
                                  (BYTE*)dest - 64 *(1 <<10), ((void*)0), 0);
}
int LZ4_decompress_fast_withPrefix64k(const char* source, char* dest, int originalSize)
{
    return LZ4_decompress_unsafe_generic(
                (const BYTE*)source, (BYTE*)dest, originalSize,
                64 *(1 <<10), ((void*)0), 0);
}
static int LZ4_decompress_safe_withSmallPrefix(const char* source, char* dest, int compressedSize, int maxOutputSize,
                                               size_t prefixSize)
{
    return LZ4_decompress_generic(source, dest, compressedSize, maxOutputSize,
                                  decode_full_block, noDict,
                                  (BYTE*)dest-prefixSize, ((void*)0), 0);
}
static int LZ4_decompress_safe_partial_withSmallPrefix(const char* source, char* dest, int compressedSize, int targetOutputSize, int dstCapacity,
                                               size_t prefixSize)
{
    dstCapacity = ( (targetOutputSize) < (dstCapacity) ? (targetOutputSize) : (dstCapacity) );
    return LZ4_decompress_generic(source, dest, compressedSize, dstCapacity,
                                  partial_decode, noDict,
                                  (BYTE*)dest-prefixSize, ((void*)0), 0);
}
int LZ4_decompress_safe_forceExtDict(const char* source, char* dest,
                                     int compressedSize, int maxOutputSize,
                                     const void* dictStart, size_t dictSize)
{
    return LZ4_decompress_generic(source, dest, compressedSize, maxOutputSize,
                                  decode_full_block, usingExtDict,
                                  (BYTE*)dest, (const BYTE*)dictStart, dictSize);
}
int LZ4_decompress_safe_partial_forceExtDict(const char* source, char* dest,
                                     int compressedSize, int targetOutputSize, int dstCapacity,
                                     const void* dictStart, size_t dictSize)
{
    dstCapacity = ( (targetOutputSize) < (dstCapacity) ? (targetOutputSize) : (dstCapacity) );
    return LZ4_decompress_generic(source, dest, compressedSize, dstCapacity,
                                  partial_decode, usingExtDict,
                                  (BYTE*)dest, (const BYTE*)dictStart, dictSize);
}
static int LZ4_decompress_fast_extDict(const char* source, char* dest, int originalSize,
                                       const void* dictStart, size_t dictSize)
{
    return LZ4_decompress_unsafe_generic(
                (const BYTE*)source, (BYTE*)dest, originalSize,
                0, (const BYTE*)dictStart, dictSize);
}
static inline __attribute__((always_inline))
int LZ4_decompress_safe_doubleDict(const char* source, char* dest, int compressedSize, int maxOutputSize,
                                   size_t prefixSize, const void* dictStart, size_t dictSize)
{
    return LZ4_decompress_generic(source, dest, compressedSize, maxOutputSize,
                                  decode_full_block, usingExtDict,
                                  (BYTE*)dest-prefixSize, (const BYTE*)dictStart, dictSize);
}
LZ4_streamDecode_t* LZ4_createStreamDecode(void)
{
    { enum { LZ4_static_assert = 1/(int)(!!(sizeof(LZ4_streamDecode_t) >= sizeof(LZ4_streamDecode_t_internal))) }; };
    return (LZ4_streamDecode_t*) rd_kafka_mem_calloc(((void*)0), 1, sizeof(LZ4_streamDecode_t));
}
int LZ4_freeStreamDecode (LZ4_streamDecode_t* LZ4_stream)
{
    if (LZ4_stream == ((void*)0)) { return 0; }
    rd_kafka_mem_free(((void*)0), LZ4_stream);
    return 0;
}
int LZ4_setStreamDecode (LZ4_streamDecode_t* LZ4_streamDecode, const char* dictionary, int dictSize)
{
    LZ4_streamDecode_t_internal* lz4sd = &LZ4_streamDecode->internal_donotuse;
    lz4sd->prefixSize = (size_t)dictSize;
    if (dictSize) {
        ((void)0);
        lz4sd->prefixEnd = (const BYTE*) dictionary + dictSize;
    } else {
        lz4sd->prefixEnd = (const BYTE*) dictionary;
    }
    lz4sd->externalDict = ((void*)0);
    lz4sd->extDictSize = 0;
    return 1;
}
int LZ4_decoderRingBufferSize(int maxBlockSize)
{
    if (maxBlockSize < 0) return 0;
    if (maxBlockSize > 0x7E000000) return 0;
    if (maxBlockSize < 16) maxBlockSize = 16;
    return (65536 + 14 + (maxBlockSize));
}
int LZ4_decompress_safe_continue (LZ4_streamDecode_t* LZ4_streamDecode, const char* source, char* dest, int compressedSize, int maxOutputSize)
{
    LZ4_streamDecode_t_internal* lz4sd = &LZ4_streamDecode->internal_donotuse;
    int result;
    if (lz4sd->prefixSize == 0) {
        ((void)0);
        result = LZ4_decompress_safe(source, dest, compressedSize, maxOutputSize);
        if (result <= 0) return result;
        lz4sd->prefixSize = (size_t)result;
        lz4sd->prefixEnd = (BYTE*)dest + result;
    } else if (lz4sd->prefixEnd == (BYTE*)dest) {
        if (lz4sd->prefixSize >= 64 *(1 <<10) - 1)
            result = LZ4_decompress_safe_withPrefix64k(source, dest, compressedSize, maxOutputSize);
        else if (lz4sd->extDictSize == 0)
            result = LZ4_decompress_safe_withSmallPrefix(source, dest, compressedSize, maxOutputSize,
                                                         lz4sd->prefixSize);
        else
            result = LZ4_decompress_safe_doubleDict(source, dest, compressedSize, maxOutputSize,
                                                    lz4sd->prefixSize, lz4sd->externalDict, lz4sd->extDictSize);
        if (result <= 0) return result;
        lz4sd->prefixSize += (size_t)result;
        lz4sd->prefixEnd += result;
    } else {
        lz4sd->extDictSize = lz4sd->prefixSize;
        lz4sd->externalDict = lz4sd->prefixEnd - lz4sd->extDictSize;
        result = LZ4_decompress_safe_forceExtDict(source, dest, compressedSize, maxOutputSize,
                                                  lz4sd->externalDict, lz4sd->extDictSize);
        if (result <= 0) return result;
        lz4sd->prefixSize = (size_t)result;
        lz4sd->prefixEnd = (BYTE*)dest + result;
    }
    return result;
}
             int
LZ4_decompress_fast_continue (LZ4_streamDecode_t* LZ4_streamDecode,
                        const char* source, char* dest, int originalSize)
{
    LZ4_streamDecode_t_internal* const lz4sd =
        (((void)0), &LZ4_streamDecode->internal_donotuse);
    int result;
    {};
    ((void)0);
    if (lz4sd->prefixSize == 0) {
        {};
        ((void)0);
        result = LZ4_decompress_fast(source, dest, originalSize);
        if (result <= 0) return result;
        lz4sd->prefixSize = (size_t)originalSize;
        lz4sd->prefixEnd = (BYTE*)dest + originalSize;
    } else if (lz4sd->prefixEnd == (BYTE*)dest) {
        {};
        result = LZ4_decompress_unsafe_generic(
                        (const BYTE*)source, (BYTE*)dest, originalSize,
                        lz4sd->prefixSize,
                        lz4sd->externalDict, lz4sd->extDictSize);
        if (result <= 0) return result;
        lz4sd->prefixSize += (size_t)originalSize;
        lz4sd->prefixEnd += originalSize;
    } else {
        {};
        lz4sd->extDictSize = lz4sd->prefixSize;
        lz4sd->externalDict = lz4sd->prefixEnd - lz4sd->extDictSize;
        result = LZ4_decompress_fast_extDict(source, dest, originalSize,
                                             lz4sd->externalDict, lz4sd->extDictSize);
        if (result <= 0) return result;
        lz4sd->prefixSize = (size_t)originalSize;
        lz4sd->prefixEnd = (BYTE*)dest + originalSize;
    }
    return result;
}
int LZ4_decompress_safe_usingDict(const char* source, char* dest, int compressedSize, int maxOutputSize, const char* dictStart, int dictSize)
{
    if (dictSize==0)
        return LZ4_decompress_safe(source, dest, compressedSize, maxOutputSize);
    if (dictStart+dictSize == dest) {
        if (dictSize >= 64 *(1 <<10) - 1) {
            return LZ4_decompress_safe_withPrefix64k(source, dest, compressedSize, maxOutputSize);
        }
        ((void)0);
        return LZ4_decompress_safe_withSmallPrefix(source, dest, compressedSize, maxOutputSize, (size_t)dictSize);
    }
    ((void)0);
    return LZ4_decompress_safe_forceExtDict(source, dest, compressedSize, maxOutputSize, dictStart, (size_t)dictSize);
}
int LZ4_decompress_safe_partial_usingDict(const char* source, char* dest, int compressedSize, int targetOutputSize, int dstCapacity, const char* dictStart, int dictSize)
{
    if (dictSize==0)
        return LZ4_decompress_safe_partial(source, dest, compressedSize, targetOutputSize, dstCapacity);
    if (dictStart+dictSize == dest) {
        if (dictSize >= 64 *(1 <<10) - 1) {
            return LZ4_decompress_safe_partial_withPrefix64k(source, dest, compressedSize, targetOutputSize, dstCapacity);
        }
        ((void)0);
        return LZ4_decompress_safe_partial_withSmallPrefix(source, dest, compressedSize, targetOutputSize, dstCapacity, (size_t)dictSize);
    }
    ((void)0);
    return LZ4_decompress_safe_partial_forceExtDict(source, dest, compressedSize, targetOutputSize, dstCapacity, dictStart, (size_t)dictSize);
}
int LZ4_decompress_fast_usingDict(const char* source, char* dest, int originalSize, const char* dictStart, int dictSize)
{
    if (dictSize==0 || dictStart+dictSize == dest)
        return LZ4_decompress_unsafe_generic(
                        (const BYTE*)source, (BYTE*)dest, originalSize,
                        (size_t)dictSize, ((void*)0), 0);
    ((void)0);
    return LZ4_decompress_fast_extDict(source, dest, originalSize, dictStart, (size_t)dictSize);
}
int LZ4_compress_limitedOutput(const char* source, char* dest, int inputSize, int maxOutputSize)
{
    return LZ4_compress_default(source, dest, inputSize, maxOutputSize);
}
int LZ4_compress(const char* src, char* dest, int srcSize)
{
    return LZ4_compress_default(src, dest, srcSize, LZ4_compressBound(srcSize));
}
int LZ4_compress_limitedOutput_withState (void* state, const char* src, char* dst, int srcSize, int dstSize)
{
    return LZ4_compress_fast_extState(state, src, dst, srcSize, dstSize, 1);
}
int LZ4_compress_withState (void* state, const char* src, char* dst, int srcSize)
{
    return LZ4_compress_fast_extState(state, src, dst, srcSize, LZ4_compressBound(srcSize), 1);
}
int LZ4_compress_limitedOutput_continue (LZ4_stream_t* LZ4_stream, const char* src, char* dst, int srcSize, int dstCapacity)
{
    return LZ4_compress_fast_continue(LZ4_stream, src, dst, srcSize, dstCapacity, 1);
}
int LZ4_compress_continue (LZ4_stream_t* LZ4_stream, const char* source, char* dest, int inputSize)
{
    return LZ4_compress_fast_continue(LZ4_stream, source, dest, inputSize, LZ4_compressBound(inputSize), 1);
}
int LZ4_uncompress (const char* source, char* dest, int outputSize)
{
    return LZ4_decompress_fast(source, dest, outputSize);
}
int LZ4_uncompress_unknownOutputSize (const char* source, char* dest, int isize, int maxOutputSize)
{
    return LZ4_decompress_safe(source, dest, isize, maxOutputSize);
}
int LZ4_sizeofStreamState(void) { return sizeof(LZ4_stream_t); }
int LZ4_resetStreamState(void* state, char* inputBuffer)
{
    (void)inputBuffer;
    LZ4_resetStream((LZ4_stream_t*)state);
    return 0;
}
void* LZ4_create (char* inputBuffer)
{
    (void)inputBuffer;
    return LZ4_createStream();
}
char* LZ4_slideInputBuffer (void* state)
{
    return (char *)(uptrval)((LZ4_stream_t*)state)->internal_donotuse.dictionary;
}
