typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;
typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;
typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;
typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;
typedef long int __quad_t;
typedef unsigned long int __u_quad_t;
typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;
typedef int __daddr_t;
typedef int __key_t;
typedef int __clockid_t;
typedef void * __timer_t;
typedef long int __blksize_t;
typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;
typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;
typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;
typedef long int __fsword_t;
typedef long int __ssize_t;
typedef long int __syscall_slong_t;
typedef unsigned long int __syscall_ulong_t;
typedef __off64_t __loff_t;
typedef char *__caddr_t;
typedef long int __intptr_t;
typedef unsigned int __socklen_t;
typedef int __sig_atomic_t;
typedef __ssize_t ssize_t;
typedef long unsigned int size_t;
typedef __gid_t gid_t;
typedef __uid_t uid_t;
typedef __off_t off_t;
typedef __useconds_t useconds_t;
typedef __pid_t pid_t;
typedef __intptr_t intptr_t;
typedef __socklen_t socklen_t;
extern int access (const char *__name, int __type) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int faccessat (int __fd, const char *__file, int __type, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
extern __off_t lseek (int __fd, __off_t __offset, int __whence) __attribute__ ((__nothrow__ ));
extern int close (int __fd);
extern void closefrom (int __lowfd) __attribute__ ((__nothrow__ ));
extern ssize_t read (int __fd, void *__buf, size_t __nbytes)
                                                  ;
extern ssize_t write (int __fd, const void *__buf, size_t __n)
                                         ;
extern ssize_t pread (int __fd, void *__buf, size_t __nbytes,
        __off_t __offset)
                                                  ;
extern ssize_t pwrite (int __fd, const void *__buf, size_t __n,
         __off_t __offset)
                                         ;
extern int pipe (int __pipedes[2]) __attribute__ ((__nothrow__ )) ;
extern unsigned int alarm (unsigned int __seconds) __attribute__ ((__nothrow__ ));
extern unsigned int sleep (unsigned int __seconds);
extern __useconds_t ualarm (__useconds_t __value, __useconds_t __interval)
     __attribute__ ((__nothrow__ ));
extern int usleep (__useconds_t __useconds);
extern int pause (void);
extern int chown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int fchown (int __fd, __uid_t __owner, __gid_t __group) __attribute__ ((__nothrow__ )) ;
extern int lchown (const char *__file, __uid_t __owner, __gid_t __group)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int fchownat (int __fd, const char *__file, __uid_t __owner,
       __gid_t __group, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
extern int chdir (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int fchdir (int __fd) __attribute__ ((__nothrow__ )) ;
extern char *getcwd (char *__buf, size_t __size) __attribute__ ((__nothrow__ )) ;
extern char *getwd (char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) __attribute__ ((__deprecated__))
                                       ;
extern int dup (int __fd) __attribute__ ((__nothrow__ )) ;
extern int dup2 (int __fd, int __fd2) __attribute__ ((__nothrow__ ));
extern char **__environ;
extern int execve (const char *__path, char *const __argv[],
     char *const __envp[]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int fexecve (int __fd, char *const __argv[], char *const __envp[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int execv (const char *__path, char *const __argv[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execle (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execl (const char *__path, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execvp (const char *__file, char *const __argv[])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int execlp (const char *__file, const char *__arg, ...)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int nice (int __inc) __attribute__ ((__nothrow__ )) ;
extern void _exit (int __status) __attribute__ ((__noreturn__));
enum
  {
    _PC_LINK_MAX,
    _PC_MAX_CANON,
    _PC_MAX_INPUT,
    _PC_NAME_MAX,
    _PC_PATH_MAX,
    _PC_PIPE_BUF,
    _PC_CHOWN_RESTRICTED,
    _PC_NO_TRUNC,
    _PC_VDISABLE,
    _PC_SYNC_IO,
    _PC_ASYNC_IO,
    _PC_PRIO_IO,
    _PC_SOCK_MAXBUF,
    _PC_FILESIZEBITS,
    _PC_REC_INCR_XFER_SIZE,
    _PC_REC_MAX_XFER_SIZE,
    _PC_REC_MIN_XFER_SIZE,
    _PC_REC_XFER_ALIGN,
    _PC_ALLOC_SIZE_MIN,
    _PC_SYMLINK_MAX,
    _PC_2_SYMLINKS
  };
enum
  {
    _SC_ARG_MAX,
    _SC_CHILD_MAX,
    _SC_CLK_TCK,
    _SC_NGROUPS_MAX,
    _SC_OPEN_MAX,
    _SC_STREAM_MAX,
    _SC_TZNAME_MAX,
    _SC_JOB_CONTROL,
    _SC_SAVED_IDS,
    _SC_REALTIME_SIGNALS,
    _SC_PRIORITY_SCHEDULING,
    _SC_TIMERS,
    _SC_ASYNCHRONOUS_IO,
    _SC_PRIORITIZED_IO,
    _SC_SYNCHRONIZED_IO,
    _SC_FSYNC,
    _SC_MAPPED_FILES,
    _SC_MEMLOCK,
    _SC_MEMLOCK_RANGE,
    _SC_MEMORY_PROTECTION,
    _SC_MESSAGE_PASSING,
    _SC_SEMAPHORES,
    _SC_SHARED_MEMORY_OBJECTS,
    _SC_AIO_LISTIO_MAX,
    _SC_AIO_MAX,
    _SC_AIO_PRIO_DELTA_MAX,
    _SC_DELAYTIMER_MAX,
    _SC_MQ_OPEN_MAX,
    _SC_MQ_PRIO_MAX,
    _SC_VERSION,
    _SC_PAGESIZE,
    _SC_RTSIG_MAX,
    _SC_SEM_NSEMS_MAX,
    _SC_SEM_VALUE_MAX,
    _SC_SIGQUEUE_MAX,
    _SC_TIMER_MAX,
    _SC_BC_BASE_MAX,
    _SC_BC_DIM_MAX,
    _SC_BC_SCALE_MAX,
    _SC_BC_STRING_MAX,
    _SC_COLL_WEIGHTS_MAX,
    _SC_EQUIV_CLASS_MAX,
    _SC_EXPR_NEST_MAX,
    _SC_LINE_MAX,
    _SC_RE_DUP_MAX,
    _SC_CHARCLASS_NAME_MAX,
    _SC_2_VERSION,
    _SC_2_C_BIND,
    _SC_2_C_DEV,
    _SC_2_FORT_DEV,
    _SC_2_FORT_RUN,
    _SC_2_SW_DEV,
    _SC_2_LOCALEDEF,
    _SC_PII,
    _SC_PII_XTI,
    _SC_PII_SOCKET,
    _SC_PII_INTERNET,
    _SC_PII_OSI,
    _SC_POLL,
    _SC_SELECT,
    _SC_UIO_MAXIOV,
    _SC_IOV_MAX = _SC_UIO_MAXIOV,
    _SC_PII_INTERNET_STREAM,
    _SC_PII_INTERNET_DGRAM,
    _SC_PII_OSI_COTS,
    _SC_PII_OSI_CLTS,
    _SC_PII_OSI_M,
    _SC_T_IOV_MAX,
    _SC_THREADS,
    _SC_THREAD_SAFE_FUNCTIONS,
    _SC_GETGR_R_SIZE_MAX,
    _SC_GETPW_R_SIZE_MAX,
    _SC_LOGIN_NAME_MAX,
    _SC_TTY_NAME_MAX,
    _SC_THREAD_DESTRUCTOR_ITERATIONS,
    _SC_THREAD_KEYS_MAX,
    _SC_THREAD_STACK_MIN,
    _SC_THREAD_THREADS_MAX,
    _SC_THREAD_ATTR_STACKADDR,
    _SC_THREAD_ATTR_STACKSIZE,
    _SC_THREAD_PRIORITY_SCHEDULING,
    _SC_THREAD_PRIO_INHERIT,
    _SC_THREAD_PRIO_PROTECT,
    _SC_THREAD_PROCESS_SHARED,
    _SC_NPROCESSORS_CONF,
    _SC_NPROCESSORS_ONLN,
    _SC_PHYS_PAGES,
    _SC_AVPHYS_PAGES,
    _SC_ATEXIT_MAX,
    _SC_PASS_MAX,
    _SC_XOPEN_VERSION,
    _SC_XOPEN_XCU_VERSION,
    _SC_XOPEN_UNIX,
    _SC_XOPEN_CRYPT,
    _SC_XOPEN_ENH_I18N,
    _SC_XOPEN_SHM,
    _SC_2_CHAR_TERM,
    _SC_2_C_VERSION,
    _SC_2_UPE,
    _SC_XOPEN_XPG2,
    _SC_XOPEN_XPG3,
    _SC_XOPEN_XPG4,
    _SC_CHAR_BIT,
    _SC_CHAR_MAX,
    _SC_CHAR_MIN,
    _SC_INT_MAX,
    _SC_INT_MIN,
    _SC_LONG_BIT,
    _SC_WORD_BIT,
    _SC_MB_LEN_MAX,
    _SC_NZERO,
    _SC_SSIZE_MAX,
    _SC_SCHAR_MAX,
    _SC_SCHAR_MIN,
    _SC_SHRT_MAX,
    _SC_SHRT_MIN,
    _SC_UCHAR_MAX,
    _SC_UINT_MAX,
    _SC_ULONG_MAX,
    _SC_USHRT_MAX,
    _SC_NL_ARGMAX,
    _SC_NL_LANGMAX,
    _SC_NL_MSGMAX,
    _SC_NL_NMAX,
    _SC_NL_SETMAX,
    _SC_NL_TEXTMAX,
    _SC_XBS5_ILP32_OFF32,
    _SC_XBS5_ILP32_OFFBIG,
    _SC_XBS5_LP64_OFF64,
    _SC_XBS5_LPBIG_OFFBIG,
    _SC_XOPEN_LEGACY,
    _SC_XOPEN_REALTIME,
    _SC_XOPEN_REALTIME_THREADS,
    _SC_ADVISORY_INFO,
    _SC_BARRIERS,
    _SC_BASE,
    _SC_C_LANG_SUPPORT,
    _SC_C_LANG_SUPPORT_R,
    _SC_CLOCK_SELECTION,
    _SC_CPUTIME,
    _SC_THREAD_CPUTIME,
    _SC_DEVICE_IO,
    _SC_DEVICE_SPECIFIC,
    _SC_DEVICE_SPECIFIC_R,
    _SC_FD_MGMT,
    _SC_FIFO,
    _SC_PIPE,
    _SC_FILE_ATTRIBUTES,
    _SC_FILE_LOCKING,
    _SC_FILE_SYSTEM,
    _SC_MONOTONIC_CLOCK,
    _SC_MULTI_PROCESS,
    _SC_SINGLE_PROCESS,
    _SC_NETWORKING,
    _SC_READER_WRITER_LOCKS,
    _SC_SPIN_LOCKS,
    _SC_REGEXP,
    _SC_REGEX_VERSION,
    _SC_SHELL,
    _SC_SIGNALS,
    _SC_SPAWN,
    _SC_SPORADIC_SERVER,
    _SC_THREAD_SPORADIC_SERVER,
    _SC_SYSTEM_DATABASE,
    _SC_SYSTEM_DATABASE_R,
    _SC_TIMEOUTS,
    _SC_TYPED_MEMORY_OBJECTS,
    _SC_USER_GROUPS,
    _SC_USER_GROUPS_R,
    _SC_2_PBS,
    _SC_2_PBS_ACCOUNTING,
    _SC_2_PBS_LOCATE,
    _SC_2_PBS_MESSAGE,
    _SC_2_PBS_TRACK,
    _SC_SYMLOOP_MAX,
    _SC_STREAMS,
    _SC_2_PBS_CHECKPOINT,
    _SC_V6_ILP32_OFF32,
    _SC_V6_ILP32_OFFBIG,
    _SC_V6_LP64_OFF64,
    _SC_V6_LPBIG_OFFBIG,
    _SC_HOST_NAME_MAX,
    _SC_TRACE,
    _SC_TRACE_EVENT_FILTER,
    _SC_TRACE_INHERIT,
    _SC_TRACE_LOG,
    _SC_LEVEL1_ICACHE_SIZE,
    _SC_LEVEL1_ICACHE_ASSOC,
    _SC_LEVEL1_ICACHE_LINESIZE,
    _SC_LEVEL1_DCACHE_SIZE,
    _SC_LEVEL1_DCACHE_ASSOC,
    _SC_LEVEL1_DCACHE_LINESIZE,
    _SC_LEVEL2_CACHE_SIZE,
    _SC_LEVEL2_CACHE_ASSOC,
    _SC_LEVEL2_CACHE_LINESIZE,
    _SC_LEVEL3_CACHE_SIZE,
    _SC_LEVEL3_CACHE_ASSOC,
    _SC_LEVEL3_CACHE_LINESIZE,
    _SC_LEVEL4_CACHE_SIZE,
    _SC_LEVEL4_CACHE_ASSOC,
    _SC_LEVEL4_CACHE_LINESIZE,
    _SC_IPV6 = _SC_LEVEL1_ICACHE_SIZE + 50,
    _SC_RAW_SOCKETS,
    _SC_V7_ILP32_OFF32,
    _SC_V7_ILP32_OFFBIG,
    _SC_V7_LP64_OFF64,
    _SC_V7_LPBIG_OFFBIG,
    _SC_SS_REPL_MAX,
    _SC_TRACE_EVENT_NAME_MAX,
    _SC_TRACE_NAME_MAX,
    _SC_TRACE_SYS_MAX,
    _SC_TRACE_USER_EVENT_MAX,
    _SC_XOPEN_STREAMS,
    _SC_THREAD_ROBUST_PRIO_INHERIT,
    _SC_THREAD_ROBUST_PRIO_PROTECT,
    _SC_MINSIGSTKSZ,
    _SC_SIGSTKSZ
  };
enum
  {
    _CS_PATH,
    _CS_V6_WIDTH_RESTRICTED_ENVS,
    _CS_GNU_LIBC_VERSION,
    _CS_GNU_LIBPTHREAD_VERSION,
    _CS_V5_WIDTH_RESTRICTED_ENVS,
    _CS_V7_WIDTH_RESTRICTED_ENVS,
    _CS_LFS_CFLAGS = 1000,
    _CS_LFS_LDFLAGS,
    _CS_LFS_LIBS,
    _CS_LFS_LINTFLAGS,
    _CS_LFS64_CFLAGS,
    _CS_LFS64_LDFLAGS,
    _CS_LFS64_LIBS,
    _CS_LFS64_LINTFLAGS,
    _CS_XBS5_ILP32_OFF32_CFLAGS = 1100,
    _CS_XBS5_ILP32_OFF32_LDFLAGS,
    _CS_XBS5_ILP32_OFF32_LIBS,
    _CS_XBS5_ILP32_OFF32_LINTFLAGS,
    _CS_XBS5_ILP32_OFFBIG_CFLAGS,
    _CS_XBS5_ILP32_OFFBIG_LDFLAGS,
    _CS_XBS5_ILP32_OFFBIG_LIBS,
    _CS_XBS5_ILP32_OFFBIG_LINTFLAGS,
    _CS_XBS5_LP64_OFF64_CFLAGS,
    _CS_XBS5_LP64_OFF64_LDFLAGS,
    _CS_XBS5_LP64_OFF64_LIBS,
    _CS_XBS5_LP64_OFF64_LINTFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_CFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_LDFLAGS,
    _CS_XBS5_LPBIG_OFFBIG_LIBS,
    _CS_XBS5_LPBIG_OFFBIG_LINTFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_CFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_LDFLAGS,
    _CS_POSIX_V6_ILP32_OFF32_LIBS,
    _CS_POSIX_V6_ILP32_OFF32_LINTFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_CFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_LDFLAGS,
    _CS_POSIX_V6_ILP32_OFFBIG_LIBS,
    _CS_POSIX_V6_ILP32_OFFBIG_LINTFLAGS,
    _CS_POSIX_V6_LP64_OFF64_CFLAGS,
    _CS_POSIX_V6_LP64_OFF64_LDFLAGS,
    _CS_POSIX_V6_LP64_OFF64_LIBS,
    _CS_POSIX_V6_LP64_OFF64_LINTFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_CFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LDFLAGS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LIBS,
    _CS_POSIX_V6_LPBIG_OFFBIG_LINTFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_CFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_LDFLAGS,
    _CS_POSIX_V7_ILP32_OFF32_LIBS,
    _CS_POSIX_V7_ILP32_OFF32_LINTFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_CFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_LDFLAGS,
    _CS_POSIX_V7_ILP32_OFFBIG_LIBS,
    _CS_POSIX_V7_ILP32_OFFBIG_LINTFLAGS,
    _CS_POSIX_V7_LP64_OFF64_CFLAGS,
    _CS_POSIX_V7_LP64_OFF64_LDFLAGS,
    _CS_POSIX_V7_LP64_OFF64_LIBS,
    _CS_POSIX_V7_LP64_OFF64_LINTFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_CFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LDFLAGS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LIBS,
    _CS_POSIX_V7_LPBIG_OFFBIG_LINTFLAGS,
    _CS_V6_ENV,
    _CS_V7_ENV
  };
extern long int pathconf (const char *__path, int __name)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int fpathconf (int __fd, int __name) __attribute__ ((__nothrow__ ));
extern long int sysconf (int __name) __attribute__ ((__nothrow__ ));
extern size_t confstr (int __name, char *__buf, size_t __len) __attribute__ ((__nothrow__ ))
                                                  ;
extern __pid_t getpid (void) __attribute__ ((__nothrow__ ));
extern __pid_t getppid (void) __attribute__ ((__nothrow__ ));
extern __pid_t getpgrp (void) __attribute__ ((__nothrow__ ));
extern __pid_t __getpgid (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern __pid_t getpgid (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern int setpgid (__pid_t __pid, __pid_t __pgid) __attribute__ ((__nothrow__ ));
extern int setpgrp (void) __attribute__ ((__nothrow__ ));
extern __pid_t setsid (void) __attribute__ ((__nothrow__ ));
extern __pid_t getsid (__pid_t __pid) __attribute__ ((__nothrow__ ));
extern __uid_t getuid (void) __attribute__ ((__nothrow__ ));
extern __uid_t geteuid (void) __attribute__ ((__nothrow__ ));
extern __gid_t getgid (void) __attribute__ ((__nothrow__ ));
extern __gid_t getegid (void) __attribute__ ((__nothrow__ ));
extern int getgroups (int __size, __gid_t __list[]) __attribute__ ((__nothrow__ ))
                                                  ;
extern int setuid (__uid_t __uid) __attribute__ ((__nothrow__ )) ;
extern int setreuid (__uid_t __ruid, __uid_t __euid) __attribute__ ((__nothrow__ )) ;
extern int seteuid (__uid_t __uid) __attribute__ ((__nothrow__ )) ;
extern int setgid (__gid_t __gid) __attribute__ ((__nothrow__ )) ;
extern int setregid (__gid_t __rgid, __gid_t __egid) __attribute__ ((__nothrow__ )) ;
extern int setegid (__gid_t __gid) __attribute__ ((__nothrow__ )) ;
extern __pid_t fork (void) __attribute__ ((__nothrow__));
extern __pid_t vfork (void) __attribute__ ((__nothrow__ ));
extern char *ttyname (int __fd) __attribute__ ((__nothrow__ ));
extern int ttyname_r (int __fd, char *__buf, size_t __buflen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                                   ;
extern int isatty (int __fd) __attribute__ ((__nothrow__ ));
extern int ttyslot (void) __attribute__ ((__nothrow__ ));
extern int link (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern int linkat (int __fromfd, const char *__from, int __tofd,
     const char *__to, int __flags)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4))) ;
extern int symlink (const char *__from, const char *__to)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern ssize_t readlink (const char *__restrict __path,
    char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)))
                                                   ;
extern int symlinkat (const char *__from, int __tofd,
        const char *__to) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 3))) ;
extern ssize_t readlinkat (int __fd, const char *__restrict __path,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)))
                                                   ;
extern int unlink (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int unlinkat (int __fd, const char *__name, int __flag)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int rmdir (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern __pid_t tcgetpgrp (int __fd) __attribute__ ((__nothrow__ ));
extern int tcsetpgrp (int __fd, __pid_t __pgrp_id) __attribute__ ((__nothrow__ ));
extern char *getlogin (void);
extern int getlogin_r (char *__name, size_t __name_len) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern int setlogin (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *optarg;
extern int optind;
extern int opterr;
extern int optopt;
extern int getopt (int ___argc, char *const *___argv, const char *__shortopts)
       __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern int gethostname (char *__name, size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern int sethostname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int sethostid (long int __id) __attribute__ ((__nothrow__ )) ;
extern int getdomainname (char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                   ;
extern int setdomainname (const char *__name, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int vhangup (void) __attribute__ ((__nothrow__ ));
extern int revoke (const char *__file) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int profil (unsigned short int *__sample_buffer, size_t __size,
     size_t __offset, unsigned int __scale)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int acct (const char *__name) __attribute__ ((__nothrow__ ));
extern char *getusershell (void) __attribute__ ((__nothrow__ ));
extern void endusershell (void) __attribute__ ((__nothrow__ ));
extern void setusershell (void) __attribute__ ((__nothrow__ ));
extern int daemon (int __nochdir, int __noclose) __attribute__ ((__nothrow__ )) ;
extern int chroot (const char *__path) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern char *getpass (const char *__prompt) __attribute__ ((__nonnull__ (1)));
extern int fsync (int __fd);
extern long int gethostid (void);
extern void sync (void) __attribute__ ((__nothrow__ ));
extern int getpagesize (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int getdtablesize (void) __attribute__ ((__nothrow__ ));
extern int truncate (const char *__file, __off_t __length)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int ftruncate (int __fd, __off_t __length) __attribute__ ((__nothrow__ )) ;
extern int brk (void *__addr) __attribute__ ((__nothrow__ )) ;
extern void *sbrk (intptr_t __delta) __attribute__ ((__nothrow__ ));
extern long int syscall (long int __sysno, ...) __attribute__ ((__nothrow__ ));
extern int lockf (int __fd, int __cmd, __off_t __len) ;
extern int fdatasync (int __fildes);
extern char *crypt (const char *__key, const char *__salt)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
int getentropy (void *__buffer, size_t __length)
                                          ;

typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;
typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
typedef signed char int_fast8_t;
typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
typedef unsigned char uint_fast8_t;
typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
typedef unsigned long int uintptr_t;
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;

int cfl_atomic_initialize();
int cfl_atomic_compare_exchange(uint64_t *storage, uint64_t old_value,
                                uint64_t new_value);
void cfl_atomic_store(uint64_t *storage, uint64_t new_value);
uint64_t cfl_atomic_load(uint64_t *storage);
extern int *__errno_location (void) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));

int cfl_report_runtime_error_impl(int errnum, char *file, int line);
typedef int wchar_t;
typedef _Complex float __cfloat128 __attribute__ ((__mode__ (__TC__)));
typedef __float128 _Float128;
typedef float _Float32;
typedef double _Float64;
typedef double _Float32x;
typedef long double _Float64x;
typedef struct
  {
    int quot;
    int rem;
  } div_t;
typedef struct
  {
    long int quot;
    long int rem;
  } ldiv_t;
__extension__ typedef struct
  {
    long long int quot;
    long long int rem;
  } lldiv_t;
extern size_t __ctype_get_mb_cur_max (void) __attribute__ ((__nothrow__ )) ;
extern double atof (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern int atoi (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern long int atol (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
__extension__ extern long long int atoll (const char *__nptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
extern double strtod (const char *__restrict __nptr,
        char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern float strtof (const char *__restrict __nptr,
       char **__restrict __endptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long double strtold (const char *__restrict __nptr,
       char **__restrict __endptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int strtol (const char *__restrict __nptr,
   char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern unsigned long int strtoul (const char *__restrict __nptr,
      char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoq (const char *__restrict __nptr,
        char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtouq (const char *__restrict __nptr,
           char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern long long int strtoll (const char *__restrict __nptr,
         char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
__extension__
extern unsigned long long int strtoull (const char *__restrict __nptr,
     char **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *l64a (long int __n) __attribute__ ((__nothrow__ )) ;
extern long int a64l (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1))) ;
typedef __u_char u_char;
typedef __u_short u_short;
typedef __u_int u_int;
typedef __u_long u_long;
typedef __quad_t quad_t;
typedef __u_quad_t u_quad_t;
typedef __fsid_t fsid_t;
typedef __loff_t loff_t;
typedef __ino_t ino_t;
typedef __dev_t dev_t;
typedef __mode_t mode_t;
typedef __nlink_t nlink_t;
typedef __id_t id_t;
typedef __daddr_t daddr_t;
typedef __caddr_t caddr_t;
typedef __key_t key_t;
typedef __clock_t clock_t;

typedef __clockid_t clockid_t;
typedef __time_t time_t;
typedef __timer_t timer_t;
typedef unsigned long int ulong;
typedef unsigned short int ushort;
typedef unsigned int uint;
typedef __uint8_t u_int8_t;
typedef __uint16_t u_int16_t;
typedef __uint32_t u_int32_t;
typedef __uint64_t u_int64_t;
typedef int register_t __attribute__ ((__mode__ (__word__)));
static __inline __uint16_t
__bswap_16 (__uint16_t __bsx)
{
  return ((__uint16_t) ((((__bsx) >> 8) & 0xff) | (((__bsx) & 0xff) << 8)));
}
static __inline __uint32_t
__bswap_32 (__uint32_t __bsx)
{
  return ((((__bsx) & 0xff000000u) >> 24) | (((__bsx) & 0x00ff0000u) >> 8) | (((__bsx) & 0x0000ff00u) << 8) | (((__bsx) & 0x000000ffu) << 24));
}
__extension__ static __inline __uint64_t
__bswap_64 (__uint64_t __bsx)
{
  return ((((__bsx) & 0xff00000000000000ull) >> 56) | (((__bsx) & 0x00ff000000000000ull) >> 40) | (((__bsx) & 0x0000ff0000000000ull) >> 24) | (((__bsx) & 0x000000ff00000000ull) >> 8) | (((__bsx) & 0x00000000ff000000ull) << 8) | (((__bsx) & 0x0000000000ff0000ull) << 24) | (((__bsx) & 0x000000000000ff00ull) << 40) | (((__bsx) & 0x00000000000000ffull) << 56));
}
static __inline __uint16_t
__uint16_identity (__uint16_t __x)
{
  return __x;
}
static __inline __uint32_t
__uint32_identity (__uint32_t __x)
{
  return __x;
}
static __inline __uint64_t
__uint64_identity (__uint64_t __x)
{
  return __x;
}
typedef struct
{
  unsigned long int __val[(1024 / (8 * sizeof (unsigned long int)))];
} __sigset_t;
typedef __sigset_t sigset_t;
struct timeval
{
  __time_t tv_sec;
  __suseconds_t tv_usec;
};

struct timespec
{
  __time_t tv_sec;
  __syscall_slong_t tv_nsec;
};
typedef __suseconds_t suseconds_t;
typedef long int __fd_mask;
typedef struct
  {
    __fd_mask __fds_bits[1024 / (8 * (int) sizeof (__fd_mask))];
  } fd_set;
typedef __fd_mask fd_mask;
extern int select (int __nfds, fd_set *__restrict __readfds,
     fd_set *__restrict __writefds,
     fd_set *__restrict __exceptfds,
     struct timeval *__restrict __timeout);
extern int pselect (int __nfds, fd_set *__restrict __readfds,
      fd_set *__restrict __writefds,
      fd_set *__restrict __exceptfds,
      const struct timespec *__restrict __timeout,
      const __sigset_t *__restrict __sigmask);
typedef __blksize_t blksize_t;
typedef __blkcnt_t blkcnt_t;
typedef __fsblkcnt_t fsblkcnt_t;
typedef __fsfilcnt_t fsfilcnt_t;

typedef union
{
  __extension__ unsigned long long int __value64;
  struct
  {
    unsigned int __low;
    unsigned int __high;
  } __value32;
} __atomic_wide_counter;
typedef struct __pthread_internal_list
{
  struct __pthread_internal_list *__prev;
  struct __pthread_internal_list *__next;
} __pthread_list_t;
typedef struct __pthread_internal_slist
{
  struct __pthread_internal_slist *__next;
} __pthread_slist_t;
struct __pthread_mutex_s
{
  int __lock;
  unsigned int __count;
  int __owner;
  unsigned int __nusers;
  int __kind;
  short __spins;
  short __unused;
  __pthread_list_t __list;
};
struct __pthread_rwlock_arch_t
{
  unsigned int __readers;
  unsigned int __writers;
  unsigned int __wrphase_futex;
  unsigned int __writers_futex;
  unsigned int __pad3;
  unsigned int __pad4;
  int __cur_writer;
  int __shared;
  unsigned long int __pad1;
  unsigned long int __pad2;
  unsigned int __flags;
};
struct __pthread_cond_s
{
  __atomic_wide_counter __wseq;
  __atomic_wide_counter __g1_start;
  unsigned int __g_size[2] ;
  unsigned int __g1_orig_size;
  unsigned int __wrefs;
  unsigned int __g_signals[2];
  unsigned int __unused_initialized_1;
  unsigned int __unused_initialized_2;
};
typedef unsigned int __tss_t;
typedef unsigned long int __thrd_t;
typedef struct
{
  int __data ;
} __once_flag;
typedef unsigned long int pthread_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_mutexattr_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_condattr_t;
typedef unsigned int pthread_key_t;
typedef int pthread_once_t;
union pthread_attr_t
{
  char __size[56];
  long int __align;
};
typedef union pthread_attr_t pthread_attr_t;
typedef union
{
  struct __pthread_mutex_s __data;
  char __size[40];
  long int __align;
} pthread_mutex_t;
typedef union
{
  struct __pthread_cond_s __data;
  char __size[48];
  __extension__ long long int __align;
} pthread_cond_t;
typedef union
{
  struct __pthread_rwlock_arch_t __data;
  char __size[56];
  long int __align;
} pthread_rwlock_t;
typedef union
{
  char __size[8];
  long int __align;
} pthread_rwlockattr_t;
typedef volatile int pthread_spinlock_t;
typedef union
{
  char __size[32];
  long int __align;
} pthread_barrier_t;
typedef union
{
  char __size[4];
  int __align;
} pthread_barrierattr_t;
extern long int random (void) __attribute__ ((__nothrow__ ));
extern void srandom (unsigned int __seed) __attribute__ ((__nothrow__ ));
extern char *initstate (unsigned int __seed, char *__statebuf,
   size_t __statelen) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *setstate (char *__statebuf) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
struct random_data
  {
    int32_t *fptr;
    int32_t *rptr;
    int32_t *state;
    int rand_type;
    int rand_deg;
    int rand_sep;
    int32_t *end_ptr;
  };
extern int random_r (struct random_data *__restrict __buf,
       int32_t *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int srandom_r (unsigned int __seed, struct random_data *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int initstate_r (unsigned int __seed, char *__restrict __statebuf,
   size_t __statelen,
   struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)));
extern int setstate_r (char *__restrict __statebuf,
         struct random_data *__restrict __buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int rand (void) __attribute__ ((__nothrow__ ));
extern void srand (unsigned int __seed) __attribute__ ((__nothrow__ ));
extern int rand_r (unsigned int *__seed) __attribute__ ((__nothrow__ ));
extern double drand48 (void) __attribute__ ((__nothrow__ ));
extern double erand48 (unsigned short int __xsubi[3]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int lrand48 (void) __attribute__ ((__nothrow__ ));
extern long int nrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern long int mrand48 (void) __attribute__ ((__nothrow__ ));
extern long int jrand48 (unsigned short int __xsubi[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void srand48 (long int __seedval) __attribute__ ((__nothrow__ ));
extern unsigned short int *seed48 (unsigned short int __seed16v[3])
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void lcong48 (unsigned short int __param[7]) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
struct drand48_data
  {
    unsigned short int __x[3];
    unsigned short int __old_x[3];
    unsigned short int __c;
    unsigned short int __init;
    __extension__ unsigned long long int __a;
  };
extern int drand48_r (struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int erand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        double *__restrict __result) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int lrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int nrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int mrand48_r (struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int jrand48_r (unsigned short int __xsubi[3],
        struct drand48_data *__restrict __buffer,
        long int *__restrict __result)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int srand48_r (long int __seedval, struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int seed48_r (unsigned short int __seed16v[3],
       struct drand48_data *__buffer) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int lcong48_r (unsigned short int __param[7],
        struct drand48_data *__buffer)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern __uint32_t arc4random (void)
     __attribute__ ((__nothrow__ )) ;
extern void arc4random_buf (void *__buf, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern __uint32_t arc4random_uniform (__uint32_t __upper_bound)
     __attribute__ ((__nothrow__ )) ;
extern void *malloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;
extern void *calloc (size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;
extern void *realloc (void *__ptr, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__)) ;
extern void free (void *__ptr) __attribute__ ((__nothrow__ ));
extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__warn_unused_result__))
                       ;
extern void *reallocarray (void *__ptr, size_t __nmemb, size_t __size)
     __attribute__ ((__nothrow__ )) ;
extern void *alloca (size_t __size) __attribute__ ((__nothrow__ ));
extern void *valloc (size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__))
                                         ;
extern int posix_memalign (void **__memptr, size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern void *aligned_alloc (size_t __alignment, size_t __size)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__alloc_align__ (1)))
                                         ;
extern void abort (void) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__)) __attribute__ ((__cold__));
extern int atexit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int at_quick_exit (void (*__func) (void)) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int on_exit (void (*__func) (int __status, void *__arg), void *__arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));
extern void quick_exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));
extern void _Exit (int __status) __attribute__ ((__nothrow__ )) __attribute__ ((__noreturn__));
extern char *getenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int putenv (char *__string) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int setenv (const char *__name, const char *__value, int __replace)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern int unsetenv (const char *__name) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int clearenv (void) __attribute__ ((__nothrow__ ));
extern char *mktemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int mkstemp (char *__template) __attribute__ ((__nonnull__ (1))) ;
extern int mkstemps (char *__template, int __suffixlen) __attribute__ ((__nonnull__ (1))) ;
extern char *mkdtemp (char *__template) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int system (const char *__command) ;
extern char *realpath (const char *__restrict __name,
         char *__restrict __resolved) __attribute__ ((__nothrow__ )) ;
typedef int (*__compar_fn_t) (const void *, const void *);
extern void *bsearch (const void *__key, const void *__base,
        size_t __nmemb, size_t __size, __compar_fn_t __compar)
     __attribute__ ((__nonnull__ (1, 2, 5))) ;
extern void qsort (void *__base, size_t __nmemb, size_t __size,
     __compar_fn_t __compar) __attribute__ ((__nonnull__ (1, 4)));
extern int abs (int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern long int labs (long int __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
__extension__ extern long long int llabs (long long int __x)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern div_t div (int __numer, int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern ldiv_t ldiv (long int __numer, long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
__extension__ extern lldiv_t lldiv (long long int __numer,
        long long int __denom)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__)) ;
extern char *ecvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *fcvt (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *gcvt (double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;
extern char *qecvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qfcvt (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4))) ;
extern char *qgcvt (long double __value, int __ndigit, char *__buf)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3))) ;
extern int ecvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int fcvt_r (double __value, int __ndigit, int *__restrict __decpt,
     int *__restrict __sign, char *__restrict __buf,
     size_t __len) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qecvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int qfcvt_r (long double __value, int __ndigit,
      int *__restrict __decpt, int *__restrict __sign,
      char *__restrict __buf, size_t __len)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (3, 4, 5)));
extern int mblen (const char *__s, size_t __n) __attribute__ ((__nothrow__ ));
extern int mbtowc (wchar_t *__restrict __pwc,
     const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ));
extern int wctomb (char *__s, wchar_t __wchar) __attribute__ ((__nothrow__ ));
extern size_t mbstowcs (wchar_t *__restrict __pwcs,
   const char *__restrict __s, size_t __n) __attribute__ ((__nothrow__ ))
                                      ;
extern size_t wcstombs (char *__restrict __s,
   const wchar_t *__restrict __pwcs, size_t __n)
     __attribute__ ((__nothrow__ ))
                                    ;
extern int rpmatch (const char *__response) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int getsubopt (char **__restrict __optionp,
        char *const *__restrict __tokens,
        char **__restrict __valuep)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2, 3))) ;
extern int getloadavg (double __loadavg[], int __nelem)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void *memset_explicit (void *__s, int __c, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1))) ;
extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;
struct __locale_struct
{
  struct __locale_data *__locales[13];
  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;
  const char *__names[13];
};
typedef struct __locale_struct *__locale_t;

typedef __locale_t locale_t;
extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;
extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))
                                         ;
extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))
                                          ;
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));
extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;
extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
typedef int __gwchar_t;
typedef struct
  {
    long int quot;
    long int rem;
  } imaxdiv_t;
extern intmax_t imaxabs (intmax_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern imaxdiv_t imaxdiv (intmax_t __numer, intmax_t __denom)
      __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
extern intmax_t strtoimax (const char *__restrict __nptr,
      char **__restrict __endptr, int __base) __attribute__ ((__nothrow__ ));
extern uintmax_t strtoumax (const char *__restrict __nptr,
       char ** __restrict __endptr, int __base) __attribute__ ((__nothrow__ ));
extern intmax_t wcstoimax (const __gwchar_t *__restrict __nptr,
      __gwchar_t **__restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));
extern uintmax_t wcstoumax (const __gwchar_t *__restrict __nptr,
       __gwchar_t ** __restrict __endptr, int __base)
     __attribute__ ((__nothrow__ ));

typedef char *cfl_sds_t;
struct cfl_arena;
#pragma pack(push, 1)
struct cfl_sds {
    uint64_t len;
    uint64_t alloc;
    char buf[];
};
#pragma pack(pop)
size_t cfl_sds_alloc(cfl_sds_t s);
static inline void cfl_sds_len_set(cfl_sds_t s, size_t len)
{
    struct cfl_sds *head;
    if (s == ((void*)0)) {
        return;
    }
    head = ((struct cfl_sds *) (s - (sizeof(uint64_t) + sizeof(uint64_t))));
    if (len > cfl_sds_alloc(s)) {
        return;
    }
    head->len = len;
    s[len] = '\0';
}
size_t cfl_sds_avail(cfl_sds_t s);
cfl_sds_t cfl_sds_increase(cfl_sds_t s, size_t len);
size_t cfl_sds_len(cfl_sds_t s);
cfl_sds_t cfl_sds_create_len(const char *str, int len);
cfl_sds_t cfl_sds_create_len_in(struct cfl_arena *arena,
                                const char *str, int len);
cfl_sds_t cfl_sds_create(const char *str);
void cfl_sds_destroy(cfl_sds_t s);
cfl_sds_t cfl_sds_cat(cfl_sds_t s, const char *str, int len);
cfl_sds_t cfl_sds_create_size(size_t size);
void cfl_sds_set_len(cfl_sds_t s, size_t len);
void cfl_sds_cat_safe(cfl_sds_t *buf, const char *str, int len);
cfl_sds_t cfl_sds_printf(cfl_sds_t *sds, const char *fmt, ...);
typedef long int ptrdiff_t;
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
struct cfl_list {
    struct cfl_list *prev, *next;
};
static inline int cfl_list_is_empty(struct cfl_list *head)
{
    if (head == ((void*)0)) {
        return 1;
    }
    if (head->next == head) {
        return 1;
    }
    return 0;
}
static inline void cfl_list_init(struct cfl_list *list)
{
    if (list == ((void*)0)) {
        return;
    }
    list->next = list;
    list->prev = list;
}
static inline void __cfl_list_del(struct cfl_list *prev,
                                  struct cfl_list *next)
{
    if (prev == ((void*)0) || next == ((void*)0)) {
        return;
    }
    prev->next = next;
    next->prev = prev;
}
static inline void cfl_list_del(struct cfl_list *entry)
{
    if (entry == ((void*)0)) {
        return;
    }
    __cfl_list_del(entry->prev, entry->next);
    entry->prev = ((void*)0);
    entry->next = ((void*)0);
}
static inline void __cfl_list_add(struct cfl_list *_new,
                                  struct cfl_list *prev,
                                  struct cfl_list *next)
{
    if (_new == ((void*)0) || prev == ((void*)0) || next == ((void*)0)) {
        return;
    }
    next->prev = _new;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
}
static inline void cfl_list_add(struct cfl_list *_new,
                                struct cfl_list *head)
{
    if (_new == ((void*)0) || head == ((void*)0)) {
        return;
    }
    __cfl_list_add(_new, head->prev, head);
}
static inline void cfl_list_add_after(struct cfl_list *_new,
                                      struct cfl_list *prev,
                                      struct cfl_list *head)
{
    struct cfl_list *next;
    if (_new == ((void*)0) || prev == ((void*)0) || head == ((void*)0)) {
        return;
    }
    next = prev->next;
    next->prev = prev;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
}
static inline void cfl_list_add_before(struct cfl_list *_new,
                                       struct cfl_list *next,
                                       struct cfl_list *head)
{
    struct cfl_list *prev;
    if (_new == ((void*)0) || next == ((void*)0) || head == ((void*)0)) {
        return;
    }
    prev = next->prev;
    _new->next = next;
    _new->prev = prev;
    prev->next = _new;
    next->prev = _new;
}
static inline void cfl_list_append(struct cfl_list *_new,
                                   struct cfl_list *head)
{
    if (_new == ((void*)0) || head == ((void*)0)) {
        return;
    }
    if (cfl_list_is_empty(head)) {
        __cfl_list_add(_new, head->prev, head);
    }
    else {
        cfl_list_add_after(_new,
                           head->prev,
                           head);
    }
}
static inline void cfl_list_prepend(struct cfl_list *_new,
                                    struct cfl_list *head)
{
    if (_new == ((void*)0) || head == ((void*)0)) {
        return;
    }
    if (cfl_list_is_empty(head)) {
        __cfl_list_add(_new, head->prev, head);
    }
    else {
        cfl_list_add_before(_new,
                           head->next,
                           head);
    }
}
static inline int cfl_list_size(struct cfl_list *head)
{
    int ret = 0;
    struct cfl_list *it;
    if (head == ((void*)0)) {
        return 0;
    }
    for (it = head->next; it != head; it = it->next, ret++);
    return ret;
}
static inline void cfl_list_entry_init(struct cfl_list *entry)
{
    entry->next = ((void*)0);
    entry->prev = ((void*)0);
}
static inline int cfl_list_entry_is_orphan(struct cfl_list *entry)
{
    if (entry == ((void*)0)) {
        return !0;
    }
    if (entry->next != ((void*)0) &&
        entry->prev != ((void*)0)) {
        return 0;
    }
    return !0;
}
static inline void cfl_list_cat(struct cfl_list *list, struct cfl_list *head)
{
    struct cfl_list *last;
    if (list == ((void*)0) || head == ((void*)0)) {
        return;
    }
    last = head->prev;
    last->next = list->next;
    list->next->prev = last;
    list->prev->next = head;
    head->prev = list->prev;
}
static __inline __attribute__((__unused__)) __attribute__((__const__)) unsigned XXH_INLINE_XXH_versionNumber (void);
typedef enum {
    XXH_NAMESPACEXXH_OK = 0,
    XXH_NAMESPACEXXH_ERROR
} XXH_NAMESPACEXXH_errorcode;
    typedef uint32_t XXH32_hash_t;
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH32_hash_t XXH_INLINE_XXH32 (const void* input, size_t length, XXH32_hash_t seed);
typedef struct XXH_NAMESPACEXXH32_state_s XXH_NAMESPACEXXH32_state_t;
static __inline __attribute__((__unused__)) __attribute__((__malloc__)) XXH_NAMESPACEXXH32_state_t* XXH_INLINE_XXH32_createState(void);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_freeState(XXH_NAMESPACEXXH32_state_t* statePtr);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_copyState(XXH_NAMESPACEXXH32_state_t* dst_state, const XXH_NAMESPACEXXH32_state_t* src_state);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_reset (XXH_NAMESPACEXXH32_state_t* statePtr, XXH32_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_update (XXH_NAMESPACEXXH32_state_t* statePtr, const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH32_hash_t XXH_INLINE_XXH32_digest (const XXH_NAMESPACEXXH32_state_t* statePtr);
typedef struct {
    unsigned char digest[4];
} XXH_NAMESPACEXXH32_canonical_t;
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_canonicalFromHash(XXH_NAMESPACEXXH32_canonical_t* dst, XXH32_hash_t hash);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH32_hash_t XXH_INLINE_XXH32_hashFromCanonical(const XXH_NAMESPACEXXH32_canonical_t* src);
   typedef uint64_t XXH64_hash_t;
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH64(__attribute__((__noescape__)) const void* input, size_t length, XXH64_hash_t seed);
typedef struct XXH_NAMESPACEXXH64_state_s XXH_NAMESPACEXXH64_state_t;
static __inline __attribute__((__unused__)) __attribute__((__malloc__)) XXH_NAMESPACEXXH64_state_t* XXH_INLINE_XXH64_createState(void);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_freeState(XXH_NAMESPACEXXH64_state_t* statePtr);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* dst_state, const XXH_NAMESPACEXXH64_state_t* src_state);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_reset (__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* statePtr, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* statePtr, __attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH64_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_state_t* statePtr);
typedef struct { unsigned char digest[sizeof(XXH64_hash_t)]; } XXH_NAMESPACEXXH64_canonical_t;
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_canonical_t* dst, XXH64_hash_t hash);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH64_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_canonical_t* src);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits(__attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_withSeed(__attribute__((__noescape__)) const void* input, size_t length, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_withSecret(__attribute__((__noescape__)) const void* data, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize);
typedef struct XXH_NAMESPACEXXH3_state_s XXH_NAMESPACEXXH3_state_t;
static __inline __attribute__((__unused__)) __attribute__((__malloc__)) XXH_NAMESPACEXXH3_state_t* XXH_INLINE_XXH3_createState(void);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_freeState(XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH3_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* dst_state, __attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* src_state);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_64bits_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* statePtr);
typedef struct {
    XXH64_hash_t low64;
    XXH64_hash_t high64;
} XXH_NAMESPACEXXH128_hash_t;
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits(__attribute__((__noescape__)) const void* data, size_t len);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_withSeed(__attribute__((__noescape__)) const void* data, size_t len, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_withSecret(__attribute__((__noescape__)) const void* data, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_128bits_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* input, size_t length);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* statePtr);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) int XXH_INLINE_XXH128_isEqual(XXH_NAMESPACEXXH128_hash_t h1, XXH_NAMESPACEXXH128_hash_t h2);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) int XXH_INLINE_XXH128_cmp(__attribute__((__noescape__)) const void* h128_1, __attribute__((__noescape__)) const void* h128_2);
typedef struct { unsigned char digest[sizeof(XXH_NAMESPACEXXH128_hash_t)]; } XXH_NAMESPACEXXH128_canonical_t;
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH128_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH128_canonical_t* dst, XXH_NAMESPACEXXH128_hash_t hash);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH128_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH128_canonical_t* src);
struct XXH_NAMESPACEXXH32_state_s {
   XXH32_hash_t total_len_32;
   XXH32_hash_t large_len;
   XXH32_hash_t acc[4];
   unsigned char buffer[16];
   XXH32_hash_t bufferedSize;
   XXH32_hash_t reserved;
};
struct XXH_NAMESPACEXXH64_state_s {
   XXH64_hash_t total_len;
   XXH64_hash_t acc[4];
   unsigned char buffer[32];
   XXH32_hash_t bufferedSize;
   XXH32_hash_t reserved32;
   XXH64_hash_t reserved64;
};
struct XXH_NAMESPACEXXH3_state_s {
   _Alignas(64) XXH64_hash_t acc[8];
   _Alignas(64) unsigned char customSecret[192];
   _Alignas(64) unsigned char buffer[256];
   XXH32_hash_t bufferedSize;
   XXH32_hash_t useSeed;
   size_t nbStripesSoFar;
   XXH64_hash_t totalLen;
   size_t nbStripesPerBlock;
   size_t secretLimit;
   XXH64_hash_t seed;
   XXH64_hash_t reserved64;
   const unsigned char* extSecret;
};
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH128(__attribute__((__noescape__)) const void* data, size_t len, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_generateSecret(__attribute__((__noescape__)) void* secretBuffer, size_t secretSize, __attribute__((__noescape__)) const void* customSeed, size_t customSeedSize);
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH3_generateSecret_fromSeed(__attribute__((__noescape__)) void* secretBuffer, XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSecretandSeed(__attribute__((__noescape__)) const void* data, size_t len,
                              __attribute__((__noescape__)) const void* secret, size_t secretSize,
                              XXH64_hash_t seed);
static __inline __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSecretandSeed(__attribute__((__noescape__)) const void* input, size_t length,
                               __attribute__((__noescape__)) const void* secret, size_t secretSize,
                               XXH64_hash_t seed64);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr,
                                    __attribute__((__noescape__)) const void* secret, size_t secretSize,
                                    XXH64_hash_t seed64);
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr,
                                     __attribute__((__noescape__)) const void* secret, size_t secretSize,
                                     XXH64_hash_t seed64);
static __attribute__((__malloc__)) void* XXH_malloc(size_t s) { return malloc(s); }
static void XXH_free(void* p) { free(p); }
 typedef uint8_t xxh_u8;
typedef XXH32_hash_t xxh_u32;
static xxh_u32 XXH_read32(const void* ptr)
{
    typedef __attribute__((__aligned__(1))) xxh_u32 xxh_unalign32;
    return *((const xxh_unalign32*)ptr);
}
static xxh_u32 XXH_swap32 (xxh_u32 x)
{
    return ((x << 24) & 0xff000000 ) |
            ((x << 8) & 0x00ff0000 ) |
            ((x >> 8) & 0x0000ff00 ) |
            ((x >> 24) & 0x000000ff );
}
typedef enum {
    XXH_aligned,
    XXH_unaligned
} XXH_alignment;
static __attribute__((__unused__)) xxh_u32 XXH_readLE32(const void* ptr)
{
    return 1 ? XXH_read32(ptr) : XXH_swap32(XXH_read32(ptr));
}
static xxh_u32 XXH_readBE32(const void* ptr)
{
    return 1 ? XXH_swap32(XXH_read32(ptr)) : XXH_read32(ptr);
}
static __attribute__((__unused__)) xxh_u32
XXH_readLE32_align(const void* ptr, XXH_alignment align)
{
    if (align==XXH_unaligned) {
        return XXH_readLE32(ptr);
    } else {
        return 1 ? *(const xxh_u32*)ptr : XXH_swap32(*(const xxh_u32*)ptr);
    }
}
static __inline __attribute__((__unused__)) unsigned XXH_INLINE_XXH_versionNumber (void) { return (0 *100*100 + 8 *100 + 3); }
static xxh_u32 XXH32_round(xxh_u32 acc, xxh_u32 input)
{
    acc += input * 0x85EBCA77U;
    acc = __builtin_rotateleft32(acc, 13);
    acc *= 0x9E3779B1U;
    return acc;
}
static xxh_u32 XXH32_avalanche(xxh_u32 hash)
{
    hash ^= hash >> 15;
    hash *= 0x85EBCA77U;
    hash ^= hash >> 13;
    hash *= 0xC2B2AE3DU;
    hash ^= hash >> 16;
    return hash;
}
static __attribute__((__unused__)) void
XXH32_initAccs(xxh_u32 *acc, xxh_u32 seed)
{
    __builtin_assume(acc != ((void*)0));
    acc[0] = seed + 0x9E3779B1U + 0x85EBCA77U;
    acc[1] = seed + 0x85EBCA77U;
    acc[2] = seed + 0;
    acc[3] = seed - 0x9E3779B1U;
}
static __attribute__((__unused__)) const xxh_u8 *
XXH32_consumeLong(
    xxh_u32 *restrict acc,
    xxh_u8 const *restrict input,
    size_t len,
    XXH_alignment align
)
{
    const xxh_u8* const bEnd = input + len;
    const xxh_u8* const limit = bEnd - 15;
    __builtin_assume(acc != ((void*)0));
    __builtin_assume(input != ((void*)0));
    __builtin_assume(len >= 16);
    do {
        acc[0] = XXH32_round(acc[0], XXH_readLE32_align(input, align)); input += 4;
        acc[1] = XXH32_round(acc[1], XXH_readLE32_align(input, align)); input += 4;
        acc[2] = XXH32_round(acc[2], XXH_readLE32_align(input, align)); input += 4;
        acc[3] = XXH32_round(acc[3], XXH_readLE32_align(input, align)); input += 4;
    } while (input < limit);
    return input;
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u32
XXH32_mergeAccs(const xxh_u32 *acc)
{
    __builtin_assume(acc != ((void*)0));
    return __builtin_rotateleft32(acc[0], 1) + __builtin_rotateleft32(acc[1], 7)
         + __builtin_rotateleft32(acc[2], 12) + __builtin_rotateleft32(acc[3], 18);
}
static __attribute__((__pure__)) xxh_u32
XXH32_finalize(xxh_u32 hash, const xxh_u8* ptr, size_t len, XXH_alignment align)
{
    if (ptr==((void*)0)) __builtin_assume(len == 0);
    if (!0) {
        len &= 15;
        while (len >= 4) {
            do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
            len -= 4;
        }
        while (len > 0) {
            do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
            --len;
        }
        return XXH32_avalanche(hash);
    } else {
         switch(len&15) {
           case 12: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 8: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 4: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         return XXH32_avalanche(hash);
           case 13: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 9: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 5: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         return XXH32_avalanche(hash);
           case 14: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 10: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 6: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         return XXH32_avalanche(hash);
           case 15: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 11: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 7: do { hash += XXH_readLE32_align(ptr, align) * 0xC2B2AE3DU; ptr += 4; hash = __builtin_rotateleft32(hash, 17) * 0x27D4EB2FU; } while (0);
                         __attribute__ ((__fallthrough__));
           case 3: do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         __attribute__ ((__fallthrough__));
           case 2: do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         __attribute__ ((__fallthrough__));
           case 1: do { hash += (*ptr++) * 0x165667B1U; hash = __builtin_rotateleft32(hash, 11) * 0x9E3779B1U; } while (0);
                         __attribute__ ((__fallthrough__));
           case 0: return XXH32_avalanche(hash);
        }
        __builtin_assume(0);
        return hash;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u32
XXH32_endian_align(const xxh_u8* input, size_t len, xxh_u32 seed, XXH_alignment align)
{
    xxh_u32 h32;
    if (input==((void*)0)) __builtin_assume(len == 0);
    if (len>=16) {
        xxh_u32 acc[4];
        XXH32_initAccs(acc, seed);
        input = XXH32_consumeLong(acc, input, len, align);
        h32 = XXH32_mergeAccs(acc);
    } else {
        h32 = seed + 0x165667B1U;
    }
    h32 += (xxh_u32)len;
    return XXH32_finalize(h32, input, len&15, align);
}
static __inline __attribute__((__unused__)) XXH32_hash_t XXH_INLINE_XXH32 (const void* input, size_t len, XXH32_hash_t seed)
{
    if (0) {
        if ((((size_t)input) & 3) == 0) {
            return XXH32_endian_align((const xxh_u8*)input, len, seed, XXH_aligned);
    } }
    return XXH32_endian_align((const xxh_u8*)input, len, seed, XXH_unaligned);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH32_state_t* XXH_INLINE_XXH32_createState(void)
{
    return (XXH_NAMESPACEXXH32_state_t*)XXH_malloc(sizeof(XXH_NAMESPACEXXH32_state_t));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_freeState(XXH_NAMESPACEXXH32_state_t* statePtr)
{
    XXH_free(statePtr);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_copyState(XXH_NAMESPACEXXH32_state_t* dstState, const XXH_NAMESPACEXXH32_state_t* srcState)
{
    memcpy(dstState, srcState, sizeof(*dstState));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH32_reset(XXH_NAMESPACEXXH32_state_t* statePtr, XXH32_hash_t seed)
{
    __builtin_assume(statePtr != ((void*)0));
    memset(statePtr, 0, sizeof(*statePtr));
    XXH32_initAccs(statePtr->acc, seed);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH32_update(XXH_NAMESPACEXXH32_state_t* state, const void* input, size_t len)
{
    if (input==((void*)0)) {
        __builtin_assume(len == 0);
        return XXH_NAMESPACEXXH_OK;
    }
    state->total_len_32 += (XXH32_hash_t)len;
    state->large_len |= (XXH32_hash_t)((len>=16) | (state->total_len_32>=16));
    __builtin_assume(state->bufferedSize < sizeof(state->buffer));
    if (len < sizeof(state->buffer) - state->bufferedSize) {
        memcpy(state->buffer + state->bufferedSize, input, len);
        state->bufferedSize += (XXH32_hash_t)len;
        return XXH_NAMESPACEXXH_OK;
    }
    { const xxh_u8* xinput = (const xxh_u8*)input;
        const xxh_u8* const bEnd = xinput + len;
        if (state->bufferedSize) {
            memcpy(state->buffer + state->bufferedSize, xinput, sizeof(state->buffer) - state->bufferedSize);
            xinput += sizeof(state->buffer) - state->bufferedSize;
            (void)XXH32_consumeLong(state->acc, state->buffer, sizeof(state->buffer), XXH_aligned);
            state->bufferedSize = 0;
        }
        __builtin_assume(xinput <= bEnd);
        if ((size_t)(bEnd - xinput) >= sizeof(state->buffer)) {
            xinput = XXH32_consumeLong(state->acc, xinput, (size_t)(bEnd - xinput), XXH_unaligned);
        }
        if (xinput < bEnd) {
            memcpy(state->buffer, xinput, (size_t)(bEnd-xinput));
            state->bufferedSize = (unsigned)(bEnd-xinput);
        }
    }
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH32_hash_t XXH_INLINE_XXH32_digest(const XXH_NAMESPACEXXH32_state_t* state)
{
    xxh_u32 h32;
    if (state->large_len) {
        h32 = XXH32_mergeAccs(state->acc);
    } else {
        h32 = state->acc[2] + 0x165667B1U;
    }
    h32 += state->total_len_32;
    return XXH32_finalize(h32, state->buffer, state->bufferedSize, XXH_aligned);
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH32_canonicalFromHash(XXH_NAMESPACEXXH32_canonical_t* dst, XXH32_hash_t hash)
{
    do { _Static_assert(((sizeof(XXH_NAMESPACEXXH32_canonical_t) == sizeof(XXH32_hash_t))),"sizeof(XXH32_canonical_t) == sizeof(XXH32_hash_t)"); } while(0);
    if (1) hash = XXH_swap32(hash);
    memcpy(dst, &hash, sizeof(*dst));
}
static __inline __attribute__((__unused__)) XXH32_hash_t XXH_INLINE_XXH32_hashFromCanonical(const XXH_NAMESPACEXXH32_canonical_t* src)
{
    return XXH_readBE32(src);
}
typedef XXH64_hash_t xxh_u64;
static xxh_u64 XXH_read64(const void* ptr)
{
    typedef __attribute__((__aligned__(1))) xxh_u64 xxh_unalign64;
    return *((const xxh_unalign64*)ptr);
}
static xxh_u64 XXH_swap64(xxh_u64 x)
{
    return ((x << 56) & 0xff00000000000000ULL) |
            ((x << 40) & 0x00ff000000000000ULL) |
            ((x << 24) & 0x0000ff0000000000ULL) |
            ((x << 8) & 0x000000ff00000000ULL) |
            ((x >> 8) & 0x00000000ff000000ULL) |
            ((x >> 24) & 0x0000000000ff0000ULL) |
            ((x >> 40) & 0x000000000000ff00ULL) |
            ((x >> 56) & 0x00000000000000ffULL);
}
static __attribute__((__unused__)) xxh_u64 XXH_readLE64(const void* ptr)
{
    return 1 ? XXH_read64(ptr) : XXH_swap64(XXH_read64(ptr));
}
static xxh_u64 XXH_readBE64(const void* ptr)
{
    return 1 ? XXH_swap64(XXH_read64(ptr)) : XXH_read64(ptr);
}
static __attribute__((__unused__)) xxh_u64
XXH_readLE64_align(const void* ptr, XXH_alignment align)
{
    if (align==XXH_unaligned)
        return XXH_readLE64(ptr);
    else
        return 1 ? *(const xxh_u64*)ptr : XXH_swap64(*(const xxh_u64*)ptr);
}
static xxh_u64 XXH64_round(xxh_u64 acc, xxh_u64 input)
{
    acc += input * 0xC2B2AE3D27D4EB4FULL;
    acc = __builtin_rotateleft64(acc, 31);
    acc *= 0x9E3779B185EBCA87ULL;
    return acc;
}
static xxh_u64 XXH64_mergeRound(xxh_u64 acc, xxh_u64 val)
{
    val = XXH64_round(0, val);
    acc ^= val;
    acc = acc * 0x9E3779B185EBCA87ULL + 0x85EBCA77C2B2AE63ULL;
    return acc;
}
static xxh_u64 XXH64_avalanche(xxh_u64 hash)
{
    hash ^= hash >> 33;
    hash *= 0xC2B2AE3D27D4EB4FULL;
    hash ^= hash >> 29;
    hash *= 0x165667B19E3779F9ULL;
    hash ^= hash >> 32;
    return hash;
}
static __attribute__((__unused__)) void
XXH64_initAccs(xxh_u64 *acc, xxh_u64 seed)
{
    __builtin_assume(acc != ((void*)0));
    acc[0] = seed + 0x9E3779B185EBCA87ULL + 0xC2B2AE3D27D4EB4FULL;
    acc[1] = seed + 0xC2B2AE3D27D4EB4FULL;
    acc[2] = seed + 0;
    acc[3] = seed - 0x9E3779B185EBCA87ULL;
}
static __attribute__((__unused__)) const xxh_u8 *
XXH64_consumeLong(
    xxh_u64 *restrict acc,
    xxh_u8 const *restrict input,
    size_t len,
    XXH_alignment align
)
{
    const xxh_u8* const bEnd = input + len;
    const xxh_u8* const limit = bEnd - 31;
    __builtin_assume(acc != ((void*)0));
    __builtin_assume(input != ((void*)0));
    __builtin_assume(len >= 32);
    do {
        if (sizeof(void *) < sizeof(xxh_u64)) {
            size_t i;
            for (i = 0; i < 4; i++) {
                acc[i] = XXH64_round(acc[i], XXH_readLE64_align(input, align));
                input += 8;
            }
        } else {
            acc[0] = XXH64_round(acc[0], XXH_readLE64_align(input, align)); input += 8;
            acc[1] = XXH64_round(acc[1], XXH_readLE64_align(input, align)); input += 8;
            acc[2] = XXH64_round(acc[2], XXH_readLE64_align(input, align)); input += 8;
            acc[3] = XXH64_round(acc[3], XXH_readLE64_align(input, align)); input += 8;
        }
    } while (input < limit);
    return input;
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u64
XXH64_mergeAccs(const xxh_u64 *acc)
{
    __builtin_assume(acc != ((void*)0));
    {
        xxh_u64 h64 = __builtin_rotateleft64(acc[0], 1) + __builtin_rotateleft64(acc[1], 7)
                    + __builtin_rotateleft64(acc[2], 12) + __builtin_rotateleft64(acc[3], 18);
        if (sizeof(void *) < sizeof(xxh_u64)) {
            size_t i;
            for (i = 0; i < 4; i++) {
                h64 = XXH64_mergeRound(h64, acc[i]);
            }
        } else {
            h64 = XXH64_mergeRound(h64, acc[0]);
            h64 = XXH64_mergeRound(h64, acc[1]);
            h64 = XXH64_mergeRound(h64, acc[2]);
            h64 = XXH64_mergeRound(h64, acc[3]);
        }
        return h64;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u64
XXH64_finalize(xxh_u64 hash, const xxh_u8* ptr, size_t len, XXH_alignment align)
{
    if (ptr==((void*)0)) __builtin_assume(len == 0);
    len &= 31;
    while (len >= 8) {
        xxh_u64 const k1 = XXH64_round(0, XXH_readLE64_align(ptr, align));
        ptr += 8;
        hash ^= k1;
        hash = __builtin_rotateleft64(hash,27) * 0x9E3779B185EBCA87ULL + 0x85EBCA77C2B2AE63ULL;
        len -= 8;
    }
    if (len >= 4) {
        hash ^= (xxh_u64)(XXH_readLE32_align(ptr, align)) * 0x9E3779B185EBCA87ULL;
        ptr += 4;
        hash = __builtin_rotateleft64(hash, 23) * 0xC2B2AE3D27D4EB4FULL + 0x165667B19E3779F9ULL;
        len -= 4;
    }
    while (len > 0) {
        hash ^= (*ptr++) * 0x27D4EB2F165667C5ULL;
        hash = __builtin_rotateleft64(hash, 11) * 0x9E3779B185EBCA87ULL;
        --len;
    }
    return XXH64_avalanche(hash);
}
static __attribute__((__unused__)) __attribute__((__pure__)) xxh_u64
XXH64_endian_align(const xxh_u8* input, size_t len, xxh_u64 seed, XXH_alignment align)
{
    xxh_u64 h64;
    if (input==((void*)0)) __builtin_assume(len == 0);
    if (len>=32) {
        xxh_u64 acc[4];
        XXH64_initAccs(acc, seed);
        input = XXH64_consumeLong(acc, input, len, align);
        h64 = XXH64_mergeAccs(acc);
    } else {
        h64 = seed + 0x27D4EB2F165667C5ULL;
    }
    h64 += (xxh_u64) len;
    return XXH64_finalize(h64, input, len, align);
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH64 (__attribute__((__noescape__)) const void* input, size_t len, XXH64_hash_t seed)
{
    if (0) {
        if ((((size_t)input) & 7)==0) {
            return XXH64_endian_align((const xxh_u8*)input, len, seed, XXH_aligned);
    } }
    return XXH64_endian_align((const xxh_u8*)input, len, seed, XXH_unaligned);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH64_state_t* XXH_INLINE_XXH64_createState(void)
{
    return (XXH_NAMESPACEXXH64_state_t*)XXH_malloc(sizeof(XXH_NAMESPACEXXH64_state_t));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_freeState(XXH_NAMESPACEXXH64_state_t* statePtr)
{
    XXH_free(statePtr);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* dstState, const XXH_NAMESPACEXXH64_state_t* srcState)
{
    memcpy(dstState, srcState, sizeof(*dstState));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH64_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* statePtr, XXH64_hash_t seed)
{
    __builtin_assume(statePtr != ((void*)0));
    memset(statePtr, 0, sizeof(*statePtr));
    XXH64_initAccs(statePtr->acc, seed);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH64_update (__attribute__((__noescape__)) XXH_NAMESPACEXXH64_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    if (input==((void*)0)) {
        __builtin_assume(len == 0);
        return XXH_NAMESPACEXXH_OK;
    }
    state->total_len += len;
    __builtin_assume(state->bufferedSize <= sizeof(state->buffer));
    if (len < sizeof(state->buffer) - state->bufferedSize) {
        memcpy(state->buffer + state->bufferedSize, input, len);
        state->bufferedSize += (XXH32_hash_t)len;
        return XXH_NAMESPACEXXH_OK;
    }
    { const xxh_u8* xinput = (const xxh_u8*)input;
        const xxh_u8* const bEnd = xinput + len;
        if (state->bufferedSize) {
            memcpy(state->buffer + state->bufferedSize, xinput, sizeof(state->buffer) - state->bufferedSize);
            xinput += sizeof(state->buffer) - state->bufferedSize;
            (void)XXH64_consumeLong(state->acc, state->buffer, sizeof(state->buffer), XXH_aligned);
            state->bufferedSize = 0;
        }
        __builtin_assume(xinput <= bEnd);
        if ((size_t)(bEnd - xinput) >= sizeof(state->buffer)) {
            xinput = XXH64_consumeLong(state->acc, xinput, (size_t)(bEnd - xinput), XXH_unaligned);
        }
        if (xinput < bEnd) {
            memcpy(state->buffer, xinput, (size_t)(bEnd-xinput));
            state->bufferedSize = (unsigned)(bEnd-xinput);
        }
    }
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH64_digest(__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_state_t* state)
{
    xxh_u64 h64;
    if (state->total_len >= 32) {
        h64 = XXH64_mergeAccs(state->acc);
    } else {
        h64 = state->acc[2] + 0x27D4EB2F165667C5ULL;
    }
    h64 += (xxh_u64) state->total_len;
    return XXH64_finalize(h64, state->buffer, (size_t)state->total_len, XXH_aligned);
}
static __inline __attribute__((__unused__)) void XXH_INLINE_XXH64_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH64_canonical_t* dst, XXH64_hash_t hash)
{
    do { _Static_assert(((sizeof(XXH_NAMESPACEXXH64_canonical_t) == sizeof(XXH64_hash_t))),"sizeof(XXH64_canonical_t) == sizeof(XXH64_hash_t)"); } while(0);
    if (1) hash = XXH_swap64(hash);
    memcpy(dst, &hash, sizeof(*dst));
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH64_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH64_canonical_t* src)
{
    return XXH_readBE64(src);
}
typedef long long __m64 __attribute__((__vector_size__(8), __aligned__(8)));
typedef long long __v1di __attribute__((__vector_size__(8)));
typedef int __v2si __attribute__((__vector_size__(8)));
typedef short __v4hi __attribute__((__vector_size__(8)));
typedef char __v8qi __attribute__((__vector_size__(8)));
typedef unsigned long long __v1du __attribute__ ((__vector_size__ (8)));
typedef unsigned int __v2su __attribute__ ((__vector_size__ (8)));
typedef unsigned short __v4hu __attribute__((__vector_size__(8)));
typedef unsigned char __v8qu __attribute__((__vector_size__(8)));
typedef signed char __v8qs __attribute__((__vector_size__(8)));
typedef long long __m128i __attribute__((__vector_size__(16), __aligned__(16)));
typedef long long __v2di __attribute__ ((__vector_size__ (16)));
typedef int __v4si __attribute__((__vector_size__(16)));
typedef short __v8hi __attribute__((__vector_size__(16)));
typedef char __v16qi __attribute__((__vector_size__(16)));
static __inline__ void __attribute__((__always_inline__, __nodebug__,
                                      __target__("mmx,no-evex512")))
_mm_empty(void) {
  __builtin_ia32_emms();
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi32_si64(int __i)
{
    return __extension__ (__m64)(__v2si){__i, 0};
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi64_si32(__m64 __m)
{
    return ((__v2si)__m)[0];
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi64_m64(long long __i)
{
    return (__m64)__i;
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtm64_si64(__m64 __m)
{
    return (long long)__m;
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_packs_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packsswb128( (__v8hi)__builtin_shufflevector(__m1, __m2, 0, 1), (__v8hi){})), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_packs_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packssdw128( (__v4si)__builtin_shufflevector(__m1, __m2, 0, 1), (__v4si){})), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_packs_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packuswb128( (__v8hi)__builtin_shufflevector(__m1, __m2, 0, 1), (__v8hi){})), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v8qi)__m1, (__v8qi)__m2,
                                          4, 12, 5, 13, 6, 14, 7, 15);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v4hi)__m1, (__v4hi)__m2,
                                          2, 6, 3, 7);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v2si)__m1, (__v2si)__m2, 1, 3);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v8qi)__m1, (__v8qi)__m2,
                                          0, 8, 1, 9, 2, 10, 3, 11);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v4hi)__m1, (__v4hi)__m2,
                                          0, 4, 1, 5);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_shufflevector((__v2si)__m1, (__v2si)__m2, 0, 2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v8qu)__m1) + ((__v8qu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hu)__m1) + ((__v4hu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v2su)__m1) + ((__v2su)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v8qs)__m1, (__v8qs)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v4hi)__m1, (__v4hi)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pu8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v8qu)__m1, (__v8qu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_adds_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_add_sat((__v4hu)__m1, (__v4hu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v8qu)__m1) - ((__v8qu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hu)__m1) - ((__v4hu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v2su)__m1) - ((__v2su)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v8qs)__m1, (__v8qs)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v4hi)__m1, (__v4hi)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pu8(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v8qu)__m1, (__v8qu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_subs_pu16(__m64 __m1, __m64 __m2)
{
    return (__m64)__builtin_elementwise_sub_sat((__v4hu)__m1, (__v4hu)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_madd_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmaddwd128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m1), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m2), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_mulhi_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmulhw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m1), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m2), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_mullo_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hu)__m1) * ((__v4hu)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sll_pi16(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_slli_pi16(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllwi128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sll_pi32(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pslld128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_slli_pi32(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pslldi128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sll_si64(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllq128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v2di)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_slli_si64(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psllqi128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sra_pi16(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psraw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srai_pi16(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrawi128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sra_pi32(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrad128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srai_pi32(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psradi128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srl_pi16(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srli_pi16(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlwi128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srl_pi32(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrld128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srli_pi32(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrldi128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srl_si64(__m64 __m, __m64 __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlq128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), (__v2di)(__m128i) __builtin_shufflevector((__v2si)(__count), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_srli_si64(__m64 __m, int __count)
{
    return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psrlqi128((__v2di)(__m128i) __builtin_shufflevector((__v2si)(__m), __extension__(__v2si){}, 0, 1, -1, -1), __count)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_and_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v1du)__m1) & ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_andnot_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(~((__v1du)__m1) & ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_or_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v1du)__m1) | ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_xor_si64(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v1du)__m1) ^ ((__v1du)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpeq_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v8qi)__m1) == ((__v8qi)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpeq_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v4hi)__m1) == ((__v4hi)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpeq_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)(((__v2si)__m1) == ((__v2si)__m2));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpgt_pi8(__m64 __m1, __m64 __m2)
{
    return (__m64)((__v8qs)__m1 > (__v8qs)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpgt_pi16(__m64 __m1, __m64 __m2)
{
    return (__m64)((__v4hi)__m1 > (__v4hi)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cmpgt_pi32(__m64 __m1, __m64 __m2)
{
    return (__m64)((__v2si)__m1 > (__v2si)__m2);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setzero_si64(void) {
  return __extension__(__m64){0LL};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_pi32(int __i1, int __i0) {
  return __extension__(__m64)(__v2si){__i0, __i1};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_pi16(short __s3, short __s2, short __s1, short __s0) {
  return __extension__(__m64)(__v4hi){__s0, __s1, __s2, __s3};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_pi8(char __b7, char __b6, char __b5, char __b4, char __b3, char __b2,
            char __b1, char __b0) {
  return __extension__(__m64)(__v8qi){__b0, __b1, __b2, __b3,
                                      __b4, __b5, __b6, __b7};
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_pi32(int __i) {
  return _mm_set_pi32(__i, __i);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_pi16(short __w) {
  return _mm_set_pi16(__w, __w, __w, __w);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_pi8(char __b) {
  return _mm_set_pi8(__b, __b, __b, __b, __b, __b, __b, __b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_pi32(int __i0, int __i1) {
  return _mm_set_pi32(__i1, __i0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_pi16(short __w0, short __w1, short __w2, short __w3) {
  return _mm_set_pi16(__w3, __w2, __w1, __w0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_pi8(char __b0, char __b1, char __b2, char __b3, char __b4, char __b5,
             char __b6, char __b7) {
  return _mm_set_pi8(__b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}

typedef int __v4si __attribute__((__vector_size__(16)));
typedef float __v4sf __attribute__((__vector_size__(16)));
typedef float __m128 __attribute__((__vector_size__(16), __aligned__(16)));
typedef float __m128_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef unsigned int __v4su __attribute__((__vector_size__(16)));
extern int posix_memalign(void **__memptr, size_t __alignment, size_t __size);
static __inline__ void *__attribute__((__always_inline__, __nodebug__,
                                       __malloc__, __alloc_size__(1),
                                       __alloc_align__(2)))
_mm_malloc(size_t __size, size_t __align) {
  if (__align == 1) {
    return malloc(__size);
  }
  if (!(__align & (__align - 1)) && __align < sizeof(void *))
    __align = sizeof(void *);
  void *__mallocedMemory;
  if (posix_memalign(&__mallocedMemory, __align, __size))
    return 0;
  return __mallocedMemory;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_free(void *__p)
{
  free(__p);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_add_ss(__m128 __a, __m128 __b) {
  __a[0] += __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_add_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a + (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sub_ss(__m128 __a, __m128 __b) {
  __a[0] -= __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sub_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a - (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_mul_ss(__m128 __a, __m128 __b) {
  __a[0] *= __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_mul_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a * (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_div_ss(__m128 __a, __m128 __b) {
  __a[0] /= __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_div_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4sf)__a / (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sqrt_ss(__m128 __a)
{
  return (__m128)__builtin_ia32_sqrtss((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_sqrt_ps(__m128 __a)
{
  return __builtin_ia32_sqrtps((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rcp_ss(__m128 __a)
{
  return (__m128)__builtin_ia32_rcpss((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rcp_ps(__m128 __a)
{
  return (__m128)__builtin_ia32_rcpps((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rsqrt_ss(__m128 __a)
{
  return __builtin_ia32_rsqrtss((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_rsqrt_ps(__m128 __a)
{
  return __builtin_ia32_rsqrtps((__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_min_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_minss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_min_ps(__m128 __a, __m128 __b)
{
  return __builtin_ia32_minps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_max_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_maxss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_max_ps(__m128 __a, __m128 __b)
{
  return __builtin_ia32_maxps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_and_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4su)__a & (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_andnot_ps(__m128 __a, __m128 __b) {
  return (__m128)(~(__v4su)__a & (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_or_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4su)__a | (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_xor_ps(__m128 __a, __m128 __b) {
  return (__m128)((__v4su)__a ^ (__v4su)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpeq_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpeqss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpeq_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpeqps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmplt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmplt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmple_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpless((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmple_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpleps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpgt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpltss((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpgt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpltps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpge_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpless((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpge_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpleps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpneq_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpneqss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpneq_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpneqps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnlt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnlt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnle_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnless((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnle_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnleps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpngt_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpnltss((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpngt_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnltps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnge_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_shufflevector((__v4sf)__a,
                                         (__v4sf)__builtin_ia32_cmpnless((__v4sf)__b, (__v4sf)__a),
                                         4, 1, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpnge_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpnleps((__v4sf)__b, (__v4sf)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpord_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpordss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpord_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpordps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpunord_ss(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpunordss((__v4sf)__a, (__v4sf)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cmpunord_ps(__m128 __a, __m128 __b)
{
  return (__m128)__builtin_ia32_cmpunordps((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comieq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comieq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comilt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comilt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comile_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comile((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comigt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comigt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comige_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comige((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_comineq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_comineq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomieq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomieq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomilt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomilt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomile_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomile((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomigt_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomigt((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomige_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomige((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_ucomineq_ss(__m128 __a, __m128 __b)
{
  return __builtin_ia32_ucomineq((__v4sf)__a, (__v4sf)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtss_si32(__m128 __a)
{
  return __builtin_ia32_cvtss2si((__v4sf)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvt_ss2si(__m128 __a)
{
  return _mm_cvtss_si32(__a);
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtss_si64(__m128 __a)
{
  return __builtin_ia32_cvtss2si64((__v4sf)__a);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pi32(__m128 __a)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvtps2dq((__v4sf)(__m128i) __builtin_shufflevector((__v4si)(__a), __extension__(__v4si){}, 0, 1, 4, 5))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvt_ps2pi(__m128 __a)
{
  return _mm_cvtps_pi32(__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvttss_si32(__m128 __a)
{
  return __builtin_ia32_cvttss2si((__v4sf)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtt_ss2si(__m128 __a)
{
  return _mm_cvttss_si32(__a);
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvttss_si64(__m128 __a)
{
  return __builtin_ia32_cvttss2si64((__v4sf)__a);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvttps_pi32(__m128 __a)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvttps2dq((__v4sf)(__m128i) __builtin_shufflevector((__v4si)(__a), __extension__(__v4si){}, 0, 1, 4, 5))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtt_ps2pi(__m128 __a)
{
  return _mm_cvttps_pi32(__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128))) _mm_cvtsi32_ss(__m128 __a,
                                                                     int __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128))) _mm_cvt_si2ss(__m128 __a,
                                                                    int __b) {
  return _mm_cvtsi32_ss(__a, __b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtsi64_ss(__m128 __a, long long __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi32_ps(__m128 __a, __m64 __b)
{
  return (__m128)__builtin_shufflevector(
      (__v4sf)__a,
      __builtin_convertvector((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, 2, 3), __v4sf),
      4, 5, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvt_pi2ps(__m128 __a, __m64 __b)
{
  return _mm_cvtpi32_ps(__a, __b);
}
static __inline__ float __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_cvtss_f32(__m128 __a) {
  return __a[0];
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadh_pi(__m128 __a, const __m64 *__p)
{
  typedef float __mm_loadh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_loadh_pi_struct {
    __mm_loadh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  __mm_loadh_pi_v2f32 __b = ((const struct __mm_loadh_pi_struct*)__p)->__u;
  __m128 __bb = __builtin_shufflevector(__b, __b, 0, 1, 0, 1);
  return __builtin_shufflevector(__a, __bb, 0, 1, 4, 5);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadl_pi(__m128 __a, const __m64 *__p)
{
  typedef float __mm_loadl_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_loadl_pi_struct {
    __mm_loadl_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  __mm_loadl_pi_v2f32 __b = ((const struct __mm_loadl_pi_struct*)__p)->__u;
  __m128 __bb = __builtin_shufflevector(__b, __b, 0, 1, 0, 1);
  return __builtin_shufflevector(__a, __bb, 4, 5, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_load_ss(const float *__p)
{
  struct __mm_load_ss_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  float __u = ((const struct __mm_load_ss_struct*)__p)->__u;
  return __extension__ (__m128){ __u, 0, 0, 0 };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_load1_ps(const float *__p)
{
  struct __mm_load1_ps_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  float __u = ((const struct __mm_load1_ps_struct*)__p)->__u;
  return __extension__ (__m128){ __u, __u, __u, __u };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_load_ps(const float *__p)
{
  return *(const __m128*)__p;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadu_ps(const float *__p)
{
  struct __loadu_ps {
    __m128_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_ps*)__p)->__v;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_loadr_ps(const float *__p)
{
  __m128 __a = _mm_load_ps(__p);
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 3, 2, 1, 0);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_undefined_ps(void)
{
  return (__m128)__builtin_ia32_undef128();
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set_ss(float __w) {
  return __extension__ (__m128){ __w, 0.0f, 0.0f, 0.0f };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set1_ps(float __w) {
  return __extension__ (__m128){ __w, __w, __w, __w };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set_ps1(float __w) {
    return _mm_set1_ps(__w);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_set_ps(float __z, float __y, float __x, float __w) {
  return __extension__ (__m128){ __w, __x, __y, __z };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_setr_ps(float __z, float __y, float __x, float __w) {
  return __extension__ (__m128){ __z, __y, __x, __w };
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_setzero_ps(void) {
  return __extension__ (__m128){ 0.0f, 0.0f, 0.0f, 0.0f };
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storeh_pi(__m64 *__p, __m128 __a)
{
  typedef float __mm_storeh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_storeh_pi_struct {
    __mm_storeh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pi_struct*)__p)->__u = __builtin_shufflevector(__a, __a, 2, 3);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storel_pi(__m64 *__p, __m128 __a)
{
  typedef float __mm_storeh_pi_v2f32 __attribute__((__vector_size__(8)));
  struct __mm_storeh_pi_struct {
    __mm_storeh_pi_v2f32 __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pi_struct*)__p)->__u = __builtin_shufflevector(__a, __a, 0, 1);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store_ss(float *__p, __m128 __a)
{
  struct __mm_store_ss_struct {
    float __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store_ss_struct*)__p)->__u = __a[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storeu_ps(float *__p, __m128 __a)
{
  struct __storeu_ps {
    __m128_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_ps*)__p)->__v = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store_ps(float *__p, __m128 __a)
{
  *(__m128*)__p = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store1_ps(float *__p, __m128 __a)
{
  __a = __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 0, 0, 0, 0);
  _mm_store_ps(__p, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_store_ps1(float *__p, __m128 __a)
{
  _mm_store1_ps(__p, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_storer_ps(float *__p, __m128 __a)
{
  __a = __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 3, 2, 1, 0);
  _mm_store_ps(__p, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_stream_pi(void *__p, __m64 __a)
{
  __builtin_nontemporal_store(__a, (__m64 *)__p);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_stream_ps(void *__p, __m128 __a)
{
  __builtin_nontemporal_store((__v4sf)__a, (__v4sf*)__p);
}
void _mm_sfence(void);
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_max_pi16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_max((__v4hi)__a, (__v4hi)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_max_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_max((__v8qu)__a, (__v8qu)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_min_pi16(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_min((__v4hi)__a, (__v4hi)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_min_pu8(__m64 __a, __m64 __b)
{
  return (__m64)__builtin_elementwise_min((__v8qu)__a, (__v8qu)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_movemask_pi8(__m64 __a)
{
  return __builtin_ia32_pmovmskb128((__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, 2, 3));
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_mulhi_pu16(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmulhuw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_maskmove_si64(__m64 __d, __m64 __n, char *__p)
{
  __m128i __d128 = (__m128i) __builtin_shufflevector((__v2si)(__d), __extension__(__v2si){}, 0, 1, -1, -1);
  __m128i __n128 = (__m128i) __builtin_shufflevector((__v2si)(__n), __extension__(__v2si){}, 0, 1, 2, 3);
  if (((long unsigned int)__p & 0xfff) >= 4096-15 &&
      ((long unsigned int)__p & 0xfff) <= 4096-8) {
    __p -= 8;
    __d128 = __builtin_ia32_pslldqi128_byteshift((__v2di)__d128, 8);
    __n128 = __builtin_ia32_pslldqi128_byteshift((__v2di)__n128, 8);
  }
  __builtin_ia32_maskmovdqu((__v16qi)__d128, (__v16qi)__n128, __p);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_avg_pu8(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pavgb128((__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_avg_pu16(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pavgw128((__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v8hi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sad_pu8(__m64 __a, __m64 __b)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_psadbw128((__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, 2, 3), (__v16qi)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, 2, 3))), __extension__(__v2di){}, 0);
}
unsigned int _mm_getcsr(void);
void _mm_setcsr(unsigned int __i);
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_unpackhi_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 2, 6, 3, 7);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_unpacklo_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 0, 4, 1, 5);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_move_ss(__m128 __a, __m128 __b) {
  __a[0] = __b[0];
  return __a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_movehl_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 6, 7, 2, 3);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_movelh_ps(__m128 __a, __m128 __b) {
  return __builtin_shufflevector((__v4sf)__a, (__v4sf)__b, 0, 1, 4, 5);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi16_ps(__m64 __a)
{
  return __builtin_convertvector((__v4hi)__a, __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpu16_ps(__m64 __a)
{
  return __builtin_convertvector((__v4hu)__a, __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi8_ps(__m64 __a)
{
  return __builtin_convertvector(
      __builtin_shufflevector((__v8qs)__a, __extension__ (__v8qs){},
                              0, 1, 2, 3), __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpu8_ps(__m64 __a)
{
  return __builtin_convertvector(
      __builtin_shufflevector((__v8qu)__a, __extension__ (__v8qu){},
                              0, 1, 2, 3), __v4sf);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi32x2_ps(__m64 __a, __m64 __b)
{
  return __builtin_convertvector(
      __builtin_shufflevector((__v2si)__a, (__v2si)__b,
                              0, 1, 2, 3), __v4sf);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pi16(__m128 __a)
{
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_packssdw128( (__v4si)__builtin_ia32_cvtps2dq((__v4sf)__a), (__v4si)_mm_setzero_ps())), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pi8(__m128 __a)
{
  __m64 __b, __c;
  __b = _mm_cvtps_pi16(__a);
  __c = _mm_setzero_si64();
  return _mm_packs_pi16(__b, __c);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse"), __min_vector_width__(128)))
_mm_movemask_ps(__m128 __a)
{
  return __builtin_ia32_movmskps((__v4sf)__a);
}

typedef double __m128d __attribute__((__vector_size__(16), __aligned__(16)));
typedef long long __m128i __attribute__((__vector_size__(16), __aligned__(16)));
typedef double __m128d_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef long long __m128i_u
    __attribute__((__vector_size__(16), __aligned__(1)));
typedef double __v2df __attribute__((__vector_size__(16)));
typedef long long __v2di __attribute__((__vector_size__(16)));
typedef short __v8hi __attribute__((__vector_size__(16)));
typedef char __v16qi __attribute__((__vector_size__(16)));
typedef unsigned long long __v2du __attribute__((__vector_size__(16)));
typedef unsigned short __v8hu __attribute__((__vector_size__(16)));
typedef unsigned char __v16qu __attribute__((__vector_size__(16)));
typedef signed char __v16qs __attribute__((__vector_size__(16)));
typedef _Float16 __v8hf __attribute__((__vector_size__(16), __aligned__(16)));
typedef _Float16 __m128h __attribute__((__vector_size__(16), __aligned__(16)));
typedef _Float16 __m128h_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef __bf16 __v8bf __attribute__((__vector_size__(16), __aligned__(16)));
typedef __bf16 __m128bh __attribute__((__vector_size__(16), __aligned__(16)));
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] += __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a + (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] -= __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a - (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] *= __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a * (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_div_sd(__m128d __a,
                                                                  __m128d __b) {
  __a[0] /= __b[0];
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_div_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2df)__a / (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sqrt_sd(__m128d __a,
                                                         __m128d __b) {
  __m128d __c = __builtin_ia32_sqrtsd((__v2df)__b);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sqrt_pd(__m128d __a) {
  return __builtin_ia32_sqrtpd((__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_minsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_pd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_minpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_maxsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_pd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_maxpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_and_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2du)__a & (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_andnot_pd(__m128d __a, __m128d __b) {
  return (__m128d)(~(__v2du)__a & (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_or_pd(__m128d __a,
                                                                 __m128d __b) {
  return (__m128d)((__v2du)__a | (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_xor_pd(__m128d __a,
                                                                  __m128d __b) {
  return (__m128d)((__v2du)__a ^ (__v2du)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpeqpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmple_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplepd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltpd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpge_pd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplepd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpord_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpordpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpunord_pd(__m128d __a,
                                                             __m128d __b) {
  return (__m128d)__builtin_ia32_cmpunordpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpneq_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpneqpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnlt_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltpd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnle_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlepd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpngt_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltpd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnge_pd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlepd((__v2df)__b, (__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpeqsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmpltsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmple_sd(__m128d __a,
                                                          __m128d __b) {
  return (__m128d)__builtin_ia32_cmplesd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_sd(__m128d __a,
                                                          __m128d __b) {
  __m128d __c = __builtin_ia32_cmpltsd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpge_sd(__m128d __a,
                                                          __m128d __b) {
  __m128d __c = __builtin_ia32_cmplesd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpord_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpordsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpunord_sd(__m128d __a,
                                                             __m128d __b) {
  return (__m128d)__builtin_ia32_cmpunordsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpneq_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpneqsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnlt_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnltsd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnle_sd(__m128d __a,
                                                           __m128d __b) {
  return (__m128d)__builtin_ia32_cmpnlesd((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpngt_sd(__m128d __a,
                                                           __m128d __b) {
  __m128d __c = __builtin_ia32_cmpnltsd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpnge_sd(__m128d __a,
                                                           __m128d __b) {
  __m128d __c = __builtin_ia32_cmpnlesd((__v2df)__b, (__v2df)__a);
  return __extension__(__m128d){__c[0], __a[1]};
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comieq_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdeq((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comilt_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdlt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comile_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdle((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comigt_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdgt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comige_sd(__m128d __a,
                                                       __m128d __b) {
  return __builtin_ia32_comisdge((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_comineq_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_comisdneq((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomieq_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdeq((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomilt_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdlt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomile_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdle((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomigt_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdgt((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomige_sd(__m128d __a,
                                                        __m128d __b) {
  return __builtin_ia32_ucomisdge((__v2df)__a, (__v2df)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_ucomineq_sd(__m128d __a,
                                                         __m128d __b) {
  return __builtin_ia32_ucomisdneq((__v2df)__a, (__v2df)__b);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtpd_ps(__m128d __a) {
  return __builtin_ia32_cvtpd2ps((__v2df)__a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtps_pd(__m128 __a) {
  return (__m128d) __builtin_convertvector(
      __builtin_shufflevector((__v4sf)__a, (__v4sf)__a, 0, 1), __v2df);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtepi32_pd(__m128i __a) {
  return (__m128d) __builtin_convertvector(
      __builtin_shufflevector((__v4si)__a, (__v4si)__a, 0, 1), __v2df);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtpd_epi32(__m128d __a) {
  return __builtin_ia32_cvtpd2dq((__v2df)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsd_si32(__m128d __a) {
  return __builtin_ia32_cvtsd2si((__v2df)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsd_ss(__m128 __a,
                                                         __m128d __b) {
  return (__m128)__builtin_ia32_cvtsd2ss((__v4sf)__a, (__v2df)__b);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi32_sd(__m128d __a, int __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtss_sd(__m128d __a, __m128 __b) {
  __a[0] = __b[0];
  return __a;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttpd_epi32(__m128d __a) {
  return (__m128i)__builtin_ia32_cvttpd2dq((__v2df)__a);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttsd_si32(__m128d __a) {
  return __builtin_ia32_cvttsd2si((__v2df)__a);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtpd_pi32(__m128d __a) {
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvtpd2dq((__v2df)__a)), __extension__(__v2di){}, 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttpd_pi32(__m128d __a) {
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_cvttpd2dq((__v2df)__a)), __extension__(__v2di){}, 0);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtpi32_pd(__m64 __a) {
  return (__m128d) __builtin_convertvector((__v2si)__a, __v2df);
}
static __inline__ double __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsd_f64(__m128d __a) {
  return __a[0];
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_load_pd(double const *__dp) {
  return *(const __m128d *)__dp;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_load1_pd(double const *__dp) {
  struct __mm_load1_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_load1_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, __u};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadr_pd(double const *__dp) {
  __m128d __u = *(const __m128d *)__dp;
  return __builtin_shufflevector((__v2df)__u, (__v2df)__u, 1, 0);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_pd(double const *__dp) {
  struct __loadu_pd {
    __m128d_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_pd *)__dp)->__v;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_si64(void const *__a) {
  struct __loadu_si64 {
    long long __v;
  } __attribute__((__packed__, __may_alias__));
  long long __u = ((const struct __loadu_si64 *)__a)->__v;
  return __extension__(__m128i)(__v2di){__u, 0LL};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_si32(void const *__a) {
  struct __loadu_si32 {
    int __v;
  } __attribute__((__packed__, __may_alias__));
  int __u = ((const struct __loadu_si32 *)__a)->__v;
  return __extension__(__m128i)(__v4si){__u, 0, 0, 0};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadu_si16(void const *__a) {
  struct __loadu_si16 {
    short __v;
  } __attribute__((__packed__, __may_alias__));
  short __u = ((const struct __loadu_si16 *)__a)->__v;
  return __extension__(__m128i)(__v8hi){__u, 0, 0, 0, 0, 0, 0, 0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_load_sd(double const *__dp) {
  struct __mm_load_sd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_load_sd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, 0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadh_pd(__m128d __a,
                                                          double const *__dp) {
  struct __mm_loadh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_loadh_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__a[0], __u};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_loadl_pd(__m128d __a,
                                                          double const *__dp) {
  struct __mm_loadl_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  double __u = ((const struct __mm_loadl_pd_struct *)__dp)->__u;
  return __extension__(__m128d){__u, __a[1]};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_undefined_pd(void) {
  return (__m128d)__builtin_ia32_undef128();
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_sd(double __w) {
  return __extension__(__m128d){__w, 0.0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set1_pd(double __w) {
  return __extension__(__m128d){__w, __w};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_pd1(double __w) {
  return _mm_set1_pd(__w);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_pd(double __w,
                                                                  double __x) {
  return __extension__(__m128d){__x, __w};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_setr_pd(double __w,
                                                                   double __x) {
  return __extension__(__m128d){__w, __x};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_setzero_pd(void) {
  return __extension__(__m128d){0.0, 0.0};
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_move_sd(__m128d __a, __m128d __b) {
  __a[0] = __b[0];
  return __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_sd(double *__dp,
                                                       __m128d __a) {
  struct __mm_store_sd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store_sd_struct *)__dp)->__u = __a[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_pd(double *__dp,
                                                       __m128d __a) {
  *(__m128d *)__dp = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store1_pd(double *__dp,
                                                        __m128d __a) {
  __a = __builtin_shufflevector((__v2df)__a, (__v2df)__a, 0, 0);
  _mm_store_pd(__dp, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_pd1(double *__dp,
                                                        __m128d __a) {
  _mm_store1_pd(__dp, __a);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_pd(double *__dp,
                                                        __m128d __a) {
  struct __storeu_pd {
    __m128d_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_pd *)__dp)->__v = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storer_pd(double *__dp,
                                                        __m128d __a) {
  __a = __builtin_shufflevector((__v2df)__a, (__v2df)__a, 1, 0);
  *(__m128d *)__dp = __a;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeh_pd(double *__dp,
                                                        __m128d __a) {
  struct __mm_storeh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pd_struct *)__dp)->__u = __a[1];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storel_pd(double *__dp,
                                                        __m128d __a) {
  struct __mm_storeh_pd_struct {
    double __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeh_pd_struct *)__dp)->__u = __a[0];
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_epi8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v16qu)__a + (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v8hu)__a + (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_epi32(__m128i __a, __m128i __b) {
  return (__m128i)((__v4su)__a + (__v4su)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_add_si64(__m64 __a, __m64 __b) {
  return (__m64)(((unsigned long long)__a) + ((unsigned long long)__b));
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_add_epi64(__m128i __a, __m128i __b) {
  return (__m128i)((__v2du)__a + (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epi8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v16qs)__a, (__v16qs)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epu8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_adds_epu16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_add_sat((__v8hu)__a, (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_avg_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_ia32_pavgb128((__v16qi)__a, (__v16qi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_avg_epu16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_ia32_pavgw128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_madd_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_ia32_pmaddwd128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_max((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_max_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_elementwise_max((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_min((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_min_epu8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)__builtin_elementwise_min((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mulhi_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_pmulhw128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mulhi_epu16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_pmulhuw128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mullo_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hu)__a * (__v8hu)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_su32(__m64 __a, __m64 __b) {
  return (__m64) __builtin_shufflevector((__v2di)(__builtin_ia32_pmuludq128((__v4si)(__m128i) __builtin_shufflevector((__v2si)(__a), __extension__(__v2si){}, 0, 1, -1, -1), (__v4si)(__m128i) __builtin_shufflevector((__v2si)(__b), __extension__(__v2si){}, 0, 1, -1, -1))), __extension__(__v2di){}, 0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_mul_epu32(__m128i __a,
                                                           __m128i __b) {
  return __builtin_ia32_pmuludq128((__v4si)__a, (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sad_epu8(__m128i __a,
                                                          __m128i __b) {
  return __builtin_ia32_psadbw128((__v16qi)__a, (__v16qi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_epi8(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v16qu)__a - (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_epi16(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v8hu)__a - (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_epi32(__m128i __a, __m128i __b) {
  return (__m128i)((__v4su)__a - (__v4su)__b);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sub_si64(__m64 __a, __m64 __b) {
  return (__m64)((unsigned long long)__a - (unsigned long long)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_sub_epi64(__m128i __a, __m128i __b) {
  return (__m128i)((__v2du)__a - (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epi8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v16qs)__a, (__v16qs)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epi16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epu8(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v16qu)__a, (__v16qu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_subs_epu16(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)__builtin_elementwise_sub_sat((__v8hu)__a, (__v8hu)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_and_si128(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a & (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_andnot_si128(__m128i __a,
                                                              __m128i __b) {
  return (__m128i)(~(__v2du)__a & (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_or_si128(__m128i __a,
                                                          __m128i __b) {
  return (__m128i)((__v2du)__a | (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_xor_si128(__m128i __a,
                                                           __m128i __b) {
  return (__m128i)((__v2du)__a ^ (__v2du)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_slli_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psllwi128((__v8hi)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sll_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psllw128((__v8hi)__a, (__v8hi)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_slli_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_pslldi128((__v4si)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sll_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_pslld128((__v4si)__a, (__v4si)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_slli_epi64(__m128i __a,
                                                            int __count) {
  return __builtin_ia32_psllqi128((__v2di)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sll_epi64(__m128i __a,
                                                           __m128i __count) {
  return __builtin_ia32_psllq128((__v2di)__a, (__v2di)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srai_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrawi128((__v8hi)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sra_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psraw128((__v8hi)__a, (__v8hi)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srai_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psradi128((__v4si)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_sra_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrad128((__v4si)__a, (__v4si)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srli_epi16(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrlwi128((__v8hi)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srl_epi16(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrlw128((__v8hi)__a, (__v8hi)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srli_epi32(__m128i __a,
                                                            int __count) {
  return (__m128i)__builtin_ia32_psrldi128((__v4si)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srl_epi32(__m128i __a,
                                                           __m128i __count) {
  return (__m128i)__builtin_ia32_psrld128((__v4si)__a, (__v4si)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srli_epi64(__m128i __a,
                                                            int __count) {
  return __builtin_ia32_psrlqi128((__v2di)__a, __count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_srl_epi64(__m128i __a,
                                                           __m128i __count) {
  return __builtin_ia32_psrlq128((__v2di)__a, (__v2di)__count);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_epi8(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)((__v16qi)__a == (__v16qi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hi)__a == (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpeq_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v4si)__a == (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_epi8(__m128i __a,
                                                            __m128i __b) {
  return (__m128i)((__v16qs)__a > (__v16qs)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v8hi)__a > (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmpgt_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)((__v4si)__a > (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_epi8(__m128i __a,
                                                            __m128i __b) {
  return _mm_cmpgt_epi8(__b, __a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_epi16(__m128i __a,
                                                             __m128i __b) {
  return _mm_cmpgt_epi16(__b, __a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cmplt_epi32(__m128i __a,
                                                             __m128i __b) {
  return _mm_cmpgt_epi32(__b, __a);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtsi64_sd(__m128d __a, long long __b) {
  __a[0] = __b;
  return __a;
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsd_si64(__m128d __a) {
  return __builtin_ia32_cvtsd2si64((__v2df)__a);
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttsd_si64(__m128d __a) {
  return __builtin_ia32_cvttsd2si64((__v2df)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_cvtepi32_ps(__m128i __a) {
  return (__m128) __builtin_convertvector((__v4si)__a, __v4sf);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtps_epi32(__m128 __a) {
  return (__m128i)__builtin_ia32_cvtps2dq((__v4sf)__a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvttps_epi32(__m128 __a) {
  return (__m128i)__builtin_ia32_cvttps2dq((__v4sf)__a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi32_si128(int __a) {
  return __extension__(__m128i)(__v4si){__a, 0, 0, 0};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi64_si128(long long __a) {
  return __extension__(__m128i)(__v2di){__a, 0};
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi128_si32(__m128i __a) {
  __v4si __b = (__v4si)__a;
  return __b[0];
}
static __inline__ long long __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_cvtsi128_si64(__m128i __a) {
  return __a[0];
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_load_si128(__m128i const *__p) {
  return *__p;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_loadu_si128(__m128i_u const *__p) {
  struct __loadu_si128 {
    __m128i_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __loadu_si128 *)__p)->__v;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_loadl_epi64(__m128i_u const *__p) {
  struct __mm_loadl_epi64_struct {
    long long __u;
  } __attribute__((__packed__, __may_alias__));
  return __extension__(__m128i){
      ((const struct __mm_loadl_epi64_struct *)__p)->__u, 0};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_undefined_si128(void) {
  return (__m128i)__builtin_ia32_undef128();
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi64x(long long __q1, long long __q0) {
  return __extension__(__m128i)(__v2di){__q0, __q1};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi64(__m64 __q1, __m64 __q0) {
  return _mm_set_epi64x((long long)__q1[0], (long long)__q0[0]);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set_epi32(int __i3,
                                                                     int __i2,
                                                                     int __i1,
                                                                     int __i0) {
  return __extension__(__m128i)(__v4si){__i0, __i1, __i2, __i3};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi16(short __w7, short __w6, short __w5, short __w4, short __w3,
              short __w2, short __w1, short __w0) {
  return __extension__(__m128i)(__v8hi){__w0, __w1, __w2, __w3,
                                        __w4, __w5, __w6, __w7};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set_epi8(char __b15, char __b14, char __b13, char __b12, char __b11,
             char __b10, char __b9, char __b8, char __b7, char __b6, char __b5,
             char __b4, char __b3, char __b2, char __b1, char __b0) {
  return __extension__(__m128i)(__v16qi){
      __b0, __b1, __b2, __b3, __b4, __b5, __b6, __b7,
      __b8, __b9, __b10, __b11, __b12, __b13, __b14, __b15};
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_epi64x(long long __q) {
  return _mm_set_epi64x(__q, __q);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_epi64(__m64 __q) {
  return _mm_set_epi64(__q, __q);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set1_epi32(int __i) {
  return _mm_set_epi32(__i, __i, __i, __i);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_set1_epi16(short __w) {
  return _mm_set_epi16(__w, __w, __w, __w, __w, __w, __w, __w);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_set1_epi8(char __b) {
  return _mm_set_epi8(__b, __b, __b, __b, __b, __b, __b, __b, __b, __b, __b,
                      __b, __b, __b, __b, __b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi64(__m64 __q0, __m64 __q1) {
  return _mm_set_epi64(__q1, __q0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi32(int __i0, int __i1, int __i2, int __i3) {
  return _mm_set_epi32(__i3, __i2, __i1, __i0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi16(short __w0, short __w1, short __w2, short __w3, short __w4,
               short __w5, short __w6, short __w7) {
  return _mm_set_epi16(__w7, __w6, __w5, __w4, __w3, __w2, __w1, __w0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_setr_epi8(char __b0, char __b1, char __b2, char __b3, char __b4, char __b5,
              char __b6, char __b7, char __b8, char __b9, char __b10,
              char __b11, char __b12, char __b13, char __b14, char __b15) {
  return _mm_set_epi8(__b15, __b14, __b13, __b12, __b11, __b10, __b9, __b8,
                      __b7, __b6, __b5, __b4, __b3, __b2, __b1, __b0);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_setzero_si128(void) {
  return __extension__(__m128i)(__v2di){0LL, 0LL};
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_store_si128(__m128i *__p,
                                                          __m128i __b) {
  *__p = __b;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si128(__m128i_u *__p,
                                                           __m128i __b) {
  struct __storeu_si128 {
    __m128i_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si128 *)__p)->__v = __b;
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si64(void *__p,
                                                          __m128i __b) {
  struct __storeu_si64 {
    long long __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si64 *)__p)->__v = ((__v2di)__b)[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si32(void *__p,
                                                          __m128i __b) {
  struct __storeu_si32 {
    int __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si32 *)__p)->__v = ((__v4si)__b)[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storeu_si16(void *__p,
                                                          __m128i __b) {
  struct __storeu_si16 {
    short __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __storeu_si16 *)__p)->__v = ((__v8hi)__b)[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_maskmoveu_si128(__m128i __d,
                                                              __m128i __n,
                                                              char *__p) {
  __builtin_ia32_maskmovdqu((__v16qi)__d, (__v16qi)__n, __p);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_storel_epi64(__m128i_u *__p,
                                                           __m128i __a) {
  struct __mm_storel_epi64_struct {
    long long __u;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storel_epi64_struct *)__p)->__u = __a[0];
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_stream_pd(void *__p,
                                                        __m128d __a) {
  __builtin_nontemporal_store((__v2df)__a, (__v2df *)__p);
}
static __inline__ void __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_stream_si128(void *__p,
                                                           __m128i __a) {
  __builtin_nontemporal_store((__v2di)__a, (__v2di *)__p);
}
static __inline__ void
    __attribute__((__always_inline__, __nodebug__, __target__("sse2")))
    _mm_stream_si32(void *__p, int __a) {
  __builtin_ia32_movnti((int *)__p, __a);
}
static __inline__ void
    __attribute__((__always_inline__, __nodebug__, __target__("sse2")))
    _mm_stream_si64(void *__p, long long __a) {
  __builtin_ia32_movnti64((long long *)__p, __a);
}
void _mm_clflush(void const *__p);
void _mm_lfence(void);
void _mm_mfence(void);
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_packs_epi16(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_packsswb128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_packs_epi32(__m128i __a,
                                                             __m128i __b) {
  return (__m128i)__builtin_ia32_packssdw128((__v4si)__a, (__v4si)__b);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_packus_epi16(__m128i __a,
                                                              __m128i __b) {
  return (__m128i)__builtin_ia32_packuswb128((__v8hi)__a, (__v8hi)__b);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_movemask_epi8(__m128i __a) {
  return __builtin_ia32_pmovmskb128((__v16qi)__a);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi8(__m128i __a,
                                                               __m128i __b) {
  return (__m128i)__builtin_shufflevector(
      (__v16qi)__a, (__v16qi)__b, 8, 16 + 8, 9, 16 + 9, 10, 16 + 10, 11,
      16 + 11, 12, 16 + 12, 13, 16 + 13, 14, 16 + 14, 15, 16 + 15);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi16(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v8hi)__a, (__v8hi)__b, 4, 8 + 4, 5,
                                          8 + 5, 6, 8 + 6, 7, 8 + 7);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi32(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v4si)__a, (__v4si)__b, 2, 4 + 2, 3,
                                          4 + 3);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpackhi_epi64(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v2di)__a, (__v2di)__b, 1, 2 + 1);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi8(__m128i __a,
                                                               __m128i __b) {
  return (__m128i)__builtin_shufflevector(
      (__v16qi)__a, (__v16qi)__b, 0, 16 + 0, 1, 16 + 1, 2, 16 + 2, 3, 16 + 3, 4,
      16 + 4, 5, 16 + 5, 6, 16 + 6, 7, 16 + 7);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi16(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v8hi)__a, (__v8hi)__b, 0, 8 + 0, 1,
                                          8 + 1, 2, 8 + 2, 3, 8 + 3);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi32(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v4si)__a, (__v4si)__b, 0, 4 + 0, 1,
                                          4 + 1);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_unpacklo_epi64(__m128i __a,
                                                                __m128i __b) {
  return (__m128i)__builtin_shufflevector((__v2di)__a, (__v2di)__b, 0, 2 + 0);
}
static __inline__ __m64 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_movepi64_pi64(__m128i __a) {
  return (__m64)__a[0];
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_movpi64_epi64(__m64 __a) {
  return __builtin_shufflevector((__v1di)__a, _mm_setzero_si64(), 0, 1);
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_move_epi64(__m128i __a) {
  return __builtin_shufflevector((__v2di)__a, _mm_setzero_si128(), 0, 2);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpackhi_pd(__m128d __a, __m128d __b) {
  return __builtin_shufflevector((__v2df)__a, (__v2df)__b, 1, 2 + 1);
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_unpacklo_pd(__m128d __a, __m128d __b) {
  return __builtin_shufflevector((__v2df)__a, (__v2df)__b, 0, 2 + 0);
}
static __inline__ int __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128))) _mm_movemask_pd(__m128d __a) {
  return __builtin_ia32_movmskpd((__v2df)__a);
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castpd_ps(__m128d __a) {
  return (__m128)__a;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castpd_si128(__m128d __a) {
  return (__m128i)__a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castps_pd(__m128 __a) {
  return (__m128d)__a;
}
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castps_si128(__m128 __a) {
  return (__m128i)__a;
}
static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castsi128_ps(__m128i __a) {
  return (__m128)__a;
}
static __inline__ __m128d __attribute__((__always_inline__, __nodebug__, __target__("sse2"), __min_vector_width__(128)))
_mm_castsi128_pd(__m128i __a) {
  return (__m128d)__a;
}
void _mm_pause(void);
_Alignas(64) static const xxh_u8 XXH3_kSecret[192] = {
    0xb8, 0xfe, 0x6c, 0x39, 0x23, 0xa4, 0x4b, 0xbe, 0x7c, 0x01, 0x81, 0x2c, 0xf7, 0x21, 0xad, 0x1c,
    0xde, 0xd4, 0x6d, 0xe9, 0x83, 0x90, 0x97, 0xdb, 0x72, 0x40, 0xa4, 0xa4, 0xb7, 0xb3, 0x67, 0x1f,
    0xcb, 0x79, 0xe6, 0x4e, 0xcc, 0xc0, 0xe5, 0x78, 0x82, 0x5a, 0xd0, 0x7d, 0xcc, 0xff, 0x72, 0x21,
    0xb8, 0x08, 0x46, 0x74, 0xf7, 0x43, 0x24, 0x8e, 0xe0, 0x35, 0x90, 0xe6, 0x81, 0x3a, 0x26, 0x4c,
    0x3c, 0x28, 0x52, 0xbb, 0x91, 0xc3, 0x00, 0xcb, 0x88, 0xd0, 0x65, 0x8b, 0x1b, 0x53, 0x2e, 0xa3,
    0x71, 0x64, 0x48, 0x97, 0xa2, 0x0d, 0xf9, 0x4e, 0x38, 0x19, 0xef, 0x46, 0xa9, 0xde, 0xac, 0xd8,
    0xa8, 0xfa, 0x76, 0x3f, 0xe3, 0x9c, 0x34, 0x3f, 0xf9, 0xdc, 0xbb, 0xc7, 0xc7, 0x0b, 0x4f, 0x1d,
    0x8a, 0x51, 0xe0, 0x4b, 0xcd, 0xb4, 0x59, 0x31, 0xc8, 0x9f, 0x7e, 0xc9, 0xd9, 0x78, 0x73, 0x64,
    0xea, 0xc5, 0xac, 0x83, 0x34, 0xd3, 0xeb, 0xc3, 0xc5, 0x81, 0xa0, 0xff, 0xfa, 0x13, 0x63, 0xeb,
    0x17, 0x0d, 0xdd, 0x51, 0xb7, 0xf0, 0xda, 0x49, 0xd3, 0x16, 0x55, 0x26, 0x29, 0xd4, 0x68, 0x9e,
    0x2b, 0x16, 0xbe, 0x58, 0x7d, 0x47, 0xa1, 0xfc, 0x8f, 0xf8, 0xb8, 0xd1, 0x7a, 0xd0, 0x31, 0xce,
    0x45, 0xcb, 0x3a, 0x8f, 0x95, 0x16, 0x04, 0x28, 0xaf, 0xd7, 0xfb, 0xca, 0xbb, 0x4b, 0x40, 0x7e,
};
static const xxh_u64 PRIME_MX1 = 0x165667919E3779F9ULL;
static const xxh_u64 PRIME_MX2 = 0x9FB21C651E98DF25ULL;
static XXH_NAMESPACEXXH128_hash_t
XXH_mult64to128(xxh_u64 lhs, xxh_u64 rhs)
{
    __uint128_t const product = (__uint128_t)lhs * (__uint128_t)rhs;
    XXH_NAMESPACEXXH128_hash_t r128;
    r128.low64 = (xxh_u64)(product);
    r128.high64 = (xxh_u64)(product >> 64);
    return r128;
}
static xxh_u64
XXH3_mul128_fold64(xxh_u64 lhs, xxh_u64 rhs)
{
    XXH_NAMESPACEXXH128_hash_t product = XXH_mult64to128(lhs, rhs);
    return product.low64 ^ product.high64;
}
static __attribute__((__unused__)) __attribute__((__const__)) xxh_u64 XXH_xorshift64(xxh_u64 v64, int shift)
{
    __builtin_assume(0 <= shift && shift < 64);
    return v64 ^ (v64 >> shift);
}
static XXH64_hash_t XXH3_avalanche(xxh_u64 h64)
{
    h64 = XXH_xorshift64(h64, 37);
    h64 *= PRIME_MX1;
    h64 = XXH_xorshift64(h64, 32);
    return h64;
}
static XXH64_hash_t XXH3_rrmxmx(xxh_u64 h64, xxh_u64 len)
{
    h64 ^= __builtin_rotateleft64(h64, 49) ^ __builtin_rotateleft64(h64, 24);
    h64 *= PRIME_MX2;
    h64 ^= (h64 >> 35) + len ;
    h64 *= PRIME_MX2;
    return XXH_xorshift64(h64, 28);
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_1to3_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(1 <= len && len <= 3);
    __builtin_assume(secret != ((void*)0));
    { xxh_u8 const c1 = input[0];
        xxh_u8 const c2 = input[len >> 1];
        xxh_u8 const c3 = input[len - 1];
        xxh_u32 const combined = ((xxh_u32)c1 << 16) | ((xxh_u32)c2 << 24)
                               | ((xxh_u32)c3 << 0) | ((xxh_u32)len << 8);
        xxh_u64 const bitflip = (XXH_readLE32(secret) ^ XXH_readLE32(secret+4)) + seed;
        xxh_u64 const keyed = (xxh_u64)combined ^ bitflip;
        return XXH64_avalanche(keyed);
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_4to8_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(4 <= len && len <= 8);
    seed ^= (xxh_u64)XXH_swap32((xxh_u32)seed) << 32;
    { xxh_u32 const input1 = XXH_readLE32(input);
        xxh_u32 const input2 = XXH_readLE32(input + len - 4);
        xxh_u64 const bitflip = (XXH_readLE64(secret+8) ^ XXH_readLE64(secret+16)) - seed;
        xxh_u64 const input64 = input2 + (((xxh_u64)input1) << 32);
        xxh_u64 const keyed = input64 ^ bitflip;
        return XXH3_rrmxmx(keyed, len);
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_9to16_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(9 <= len && len <= 16);
    { xxh_u64 const bitflip1 = (XXH_readLE64(secret+24) ^ XXH_readLE64(secret+32)) + seed;
        xxh_u64 const bitflip2 = (XXH_readLE64(secret+40) ^ XXH_readLE64(secret+48)) - seed;
        xxh_u64 const input_lo = XXH_readLE64(input) ^ bitflip1;
        xxh_u64 const input_hi = XXH_readLE64(input + len - 8) ^ bitflip2;
        xxh_u64 const acc = len
                          + XXH_swap64(input_lo) + input_hi
                          + XXH3_mul128_fold64(input_lo, input_hi);
        return XXH3_avalanche(acc);
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_0to16_64b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(len <= 16);
    { if (__builtin_expect(len > 8, 1)) return XXH3_len_9to16_64b(input, len, secret, seed);
        if (__builtin_expect(len >= 4, 1)) return XXH3_len_4to8_64b(input, len, secret, seed);
        if (len) return XXH3_len_1to3_64b(input, len, secret, seed);
        return XXH64_avalanche(seed ^ (XXH_readLE64(secret+56) ^ XXH_readLE64(secret+64)));
    }
}
static __attribute__((__unused__)) xxh_u64 XXH3_mix16B(const xxh_u8* restrict input,
                                     const xxh_u8* restrict secret, xxh_u64 seed64)
{
    { xxh_u64 const input_lo = XXH_readLE64(input);
        xxh_u64 const input_hi = XXH_readLE64(input+8);
        return XXH3_mul128_fold64(
            input_lo ^ (XXH_readLE64(secret) + seed64),
            input_hi ^ (XXH_readLE64(secret+8) - seed64)
        );
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH64_hash_t
XXH3_len_17to128_64b(const xxh_u8* restrict input, size_t len,
                     const xxh_u8* restrict secret, size_t secretSize,
                     XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(16 < len && len <= 128);
    { xxh_u64 acc = len * 0x9E3779B185EBCA87ULL;
        if (len > 32) {
            if (len > 64) {
                if (len > 96) {
                    acc += XXH3_mix16B(input+48, secret+96, seed);
                    acc += XXH3_mix16B(input+len-64, secret+112, seed);
                }
                acc += XXH3_mix16B(input+32, secret+64, seed);
                acc += XXH3_mix16B(input+len-48, secret+80, seed);
            }
            acc += XXH3_mix16B(input+16, secret+32, seed);
            acc += XXH3_mix16B(input+len-32, secret+48, seed);
        }
        acc += XXH3_mix16B(input+0, secret+0, seed);
        acc += XXH3_mix16B(input+len-16, secret+16, seed);
        return XXH3_avalanche(acc);
    }
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_len_129to240_64b(const xxh_u8* restrict input, size_t len,
                      const xxh_u8* restrict secret, size_t secretSize,
                      XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(128 < len && len <= 240);
    { xxh_u64 acc = len * 0x9E3779B185EBCA87ULL;
        xxh_u64 acc_end;
        unsigned int const nbRounds = (unsigned int)len / 16;
        unsigned int i;
        __builtin_assume(128 < len && len <= 240);
        for (i=0; i<8; i++) {
            acc += XXH3_mix16B(input+(16*i), secret+(16*i), seed);
        }
        acc_end = XXH3_mix16B(input + len - 16, secret + 136 - 17, seed);
        __builtin_assume(nbRounds >= 8);
        acc = XXH3_avalanche(acc);
        for (i=8 ; i < nbRounds; i++) {
            __asm__("" : "+r" (acc));
            acc_end += XXH3_mix16B(input+(16*i), secret+(16*(i-8)) + 3, seed);
        }
        return XXH3_avalanche(acc + acc_end);
    }
}
static __attribute__((__unused__)) void XXH_writeLE64(void* dst, xxh_u64 v64)
{
    if (!1) v64 = XXH_swap64(v64);
    memcpy(dst, &v64, sizeof(v64));
}
    typedef int64_t xxh_i64;
static __attribute__((__unused__)) void
XXH3_accumulate_512_sse2( void* restrict acc,
                    const void* restrict input,
                    const void* restrict secret)
{
    __builtin_assume((((size_t)acc) & 15) == 0);
    { __m128i* const xacc = (__m128i *) acc;
        const __m128i* const xinput = (const __m128i *) input;
        const __m128i* const xsecret = (const __m128i *) secret;
        size_t i;
        for (i=0; i < 64/sizeof(__m128i); i++) {
            __m128i const data_vec = _mm_loadu_si128 (xinput+i);
            __m128i const key_vec = _mm_loadu_si128 (xsecret+i);
            __m128i const data_key = _mm_xor_si128 (data_vec, key_vec);
            __m128i const data_key_lo = ((__m128i)__builtin_ia32_pshufd((__v4si)(__m128i)(data_key), (int)((((0) << 6) | ((3) << 4) | ((0) << 2) | (1)))));
            __m128i const product = _mm_mul_epu32 (data_key, data_key_lo);
            __m128i const data_swap = ((__m128i)__builtin_ia32_pshufd((__v4si)(__m128i)(data_vec), (int)((((1) << 6) | ((0) << 4) | ((3) << 2) | (2)))));
            __m128i const sum = _mm_add_epi64(xacc[i], data_swap);
            xacc[i] = _mm_add_epi64(product, sum);
    } }
}
static __attribute__((__unused__)) void XXH3_accumulate_sse2(xxh_u64* restrict acc, const xxh_u8* restrict input, const xxh_u8* restrict secret, size_t nbStripes) { size_t n; for (n = 0; n < nbStripes; n++ ) { const xxh_u8* const in = input + n*64; __builtin_prefetch((in + 320), 0 , 3 ); XXH3_accumulate_512_sse2( acc, in, secret + n*8); } }
static __attribute__((__unused__)) void
XXH3_scrambleAcc_sse2(void* restrict acc, const void* restrict secret)
{
    __builtin_assume((((size_t)acc) & 15) == 0);
    { __m128i* const xacc = (__m128i*) acc;
        const __m128i* const xsecret = (const __m128i *) secret;
        const __m128i prime32 = _mm_set1_epi32((int)0x9E3779B1U);
        size_t i;
        for (i=0; i < 64/sizeof(__m128i); i++) {
            __m128i const acc_vec = xacc[i];
            __m128i const shifted = _mm_srli_epi64 (acc_vec, 47);
            __m128i const data_vec = _mm_xor_si128 (acc_vec, shifted);
            __m128i const key_vec = _mm_loadu_si128 (xsecret+i);
            __m128i const data_key = _mm_xor_si128 (data_vec, key_vec);
            __m128i const data_key_hi = ((__m128i)__builtin_ia32_pshufd((__v4si)(__m128i)(data_key), (int)((((0) << 6) | ((3) << 4) | ((0) << 2) | (1)))));
            __m128i const prod_lo = _mm_mul_epu32 (data_key, prime32);
            __m128i const prod_hi = _mm_mul_epu32 (data_key_hi, prime32);
            xacc[i] = _mm_add_epi64(prod_lo, _mm_slli_epi64(prod_hi, 32));
        }
    }
}
static __attribute__((__unused__)) void XXH3_initCustomSecret_sse2(void* restrict customSecret, xxh_u64 seed64)
{
    do { _Static_assert((((192 & 15) == 0)),"(XXH_SECRET_DEFAULT_SIZE & 15) == 0"); } while(0);
    (void)(&XXH_writeLE64);
    { int const nbRounds = 192 / sizeof(__m128i);
        __m128i const seed = _mm_set_epi64x((xxh_i64)(0U - seed64), (xxh_i64)seed64);
        int i;
        const void* const src16 = XXH3_kSecret;
        __m128i* dst16 = (__m128i*) customSecret;
        __asm__("" : "+r" (dst16));
        __builtin_assume(((size_t)src16 & 15) == 0);
        __builtin_assume(((size_t)dst16 & 15) == 0);
        for (i=0; i < nbRounds; ++i) {
            dst16[i] = _mm_add_epi64(_mm_load_si128((const __m128i *)src16+i), seed);
    } }
}
static __attribute__((__unused__)) xxh_u64
XXH_mult32to64_add64(xxh_u64 lhs, xxh_u64 rhs, xxh_u64 acc)
{
    return ((xxh_u64)(xxh_u32)((xxh_u32)lhs) * (xxh_u64)(xxh_u32)((xxh_u32)rhs)) + acc;
}
static __attribute__((__unused__)) void
XXH3_scalarRound(void* restrict acc,
                 void const* restrict input,
                 void const* restrict secret,
                 size_t lane)
{
    xxh_u64* xacc = (xxh_u64*) acc;
    xxh_u8 const* xinput = (xxh_u8 const*) input;
    xxh_u8 const* xsecret = (xxh_u8 const*) secret;
    __builtin_assume(lane < (64 / sizeof(xxh_u64)));
    __builtin_assume(((size_t)acc & (16 -1)) == 0);
    {
        xxh_u64 const data_val = XXH_readLE64(xinput + lane * 8);
        xxh_u64 const data_key = data_val ^ XXH_readLE64(xsecret + lane * 8);
        xacc[lane ^ 1] += data_val;
        xacc[lane] = XXH_mult32to64_add64(data_key , data_key >> 32, xacc[lane]);
    }
}
static __attribute__((__unused__)) void
XXH3_accumulate_512_scalar(void* restrict acc,
                     const void* restrict input,
                     const void* restrict secret)
{
    size_t i;
    for (i=0; i < (64 / sizeof(xxh_u64)); i++) {
        XXH3_scalarRound(acc, input, secret, i);
    }
}
static __attribute__((__unused__)) void XXH3_accumulate_scalar(xxh_u64* restrict acc, const xxh_u8* restrict input, const xxh_u8* restrict secret, size_t nbStripes) { size_t n; for (n = 0; n < nbStripes; n++ ) { const xxh_u8* const in = input + n*64; __builtin_prefetch((in + 320), 0 , 3 ); XXH3_accumulate_512_scalar( acc, in, secret + n*8); } }
static __attribute__((__unused__)) void
XXH3_scalarScrambleRound(void* restrict acc,
                         void const* restrict secret,
                         size_t lane)
{
    xxh_u64* const xacc = (xxh_u64*) acc;
    const xxh_u8* const xsecret = (const xxh_u8*) secret;
    __builtin_assume((((size_t)acc) & (16 -1)) == 0);
    __builtin_assume(lane < (64 / sizeof(xxh_u64)));
    {
        xxh_u64 const key64 = XXH_readLE64(xsecret + lane * 8);
        xxh_u64 acc64 = xacc[lane];
        acc64 = XXH_xorshift64(acc64, 47);
        acc64 ^= key64;
        acc64 *= 0x9E3779B1U;
        xacc[lane] = acc64;
    }
}
static __attribute__((__unused__)) void
XXH3_scrambleAcc_scalar(void* restrict acc, const void* restrict secret)
{
    size_t i;
    for (i=0; i < (64 / sizeof(xxh_u64)); i++) {
        XXH3_scalarScrambleRound(acc, secret, i);
    }
}
static __attribute__((__unused__)) void
XXH3_initCustomSecret_scalar(void* restrict customSecret, xxh_u64 seed64)
{
    const xxh_u8* kSecretPtr = XXH3_kSecret;
    do { _Static_assert((((192 & 15) == 0)),"(XXH_SECRET_DEFAULT_SIZE & 15) == 0"); } while(0);
    { int const nbRounds = 192 / 16;
        int i;
        for (i=0; i < nbRounds; i++) {
            xxh_u64 lo = XXH_readLE64(kSecretPtr + 16*i) + seed64;
            xxh_u64 hi = XXH_readLE64(kSecretPtr + 16*i + 8) - seed64;
            XXH_writeLE64((xxh_u8*)customSecret + 16*i, lo);
            XXH_writeLE64((xxh_u8*)customSecret + 16*i + 8, hi);
    } }
}
typedef void (*XXH3_f_accumulate)(xxh_u64* restrict, const xxh_u8* restrict, const xxh_u8* restrict, size_t);
typedef void (*XXH3_f_scrambleAcc)(void* restrict, const void*);
typedef void (*XXH3_f_initCustomSecret)(void* restrict, xxh_u64);
static __attribute__((__unused__)) void
XXH3_hashLong_internal_loop(xxh_u64* restrict acc,
                      const xxh_u8* restrict input, size_t len,
                      const xxh_u8* restrict secret, size_t secretSize,
                            XXH3_f_accumulate f_acc,
                            XXH3_f_scrambleAcc f_scramble)
{
    size_t const nbStripesPerBlock = (secretSize - 64) / 8;
    size_t const block_len = 64 * nbStripesPerBlock;
    size_t const nb_blocks = (len - 1) / block_len;
    size_t n;
    __builtin_assume(secretSize >= 136);
    for (n = 0; n < nb_blocks; n++) {
        f_acc(acc, input + n*block_len, secret, nbStripesPerBlock);
        f_scramble(acc, secret + secretSize - 64);
    }
    __builtin_assume(len > 64);
    { size_t const nbStripes = ((len - 1) - (block_len * nb_blocks)) / 64;
        __builtin_assume(nbStripes <= (secretSize / 8));
        f_acc(acc, input + nb_blocks*block_len, secret, nbStripes);
        { const xxh_u8* const p = input + len - 64;
            XXH3_accumulate_512_sse2(acc, p, secret + secretSize - 64 - 7);
    } }
}
static __attribute__((__unused__)) xxh_u64
XXH3_mix2Accs(const xxh_u64* restrict acc, const xxh_u8* restrict secret)
{
    return XXH3_mul128_fold64(
               acc[0] ^ XXH_readLE64(secret),
               acc[1] ^ XXH_readLE64(secret+8) );
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_mergeAccs(const xxh_u64* restrict acc, const xxh_u8* restrict secret, xxh_u64 start)
{
    xxh_u64 result64 = start;
    size_t i = 0;
    for (i = 0; i < 4; i++) {
        result64 += XXH3_mix2Accs(acc+2*i, secret + 16*i);
    }
    return XXH3_avalanche(result64);
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_finalizeLong_64b(const xxh_u64* restrict acc, const xxh_u8* restrict secret, xxh_u64 len)
{
    return XXH3_mergeAccs(acc, secret + 11, len * 0x9E3779B185EBCA87ULL);
}
static __attribute__((__unused__)) XXH64_hash_t
XXH3_hashLong_64b_internal(const void* restrict input, size_t len,
                           const void* restrict secret, size_t secretSize,
                           XXH3_f_accumulate f_acc,
                           XXH3_f_scrambleAcc f_scramble)
{
    _Alignas(16) xxh_u64 acc[(64 / sizeof(xxh_u64))] = { 0xC2B2AE3DU, 0x9E3779B185EBCA87ULL, 0xC2B2AE3D27D4EB4FULL, 0x165667B19E3779F9ULL, 0x85EBCA77C2B2AE63ULL, 0x85EBCA77U, 0x27D4EB2F165667C5ULL, 0x9E3779B1U };
    XXH3_hashLong_internal_loop(acc, (const xxh_u8*)input, len, (const xxh_u8*)secret, secretSize, f_acc, f_scramble);
    do { _Static_assert(((sizeof(acc) == 64)),"sizeof(acc) == 64"); } while(0);
    __builtin_assume(secretSize >= sizeof(acc) + 11);
    return XXH3_finalizeLong_64b(acc, (const xxh_u8*)secret, (xxh_u64)len);
}
static __attribute__((__unused__)) XXH64_hash_t
XXH3_hashLong_64b_withSecret(const void* restrict input, size_t len,
                             XXH64_hash_t seed64, const xxh_u8* restrict secret, size_t secretLen)
{
    (void)seed64;
    return XXH3_hashLong_64b_internal(input, len, secret, secretLen, XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__pure__)) XXH64_hash_t
XXH3_hashLong_64b_default(const void* restrict input, size_t len,
                          XXH64_hash_t seed64, const xxh_u8* restrict secret, size_t secretLen)
{
    (void)seed64; (void)secret; (void)secretLen;
    return XXH3_hashLong_64b_internal(input, len, XXH3_kSecret, sizeof(XXH3_kSecret), XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__unused__)) XXH64_hash_t
XXH3_hashLong_64b_withSeed_internal(const void* input, size_t len,
                                    XXH64_hash_t seed,
                                    XXH3_f_accumulate f_acc,
                                    XXH3_f_scrambleAcc f_scramble,
                                    XXH3_f_initCustomSecret f_initSec)
{
    if (seed == 0)
        return XXH3_hashLong_64b_internal(input, len,
                                          XXH3_kSecret, sizeof(XXH3_kSecret),
                                          f_acc, f_scramble);
    { _Alignas(16) xxh_u8 secret[192];
        f_initSec(secret, seed);
        return XXH3_hashLong_64b_internal(input, len, secret, sizeof(secret),
                                          f_acc, f_scramble);
    }
}
static XXH64_hash_t
XXH3_hashLong_64b_withSeed(const void* restrict input, size_t len,
                           XXH64_hash_t seed, const xxh_u8* restrict secret, size_t secretLen)
{
    (void)secret; (void)secretLen;
    return XXH3_hashLong_64b_withSeed_internal(input, len, seed,
                XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2, XXH3_initCustomSecret_sse2);
}
typedef XXH64_hash_t (*XXH3_hashLong64_f)(const void* restrict, size_t,
                                          XXH64_hash_t, const xxh_u8* restrict, size_t);
static __attribute__((__unused__)) XXH64_hash_t
XXH3_64bits_internal(const void* restrict input, size_t len,
                     XXH64_hash_t seed64, const void* restrict secret, size_t secretLen,
                     XXH3_hashLong64_f f_hashLong)
{
    __builtin_assume(secretLen >= 136);
    if (len <= 16)
        return XXH3_len_0to16_64b((const xxh_u8*)input, len, (const xxh_u8*)secret, seed64);
    if (len <= 128)
        return XXH3_len_17to128_64b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    if (len <= 240)
        return XXH3_len_129to240_64b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    return f_hashLong(input, len, seed64, (const xxh_u8*)secret, secretLen);
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH3_64bits(__attribute__((__noescape__)) const void* input, size_t length)
{
    return XXH3_64bits_internal(input, length, 0, XXH3_kSecret, sizeof(XXH3_kSecret), XXH3_hashLong_64b_default);
}
static __inline __attribute__((__unused__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSecret(__attribute__((__noescape__)) const void* input, size_t length, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    return XXH3_64bits_internal(input, length, 0, secret, secretSize, XXH3_hashLong_64b_withSecret);
}
static __inline __attribute__((__unused__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSeed(__attribute__((__noescape__)) const void* input, size_t length, XXH64_hash_t seed)
{
    return XXH3_64bits_internal(input, length, seed, XXH3_kSecret, sizeof(XXH3_kSecret), XXH3_hashLong_64b_withSeed);
}
static __inline __attribute__((__unused__)) XXH64_hash_t
XXH_INLINE_XXH3_64bits_withSecretandSeed(__attribute__((__noescape__)) const void* input, size_t length, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed)
{
    if (length <= 240)
        return XXH3_64bits_internal(input, length, seed, XXH3_kSecret, sizeof(XXH3_kSecret), ((void*)0));
    return XXH3_hashLong_64b_withSecret(input, length, seed, (const xxh_u8*)secret, secretSize);
}
static __attribute__((__malloc__)) void* XXH_alignedMalloc(size_t s, size_t align)
{
    __builtin_assume(align <= 128 && align >= 8);
    __builtin_assume((align & (align-1)) == 0);
    __builtin_assume(s != 0 && s < (s + align));
    {
        xxh_u8* base = (xxh_u8*)XXH_malloc(s + align);
        if (base != ((void*)0)) {
            size_t offset = align - ((size_t)base & (align - 1));
            xxh_u8* ptr = base + offset;
            __builtin_assume((size_t)ptr % align == 0);
            ptr[-1] = (xxh_u8)offset;
            return ptr;
        }
        return ((void*)0);
    }
}
static void XXH_alignedFree(void* p)
{
    if (p != ((void*)0)) {
        xxh_u8* ptr = (xxh_u8*)p;
        xxh_u8 offset = ptr[-1];
        xxh_u8* base = ptr - offset;
        XXH_free(base);
    }
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH3_state_t* XXH_INLINE_XXH3_createState(void)
{
    XXH_NAMESPACEXXH3_state_t* const state = (XXH_NAMESPACEXXH3_state_t*)XXH_alignedMalloc(sizeof(XXH_NAMESPACEXXH3_state_t), 64);
    if (state==((void*)0)) return ((void*)0);
    do { XXH_NAMESPACEXXH3_state_t* tmp_xxh3_state_ptr = (state); tmp_xxh3_state_ptr->seed = 0; tmp_xxh3_state_ptr->extSecret = ((void*)0); } while(0);
    return state;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode XXH_INLINE_XXH3_freeState(XXH_NAMESPACEXXH3_state_t* statePtr)
{
    XXH_alignedFree(statePtr);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void
XXH_INLINE_XXH3_copyState(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* dst_state, __attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* src_state)
{
    memcpy(dst_state, src_state, sizeof(*dst_state));
}
static void
XXH3_reset_internal(XXH_NAMESPACEXXH3_state_t* statePtr,
                    XXH64_hash_t seed,
                    const void* secret, size_t secretSize)
{
    size_t const initStart = __builtin_offsetof(XXH_NAMESPACEXXH3_state_t, bufferedSize);
    size_t const initLength = __builtin_offsetof(XXH_NAMESPACEXXH3_state_t, nbStripesPerBlock) - initStart;
    __builtin_assume(__builtin_offsetof(XXH_NAMESPACEXXH3_state_t, nbStripesPerBlock) > initStart);
    __builtin_assume(statePtr != ((void*)0));
    memset((char*)statePtr + initStart, 0, initLength);
    statePtr->acc[0] = 0xC2B2AE3DU;
    statePtr->acc[1] = 0x9E3779B185EBCA87ULL;
    statePtr->acc[2] = 0xC2B2AE3D27D4EB4FULL;
    statePtr->acc[3] = 0x165667B19E3779F9ULL;
    statePtr->acc[4] = 0x85EBCA77C2B2AE63ULL;
    statePtr->acc[5] = 0x85EBCA77U;
    statePtr->acc[6] = 0x27D4EB2F165667C5ULL;
    statePtr->acc[7] = 0x9E3779B1U;
    statePtr->seed = seed;
    statePtr->useSeed = (seed != 0);
    statePtr->extSecret = (const unsigned char*)secret;
    __builtin_assume(secretSize >= 136);
    statePtr->secretLimit = secretSize - 64;
    statePtr->nbStripesPerBlock = statePtr->secretLimit / 8;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    XXH3_reset_internal(statePtr, 0, XXH3_kSecret, 192);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    XXH3_reset_internal(statePtr, 0, secret, secretSize);
    if (secret == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secretSize < 136) return XXH_NAMESPACEXXH_ERROR;
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (seed==0) return XXH_INLINE_XXH3_64bits_reset(statePtr);
    if ((seed != statePtr->seed) || (statePtr->extSecret != ((void*)0)))
        XXH3_initCustomSecret_sse2(statePtr->customSecret, seed);
    XXH3_reset_internal(statePtr, seed, ((void*)0), 192);
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed64)
{
    if (statePtr == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secret == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secretSize < 136) return XXH_NAMESPACEXXH_ERROR;
    XXH3_reset_internal(statePtr, seed64, secret, secretSize);
    statePtr->useSeed = 1;
    return XXH_NAMESPACEXXH_OK;
}
static __attribute__((__unused__)) const xxh_u8 *
XXH3_consumeStripes(xxh_u64* restrict acc,
                    size_t* restrict nbStripesSoFarPtr, size_t nbStripesPerBlock,
                    const xxh_u8* restrict input, size_t nbStripes,
                    const xxh_u8* restrict secret, size_t secretLimit,
                    XXH3_f_accumulate f_acc,
                    XXH3_f_scrambleAcc f_scramble)
{
    const xxh_u8* initialSecret = secret + *nbStripesSoFarPtr * 8;
    if (nbStripes >= (nbStripesPerBlock - *nbStripesSoFarPtr)) {
        size_t nbStripesThisIter = nbStripesPerBlock - *nbStripesSoFarPtr;
        do {
            f_acc(acc, input, initialSecret, nbStripesThisIter);
            f_scramble(acc, secret + secretLimit);
            input += nbStripesThisIter * 64;
            nbStripes -= nbStripesThisIter;
            nbStripesThisIter = nbStripesPerBlock;
            initialSecret = secret;
        } while (nbStripes >= nbStripesPerBlock);
        *nbStripesSoFarPtr = 0;
    }
    if (nbStripes > 0) {
        f_acc(acc, input, initialSecret, nbStripes);
        input += nbStripes * 64;
        *nbStripesSoFarPtr += nbStripes;
    }
    return input;
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH3_update(XXH_NAMESPACEXXH3_state_t* restrict const state,
            const xxh_u8* restrict input, size_t len,
            XXH3_f_accumulate f_acc,
            XXH3_f_scrambleAcc f_scramble)
{
    if (input==((void*)0)) {
        __builtin_assume(len == 0);
        return XXH_NAMESPACEXXH_OK;
    }
    __builtin_assume(state != ((void*)0));
    { const xxh_u8* const bEnd = input + len;
        const unsigned char* const secret = (state->extSecret == ((void*)0)) ? state->customSecret : state->extSecret;
        xxh_u64* restrict const acc = state->acc;
        state->totalLen += len;
        __builtin_assume(state->bufferedSize <= 256);
        if (len <= 256 - state->bufferedSize) {
            memcpy(state->buffer + state->bufferedSize, input, len);
            state->bufferedSize += (XXH32_hash_t)len;
            return XXH_NAMESPACEXXH_OK;
        }
        do { _Static_assert(((256 % 64 == 0)),"XXH3_INTERNALBUFFER_SIZE % XXH_STRIPE_LEN == 0"); } while(0);
        if (state->bufferedSize) {
            size_t const loadSize = 256 - state->bufferedSize;
            memcpy(state->buffer + state->bufferedSize, input, loadSize);
            input += loadSize;
            XXH3_consumeStripes(acc,
                               &state->nbStripesSoFar, state->nbStripesPerBlock,
                                state->buffer, (256 / 64),
                                secret, state->secretLimit,
                                f_acc, f_scramble);
            state->bufferedSize = 0;
        }
        __builtin_assume(input < bEnd);
        if (bEnd - input > 256) {
            size_t nbStripes = (size_t)(bEnd - 1 - input) / 64;
            input = XXH3_consumeStripes(acc,
                                       &state->nbStripesSoFar, state->nbStripesPerBlock,
                                       input, nbStripes,
                                       secret, state->secretLimit,
                                       f_acc, f_scramble);
            memcpy(state->buffer + sizeof(state->buffer) - 64, input - 64, 64);
        }
        __builtin_assume(input < bEnd);
        __builtin_assume(bEnd - input <= 256);
        __builtin_assume(state->bufferedSize == 0);
        memcpy(state->buffer, input, (size_t)(bEnd-input));
        state->bufferedSize = (XXH32_hash_t)(bEnd-input);
    }
    return XXH_NAMESPACEXXH_OK;
}
static XXH_NAMESPACEXXH_errorcode
XXH3_update_regular(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_update(state, (const xxh_u8*)input, len,
                       XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_64bits_update(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_update_regular(state, input, len);
}
static __attribute__((__unused__)) void
XXH3_digest_long (XXH64_hash_t* acc,
                  const XXH_NAMESPACEXXH3_state_t* state,
                  const unsigned char* secret)
{
    xxh_u8 lastStripe[64];
    const xxh_u8* lastStripePtr;
    memcpy(acc, state->acc, sizeof(state->acc));
    if (state->bufferedSize >= 64) {
        size_t const nbStripes = (state->bufferedSize - 1) / 64;
        size_t nbStripesSoFar = state->nbStripesSoFar;
        XXH3_consumeStripes(acc,
                           &nbStripesSoFar, state->nbStripesPerBlock,
                            state->buffer, nbStripes,
                            secret, state->secretLimit,
                            XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
        lastStripePtr = state->buffer + state->bufferedSize - 64;
    } else {
        size_t const catchupSize = 64 - state->bufferedSize;
        __builtin_assume(state->bufferedSize > 0);
        memcpy(lastStripe, state->buffer + sizeof(state->buffer) - catchupSize, catchupSize);
        memcpy(lastStripe + catchupSize, state->buffer, state->bufferedSize);
        lastStripePtr = lastStripe;
    }
    XXH3_accumulate_512_sse2(acc,
                        lastStripePtr,
                        secret + state->secretLimit - 7);
}
static __inline __attribute__((__unused__)) XXH64_hash_t XXH_INLINE_XXH3_64bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* state)
{
    const unsigned char* const secret = (state->extSecret == ((void*)0)) ? state->customSecret : state->extSecret;
    if (state->totalLen > 240) {
        _Alignas(16) XXH64_hash_t acc[(64 / sizeof(xxh_u64))];
        XXH3_digest_long(acc, state, secret);
        return XXH3_finalizeLong_64b(acc, secret, (xxh_u64)state->totalLen);
    }
    if (state->useSeed)
        return XXH_INLINE_XXH3_64bits_withSeed(state->buffer, (size_t)state->totalLen, state->seed);
    return XXH_INLINE_XXH3_64bits_withSecret(state->buffer, (size_t)(state->totalLen),
                                  secret, state->secretLimit + 64);
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_1to3_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(1 <= len && len <= 3);
    __builtin_assume(secret != ((void*)0));
    { xxh_u8 const c1 = input[0];
        xxh_u8 const c2 = input[len >> 1];
        xxh_u8 const c3 = input[len - 1];
        xxh_u32 const combinedl = ((xxh_u32)c1 <<16) | ((xxh_u32)c2 << 24)
                                | ((xxh_u32)c3 << 0) | ((xxh_u32)len << 8);
        xxh_u32 const combinedh = __builtin_rotateleft32(XXH_swap32(combinedl), 13);
        xxh_u64 const bitflipl = (XXH_readLE32(secret) ^ XXH_readLE32(secret+4)) + seed;
        xxh_u64 const bitfliph = (XXH_readLE32(secret+8) ^ XXH_readLE32(secret+12)) - seed;
        xxh_u64 const keyed_lo = (xxh_u64)combinedl ^ bitflipl;
        xxh_u64 const keyed_hi = (xxh_u64)combinedh ^ bitfliph;
        XXH_NAMESPACEXXH128_hash_t h128;
        h128.low64 = XXH64_avalanche(keyed_lo);
        h128.high64 = XXH64_avalanche(keyed_hi);
        return h128;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_4to8_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(4 <= len && len <= 8);
    seed ^= (xxh_u64)XXH_swap32((xxh_u32)seed) << 32;
    { xxh_u32 const input_lo = XXH_readLE32(input);
        xxh_u32 const input_hi = XXH_readLE32(input + len - 4);
        xxh_u64 const input_64 = input_lo + ((xxh_u64)input_hi << 32);
        xxh_u64 const bitflip = (XXH_readLE64(secret+16) ^ XXH_readLE64(secret+24)) + seed;
        xxh_u64 const keyed = input_64 ^ bitflip;
        XXH_NAMESPACEXXH128_hash_t m128 = XXH_mult64to128(keyed, 0x9E3779B185EBCA87ULL + (len << 2));
        m128.high64 += (m128.low64 << 1);
        m128.low64 ^= (m128.high64 >> 3);
        m128.low64 = XXH_xorshift64(m128.low64, 35);
        m128.low64 *= PRIME_MX2;
        m128.low64 = XXH_xorshift64(m128.low64, 28);
        m128.high64 = XXH3_avalanche(m128.high64);
        return m128;
    }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_9to16_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(input != ((void*)0));
    __builtin_assume(secret != ((void*)0));
    __builtin_assume(9 <= len && len <= 16);
    { xxh_u64 const bitflipl = (XXH_readLE64(secret+32) ^ XXH_readLE64(secret+40)) - seed;
        xxh_u64 const bitfliph = (XXH_readLE64(secret+48) ^ XXH_readLE64(secret+56)) + seed;
        xxh_u64 const input_lo = XXH_readLE64(input);
        xxh_u64 input_hi = XXH_readLE64(input + len - 8);
        XXH_NAMESPACEXXH128_hash_t m128 = XXH_mult64to128(input_lo ^ input_hi ^ bitflipl, 0x9E3779B185EBCA87ULL);
        m128.low64 += (xxh_u64)(len - 1) << 54;
        input_hi ^= bitfliph;
        if (sizeof(void *) < sizeof(xxh_u64)) {
            m128.high64 += (input_hi & 0xFFFFFFFF00000000ULL) + ((xxh_u64)(xxh_u32)((xxh_u32)input_hi) * (xxh_u64)(xxh_u32)(0x85EBCA77U));
        } else {
            m128.high64 += input_hi + ((xxh_u64)(xxh_u32)((xxh_u32)input_hi) * (xxh_u64)(xxh_u32)(0x85EBCA77U - 1));
        }
        m128.low64 ^= XXH_swap64(m128.high64);
        {
            XXH_NAMESPACEXXH128_hash_t h128 = XXH_mult64to128(m128.low64, 0xC2B2AE3D27D4EB4FULL);
            h128.high64 += m128.high64 * 0xC2B2AE3D27D4EB4FULL;
            h128.low64 = XXH3_avalanche(h128.low64);
            h128.high64 = XXH3_avalanche(h128.high64);
            return h128;
    } }
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_0to16_128b(const xxh_u8* input, size_t len, const xxh_u8* secret, XXH64_hash_t seed)
{
    __builtin_assume(len <= 16);
    { if (len > 8) return XXH3_len_9to16_128b(input, len, secret, seed);
        if (len >= 4) return XXH3_len_4to8_128b(input, len, secret, seed);
        if (len) return XXH3_len_1to3_128b(input, len, secret, seed);
        { XXH_NAMESPACEXXH128_hash_t h128;
            xxh_u64 const bitflipl = XXH_readLE64(secret+64) ^ XXH_readLE64(secret+72);
            xxh_u64 const bitfliph = XXH_readLE64(secret+80) ^ XXH_readLE64(secret+88);
            h128.low64 = XXH64_avalanche(seed ^ bitflipl);
            h128.high64 = XXH64_avalanche( seed ^ bitfliph);
            return h128;
    } }
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH128_mix32B(XXH_NAMESPACEXXH128_hash_t acc, const xxh_u8* input_1, const xxh_u8* input_2,
              const xxh_u8* secret, XXH64_hash_t seed)
{
    acc.low64 += XXH3_mix16B (input_1, secret+0, seed);
    acc.low64 ^= XXH_readLE64(input_2) + XXH_readLE64(input_2 + 8);
    acc.high64 += XXH3_mix16B (input_2, secret+16, seed);
    acc.high64 ^= XXH_readLE64(input_1) + XXH_readLE64(input_1 + 8);
    return acc;
}
static __attribute__((__unused__)) __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_17to128_128b(const xxh_u8* restrict input, size_t len,
                      const xxh_u8* restrict secret, size_t secretSize,
                      XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(16 < len && len <= 128);
    { XXH_NAMESPACEXXH128_hash_t acc;
        acc.low64 = len * 0x9E3779B185EBCA87ULL;
        acc.high64 = 0;
        if (len > 32) {
            if (len > 64) {
                if (len > 96) {
                    acc = XXH128_mix32B(acc, input+48, input+len-64, secret+96, seed);
                }
                acc = XXH128_mix32B(acc, input+32, input+len-48, secret+64, seed);
            }
            acc = XXH128_mix32B(acc, input+16, input+len-32, secret+32, seed);
        }
        acc = XXH128_mix32B(acc, input, input+len-16, secret, seed);
        { XXH_NAMESPACEXXH128_hash_t h128;
            h128.low64 = acc.low64 + acc.high64;
            h128.high64 = (acc.low64 * 0x9E3779B185EBCA87ULL)
                        + (acc.high64 * 0x85EBCA77C2B2AE63ULL)
                        + ((len - seed) * 0xC2B2AE3D27D4EB4FULL);
            h128.low64 = XXH3_avalanche(h128.low64);
            h128.high64 = (XXH64_hash_t)0 - XXH3_avalanche(h128.high64);
            return h128;
        }
    }
}
static __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_len_129to240_128b(const xxh_u8* restrict input, size_t len,
                       const xxh_u8* restrict secret, size_t secretSize,
                       XXH64_hash_t seed)
{
    __builtin_assume(secretSize >= 136); (void)secretSize;
    __builtin_assume(128 < len && len <= 240);
    { XXH_NAMESPACEXXH128_hash_t acc;
        unsigned i;
        acc.low64 = len * 0x9E3779B185EBCA87ULL;
        acc.high64 = 0;
        for (i = 32; i < 160; i += 32) {
            acc = XXH128_mix32B(acc,
                                input + i - 32,
                                input + i - 16,
                                secret + i - 32,
                                seed);
        }
        acc.low64 = XXH3_avalanche(acc.low64);
        acc.high64 = XXH3_avalanche(acc.high64);
        for (i=160; i <= len; i += 32) {
            acc = XXH128_mix32B(acc,
                                input + i - 32,
                                input + i - 16,
                                secret + 3 + i - 160,
                                seed);
        }
        acc = XXH128_mix32B(acc,
                            input + len - 16,
                            input + len - 32,
                            secret + 136 - 17 - 16,
                            (XXH64_hash_t)0 - seed);
        { XXH_NAMESPACEXXH128_hash_t h128;
            h128.low64 = acc.low64 + acc.high64;
            h128.high64 = (acc.low64 * 0x9E3779B185EBCA87ULL)
                        + (acc.high64 * 0x85EBCA77C2B2AE63ULL)
                        + ((len - seed) * 0xC2B2AE3D27D4EB4FULL);
            h128.low64 = XXH3_avalanche(h128.low64);
            h128.high64 = (XXH64_hash_t)0 - XXH3_avalanche(h128.high64);
            return h128;
        }
    }
}
static __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_finalizeLong_128b(const xxh_u64* restrict acc, const xxh_u8* restrict secret, size_t secretSize, xxh_u64 len)
{
    XXH_NAMESPACEXXH128_hash_t h128;
    h128.low64 = XXH3_finalizeLong_64b(acc, secret, len);
    h128.high64 = XXH3_mergeAccs(acc, secret + secretSize
                                             - 64 - 11,
                                             ~(len * 0xC2B2AE3D27D4EB4FULL));
    return h128;
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_internal(const void* restrict input, size_t len,
                            const xxh_u8* restrict secret, size_t secretSize,
                            XXH3_f_accumulate f_acc,
                            XXH3_f_scrambleAcc f_scramble)
{
    _Alignas(16) xxh_u64 acc[(64 / sizeof(xxh_u64))] = { 0xC2B2AE3DU, 0x9E3779B185EBCA87ULL, 0xC2B2AE3D27D4EB4FULL, 0x165667B19E3779F9ULL, 0x85EBCA77C2B2AE63ULL, 0x85EBCA77U, 0x27D4EB2F165667C5ULL, 0x9E3779B1U };
    XXH3_hashLong_internal_loop(acc, (const xxh_u8*)input, len, secret, secretSize, f_acc, f_scramble);
    do { _Static_assert(((sizeof(acc) == 64)),"sizeof(acc) == 64"); } while(0);
    __builtin_assume(secretSize >= sizeof(acc) + 11);
    return XXH3_finalizeLong_128b(acc, secret, secretSize, (xxh_u64)len);
}
static __attribute__((__pure__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_default(const void* restrict input, size_t len,
                           XXH64_hash_t seed64,
                           const void* restrict secret, size_t secretLen)
{
    (void)seed64; (void)secret; (void)secretLen;
    return XXH3_hashLong_128b_internal(input, len, XXH3_kSecret, sizeof(XXH3_kSecret),
                                       XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_withSecret(const void* restrict input, size_t len,
                              XXH64_hash_t seed64,
                              const void* restrict secret, size_t secretLen)
{
    (void)seed64;
    return XXH3_hashLong_128b_internal(input, len, (const xxh_u8*)secret, secretLen,
                                       XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2);
}
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_withSeed_internal(const void* restrict input, size_t len,
                                XXH64_hash_t seed64,
                                XXH3_f_accumulate f_acc,
                                XXH3_f_scrambleAcc f_scramble,
                                XXH3_f_initCustomSecret f_initSec)
{
    if (seed64 == 0)
        return XXH3_hashLong_128b_internal(input, len,
                                           XXH3_kSecret, sizeof(XXH3_kSecret),
                                           f_acc, f_scramble);
    { _Alignas(16) xxh_u8 secret[192];
        f_initSec(secret, seed64);
        return XXH3_hashLong_128b_internal(input, len, (const xxh_u8*)secret, sizeof(secret),
                                           f_acc, f_scramble);
    }
}
static XXH_NAMESPACEXXH128_hash_t
XXH3_hashLong_128b_withSeed(const void* input, size_t len,
                            XXH64_hash_t seed64, const void* restrict secret, size_t secretLen)
{
    (void)secret; (void)secretLen;
    return XXH3_hashLong_128b_withSeed_internal(input, len, seed64,
                XXH3_accumulate_sse2, XXH3_scrambleAcc_sse2, XXH3_initCustomSecret_sse2);
}
typedef XXH_NAMESPACEXXH128_hash_t (*XXH3_hashLong128_f)(const void* restrict, size_t,
                                            XXH64_hash_t, const void* restrict, size_t);
static __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH3_128bits_internal(const void* input, size_t len,
                      XXH64_hash_t seed64, const void* restrict secret, size_t secretLen,
                      XXH3_hashLong128_f f_hl128)
{
    __builtin_assume(secretLen >= 136);
    if (len <= 16)
        return XXH3_len_0to16_128b((const xxh_u8*)input, len, (const xxh_u8*)secret, seed64);
    if (len <= 128)
        return XXH3_len_17to128_128b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    if (len <= 240)
        return XXH3_len_129to240_128b((const xxh_u8*)input, len, (const xxh_u8*)secret, secretLen, seed64);
    return f_hl128(input, len, seed64, secret, secretLen);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits(__attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_128bits_internal(input, len, 0,
                                 XXH3_kSecret, sizeof(XXH3_kSecret),
                                 XXH3_hashLong_128b_default);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSecret(__attribute__((__noescape__)) const void* input, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    return XXH3_128bits_internal(input, len, 0,
                                 (const xxh_u8*)secret, secretSize,
                                 XXH3_hashLong_128b_withSecret);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSeed(__attribute__((__noescape__)) const void* input, size_t len, XXH64_hash_t seed)
{
    return XXH3_128bits_internal(input, len, seed,
                                 XXH3_kSecret, sizeof(XXH3_kSecret),
                                 XXH3_hashLong_128b_withSeed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH3_128bits_withSecretandSeed(__attribute__((__noescape__)) const void* input, size_t len, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed)
{
    if (len <= 240)
        return XXH3_128bits_internal(input, len, seed, XXH3_kSecret, sizeof(XXH3_kSecret), ((void*)0));
    return XXH3_hashLong_128b_withSecret(input, len, seed, secret, secretSize);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH128(__attribute__((__noescape__)) const void* input, size_t len, XXH64_hash_t seed)
{
    return XXH_INLINE_XXH3_128bits_withSeed(input, len, seed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr)
{
    return XXH_INLINE_XXH3_64bits_reset(statePtr);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSecret(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize)
{
    return XXH_INLINE_XXH3_64bits_reset_withSecret(statePtr, secret, secretSize);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, XXH64_hash_t seed)
{
    return XXH_INLINE_XXH3_64bits_reset_withSeed(statePtr, seed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_reset_withSecretandSeed(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* statePtr, __attribute__((__noescape__)) const void* secret, size_t secretSize, XXH64_hash_t seed)
{
    return XXH_INLINE_XXH3_64bits_reset_withSecretandSeed(statePtr, secret, secretSize, seed);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_128bits_update(__attribute__((__noescape__)) XXH_NAMESPACEXXH3_state_t* state, __attribute__((__noescape__)) const void* input, size_t len)
{
    return XXH3_update_regular(state, input, len);
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t XXH_INLINE_XXH3_128bits_digest (__attribute__((__noescape__)) const XXH_NAMESPACEXXH3_state_t* state)
{
    const unsigned char* const secret = (state->extSecret == ((void*)0)) ? state->customSecret : state->extSecret;
    if (state->totalLen > 240) {
        _Alignas(16) XXH64_hash_t acc[(64 / sizeof(xxh_u64))];
        XXH3_digest_long(acc, state, secret);
        __builtin_assume(state->secretLimit + 64 >= sizeof(acc) + 11);
        return XXH3_finalizeLong_128b(acc, secret, state->secretLimit + 64, (xxh_u64)state->totalLen);
    }
    if (state->useSeed)
        return XXH_INLINE_XXH3_128bits_withSeed(state->buffer, (size_t)state->totalLen, state->seed);
    return XXH_INLINE_XXH3_128bits_withSecret(state->buffer, (size_t)(state->totalLen),
                                   secret, state->secretLimit + 64);
}
static __inline __attribute__((__unused__)) int XXH_INLINE_XXH128_isEqual(XXH_NAMESPACEXXH128_hash_t h1, XXH_NAMESPACEXXH128_hash_t h2)
{
    return !(memcmp(&h1, &h2, sizeof(h1)));
}
static __inline __attribute__((__unused__)) int XXH_INLINE_XXH128_cmp(__attribute__((__noescape__)) const void* h128_1, __attribute__((__noescape__)) const void* h128_2)
{
    XXH_NAMESPACEXXH128_hash_t const h1 = *(const XXH_NAMESPACEXXH128_hash_t*)h128_1;
    XXH_NAMESPACEXXH128_hash_t const h2 = *(const XXH_NAMESPACEXXH128_hash_t*)h128_2;
    int const hcmp = (h1.high64 > h2.high64) - (h2.high64 > h1.high64);
    if (hcmp) return hcmp;
    return (h1.low64 > h2.low64) - (h2.low64 > h1.low64);
}
static __inline __attribute__((__unused__)) void
XXH_INLINE_XXH128_canonicalFromHash(__attribute__((__noescape__)) XXH_NAMESPACEXXH128_canonical_t* dst, XXH_NAMESPACEXXH128_hash_t hash)
{
    do { _Static_assert(((sizeof(XXH_NAMESPACEXXH128_canonical_t) == sizeof(XXH_NAMESPACEXXH128_hash_t))),"sizeof(XXH128_canonical_t) == sizeof(XXH128_hash_t)"); } while(0);
    if (1) {
        hash.high64 = XXH_swap64(hash.high64);
        hash.low64 = XXH_swap64(hash.low64);
    }
    memcpy(dst, &hash.high64, sizeof(hash.high64));
    memcpy((char*)dst + sizeof(hash.high64), &hash.low64, sizeof(hash.low64));
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH128_hash_t
XXH_INLINE_XXH128_hashFromCanonical(__attribute__((__noescape__)) const XXH_NAMESPACEXXH128_canonical_t* src)
{
    XXH_NAMESPACEXXH128_hash_t h;
    h.high64 = XXH_readBE64(src);
    h.low64 = XXH_readBE64(src->digest + 8);
    return h;
}
static __attribute__((__unused__)) void XXH3_combine16(void* dst, XXH_NAMESPACEXXH128_hash_t h128)
{
    XXH_writeLE64( dst, XXH_readLE64(dst) ^ h128.low64 );
    XXH_writeLE64( (char*)dst+8, XXH_readLE64((char*)dst+8) ^ h128.high64 );
}
static __inline __attribute__((__unused__)) XXH_NAMESPACEXXH_errorcode
XXH_INLINE_XXH3_generateSecret(__attribute__((__noescape__)) void* secretBuffer, size_t secretSize, __attribute__((__noescape__)) const void* customSeed, size_t customSeedSize)
{
    if (secretBuffer == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    if (secretSize < 136) return XXH_NAMESPACEXXH_ERROR;
    if (customSeedSize == 0) {
        customSeed = XXH3_kSecret;
        customSeedSize = 192;
    }
    if (customSeed == ((void*)0)) return XXH_NAMESPACEXXH_ERROR;
    { size_t pos = 0;
        while (pos < secretSize) {
            size_t const toCopy = ((((secretSize - pos)) > (customSeedSize)) ? (customSeedSize) : ((secretSize - pos)));
            memcpy((char*)secretBuffer + pos, customSeed, toCopy);
            pos += toCopy;
    } }
    { size_t const nbSeg16 = secretSize / 16;
        size_t n;
        XXH_NAMESPACEXXH128_canonical_t scrambler;
        XXH_INLINE_XXH128_canonicalFromHash(&scrambler, XXH_INLINE_XXH128(customSeed, customSeedSize, 0));
        for (n=0; n<nbSeg16; n++) {
            XXH_NAMESPACEXXH128_hash_t const h128 = XXH_INLINE_XXH128(&scrambler, sizeof(scrambler), n);
            XXH3_combine16((char*)secretBuffer + n*16, h128);
        }
        XXH3_combine16((char*)secretBuffer + secretSize - 16, XXH_INLINE_XXH128_hashFromCanonical(&scrambler));
    }
    return XXH_NAMESPACEXXH_OK;
}
static __inline __attribute__((__unused__)) void
XXH_INLINE_XXH3_generateSecret_fromSeed(__attribute__((__noescape__)) void* secretBuffer, XXH64_hash_t seed)
{
    _Alignas(16) xxh_u8 secret[192];
    XXH3_initCustomSecret_sse2(secret, seed);
    __builtin_assume(secretBuffer != ((void*)0));
    memcpy(secretBuffer, secret, 192);
}
typedef __builtin_va_list __gnuc_va_list;
typedef struct
{
  int __count;
  union
  {
    unsigned int __wch;
    char __wchb[4];
  } __value;
} __mbstate_t;
typedef struct _G_fpos_t
{
  __off_t __pos;
  __mbstate_t __state;
} __fpos_t;
typedef struct _G_fpos64_t
{
  __off64_t __pos;
  __mbstate_t __state;
} __fpos64_t;
struct _IO_FILE;
typedef struct _IO_FILE __FILE;
struct _IO_FILE;
typedef struct _IO_FILE FILE;

struct _IO_FILE;
struct _IO_marker;
struct _IO_codecvt;
struct _IO_wide_data;
typedef void _IO_lock_t;
struct _IO_FILE
{
  int _flags;
  char *_IO_read_ptr;
  char *_IO_read_end;
  char *_IO_read_base;
  char *_IO_write_base;
  char *_IO_write_ptr;
  char *_IO_write_end;
  char *_IO_buf_base;
  char *_IO_buf_end;
  char *_IO_save_base;
  char *_IO_backup_base;
  char *_IO_save_end;
  struct _IO_marker *_markers;
  struct _IO_FILE *_chain;
  int _fileno;
  int _flags2:24;
  char _short_backupbuf[1];
  __off_t _old_offset;
  unsigned short _cur_column;
  signed char _vtable_offset;
  char _shortbuf[1];
  _IO_lock_t *_lock;
  __off64_t _offset;
  struct _IO_codecvt *_codecvt;
  struct _IO_wide_data *_wide_data;
  struct _IO_FILE *_freeres_list;
  void *_freeres_buf;
  struct _IO_FILE **_prevchain;
  int _mode;
  int _unused3;
  __uint64_t _total_written;
  char _unused2[12 * sizeof (int) - 5 * sizeof (void *)];
};
typedef __ssize_t cookie_read_function_t (void *__cookie, char *__buf,
                                          size_t __nbytes);
typedef __ssize_t cookie_write_function_t (void *__cookie, const char *__buf,
                                           size_t __nbytes);
typedef int cookie_seek_function_t (void *__cookie, __off64_t *__pos, int __w);
typedef int cookie_close_function_t (void *__cookie);
typedef struct _IO_cookie_io_functions_t
{
  cookie_read_function_t *read;
  cookie_write_function_t *write;
  cookie_seek_function_t *seek;
  cookie_close_function_t *close;
} cookie_io_functions_t;
typedef __gnuc_va_list va_list;
typedef __fpos_t fpos_t;
extern FILE *stdin;
extern FILE *stdout;
extern FILE *stderr;
extern int remove (const char *__filename) __attribute__ ((__nothrow__ ));
extern int rename (const char *__old, const char *__new) __attribute__ ((__nothrow__ ));
extern int renameat (int __oldfd, const char *__old, int __newfd,
       const char *__new) __attribute__ ((__nothrow__ ));
extern int fclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern FILE *tmpfile (void)
  __attribute__ ((__malloc__)) ;
extern char *tmpnam (char[20]) __attribute__ ((__nothrow__ )) ;
extern char *tmpnam_r (char __s[20]) __attribute__ ((__nothrow__ )) ;
extern char *tempnam (const char *__dir, const char *__pfx)
   __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;
extern int fflush (FILE *__stream);
extern int fflush_unlocked (FILE *__stream);
extern FILE *fopen (const char *__restrict __filename,
      const char *__restrict __modes)
  __attribute__ ((__malloc__)) ;
extern FILE *freopen (const char *__restrict __filename,
        const char *__restrict __modes,
        FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern FILE *fdopen (int __fd, const char *__modes) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
extern FILE *fopencookie (void *__restrict __magic_cookie,
     const char *__restrict __modes,
     cookie_io_functions_t __io_funcs) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
extern FILE *fmemopen (void *__s, size_t __len, const char *__modes)
  __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) ;
extern FILE *open_memstream (char **__bufloc, size_t *__sizeloc) __attribute__ ((__nothrow__ ))
  __attribute__ ((__malloc__)) ;
extern void setbuf (FILE *__restrict __stream, char *__restrict __buf) __attribute__ ((__nothrow__ ))
  __attribute__ ((__nonnull__ (1)));
extern int setvbuf (FILE *__restrict __stream, char *__restrict __buf,
      int __modes, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void setbuffer (FILE *__restrict __stream, char *__restrict __buf,
         size_t __size) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void setlinebuf (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int fprintf (FILE *__restrict __stream,
      const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));
extern int printf (const char *__restrict __format, ...);
extern int sprintf (char *__restrict __s,
      const char *__restrict __format, ...) __attribute__ ((__nothrow__));
extern int vfprintf (FILE *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nonnull__ (1)));
extern int vprintf (const char *__restrict __format, __gnuc_va_list __arg);
extern int vsprintf (char *__restrict __s, const char *__restrict __format,
       __gnuc_va_list __arg) __attribute__ ((__nothrow__));
extern int snprintf (char *__restrict __s, size_t __maxlen,
       const char *__restrict __format, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 4)));
extern int vsnprintf (char *__restrict __s, size_t __maxlen,
        const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 3, 0)));
extern int vasprintf (char **__restrict __ptr, const char *__restrict __f,
        __gnuc_va_list __arg)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 0))) ;
extern int __asprintf (char **__restrict __ptr,
         const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int asprintf (char **__restrict __ptr,
       const char *__restrict __fmt, ...)
     __attribute__ ((__nothrow__)) __attribute__ ((__format__ (__printf__, 2, 3))) ;
extern int vdprintf (int __fd, const char *__restrict __fmt,
       __gnuc_va_list __arg)
     __attribute__ ((__format__ (__printf__, 2, 0)));
extern int dprintf (int __fd, const char *__restrict __fmt, ...)
     __attribute__ ((__format__ (__printf__, 2, 3)));
extern int fscanf (FILE *__restrict __stream,
     const char *__restrict __format, ...) __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) ;
extern int sscanf (const char *__restrict __s,
     const char *__restrict __format, ...) __attribute__ ((__nothrow__ ));
extern int fscanf (FILE *__restrict __stream, const char *__restrict __format, ...) __asm__ ("" "__isoc99_fscanf") __attribute__ ((__nonnull__ (1)));
extern int scanf (const char *__restrict __format, ...) __asm__ ("" "__isoc99_scanf") ;
extern int sscanf (const char *__restrict __s, const char *__restrict __format, ...) __asm__ ("" "__isoc99_sscanf") __attribute__ ((__nothrow__ ));
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format,
      __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s,
      const char *__restrict __format, __gnuc_va_list __arg)
     __attribute__ ((__nothrow__ )) __attribute__ ((__format__ (__scanf__, 2, 0)));
extern int vfscanf (FILE *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vfscanf")
     __attribute__ ((__format__ (__scanf__, 2, 0))) __attribute__ ((__nonnull__ (1)));
extern int vscanf (const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vscanf")
     __attribute__ ((__format__ (__scanf__, 1, 0))) ;
extern int vsscanf (const char *__restrict __s, const char *__restrict __format, __gnuc_va_list __arg) __asm__ ("" "__isoc99_vsscanf") __attribute__ ((__nothrow__ ))
     __attribute__ ((__format__ (__scanf__, 2, 0)));
extern int fgetc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getc (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar (void);
extern int getc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int getchar_unlocked (void);
extern int fgetc_unlocked (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fputc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar (int __c);
extern int fputc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putc_unlocked (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern int putchar_unlocked (int __c);
extern int getw (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int putw (int __w, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern char *fgets (char *__restrict __s, int __n, FILE *__restrict __stream)
                                                          __attribute__ ((__nonnull__ (3)));
extern __ssize_t __getdelim (char **__restrict __lineptr,
                             size_t *__restrict __n, int __delimiter,
                             FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getdelim (char **__restrict __lineptr,
                           size_t *__restrict __n, int __delimiter,
                           FILE *__restrict __stream) __attribute__ ((__nonnull__ (4)));
extern __ssize_t getline (char **__restrict __lineptr,
                          size_t *__restrict __n,
                          FILE *__restrict __stream) __attribute__ ((__nonnull__ (3)));
extern int fputs (const char *__restrict __s, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (2)));
extern int puts (const char *__s);
extern int ungetc (int __c, FILE *__stream) __attribute__ ((__nonnull__ (2)));
extern size_t fread (void *__restrict __ptr, size_t __size,
       size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite (const void *__restrict __ptr, size_t __size,
        size_t __n, FILE *__restrict __s) __attribute__ ((__nonnull__ (4)));
extern size_t fread_unlocked (void *__restrict __ptr, size_t __size,
         size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern size_t fwrite_unlocked (const void *__restrict __ptr, size_t __size,
          size_t __n, FILE *__restrict __stream)
  __attribute__ ((__nonnull__ (4)));
extern int fseek (FILE *__stream, long int __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern long int ftell (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern void rewind (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fseeko (FILE *__stream, __off_t __off, int __whence)
  __attribute__ ((__nonnull__ (1)));
extern __off_t ftello (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern int fgetpos (FILE *__restrict __stream, fpos_t *__restrict __pos)
  __attribute__ ((__nonnull__ (1)));
extern int fsetpos (FILE *__stream, const fpos_t *__pos) __attribute__ ((__nonnull__ (1)));
extern void clearerr (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int feof (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ferror (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void clearerr_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int feof_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ferror_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void perror (const char *__s) __attribute__ ((__cold__));
extern int fileno (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int fileno_unlocked (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int pclose (FILE *__stream) __attribute__ ((__nonnull__ (1)));
extern FILE *popen (const char *__command, const char *__modes)
  __attribute__ ((__malloc__)) ;
extern char *ctermid (char *__s) __attribute__ ((__nothrow__ ))
                                     ;
extern void flockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int ftrylockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern void funlockfile (FILE *__stream) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
extern int __uflow (FILE *);
extern int __overflow (FILE *, int);
struct cfl_array;
struct cfl_kvlist;
struct cfl_arena;
struct cfl_variant {
    int type;
    size_t size;
    uint8_t referenced;
    uint8_t owned;
    union {
        cfl_sds_t as_string;
        cfl_sds_t as_bytes;
        unsigned int as_bool;
        int64_t as_int64;
        uint64_t as_uint64;
        double as_double;
        void *as_reference;
        struct cfl_array *as_array;
        struct cfl_kvlist *as_kvlist;
    } data;
    struct cfl_arena *arena;
};
int cfl_variant_print(FILE *fp, struct cfl_variant *val);
struct cfl_variant *cfl_variant_create_from_string(char *value);
struct cfl_variant *cfl_variant_create_from_string_s(char *value, size_t value_length, int referenced);
struct cfl_variant *cfl_variant_create_from_bytes(char *value, size_t length, int referenced);
struct cfl_variant *cfl_variant_create_from_bool(int value);
struct cfl_variant *cfl_variant_create_from_int64(int64_t value);
struct cfl_variant *cfl_variant_create_from_uint64(uint64_t value);
struct cfl_variant *cfl_variant_create_from_double(double value);
struct cfl_variant *cfl_variant_create_from_array(struct cfl_array *value);
struct cfl_variant *cfl_variant_create_from_null();
struct cfl_variant *cfl_variant_create_from_kvlist(struct cfl_kvlist *value);
struct cfl_variant *cfl_variant_create_from_reference(void *value);
struct cfl_variant *cfl_variant_create();
struct cfl_variant *cfl_variant_create_in(struct cfl_arena *arena);
struct cfl_variant *cfl_variant_create_from_string_in(struct cfl_arena *arena,
                                                       char *value);
struct cfl_variant *cfl_variant_create_from_string_s_in(struct cfl_arena *arena,
                                                         char *value,
                                                         size_t value_length,
                                                         int referenced);
struct cfl_variant *cfl_variant_create_from_bytes_in(struct cfl_arena *arena,
                                                      char *value, size_t length,
                                                      int referenced);
struct cfl_variant *cfl_variant_create_from_bool_in(struct cfl_arena *arena,
                                                     int value);
struct cfl_variant *cfl_variant_create_from_int64_in(struct cfl_arena *arena,
                                                      int64_t value);
struct cfl_variant *cfl_variant_create_from_uint64_in(struct cfl_arena *arena,
                                                       uint64_t value);
struct cfl_variant *cfl_variant_create_from_double_in(struct cfl_arena *arena,
                                                       double value);
struct cfl_variant *cfl_variant_create_from_null_in(struct cfl_arena *arena);
struct cfl_variant *cfl_variant_create_from_reference_in(struct cfl_arena *arena,
                                                          void *value);
struct cfl_variant *cfl_variant_create_from_array_in(struct cfl_arena *arena,
                                                      struct cfl_array *value);
struct cfl_variant *cfl_variant_create_from_kvlist_in(struct cfl_arena *arena,
                                                       struct cfl_kvlist *value);
void cfl_variant_destroy(struct cfl_variant *instance);
void cfl_variant_size_set(struct cfl_variant *var, size_t size);
size_t cfl_variant_size_get(struct cfl_variant *var);

struct cfl_kvlist;
struct cfl_arena;
struct cfl_array {
    int resizable;
    struct cfl_variant **entries;
    size_t slot_count;
    size_t entry_count;
    struct cfl_variant *owner;
    struct cfl_array *parent_array;
    struct cfl_kvlist *parent_kvlist;
    struct cfl_arena *arena;
};
struct cfl_array *cfl_array_create(size_t slot_count);
struct cfl_array *cfl_array_create_in(struct cfl_arena *arena,
                                      size_t slot_count);
struct cfl_array *cfl_array_create_like(struct cfl_array *parent,
                                        size_t slot_count);
void cfl_array_destroy(struct cfl_array *array);
static inline struct cfl_variant *cfl_array_fetch_by_index(struct cfl_array *array,
                                                           size_t position)
{
    if (array == ((void*)0)) {
        return ((void*)0);
    }
    if (position >= array->entry_count) {
        return ((void*)0);
    }
    return array->entries[position];
}
static inline size_t cfl_array_size(struct cfl_array *array)
{
    if (array == ((void*)0)) {
        return 0;
    }
    return array->entry_count;
}
int cfl_array_append(struct cfl_array *array, struct cfl_variant *value);
int cfl_array_append_string(struct cfl_array *array, char *value);
int cfl_array_append_string_s(struct cfl_array *array, char *str, size_t str_len, int referenced);
int cfl_array_append_bytes(struct cfl_array *array, char *value, size_t length, int referenced);
int cfl_array_append_reference(struct cfl_array *array, void *value);
int cfl_array_append_bool(struct cfl_array *array, int value);
int cfl_array_append_int64(struct cfl_array *array, int64_t value);
int cfl_array_append_uint64(struct cfl_array *array, uint64_t value);
int cfl_array_append_double(struct cfl_array *array, double value);
int cfl_array_append_null(struct cfl_array *array);
int cfl_array_append_array(struct cfl_array *array, struct cfl_array *value);
int cfl_array_append_new_array(struct cfl_array *array, size_t size);
int cfl_array_append_kvlist(struct cfl_array *array, struct cfl_kvlist *value);
int cfl_array_resizable(struct cfl_array *array, int v);
int cfl_array_remove_by_index(struct cfl_array *array, size_t position);
int cfl_array_remove_by_reference(struct cfl_array *array, struct cfl_variant *value);
int cfl_array_print(FILE *fp, struct cfl_array *array);
struct cfl_kv {
  cfl_sds_t key;
  cfl_sds_t val;
  struct cfl_list _head;
};
void cfl_kv_init(struct cfl_list *list);
struct cfl_kv *cfl_kv_item_create_len(struct cfl_list *list,
                                      char *k_buf, size_t k_len,
                                      char *v_buf, size_t v_len);
struct cfl_kv *cfl_kv_item_create(struct cfl_list *list,
                                  char *k_buf, char *v_buf);
void cfl_kv_item_destroy(struct cfl_kv *kv);
void cfl_kv_release(struct cfl_list *list);
const char *cfl_kv_get_key_value(const char *key, struct cfl_list *list);
struct cfl_array;
struct cfl_arena;
enum cfl_kvlist_match_mode {
    CFL_KVLIST_MATCH_CASE_INSENSITIVE = 0,
    CFL_KVLIST_MATCH_CASE_SENSITIVE
};
struct cfl_kvpair {
    cfl_sds_t key;
    struct cfl_variant *val;
    struct cfl_list _head;
    struct cfl_arena *arena;
};
struct cfl_kvlist {
    struct cfl_list list;
    struct cfl_variant *owner;
    struct cfl_array *parent_array;
    struct cfl_kvlist *parent_kvlist;
    struct cfl_arena *arena;
};
struct cfl_kvlist *cfl_kvlist_create();
struct cfl_kvlist *cfl_kvlist_create_in(struct cfl_arena *arena);
struct cfl_kvlist *cfl_kvlist_create_like(struct cfl_kvlist *parent);
void cfl_kvlist_destroy(struct cfl_kvlist *list);
int cfl_kvlist_insert_string(struct cfl_kvlist *list,
                             char *key, char *value);
int cfl_kvlist_insert_bytes(struct cfl_kvlist *list,
                             char *key, char *value,
                             size_t value_length,
                             int referenced);
int cfl_kvlist_insert_reference(struct cfl_kvlist *list,
                                char *key, void *value);
int cfl_kvlist_insert_bool(struct cfl_kvlist *list,
                           char *key, int value);
int cfl_kvlist_insert_int64(struct cfl_kvlist *list,
                            char *key, int64_t value);
int cfl_kvlist_insert_uint64(struct cfl_kvlist *list,
                            char *key, uint64_t value);
int cfl_kvlist_insert_double(struct cfl_kvlist *list,
                             char *key, double value);
int cfl_kvlist_insert_array(struct cfl_kvlist *list,
                            char *key, struct cfl_array *value);
int cfl_kvlist_insert_new_array(struct cfl_kvlist *list,
                                char *key, size_t size);
int cfl_kvlist_insert_kvlist(struct cfl_kvlist *list,
                             char *key, struct cfl_kvlist *value);
int cfl_kvlist_insert(struct cfl_kvlist *list,
                      char *key, struct cfl_variant *value);
int cfl_kvlist_count(struct cfl_kvlist *list);
struct cfl_variant *cfl_kvlist_fetch(struct cfl_kvlist *list, char *key);
int cfl_kvlist_print(FILE *fp, struct cfl_kvlist *list);
int cfl_kvlist_insert_string_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               char *value, size_t value_size,
                               int referenced);
int cfl_kvlist_insert_bytes_s(struct cfl_kvlist *list,
                              char *key, size_t key_size,
                              char *value,
                              size_t value_length,
                              int referenced);
int cfl_kvlist_insert_reference_s(struct cfl_kvlist *list,
                                  char *key, size_t key_size,
                                  void *value);
int cfl_kvlist_insert_bool_s(struct cfl_kvlist *list,
                             char *key, size_t key_size, int value);
int cfl_kvlist_insert_int64_s(struct cfl_kvlist *list,
                              char *key, size_t key_size,
                              int64_t value);
int cfl_kvlist_insert_uint64_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               uint64_t value);
int cfl_kvlist_insert_double_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               double value);
int cfl_kvlist_insert_array_s(struct cfl_kvlist *list,
                              char *key, size_t key_size,
                              struct cfl_array *value);
int cfl_kvlist_insert_new_array_s(struct cfl_kvlist *list,
                                  char *key, size_t key_size,
                                  size_t size);
int cfl_kvlist_insert_kvlist_s(struct cfl_kvlist *list,
                               char *key, size_t key_size,
                               struct cfl_kvlist *value);
int cfl_kvlist_insert_s(struct cfl_kvlist *list,
                        char *key, size_t key_size,
                        struct cfl_variant *value);
struct cfl_variant *cfl_kvlist_fetch_s(struct cfl_kvlist *list,
                                       char *key, size_t key_size);
struct cfl_variant *cfl_kvlist_fetch_ex(struct cfl_kvlist *list,
                                        char *key,
                                        enum cfl_kvlist_match_mode mode);
struct cfl_variant *cfl_kvlist_fetch_s_ex(struct cfl_kvlist *list,
                                          char *key, size_t key_size,
                                          enum cfl_kvlist_match_mode mode);
struct cfl_variant *cfl_kvlist_fetch_case_s(struct cfl_kvlist *list,
                                            char *key, size_t key_size);
int cfl_kvlist_contains(struct cfl_kvlist *kvlist, char *name);
int cfl_kvlist_contains_ex(struct cfl_kvlist *kvlist, char *name,
                           enum cfl_kvlist_match_mode mode);
int cfl_kvlist_remove(struct cfl_kvlist *kvlist, char *name);
int cfl_kvlist_remove_ex(struct cfl_kvlist *kvlist, char *name,
                         enum cfl_kvlist_match_mode mode);
void cfl_kvpair_destroy(struct cfl_kvpair *pair);
struct cfl_variant *cfl_kvpair_take_value(struct cfl_kvpair *pair);
int cfl_kvpair_key_set_s(struct cfl_kvpair *pair,
                         char *key, size_t key_size);
int cfl_kvlist_rename_s(struct cfl_kvlist *list,
                        char *old_key, size_t old_key_size,
                        char *new_key, size_t new_key_size);
uint32_t cfl_checksum_crc32c(unsigned char *buffer, size_t length);
uint64_t cfl_time_now();


struct cfl_arena;
typedef void *(*cfl_arena_malloc_fn)(void *context, size_t size);
typedef void (*cfl_arena_free_fn)(void *context, void *pointer);
struct cfl_arena_options {
    size_t struct_size;
    size_t chunk_size;
    size_t maximum_chunk_size;
    size_t large_object_threshold;
    cfl_arena_malloc_fn malloc_fn;
    cfl_arena_free_fn free_fn;
    void *allocator_context;
};
struct cfl_arena *cfl_arena_create(size_t chunk_size);
struct cfl_arena *cfl_arena_create_ex(size_t chunk_size,
                                      size_t large_object_threshold);
void cfl_arena_options_init(struct cfl_arena_options *options);
struct cfl_arena *cfl_arena_create_with_options(
    const struct cfl_arena_options *options);
void cfl_arena_destroy(struct cfl_arena *arena);
void cfl_arena_reset(struct cfl_arena *arena);
void *cfl_arena_malloc(struct cfl_arena *arena, size_t size);
void *cfl_arena_calloc(struct cfl_arena *arena,
                       size_t count, size_t size);
void *cfl_arena_memdup(struct cfl_arena *arena,
                       const void *source, size_t size);
char *cfl_arena_strndup(struct cfl_arena *arena,
                        const char *source, size_t length);
size_t cfl_arena_bytes_reserved(struct cfl_arena *arena);
size_t cfl_arena_bytes_used(struct cfl_arena *arena);
size_t cfl_arena_large_object_threshold(struct cfl_arena *arena);
void cfl_arena_external_cache_limit_set(struct cfl_arena *arena,
                                        size_t limit);
size_t cfl_arena_external_cache_limit_get(struct cfl_arena *arena);
size_t cfl_arena_external_cache_bytes(struct cfl_arena *arena);
enum {
    CFL_OBJECT_NONE = 0,
    CFL_OBJECT_KVLIST = 1,
    CFL_OBJECT_VARIANT,
    CFL_OBJECT_ARRAY
};
struct cfl_object {
    int type;
    struct cfl_variant *variant;
    struct cfl_list _head;
};
struct cfl_object *cfl_object_create();
void cfl_object_destroy(struct cfl_object *obj);
int cfl_object_set(struct cfl_object *o, int type, void *ptr);
int cfl_object_print(FILE *stream, struct cfl_object *o);
struct cfl_split_entry {
    char *value;
    int len;
    off_t last_pos;
    struct cfl_list _head;
};
struct cfl_list *cfl_utils_split_quoted(const char *line, int separator, int max_split);
struct cfl_list *cfl_utils_split(const char *line, int separator, int max_split);
void cfl_utils_split_free_entry(struct cfl_split_entry *entry);
void cfl_utils_split_free(struct cfl_list *list);

int cfl_init();
char *cfl_version();

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
        inline void* mpack_realloc(void* old_ptr, size_t used_size, size_t new_size) {
            ((void)(used_size));
            return realloc(old_ptr, new_size);
        }
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef enum mpack_error_t {
    mpack_ok = 0,
    mpack_error_io = 2,
    mpack_error_invalid,
    mpack_error_unsupported,
    mpack_error_type,
    mpack_error_too_big,
    mpack_error_memory,
    mpack_error_bug,
    mpack_error_data,
    mpack_error_eof,
} mpack_error_t;
const char* mpack_error_to_string(mpack_error_t error);
typedef enum mpack_type_t {
    mpack_type_missing = 0,
    mpack_type_nil,
    mpack_type_bool,
    mpack_type_int,
    mpack_type_uint,
    mpack_type_float,
    mpack_type_double,
    mpack_type_str,
    mpack_type_bin,
    mpack_type_array,
    mpack_type_map,
    mpack_type_ext,
} mpack_type_t;
const char* mpack_type_to_string(mpack_type_t type);
typedef struct mpack_timestamp_t {
    int64_t seconds;
    uint32_t nanoseconds;
} mpack_timestamp_t;
typedef struct mpack_tag_t mpack_tag_t;
struct mpack_tag_t {
    mpack_type_t type;
    int8_t exttype;
    union {
        uint64_t u;
        int64_t i;
        _Bool b;
        float f;
        double d;
        uint32_t l;
        uint32_t n;
    } v;
};
inline mpack_tag_t mpack_tag_make_nil(void) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_nil;
    return ret;
}
inline mpack_tag_t mpack_tag_make_bool(_Bool value) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bool;
    ret.v.b = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_true(void) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bool;
    ret.v.b = 1;
    return ret;
}
inline mpack_tag_t mpack_tag_make_false(void) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bool;
    ret.v.b = 0;
    return ret;
}
inline mpack_tag_t mpack_tag_make_int(int64_t value) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_int;
    ret.v.i = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_uint(uint64_t value) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_uint;
    ret.v.u = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_float(float value)
{
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_float;
    ret.v.f = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_double(double value)
{
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_double;
    ret.v.d = value;
    return ret;
}
inline mpack_tag_t mpack_tag_make_array(uint32_t count) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_array;
    ret.v.n = count;
    return ret;
}
inline mpack_tag_t mpack_tag_make_map(uint32_t count) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_map;
    ret.v.n = count;
    return ret;
}
inline mpack_tag_t mpack_tag_make_str(uint32_t length) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_str;
    ret.v.l = length;
    return ret;
}
inline mpack_tag_t mpack_tag_make_bin(uint32_t length) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_bin;
    ret.v.l = length;
    return ret;
}
inline mpack_tag_t mpack_tag_make_ext(int8_t exttype, uint32_t length) {
    mpack_tag_t ret = {(mpack_type_t)0, 0, {0}};
    ret.type = mpack_type_ext;
    ret.exttype = exttype;
    ret.v.l = length;
    return ret;
}
inline mpack_type_t mpack_tag_type(mpack_tag_t* tag) {
    return tag->type;
}
inline _Bool mpack_tag_bool_value(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_bool)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.b;
}
inline int64_t mpack_tag_int_value(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_int)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.i;
}
inline uint64_t mpack_tag_uint_value(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_uint)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.u;
}
inline
float mpack_tag_float_value(mpack_tag_t* tag)
{
    ((!(tag->type == mpack_type_float)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.f;
}
inline
double mpack_tag_double_value(mpack_tag_t* tag)
{
    ((!(tag->type == mpack_type_double)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.d;
}
inline uint32_t mpack_tag_array_count(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_array)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.n;
}
inline uint32_t mpack_tag_map_count(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_map)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.n;
}
inline uint32_t mpack_tag_str_length(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_str)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
inline uint32_t mpack_tag_bin_length(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_bin)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
inline uint32_t mpack_tag_ext_length(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_ext)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
inline int8_t mpack_tag_ext_exttype(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_ext)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->exttype;
}
inline uint32_t mpack_tag_bytes(mpack_tag_t* tag) {
    ((!(tag->type == mpack_type_str || tag->type == mpack_type_bin || tag->type == mpack_type_ext)) ? (__builtin_unreachable(), (void)0) : (void)0);
    return tag->v.l;
}
int mpack_tag_cmp(mpack_tag_t left, mpack_tag_t right);
inline _Bool mpack_tag_equal(mpack_tag_t left, mpack_tag_t right) {
    return mpack_tag_cmp(left, right) == 0;
}
inline mpack_tag_t mpack_tag_nil(void) {
    return mpack_tag_make_nil();
}
inline mpack_tag_t mpack_tag_bool(_Bool value) {
    return mpack_tag_make_bool(value);
}
inline mpack_tag_t mpack_tag_true(void) {
    return mpack_tag_make_true();
}
inline mpack_tag_t mpack_tag_false(void) {
    return mpack_tag_make_false();
}
inline mpack_tag_t mpack_tag_int(int64_t value) {
    return mpack_tag_make_int(value);
}
inline mpack_tag_t mpack_tag_uint(uint64_t value) {
    return mpack_tag_make_uint(value);
}
inline mpack_tag_t mpack_tag_float(float value) {
    return mpack_tag_make_float(value);
}
inline mpack_tag_t mpack_tag_double(double value) {
    return mpack_tag_make_double(value);
}
inline mpack_tag_t mpack_tag_array(int32_t count) {
    return mpack_tag_make_array((uint32_t)count);
}
inline mpack_tag_t mpack_tag_map(int32_t count) {
    return mpack_tag_make_map((uint32_t)count);
}
inline mpack_tag_t mpack_tag_str(int32_t length) {
    return mpack_tag_make_str((uint32_t)length);
}
inline mpack_tag_t mpack_tag_bin(int32_t length) {
    return mpack_tag_make_bin((uint32_t)length);
}
inline mpack_tag_t mpack_tag_ext(int8_t exttype, int32_t length) {
    return mpack_tag_make_ext(exttype, (uint32_t)length);
}
inline uint8_t mpack_load_u8(const char* p) {
    return (uint8_t)p[0];
}
inline uint16_t mpack_load_u16(const char* p) {
    uint16_t val;
    memcpy(&val, p, sizeof(val));
    return __builtin_bswap16(val);
}
inline uint32_t mpack_load_u32(const char* p) {
    uint32_t val;
    memcpy(&val, p, sizeof(val));
    return __builtin_bswap32(val);
}
inline uint64_t mpack_load_u64(const char* p) {
    uint64_t val;
    memcpy(&val, p, sizeof(val));
    return __builtin_bswap64(val);
}
inline void mpack_store_u8(char* p, uint8_t val) {
    uint8_t* u = (uint8_t*)p;
    u[0] = val;
}
inline void mpack_store_u16(char* p, uint16_t val) {
    val = __builtin_bswap16(val);
    memcpy(p, &val, sizeof(val));
}
inline void mpack_store_u32(char* p, uint32_t val) {
    val = __builtin_bswap32(val);
    memcpy(p, &val, sizeof(val));
}
inline void mpack_store_u64(char* p, uint64_t val) {
    val = __builtin_bswap64(val);
    memcpy(p, &val, sizeof(val));
}
inline int8_t mpack_load_i8 (const char* p) {return (int8_t) mpack_load_u8 (p);}
inline int16_t mpack_load_i16(const char* p) {return (int16_t)mpack_load_u16(p);}
inline int32_t mpack_load_i32(const char* p) {return (int32_t)mpack_load_u32(p);}
inline int64_t mpack_load_i64(const char* p) {return (int64_t)mpack_load_u64(p);}
inline void mpack_store_i8 (char* p, int8_t val) {mpack_store_u8 (p, (uint8_t) val);}
inline void mpack_store_i16(char* p, int16_t val) {mpack_store_u16(p, (uint16_t)val);}
inline void mpack_store_i32(char* p, int32_t val) {mpack_store_u32(p, (uint32_t)val);}
inline void mpack_store_i64(char* p, int64_t val) {mpack_store_u64(p, (uint64_t)val);}
inline float mpack_load_float(const char* p) {
                             ;
    _Static_assert(sizeof(float) == sizeof(uint32_t), "float is wrong size??");
    union {
        float f;
        uint32_t u;
    } v;
    v.u = mpack_load_u32(p);
    return v.f;
}
inline double mpack_load_double(const char* p) {
                             ;
    _Static_assert(sizeof(double) == sizeof(uint64_t), "double is wrong size??");
    union {
        double d;
        uint64_t u;
    } v;
    v.u = mpack_load_u64(p);
    return v.d;
}
inline void mpack_store_float(char* p, float value) {
                             ;
    union {
        float f;
        uint32_t u;
    } v;
    v.f = value;
    mpack_store_u32(p, v.u);
}
inline void mpack_store_double(char* p, double value) {
                             ;
    union {
        double d;
        uint64_t u;
    } v;
    v.d = value;
    mpack_store_u64(p, v.u);
}
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef struct mpack_writer_t mpack_writer_t;
typedef void (*mpack_writer_flush_t)(mpack_writer_t* writer, const char* buffer, size_t count);
typedef void (*mpack_writer_error_t)(mpack_writer_t* writer, mpack_error_t error);
typedef void (*mpack_writer_teardown_t)(mpack_writer_t* writer);
typedef struct mpack_builder_page_t {
    struct mpack_builder_page_t* next;
    size_t bytes_used;
} mpack_builder_page_t;
typedef struct mpack_build_t {
    struct mpack_build_t* parent;
    size_t bytes;
    uint32_t count;
    mpack_type_t type;
    uint32_t nested_compound_elements;
    _Bool key_needs_value;
} mpack_build_t;
typedef struct mpack_builder_t {
    mpack_build_t* current_build;
    mpack_build_t* latest_build;
    mpack_builder_page_t* current_page;
    mpack_builder_page_t* pages;
    char* stash_buffer;
    char* stash_position;
    char* stash_end;
} mpack_builder_t;
struct mpack_writer_t {
    mpack_writer_flush_t flush;
    mpack_writer_error_t error_fn;
    mpack_writer_teardown_t teardown;
    void* context;
    char* buffer;
    char* position;
    char* end;
    mpack_error_t error;
    void* reserved[2];
    mpack_builder_t builder;
};
inline void mpack_writer_track_push(mpack_writer_t* writer, mpack_type_t type, uint32_t count) {
    ((void)(writer));
    ((void)(type));
    ((void)(count));
}
inline void mpack_writer_track_push_builder(mpack_writer_t* writer, mpack_type_t type) {
    ((void)(writer));
    ((void)(type));
}
inline void mpack_writer_track_pop(mpack_writer_t* writer, mpack_type_t type) {
    ((void)(writer));
    ((void)(type));
}
inline void mpack_writer_track_pop_builder(mpack_writer_t* writer, mpack_type_t type) {
    ((void)(writer));
    ((void)(type));
}
inline void mpack_writer_track_bytes(mpack_writer_t* writer, size_t count) {
    ((void)(writer));
    ((void)(count));
}
void mpack_writer_init(mpack_writer_t* writer, char* buffer, size_t size);
void mpack_writer_init_growable(mpack_writer_t* writer, char** data, size_t* size);
void mpack_writer_init_error(mpack_writer_t* writer, mpack_error_t error);
void mpack_writer_init_filename(mpack_writer_t* writer, const char* filename);
inline void mpack_writer_init_file(mpack_writer_t* writer, const char* filename) {
    mpack_writer_init_filename(writer, filename);
}
void mpack_writer_init_stdfile(mpack_writer_t* writer, FILE* stdfile, _Bool close_when_done);
mpack_error_t mpack_writer_destroy(mpack_writer_t* writer);
inline void mpack_writer_set_context(mpack_writer_t* writer, void* context) {
    writer->context = context;
}
inline void* mpack_writer_context(mpack_writer_t* writer) {
    return writer->context;
}
void mpack_writer_set_flush(mpack_writer_t* writer, mpack_writer_flush_t flush);
inline void mpack_writer_set_error_handler(mpack_writer_t* writer, mpack_writer_error_t error_fn) {
    writer->error_fn = error_fn;
}
inline void mpack_writer_set_teardown(mpack_writer_t* writer, mpack_writer_teardown_t teardown) {
    writer->teardown = teardown;
}
void mpack_writer_flush_message(mpack_writer_t* writer);
inline size_t mpack_writer_buffer_used(mpack_writer_t* writer) {
    return (size_t)(writer->position - writer->buffer);
}
inline size_t mpack_writer_buffer_left(mpack_writer_t* writer) {
    return (size_t)(writer->end - writer->position);
}
inline size_t mpack_writer_buffer_size(mpack_writer_t* writer) {
    return (size_t)(writer->end - writer->buffer);
}
void mpack_writer_flag_error(mpack_writer_t* writer, mpack_error_t error);
inline mpack_error_t mpack_writer_error(mpack_writer_t* writer) {
    return writer->error;
}
void mpack_write_tag(mpack_writer_t* writer, mpack_tag_t tag);
void mpack_write_i8(mpack_writer_t* writer, int8_t value);
void mpack_write_i16(mpack_writer_t* writer, int16_t value);
void mpack_write_i32(mpack_writer_t* writer, int32_t value);
void mpack_write_i64(mpack_writer_t* writer, int64_t value);
inline void mpack_write_int(mpack_writer_t* writer, int64_t value) {
    mpack_write_i64(writer, value);
}
void mpack_write_u8(mpack_writer_t* writer, uint8_t value);
void mpack_write_u16(mpack_writer_t* writer, uint16_t value);
void mpack_write_u32(mpack_writer_t* writer, uint32_t value);
void mpack_write_u64(mpack_writer_t* writer, uint64_t value);
inline void mpack_write_uint(mpack_writer_t* writer, uint64_t value) {
    mpack_write_u64(writer, value);
}
void mpack_write_float(mpack_writer_t* writer, float value);
void mpack_write_double(mpack_writer_t* writer, double value);
void mpack_write_bool(mpack_writer_t* writer, _Bool value);
void mpack_write_true(mpack_writer_t* writer);
void mpack_write_false(mpack_writer_t* writer);
void mpack_write_nil(mpack_writer_t* writer);
void mpack_write_object_bytes(mpack_writer_t* writer, const char* data, size_t bytes);
void mpack_write_timestamp(mpack_writer_t* writer, int64_t seconds, uint32_t nanoseconds);
inline void mpack_write_timestamp_seconds(mpack_writer_t* writer, int64_t seconds) {
    mpack_write_timestamp(writer, seconds, 0);
}
inline void mpack_write_timestamp_struct(mpack_writer_t* writer, mpack_timestamp_t timestamp) {
    mpack_write_timestamp(writer, timestamp.seconds, timestamp.nanoseconds);
}
void mpack_start_array(mpack_writer_t* writer, uint32_t count);
void mpack_start_map(mpack_writer_t* writer, uint32_t count);
inline void mpack_builder_compound_push(mpack_writer_t* writer) {
    ((void)(writer));
    mpack_build_t* build = writer->builder.current_build;
    if (build != ((void*)0)) {
        ++build->nested_compound_elements;
    }
}
inline void mpack_builder_compound_pop(mpack_writer_t* writer) {
    ((void)(writer));
    mpack_build_t* build = writer->builder.current_build;
    if (build != ((void*)0)) {
        ((!(build->nested_compound_elements > 0)) ? (__builtin_unreachable(), (void)0) : (void)0);
        --build->nested_compound_elements;
    }
}
inline void mpack_finish_array(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_array);
    mpack_builder_compound_pop(writer);
}
inline void mpack_finish_map(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_map);
    mpack_builder_compound_pop(writer);
}
void mpack_build_array(struct mpack_writer_t* writer);
void mpack_build_map(struct mpack_writer_t* writer);
void mpack_complete_array(struct mpack_writer_t* writer);
void mpack_complete_map(struct mpack_writer_t* writer);
void mpack_write_str(mpack_writer_t* writer, const char* str, uint32_t length);
void mpack_write_utf8(mpack_writer_t* writer, const char* str, uint32_t length);
void mpack_write_cstr(mpack_writer_t* writer, const char* cstr);
void mpack_write_cstr_or_nil(mpack_writer_t* writer, const char* cstr);
void mpack_write_utf8_cstr(mpack_writer_t* writer, const char* cstr);
void mpack_write_utf8_cstr_or_nil(mpack_writer_t* writer, const char* cstr);
void mpack_write_bin(mpack_writer_t* writer, const char* data, uint32_t count);
void mpack_write_ext(mpack_writer_t* writer, int8_t exttype, const char* data, uint32_t count);
void mpack_start_str(mpack_writer_t* writer, uint32_t count);
void mpack_start_bin(mpack_writer_t* writer, uint32_t count);
void mpack_start_ext(mpack_writer_t* writer, int8_t exttype, uint32_t count);
void mpack_write_bytes(mpack_writer_t* writer, const char* data, size_t count);
inline void mpack_finish_str(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_str);
}
inline void mpack_finish_bin(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_bin);
}
inline void mpack_finish_ext(mpack_writer_t* writer) {
    mpack_writer_track_pop(writer, mpack_type_ext);
}
inline void mpack_finish_type(mpack_writer_t* writer, mpack_type_t type) {
    mpack_writer_track_pop(writer, type);
}
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef struct mpack_reader_t mpack_reader_t;
typedef size_t (*mpack_reader_fill_t)(mpack_reader_t* reader, char* buffer, size_t count);
typedef void (*mpack_reader_skip_t)(mpack_reader_t* reader, size_t count);
typedef void (*mpack_reader_error_t)(mpack_reader_t* reader, mpack_error_t error);
typedef void (*mpack_reader_teardown_t)(mpack_reader_t* reader);
struct mpack_reader_t {
    void* context;
    mpack_reader_fill_t fill;
    mpack_reader_error_t error_fn;
    mpack_reader_teardown_t teardown;
    mpack_reader_skip_t skip;
    char* buffer;
    size_t size;
    const char* data;
    const char* end;
    mpack_error_t error;
};
void mpack_reader_init(mpack_reader_t* reader, char* buffer, size_t size, size_t count);
void mpack_reader_init_error(mpack_reader_t* reader, mpack_error_t error);
void mpack_reader_init_data(mpack_reader_t* reader, const char* data, size_t count);
void mpack_reader_init_filename(mpack_reader_t* reader, const char* filename);
inline void mpack_reader_init_file(mpack_reader_t* reader, const char* filename) {
    mpack_reader_init_filename(reader, filename);
}
void mpack_reader_init_stdfile(mpack_reader_t* reader, FILE* stdfile, _Bool close_when_done);
mpack_error_t mpack_reader_destroy(mpack_reader_t* reader);
inline void mpack_reader_set_context(mpack_reader_t* reader, void* context) {
    reader->context = context;
}
inline void* mpack_reader_context(mpack_reader_t* reader) {
    return reader->context;
}
void mpack_reader_set_fill(mpack_reader_t* reader, mpack_reader_fill_t fill);
void mpack_reader_set_skip(mpack_reader_t* reader, mpack_reader_skip_t skip);
inline void mpack_reader_set_error_handler(mpack_reader_t* reader, mpack_reader_error_t error_fn) {
    reader->error_fn = error_fn;
}
inline void mpack_reader_set_teardown(mpack_reader_t* reader, mpack_reader_teardown_t teardown) {
    reader->teardown = teardown;
}
inline mpack_error_t mpack_reader_error(mpack_reader_t* reader) {
    return reader->error;
}
void mpack_reader_flag_error(mpack_reader_t* reader, mpack_error_t error);
inline mpack_error_t mpack_reader_flag_if_error(mpack_reader_t* reader, mpack_error_t error) {
    if (error != mpack_ok)
        mpack_reader_flag_error(reader, error);
    return mpack_reader_error(reader);
}
size_t mpack_reader_remaining(mpack_reader_t* reader, const char** data);
mpack_tag_t mpack_read_tag(mpack_reader_t* reader);
mpack_tag_t mpack_peek_tag(mpack_reader_t* reader);
void mpack_skip_bytes(mpack_reader_t* reader, size_t count);
void mpack_read_bytes(mpack_reader_t* reader, char* p, size_t count);
void mpack_read_utf8(mpack_reader_t* reader, char* p, size_t byte_count);
void mpack_read_cstr(mpack_reader_t* reader, char* buf, size_t buffer_size, size_t byte_count);
void mpack_read_utf8_cstr(mpack_reader_t* reader, char* buf, size_t buffer_size, size_t byte_count);
char* mpack_read_bytes_alloc_impl(mpack_reader_t* reader, size_t count, _Bool null_terminated);
inline char* mpack_read_bytes_alloc(mpack_reader_t* reader, size_t count) {
    return mpack_read_bytes_alloc_impl(reader, count, 0);
}
const char* mpack_read_bytes_inplace(mpack_reader_t* reader, size_t count);
const char* mpack_read_utf8_inplace(mpack_reader_t* reader, size_t count);
inline _Bool mpack_should_read_bytes_inplace(mpack_reader_t* reader, size_t count) {
    return (reader->size == 0 || count <= reader->size / 32);
}
mpack_timestamp_t mpack_read_timestamp(mpack_reader_t* reader, size_t size);
inline void mpack_done_type(mpack_reader_t* reader, mpack_type_t type) {
    ((void)(reader));
    ((void)(type));
}
inline void mpack_done_array(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_array);
}
inline void mpack_done_map(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_map);
}
inline void mpack_done_str(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_str);
}
inline void mpack_done_bin(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_bin);
}
inline void mpack_done_ext(mpack_reader_t* reader) {
    mpack_done_type(reader, mpack_type_ext);
}
void mpack_discard(mpack_reader_t* reader);
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
uint8_t mpack_expect_u8(mpack_reader_t* reader);
uint16_t mpack_expect_u16(mpack_reader_t* reader);
uint32_t mpack_expect_u32(mpack_reader_t* reader);
uint64_t mpack_expect_u64(mpack_reader_t* reader);
int8_t mpack_expect_i8(mpack_reader_t* reader);
int16_t mpack_expect_i16(mpack_reader_t* reader);
int32_t mpack_expect_i32(mpack_reader_t* reader);
int64_t mpack_expect_i64(mpack_reader_t* reader);
float mpack_expect_float(mpack_reader_t* reader);
double mpack_expect_double(mpack_reader_t* reader);
float mpack_expect_float_strict(mpack_reader_t* reader);
double mpack_expect_double_strict(mpack_reader_t* reader);
uint8_t mpack_expect_u8_range(mpack_reader_t* reader, uint8_t min_value, uint8_t max_value);
uint16_t mpack_expect_u16_range(mpack_reader_t* reader, uint16_t min_value, uint16_t max_value);
uint32_t mpack_expect_u32_range(mpack_reader_t* reader, uint32_t min_value, uint32_t max_value);
uint64_t mpack_expect_u64_range(mpack_reader_t* reader, uint64_t min_value, uint64_t max_value);
inline unsigned int mpack_expect_uint_range(mpack_reader_t* reader, unsigned int min_value, unsigned int max_value) {
    if (sizeof(unsigned int) == 4)
        return (unsigned int)mpack_expect_u32_range(reader, (uint32_t)min_value, (uint32_t)max_value);
    return (unsigned int)mpack_expect_u64_range(reader, min_value, max_value);
}
inline uint8_t mpack_expect_u8_max(mpack_reader_t* reader, uint8_t max_value) {
    return mpack_expect_u8_range(reader, 0, max_value);
}
inline uint16_t mpack_expect_u16_max(mpack_reader_t* reader, uint16_t max_value) {
    return mpack_expect_u16_range(reader, 0, max_value);
}
inline uint32_t mpack_expect_u32_max(mpack_reader_t* reader, uint32_t max_value) {
    return mpack_expect_u32_range(reader, 0, max_value);
}
inline uint64_t mpack_expect_u64_max(mpack_reader_t* reader, uint64_t max_value) {
    return mpack_expect_u64_range(reader, 0, max_value);
}
inline unsigned int mpack_expect_uint_max(mpack_reader_t* reader, unsigned int max_value) {
    return mpack_expect_uint_range(reader, 0, max_value);
}
int8_t mpack_expect_i8_range(mpack_reader_t* reader, int8_t min_value, int8_t max_value);
int16_t mpack_expect_i16_range(mpack_reader_t* reader, int16_t min_value, int16_t max_value);
int32_t mpack_expect_i32_range(mpack_reader_t* reader, int32_t min_value, int32_t max_value);
int64_t mpack_expect_i64_range(mpack_reader_t* reader, int64_t min_value, int64_t max_value);
inline int mpack_expect_int_range(mpack_reader_t* reader, int min_value, int max_value) {
    if (sizeof(int) == 4)
        return (int)mpack_expect_i32_range(reader, (int32_t)min_value, (int32_t)max_value);
    return (int)mpack_expect_i64_range(reader, min_value, max_value);
}
inline int8_t mpack_expect_i8_max(mpack_reader_t* reader, int8_t max_value) {
    return mpack_expect_i8_range(reader, 0, max_value);
}
inline int16_t mpack_expect_i16_max(mpack_reader_t* reader, int16_t max_value) {
    return mpack_expect_i16_range(reader, 0, max_value);
}
inline int32_t mpack_expect_i32_max(mpack_reader_t* reader, int32_t max_value) {
    return mpack_expect_i32_range(reader, 0, max_value);
}
inline int64_t mpack_expect_i64_max(mpack_reader_t* reader, int64_t max_value) {
    return mpack_expect_i64_range(reader, 0, max_value);
}
inline int mpack_expect_int_max(mpack_reader_t* reader, int max_value) {
    return mpack_expect_int_range(reader, 0, max_value);
}
float mpack_expect_float_range(mpack_reader_t* reader, float min_value, float max_value);
double mpack_expect_double_range(mpack_reader_t* reader, double min_value, double max_value);
inline unsigned int mpack_expect_uint(mpack_reader_t* reader) {
    if (sizeof(unsigned int) == 4)
        return (unsigned int)mpack_expect_u32(reader);
    return (unsigned int)mpack_expect_u64_max(reader, (2147483647 *2U +1U));
}
inline int mpack_expect_int(mpack_reader_t* reader) {
    if (sizeof(int) == 4)
        return (int)mpack_expect_i32(reader);
    return (int)mpack_expect_i64_range(reader, (-2147483647 -1), 2147483647);
}
void mpack_expect_uint_match(mpack_reader_t* reader, uint64_t value);
void mpack_expect_int_match(mpack_reader_t* reader, int64_t value);
void mpack_expect_nil(mpack_reader_t* reader);
_Bool mpack_expect_bool(mpack_reader_t* reader);
void mpack_expect_true(mpack_reader_t* reader);
void mpack_expect_false(mpack_reader_t* reader);
mpack_timestamp_t mpack_expect_timestamp(mpack_reader_t* reader);
int64_t mpack_expect_timestamp_truncate(mpack_reader_t* reader);
uint32_t mpack_expect_map(mpack_reader_t* reader);
uint32_t mpack_expect_map_range(mpack_reader_t* reader, uint32_t min_count, uint32_t max_count);
inline uint32_t mpack_expect_map_max(mpack_reader_t* reader, uint32_t max_count) {
    return mpack_expect_map_range(reader, 0, max_count);
}
void mpack_expect_map_match(mpack_reader_t* reader, uint32_t count);
_Bool mpack_expect_map_or_nil(mpack_reader_t* reader, uint32_t* count);
_Bool mpack_expect_map_max_or_nil(mpack_reader_t* reader, uint32_t max_count, uint32_t* count);
uint32_t mpack_expect_array(mpack_reader_t* reader);
uint32_t mpack_expect_array_range(mpack_reader_t* reader, uint32_t min_count, uint32_t max_count);
inline uint32_t mpack_expect_array_max(mpack_reader_t* reader, uint32_t max_count) {
    return mpack_expect_array_range(reader, 0, max_count);
}
void mpack_expect_array_match(mpack_reader_t* reader, uint32_t count);
_Bool mpack_expect_array_or_nil(mpack_reader_t* reader, uint32_t* count);
_Bool mpack_expect_array_max_or_nil(mpack_reader_t* reader, uint32_t max_count, uint32_t* count);
void* mpack_expect_array_alloc_impl(mpack_reader_t* reader,
        size_t element_size, uint32_t max_count, uint32_t* out_count, _Bool allow_nil);
uint32_t mpack_expect_str(mpack_reader_t* reader);
size_t mpack_expect_str_buf(mpack_reader_t* reader, char* buf, size_t bufsize);
size_t mpack_expect_utf8(mpack_reader_t* reader, char* buf, size_t bufsize);
inline uint32_t mpack_expect_str_max(mpack_reader_t* reader, uint32_t maxsize) {
    uint32_t length = mpack_expect_str(reader);
    if (length > maxsize) {
        mpack_reader_flag_error(reader, mpack_error_too_big);
        return 0;
    }
    return length;
}
inline void mpack_expect_str_length(mpack_reader_t* reader, uint32_t count) {
    if (mpack_expect_str(reader) != count)
        mpack_reader_flag_error(reader, mpack_error_type);
}
void mpack_expect_str_match(mpack_reader_t* reader, const char* str, size_t length);
void mpack_expect_cstr(mpack_reader_t* reader, char* buf, size_t size);
void mpack_expect_utf8_cstr(mpack_reader_t* reader, char* buf, size_t size);
char* mpack_expect_cstr_alloc(mpack_reader_t* reader, size_t maxsize);
char* mpack_expect_utf8_cstr_alloc(mpack_reader_t* reader, size_t maxsize);
inline void mpack_expect_cstr_match(mpack_reader_t* reader, const char* cstr) {
    ((!(cstr != ((void*)0))) ? (__builtin_unreachable(), (void)0) : (void)0);
    mpack_expect_str_match(reader, cstr, strlen(cstr));
}
uint32_t mpack_expect_bin(mpack_reader_t* reader);
inline uint32_t mpack_expect_bin_max(mpack_reader_t* reader, uint32_t maxsize) {
    uint32_t length = mpack_expect_bin(reader);
    if (length > maxsize) {
        mpack_reader_flag_error(reader, mpack_error_type);
        return 0;
    }
    return length;
}
inline void mpack_expect_bin_size(mpack_reader_t* reader, uint32_t count) {
    if (mpack_expect_bin(reader) != count)
        mpack_reader_flag_error(reader, mpack_error_type);
}
size_t mpack_expect_bin_buf(mpack_reader_t* reader, char* buf, size_t size);
void mpack_expect_bin_size_buf(mpack_reader_t* reader, char* buf, uint32_t size);
char* mpack_expect_bin_alloc(mpack_reader_t* reader, size_t maxsize, size_t* size);
uint32_t mpack_expect_ext(mpack_reader_t* reader, int8_t* type);
inline uint32_t mpack_expect_ext_max(mpack_reader_t* reader, int8_t* type, uint32_t maxsize) {
    uint32_t length = mpack_expect_ext(reader, type);
    if (length > maxsize) {
        mpack_reader_flag_error(reader, mpack_error_type);
        return 0;
    }
    return length;
}
inline void mpack_expect_ext_size(mpack_reader_t* reader, int8_t* type, uint32_t count) {
    if (mpack_expect_ext(reader, type) != count) {
        *type = 0;
        mpack_reader_flag_error(reader, mpack_error_type);
    }
}
size_t mpack_expect_ext_buf(mpack_reader_t* reader, int8_t* type, char* buf, size_t size);
char* mpack_expect_ext_alloc(mpack_reader_t* reader, int8_t* type, size_t maxsize, size_t* size);
void mpack_expect_tag(mpack_reader_t* reader, mpack_tag_t tag);
size_t mpack_expect_enum(mpack_reader_t* reader, const char* strings[], size_t count);
size_t mpack_expect_enum_optional(mpack_reader_t* reader, const char* strings[], size_t count);
size_t mpack_expect_key_uint(mpack_reader_t* reader, _Bool found[], size_t count);
size_t mpack_expect_key_cstr(mpack_reader_t* reader, const char* keys[],
        _Bool found[], size_t count);
#pragma GCC diagnostic pop
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeclaration-after-statement"
typedef struct mpack_node_t mpack_node_t;
typedef struct mpack_node_data_t mpack_node_data_t;
typedef struct mpack_tree_t mpack_tree_t;
typedef void (*mpack_tree_error_t)(mpack_tree_t* tree, mpack_error_t error);
typedef size_t (*mpack_tree_read_t)(mpack_tree_t* tree, char* buffer, size_t count);
typedef void (*mpack_tree_teardown_t)(mpack_tree_t* tree);
struct mpack_node_t {
    mpack_node_data_t* data;
    mpack_tree_t* tree;
};
struct mpack_node_data_t {
    mpack_type_t type;
    uint32_t len;
    union {
        _Bool b;
        float f;
        double d;
        int64_t i;
        uint64_t u;
        size_t offset;
        mpack_node_data_t* children;
    } value;
};
typedef struct mpack_tree_page_t {
    struct mpack_tree_page_t* next;
    mpack_node_data_t nodes[1];
} mpack_tree_page_t;
typedef enum mpack_tree_parse_state_t {
    mpack_tree_parse_state_not_started,
    mpack_tree_parse_state_in_progress,
    mpack_tree_parse_state_parsed,
} mpack_tree_parse_state_t;
typedef struct mpack_level_t {
    mpack_node_data_t* child;
    size_t left;
} mpack_level_t;
typedef struct mpack_tree_parser_t {
    mpack_tree_parse_state_t state;
    size_t possible_nodes_left;
    mpack_node_data_t* nodes;
    size_t nodes_left;
    size_t current_node_reserved;
    size_t level;
    mpack_level_t* stack;
    size_t stack_capacity;
    _Bool stack_owned;
    mpack_level_t stack_local[8];
} mpack_tree_parser_t;
struct mpack_tree_t {
    mpack_tree_error_t error_fn;
    mpack_tree_read_t read_fn;
    mpack_tree_teardown_t teardown;
    void* context;
    mpack_node_data_t nil_node;
    mpack_node_data_t missing_node;
    mpack_error_t error;
    char* buffer;
    size_t buffer_capacity;
    const char* data;
    size_t data_length;
    size_t size;
    size_t node_count;
    size_t max_size;
    size_t max_nodes;
    mpack_tree_parser_t parser;
    mpack_node_data_t* root;
    mpack_node_data_t* pool;
    size_t pool_count;
    mpack_tree_page_t* next;
};
inline mpack_node_t mpack_node(mpack_tree_t* tree, mpack_node_data_t* data) {
    mpack_node_t node;
    node.data = data;
    node.tree = tree;
    return node;
}
inline mpack_node_data_t* mpack_node_child(mpack_node_t node, size_t child) {
    return node.data->value.children + child;
}
inline mpack_node_t mpack_tree_nil_node(mpack_tree_t* tree) {
    return mpack_node(tree, &tree->nil_node);
}
inline mpack_node_t mpack_tree_missing_node(mpack_tree_t* tree) {
    return mpack_node(tree, &tree->missing_node);
}
void mpack_tree_init_data(mpack_tree_t* tree, const char* data, size_t length);
inline void mpack_tree_init(mpack_tree_t* tree, const char* data, size_t length) {
    mpack_tree_init_data(tree, data, length);
}
void mpack_tree_init_stream(mpack_tree_t* tree, mpack_tree_read_t read_fn, void* context,
        size_t max_message_size, size_t max_message_nodes);
void mpack_tree_init_pool(mpack_tree_t* tree, const char* data, size_t length,
        mpack_node_data_t* node_pool, size_t node_pool_count);
void mpack_tree_init_error(mpack_tree_t* tree, mpack_error_t error);
void mpack_tree_init_filename(mpack_tree_t* tree, const char* filename, size_t max_bytes);
inline void mpack_tree_init_file(mpack_tree_t* tree, const char* filename, size_t max_bytes) {
    mpack_tree_init_filename(tree, filename, max_bytes);
}
void mpack_tree_init_stdfile(mpack_tree_t* tree, FILE* stdfile, size_t max_bytes, _Bool close_when_done);
void mpack_tree_set_limits(mpack_tree_t* tree, size_t max_message_size,
        size_t max_message_nodes);
void mpack_tree_parse(mpack_tree_t* tree);
_Bool mpack_tree_try_parse(mpack_tree_t* tree);
mpack_node_t mpack_tree_root(mpack_tree_t* tree);
inline mpack_error_t mpack_tree_error(mpack_tree_t* tree) {
    return tree->error;
}
inline size_t mpack_tree_size(mpack_tree_t* tree) {
    return tree->size;
}
mpack_error_t mpack_tree_destroy(mpack_tree_t* tree);
inline void mpack_tree_set_context(mpack_tree_t* tree, void* context) {
    tree->context = context;
}
inline void* mpack_tree_context(mpack_tree_t* tree) {
    return tree->context;
}
inline void mpack_tree_set_error_handler(mpack_tree_t* tree, mpack_tree_error_t error_fn) {
    tree->error_fn = error_fn;
}
inline void mpack_tree_set_teardown(mpack_tree_t* tree, mpack_tree_teardown_t teardown) {
    tree->teardown = teardown;
}
void mpack_tree_flag_error(mpack_tree_t* tree, mpack_error_t error);
void mpack_node_flag_error(mpack_node_t node, mpack_error_t error);
inline mpack_error_t mpack_node_error(mpack_node_t node) {
    return mpack_tree_error(node.tree);
}
mpack_tag_t mpack_node_tag(mpack_node_t node);
mpack_type_t mpack_node_type(mpack_node_t node);
_Bool mpack_node_is_nil(mpack_node_t node);
_Bool mpack_node_is_missing(mpack_node_t node);
void mpack_node_nil(mpack_node_t node);
void mpack_node_missing(mpack_node_t node);
_Bool mpack_node_bool(mpack_node_t node);
void mpack_node_true(mpack_node_t node);
void mpack_node_false(mpack_node_t node);
uint8_t mpack_node_u8(mpack_node_t node);
int8_t mpack_node_i8(mpack_node_t node);
uint16_t mpack_node_u16(mpack_node_t node);
int16_t mpack_node_i16(mpack_node_t node);
uint32_t mpack_node_u32(mpack_node_t node);
int32_t mpack_node_i32(mpack_node_t node);
uint64_t mpack_node_u64(mpack_node_t node);
int64_t mpack_node_i64(mpack_node_t node);
unsigned int mpack_node_uint(mpack_node_t node);
int mpack_node_int(mpack_node_t node);
float mpack_node_float(mpack_node_t node);
double mpack_node_double(mpack_node_t node);
float mpack_node_float_strict(mpack_node_t node);
double mpack_node_double_strict(mpack_node_t node);
mpack_timestamp_t mpack_node_timestamp(mpack_node_t node);
int64_t mpack_node_timestamp_seconds(mpack_node_t node);
uint32_t mpack_node_timestamp_nanoseconds(mpack_node_t node);
void mpack_node_check_utf8(mpack_node_t node);
void mpack_node_check_utf8_cstr(mpack_node_t node);
int8_t mpack_node_exttype(mpack_node_t node);
size_t mpack_node_bin_size(mpack_node_t node);
uint32_t mpack_node_data_len(mpack_node_t node);
size_t mpack_node_strlen(mpack_node_t node);
const char* mpack_node_str(mpack_node_t node);
const char* mpack_node_data(mpack_node_t node);
const char* mpack_node_bin_data(mpack_node_t node);
size_t mpack_node_copy_data(mpack_node_t node, char* buffer, size_t bufsize);
size_t mpack_node_copy_utf8(mpack_node_t node, char* buffer, size_t bufsize);
void mpack_node_copy_cstr(mpack_node_t node, char* buffer, size_t size);
void mpack_node_copy_utf8_cstr(mpack_node_t node, char* buffer, size_t size);
char* mpack_node_data_alloc(mpack_node_t node, size_t maxsize);
char* mpack_node_cstr_alloc(mpack_node_t node, size_t maxsize);
char* mpack_node_utf8_cstr_alloc(mpack_node_t node, size_t maxsize);
size_t mpack_node_enum(mpack_node_t node, const char* strings[], size_t count);
size_t mpack_node_enum_optional(mpack_node_t node, const char* strings[], size_t count);
size_t mpack_node_array_length(mpack_node_t node);
mpack_node_t mpack_node_array_at(mpack_node_t node, size_t index);
size_t mpack_node_map_count(mpack_node_t node);
mpack_node_t mpack_node_map_key_at(mpack_node_t node, size_t index);
mpack_node_t mpack_node_map_value_at(mpack_node_t node, size_t index);
mpack_node_t mpack_node_map_int(mpack_node_t node, int64_t num);
mpack_node_t mpack_node_map_int_optional(mpack_node_t node, int64_t num);
mpack_node_t mpack_node_map_uint(mpack_node_t node, uint64_t num);
mpack_node_t mpack_node_map_uint_optional(mpack_node_t node, uint64_t num);
mpack_node_t mpack_node_map_str(mpack_node_t node, const char* str, size_t length);
mpack_node_t mpack_node_map_str_optional(mpack_node_t node, const char* str, size_t length);
mpack_node_t mpack_node_map_cstr(mpack_node_t node, const char* cstr);
mpack_node_t mpack_node_map_cstr_optional(mpack_node_t node, const char* cstr);
_Bool mpack_node_map_contains_int(mpack_node_t node, int64_t num);
_Bool mpack_node_map_contains_uint(mpack_node_t node, uint64_t num);
_Bool mpack_node_map_contains_str(mpack_node_t node, const char* str, size_t length);
_Bool mpack_node_map_contains_cstr(mpack_node_t node, const char* cstr);
#pragma GCC diagnostic pop
struct ctrace_opts {
    int _make_windows_happy;
};
struct ctrace {
    uint64_t last_span_id;
    struct cfl_list resource_spans;
    struct cfl_list span_list;
    int log_level;
    void (*log_cb)(void *, int, const char *, int, const char *);
};
struct ctrace *ctr_create(struct ctrace_opts *opts);
void ctr_destroy(struct ctrace *ctx);
void ctr_opts_init(struct ctrace_opts *opts);
void ctr_opts_set(struct ctrace_opts *opts, int value, char *val);
void ctr_opts_exit(struct ctrace_opts *opts);
struct ctrace_id {
    cfl_sds_t buf;
};
struct ctrace_id *ctr_id_create_random(size_t size);
struct ctrace_id *ctr_id_create(void *buf, size_t len);
void ctr_id_destroy(struct ctrace_id *cid);
int ctr_id_set(struct ctrace_id *cid, void *buf, size_t len);
int ctr_id_cmp(struct ctrace_id *cid1, struct ctrace_id *cid2);
size_t ctr_id_get_len(struct ctrace_id *cid);
void *ctr_id_get_buf(struct ctrace_id *cid);
cfl_sds_t ctr_id_to_lower_base16(struct ctrace_id *cid);
struct ctrace_id *ctr_id_from_base16(cfl_sds_t id);

ssize_t ctr_random_get(void *buf, size_t len);
char *ctr_version();

struct ctrace_resource {
    uint32_t dropped_attr_count;
    struct ctrace_attributes *attr;
};
struct ctrace_resource_span {
    struct ctrace_resource *resource;
    struct cfl_list scope_spans;
    cfl_sds_t schema_url;
    struct cfl_list _head;
};
struct ctrace_resource *ctr_resource_create();
struct ctrace_resource *ctr_resource_create_default();
int ctr_resource_set_attributes(struct ctrace_resource *res, struct ctrace_attributes *attr);
void ctr_resource_set_dropped_attr_count(struct ctrace_resource *res, uint32_t count);
void ctr_resource_destroy(struct ctrace_resource *res);
struct ctrace_resource_span *ctr_resource_span_create(struct ctrace *ctx);
struct ctrace_resource *ctr_resource_span_get_resource(struct ctrace_resource_span *resource_span);
int ctr_resource_span_set_schema_url(struct ctrace_resource_span *resource_span, char *url);
void ctr_resource_span_destroy(struct ctrace_resource_span *resource_span);

struct ctrace_instrumentation_scope {
    cfl_sds_t name;
    cfl_sds_t version;
    uint32_t dropped_attr_count;
    struct ctrace_attributes *attr;
};
struct ctrace_scope_span {
    struct ctrace_instrumentation_scope *instrumentation_scope;
    struct cfl_list spans;
    cfl_sds_t schema_url;
    struct ctrace_resource_span *resource_span;
    struct cfl_list _head;
};
struct ctrace_scope_span *ctr_scope_span_create(struct ctrace_resource_span *resource_span);
void ctr_scope_span_destroy(struct ctrace_scope_span *scope_span);
int ctr_scope_span_set_schema_url(struct ctrace_scope_span *scope_span, char *url);
void ctr_scope_span_set_instrumentation_scope(struct ctrace_scope_span *scope_span, struct ctrace_instrumentation_scope *ins_scope);
struct ctrace_instrumentation_scope *ctr_instrumentation_scope_create(char *name, char *version,
                                                                      uint32_t dropped_attr_count,
                                                                      struct ctrace_attributes *attr);
void ctr_instrumentation_scope_destroy(struct ctrace_instrumentation_scope *ins_scope);
struct ctrace_span_status {
    int code;
    cfl_sds_t message;
};
struct ctrace_span_event {
    uint64_t time_unix_nano;
    cfl_sds_t name;
    struct ctrace_attributes *attr;
    uint32_t dropped_attr_count;
    struct cfl_list _head;
};
struct ctrace_span {
    struct ctrace_id *trace_id;
    struct ctrace_id *span_id;
    struct ctrace_id *parent_span_id;
    cfl_sds_t trace_state;
    int32_t flags;
    cfl_sds_t name;
    int kind;
    uint64_t start_time_unix_nano;
    uint64_t end_time_unix_nano;
    struct ctrace_attributes *attr;
    uint32_t dropped_attr_count;
    struct cfl_list events;
    uint32_t dropped_events_count;
    struct cfl_list links;
    uint32_t dropped_links_count;
    cfl_sds_t schema_url;
    struct ctrace_span_status status;
    struct cfl_list _head;
    struct cfl_list _head_global;
    struct ctrace_scope_span *scope_span;
    struct ctrace *ctx;
};
struct ctrace_span *ctr_span_create(struct ctrace *ctx, struct ctrace_scope_span *scope_span, cfl_sds_t name,
                                    struct ctrace_span *parent);
void ctr_span_destroy(struct ctrace_span *span);
int ctr_span_set_status(struct ctrace_span *span, int code, char *message);
void ctr_span_set_dropped_events_count(struct ctrace_span *span, uint32_t count);
void ctr_span_set_dropped_links_count(struct ctrace_span *span, uint32_t count);
int ctr_span_set_trace_state(struct ctrace_span *span, char *state, int len);
int ctr_span_set_flags(struct ctrace_span *span, uint32_t flags);
void ctr_span_set_schema_url(struct ctrace_span *span, char *url);
int ctr_span_set_trace_id(struct ctrace_span *span, void *buf, size_t len);
int ctr_span_set_trace_id_with_cid(struct ctrace_span *span, struct ctrace_id *cid);
int ctr_span_set_span_id(struct ctrace_span *span, void *buf, size_t len);
int ctr_span_set_span_id_with_cid(struct ctrace_span *span, struct ctrace_id *cid);
int ctr_span_set_parent_span_id(struct ctrace_span *span, void *buf, size_t len);
int ctr_span_set_parent_span_id_with_cid(struct ctrace_span *span, struct ctrace_id *cid);
int ctr_span_set_attributes(struct ctrace_span *span, struct ctrace_attributes *attr);
int ctr_span_set_attribute_string(struct ctrace_span *span, char *key, char *value);
int ctr_span_set_attribute_bool(struct ctrace_span *span, char *key, int b);
int ctr_span_set_attribute_int64(struct ctrace_span *span, char *key, int64_t value);
int ctr_span_set_attribute_double(struct ctrace_span *span, char *key, double value);
int ctr_span_set_attribute_array(struct ctrace_span *span, char *key,
                                 struct cfl_array *value);
int ctr_span_set_attribute_kvlist(struct ctrace_span *span, char *key,
                                  struct cfl_kvlist *value);
void ctr_span_set_dropped_attributes_count(struct ctrace_span *span, uint32_t count);
void ctr_span_start(struct ctrace *ctx, struct ctrace_span *span);
void ctr_span_start_ts(struct ctrace *ctx, struct ctrace_span *span, uint64_t ts);
void ctr_span_end(struct ctrace *ctx, struct ctrace_span *span);
void ctr_span_end_ts(struct ctrace *ctx, struct ctrace_span *span, uint64_t ts);
int ctr_span_kind_set(struct ctrace_span *span, int kind);
char *ctr_span_kind_string(struct ctrace_span *span);
struct ctrace_span_event *ctr_span_event_add(struct ctrace_span *span, char *name);
struct ctrace_span_event *ctr_span_event_add_ts(struct ctrace_span *span, char *name, uint64_t ts);
int ctr_span_event_set_attributes(struct ctrace_span_event *event, struct ctrace_attributes *attr);
void ctr_span_event_set_dropped_attributes_count(struct ctrace_span_event *event, uint32_t count);
void ctr_span_event_delete(struct ctrace_span_event *event);
int ctr_span_event_set_attribute_string(struct ctrace_span_event *event, char *key, char *value);
int ctr_span_event_set_attribute_bool(struct ctrace_span_event *event, char *key, int b);
int ctr_span_event_set_attribute_int(struct ctrace_span_event *event, char *key, int value);
int ctr_span_event_set_attribute_double(struct ctrace_span_event *event, char *key, double value);
int ctr_span_event_set_attribute_array(struct ctrace_span_event *event, char *key,
                                       struct cfl_array *value);
int ctr_span_event_set_attribute_kvlist(struct ctrace_span_event *event, char *key,
                                        struct cfl_kvlist *value);


struct ctrace_link {
 struct ctrace_id *trace_id;
    struct ctrace_id *span_id;
 cfl_sds_t trace_state;
    struct ctrace_attributes *attr;
    uint32_t dropped_attr_count;
    uint32_t flags;
    struct cfl_list _head;
};
struct ctrace_link *ctr_link_create(struct ctrace_span *span,
                                    void *trace_id_buf, size_t trace_id_len,
                                    void *span_id_buf, size_t span_id_len);
struct ctrace_link *ctr_link_create_with_cid(struct ctrace_span *span,
                                             struct ctrace_id *trace_id_cid,
                struct ctrace_id *span_id_cid);
int ctr_link_set_trace_state(struct ctrace_link *link, char *trace_state);
int ctr_link_set_attributes(struct ctrace_link *link, struct ctrace_attributes *attr);
void ctr_link_set_dropped_attr_count(struct ctrace_link *link, uint32_t count);
void ctr_link_set_flags(struct ctrace_link *link, uint32_t flags);
void ctr_link_destroy(struct ctrace_link *link);
struct ctrace_attributes {
    struct cfl_kvlist *kv;
};
struct ctrace_attributes *ctr_attributes_create();
void ctr_attributes_destroy(struct ctrace_attributes *attr);
int ctr_attributes_count(struct ctrace_attributes *attr);
int ctr_attributes_set_string(struct ctrace_attributes *attr, char *key, char *value);
int ctr_attributes_set_bool(struct ctrace_attributes *attr, char *key, int b);
int ctr_attributes_set_int64(struct ctrace_attributes *attr, char *key, int64_t value);
int ctr_attributes_set_double(struct ctrace_attributes *attr, char *key, double value);
int ctr_attributes_set_array(struct ctrace_attributes *attr, char *key,
                             struct cfl_array *value);
int ctr_attributes_set_kvlist(struct ctrace_attributes *attr, char *key,
                              struct cfl_kvlist *value);
void ctr_log_print(void *ctx, int level, const char *file, int line,
                     const char *fmt, ...);
int ctr_errno_print(int errnum, const char *file, int line);

cfl_sds_t ctr_encode_text_create(struct ctrace *ctx);
void ctr_encode_text_destroy(cfl_sds_t text);

int ctr_encode_msgpack_create(struct ctrace *ctx, char **out_buf, size_t *out_size);
void ctr_encode_msgpack_destroy(char *buf);

cfl_sds_t ctr_encode_opentelemetry_create(struct ctrace *ctr);
void ctr_encode_opentelemetry_destroy(cfl_sds_t text);
typedef enum {
    CTR_OPENTELEMETRY_TYPE_ATTRIBUTE = 0,
    CTR_OPENTELEMETRY_TYPE_ARRAY = 1,
    CTR_OPENTELEMETRY_TYPE_KVLIST = 2,
} opentelemetry_decode_value_type;
struct opentelemetry_decode_value {
    opentelemetry_decode_value_type type;
    union {
        struct ctrace_attributes *ctr_attr;
        struct cfl_array *cfl_arr;
        struct cfl_kvlist *cfl_kvlist;
    };
};
int ctr_decode_opentelemetry_create(struct ctrace **out_ctr, char *in_buf, size_t in_size,
                                    size_t *offset);
void ctr_decode_opentelemetry_destroy(struct ctrace *ctr);
struct ctrace_resource *ctr_resource_create()
{
    struct ctrace_resource *res;
    struct ctrace_attributes *attr;
    res = calloc(1, sizeof(struct ctrace_resource));
    if (!res) {
        ctr_errno_print((*__errno_location ()), "<stdin>", 30);
        return ((void*)0);
    }
    attr = ctr_attributes_create();
    if (!attr) {
        ctr_resource_destroy(res);
        return ((void*)0);
    }
    res->attr = attr;
    return res;
}
struct ctrace_resource *ctr_resource_create_default()
{
    struct ctrace_resource *res;
    res = ctr_resource_create();
    if (!res) {
        return ((void*)0);
    }
    ctr_attributes_set_string(res->attr, "service.name", "Fluent Bit");
    ctr_attributes_set_int64(res->attr, "release_year", 2014);
    return res;
}
int ctr_resource_set_attributes(struct ctrace_resource *res, struct ctrace_attributes *attr)
{
    if (!attr) {
        return -1;
    }
    if (res->attr) {
        ctr_attributes_destroy(res->attr);
    }
    res->attr = attr;
    return 0;
}
void ctr_resource_set_dropped_attr_count(struct ctrace_resource *res, uint32_t count)
{
    res->dropped_attr_count = count;
}
void ctr_resource_destroy(struct ctrace_resource *res)
{
    if (res->attr) {
        ctr_attributes_destroy(res->attr);
    }
    free(res);
}
struct ctrace_resource_span *ctr_resource_span_create(struct ctrace *ctx)
{
    struct ctrace_resource_span *resource_span;
    resource_span = calloc(1, sizeof(struct ctrace_resource_span));
    if (!resource_span) {
        ctr_errno_print((*__errno_location ()), "<stdin>", 99);
        return ((void*)0);
    }
    cfl_list_init(&resource_span->scope_spans);
    cfl_list_add(&resource_span->_head, &ctx->resource_spans);
    resource_span->resource = ctr_resource_create();
    if (!resource_span->resource) {
        free(resource_span);
        return ((void*)0);
    }
    return resource_span;
}
struct ctrace_resource *ctr_resource_span_get_resource(struct ctrace_resource_span *resource_span)
{
    return resource_span->resource;
}
int ctr_resource_span_set_schema_url(struct ctrace_resource_span *resource_span, char *url)
{
    if (resource_span->schema_url) {
        cfl_sds_destroy(resource_span->schema_url);
    }
    resource_span->schema_url = cfl_sds_create(url);
    if (!resource_span->schema_url) {
        return -1;
    }
    return 0;
}
void ctr_resource_span_destroy(struct ctrace_resource_span *resource_span)
{
    struct cfl_list *tmp;
    struct cfl_list *head;
    struct ctrace_scope_span *scope_span;
    if (resource_span->resource) {
        ctr_resource_destroy(resource_span->resource);
    }
    if (resource_span->schema_url) {
        cfl_sds_destroy(resource_span->schema_url);
    }
    for (head = (&resource_span->scope_spans)->next, tmp = head->next; head != (&resource_span->scope_spans); head = tmp, tmp = head->next) {
        scope_span = ({ const typeof( ((struct ctrace_scope_span *)0)->_head ) *__mptr = (head); (struct ctrace_scope_span *)( (char *)__mptr - __builtin_offsetof(struct ctrace_scope_span, _head) );});
        ctr_scope_span_destroy(scope_span);
    }
    free(resource_span);
}
